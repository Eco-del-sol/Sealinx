./sealinx-phy-layer -i 2 & 
./sealinx-mac-layer -i 2 & 
./sealinx-net-layer -i 2 -m 1 & 
./sealinx-tra-layer -i 2 -n 1 -m 1 & 
./sealinx-app-layer -i 2 -t 1 -n 1 -m 1 & 
