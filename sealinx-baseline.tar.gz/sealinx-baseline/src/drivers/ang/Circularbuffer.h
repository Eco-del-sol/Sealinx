/*
*CopyRight Reserved: 智慧海洋
* Filename:          CircularBuffer.h
* Description:      循环缓冲区接收数据头文件
* Date:             2017.07.04
* Author:           Lxt
*/
#ifndef _CIRCULARBUFFER_H_
#define _CIRCULARBUFFER_H_

typedef struct CIRCULARBUFFER {
	int head;
	int tail;
	int maxLen;
	char buf[0];
} CircularBuffer;

CircularBuffer *CircularBuffer_create(int maxLen);

void CircularBuffer_delete(CircularBuffer * cirbuf);

#define CircularBuffer_getMaxLen(cbuf)		((cbuf)->maxLen)

#define CircularBuffer_getPhyLen(cbuf)		((cbuf)->maxLen + 1)

int CircularBuffer_getLen(CircularBuffer * cbuf);

int CircularBuffer_getFreeLen(CircularBuffer * cbuf);

int CircularBuffer_append(CircularBuffer * cbuf, char *buf, int len);

#define  CircularBuffer_increasePointer(cbuf, pointer, inc) ({	\
	int newP, phyLen;					\
	phyLen = CircularBuffer_getPhyLen(cbuf);		\
	newP = (pointer) + (inc);				\
	(newP >= phyLen) ? newP-phyLen : newP;			\
})

#define  CircularBuffer_decreasePointer(cbuf, pointer, dec) ({	\
	int newP, phyLen;					\
	phyLen = CircularBuffer_getPhyLen(cbuf);		\
	newP = (pointer) + phyLen - (dec);			\
	(newP >= phyLen) ? newP-phyLen : newP;			\
})

#endif
