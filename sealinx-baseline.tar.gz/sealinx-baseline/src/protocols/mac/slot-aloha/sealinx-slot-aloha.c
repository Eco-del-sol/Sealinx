/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 * Modified by haining 02/15/2015 -- to SeaLinx 1.0
 */

#include <sys/time.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <sys/un.h>
#include <err.h>
#include <sys/select.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <unistd.h>
#include <sealinx.h>

#include "sealinx-slot-aloha.h"
#include "sealinx_trace.h"

#define DEFAULT_LOG_ID "S_ALOHA"
#define DEFAULT_LOG_FOLDER "logs/"

unsigned short my_mac_addr;
unsigned short mac_broadcast_addr;

int use_jitter = 1;

sealinx_timer_t broadcast_delay_timer;
unsigned long broadcastmac_jitter_interval;

struct pkt_elem* broadcast_queue_head;

int s_aloha_pktq_len = 0;
int s_aloha_max_pktq_len = 50;

int recved_pkt = 0;
int sent_pkt = 0;

/** Log identity for this module. */
char * gLogId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char * gLogFolder = DEFAULT_LOG_FOLDER;

/** File descriptor of the connection to the core. */
int g_connFd;

/** ID of the current module. */
ModuleId g_moduleId;

/** Shared data by the core module. */
CoreSharedData *g_coreSharedData;

/** ID of the shared memory by the core module. */
int g_coreSharedMemId;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 1;

/*add by yuansong*/
#define BROADCAST_NET_ADDR 99

ArpTable arpTable = NULL;

#define TX_SLOT_NUM 1
#define SLOT_LEN 5

int slot_len    = 0;
int tx_slot_num = 0;/*value:0~2*/

int getSendPktTimervalue()
{
    int left_time  = 0;
	int slot_num   = 0;
    int interval   = 0;
    int inter_slot = 0;

	time_t curtime;
	time(&curtime);

    /*computer current slot number and interval time*/
    left_time = curtime%/*SLOT_LEN*/slot_len;
    //slot_num  = (curtime/SLOT_LEN)%3;
    slot_num  = (curtime/slot_len)%3;
    if (left_time==0)
    {
    	if (slot_num)
  		    slot_num--;
		else
			slot_num = 2;
    }

    /*computer interval slot to TX chance*/
    if (slot_num==/*TX_SLOT_NUM*/tx_slot_num)
		inter_slot=2;
	else
	{
	   if ((slot_num+1)%3 == /*TX_SLOT_NUM*/tx_slot_num)
	   	inter_slot = 0;
	   else
	   	inter_slot = 1;
	}

	//interval = inter_slot*SLOT_LEN+(left_time?(SLOT_LEN-left_time):0);/*interval time to TX*/
	interval = inter_slot*slot_len+(left_time?(slot_len-left_time):0);/*interval time to TX*/

	return interval;
}

/*add by yuansong 2018-12-21*/

void hqu_schedule_send(unsigned long delay);

int load_cfgfile(const char* configFile);
/*debug compile warning, 2018-12-26*/


int main(int argc, char **argv) {
    atexit(clean_up);
    signal(SIGINT, signal_handler);

    if (!parse_arguments(argc, argv)) {
        exit(EXIT_FAILURE);
    }

    if (!init_broadcastmac())
        exit(EXIT_FAILURE);

    logInfo("Starting S_ALOHA");

    broadcast_protocol();
    return EXIT_SUCCESS;
}

void* broadcast_protocol() {
    int result = broadcast();
    if (result < 0) {
        logError("The protocol detected error, stopping here...");
    } else {
        logError("The protocol unexpectedly returned without reporting error, stopping here...");
    }
    return NULL;
}

int broadcast() {
    int recv_num = 0;
    PduBuff * pbuf;
    char recv_buf[IMSG_MAX_DATA_LENGTH];

    InternalMessageHeader dataHeader;

    while (1) {
        memset(recv_buf, 0, sizeof (recv_buf));

        recv_num = client_read(g_connFd, recv_buf, IMSG_MAX_DATA_LENGTH, &dataHeader, NULL, 0);

        if (recv_num == -1) {
            logError("Connection error");
            exit(1);
        } else if (recv_num == -2) {
            log_warning("Data was not successfully received");
        } else if (recv_num == 0) {
            logInfo("Connection closed");
            break;
        }

        pbuf = (PduBuff*) recv_buf;

        if (from_upper_layer(dataHeader)) {
            broadcastmac_tx_process(pbuf);
        } else if (from_lower_layer(dataHeader)) {
            broadcastmac_recv_process(pbuf);
            recved_pkt++;
        }
    }

    return 0;
}

int init_broadcastmac() {
    int type = 0;
    ModuleId moduleIds[NUM_LAYERS];
    moduleIds[LAYER_MAC] = g_moduleId;
    if (!init_logger(gLogFolder, gLogId, gLogFile, TRUE, moduleIds, 1)) {
        fprintf(stderr, "Unable to init the log module.");
        return FALSE;
    }

    RegistrationResponse serverResponse;

    g_connFd = client_connect(type, LAYER_MAC, moduleIds, &serverResponse, NULL, 0);

    g_coreSharedMemId = serverResponse.coreShareMemId;

    log_info("Key of shared memory by the core: %d", g_coreSharedMemId);

    g_coreSharedData = (CoreSharedData *) shmat(g_coreSharedMemId, NULL, 0);
    if (g_coreSharedData == (CoreSharedData *) - 1) {
        fprintf(stderr, "Unable to attach the shared memory: %s", strerror(errno));
        return FALSE;
    }

    logger_set_node_id(g_coreSharedData->macAddr, g_coreSharedData->netAddr);
    log_info("Mac address: %d, net address: %d",
            (int) g_coreSharedData->macAddr, (int) g_coreSharedData->netAddr);
    my_mac_addr = (int) g_coreSharedData->macAddr;

    mac_broadcast_addr = 99;
    s_aloha_pktq_len = 0;

    tx_slot_num = (my_mac_addr-1) % 3;/*add by yuansong 2018-12-26*/
	arpTable = readArpTable(ARP_FILE);/*add by yuansong 2018-12-22*/

    /*initialize broadcast_delay_timer*/
    broadcast_delay_timer.arg = NULL;
    broadcast_delay_timer.timer_call_back = broadcastmac_delay_timer_process;
    broadcast_delay_timer.timer_status = SEALINX_TIMER_IDLE;

    srandom(time(0));
    pkt_queue_init(&broadcast_queue_head);

    return TRUE;
}

void release_broadcastmac() {
    close(g_connFd);
    pkt_queue_free(broadcast_queue_head);
}

/*the packet gotten from upper layer*/
void broadcastmac_tx_process(Packet* pkt) {

	if (pkt->hdr_net.dst_addr == BROADCAST_NET_ADDR)
		pkt->hdr_mac.dst_addr = mac_broadcast_addr;
	else
		pkt->hdr_mac.dst_addr = getMac(arpTable, pkt->hdr_net.next_hop);
    pkt->hdr_mac.src_addr = my_mac_addr;
    //setting hdr_mac.mac_type is mandatory in Sealinx1.0
    pkt->hdr_mac.mac_type = g_moduleId;
    pkt->hdr_mac.hdr_len = sizeof (pkt->hdr_mac) - sizeof (pkt->hdr_mac.mac_data);

    logInfo("Node %d : Get Packet from upper layer & cache it", my_mac_addr);

    if (s_aloha_pktq_len < s_aloha_max_pktq_len) {
        if (pkt_queue_empty(broadcast_queue_head)) {
            pkt_queue_insert_pkt(pkt, broadcast_queue_head);
            s_aloha_pktq_len++;
			/* del by yuansong 2018-12-22
                    if (use_jitter)
                        schedule_send(broadcast_jitter());
                    else
                        broadcastmac_sendpkt();
                    */
            /*add by yuansong 2018-12-22*/
            if (getSendPktTimervalue())
                hqu_schedule_send(getSendPktTimervalue());
			else
				//broadcastmac_sendpkt();debug for conintue tx error.
				hqu_schedule_send(0);/* modify by yuansong for precision control*/
        } else {
            pkt_queue_insert_pkt(pkt, broadcast_queue_head);
            s_aloha_pktq_len++;
        }
    } else {
        logDrop(PKT_DATA,
                pkt->hdr_mac.src_addr,
                pkt->hdr_mac.dst_addr,
                getPktSize(pkt),
                "Packet Queue Overflow");
    }

}
/*the packet gotten from lower layer*/
void broadcastmac_recv_process(Packet* pkt) {
    char send_buf[sizeof (Packet)];
    pkt->hdr_mac.hdr_len = 0;
    /*submit the packet to upper layer*/
    memset(send_buf, 0, sizeof (Packet));
    memcpy(send_buf, pkt, sizeof (Packet));

    logReceive(PKT_DATA,
            pkt->hdr_mac.src_addr,
            pkt->hdr_mac.dst_addr,
            getPktSize(pkt),
            "DATA");

	/*add by yuansong 2018-12-22*/
	if (pkt->hdr_mac.dst_addr==my_mac_addr || pkt->hdr_mac.dst_addr==mac_broadcast_addr)
	    client_send_up(g_connFd, (Packet*) send_buf, PDU_SIZE(pkt->msg_len), g_moduleId, NULL, 0);
	else
		logInfo("recv a pkt that his dest addr not local mode addr in broadcastmac_recv_process");

}

void schedule_send(unsigned long delay) {
    broadcast_delay_timer.delay_time.tv_sec = delay / MillionMicroSecond;
    broadcast_delay_timer.delay_time.tv_usec = delay % MillionMicroSecond;

    if (broadcast_delay_timer.delay_time.tv_sec == 0 &&
            broadcast_delay_timer.delay_time.tv_usec < 10000)
        broadcast_delay_timer.delay_time.tv_usec = 10000;

    sealinx_timer_start(&broadcast_delay_timer);

    logInfo("Node %d: Send Packet in %dS%dmS",
            my_mac_addr,
            broadcast_delay_timer.delay_time.tv_sec,
            broadcast_delay_timer.delay_time.tv_usec);
}


/*add by yuansong 2018-12-22*/
void hqu_schedule_send(unsigned long delay){
    /*modify by yuansong for continue tx error*/
    if (0==delay)
    {
		broadcast_delay_timer.delay_time.tv_sec  = 0;
		broadcast_delay_timer.delay_time.tv_usec = 1000;
    }
	else
	{
		broadcast_delay_timer.delay_time.tv_sec  = delay ;
        broadcast_delay_timer.delay_time.tv_usec = 0;
	}
    sealinx_timer_start(&broadcast_delay_timer);

    logInfo("Node %d: Send Packet in %dS%dmS in hqu_schedule_send",
            my_mac_addr,
            broadcast_delay_timer.delay_time.tv_sec,
            broadcast_delay_timer.delay_time.tv_usec);
}


void broadcastmac_delay_timer_process(void* arg) {

    broadcastmac_sendpkt();

    if (!pkt_queue_empty(broadcast_queue_head)) {
       /* del by yuansong 2018-12-22
           schedule_send(broadcast_jitter());
           */
       /*add by yuansong 2018-12-22*/
       sleep(1);
	   hqu_schedule_send(getSendPktTimervalue());
    }
}

void broadcastmac_sendpkt() {
    char send_buf[sizeof (Packet)];
    Packet* pkt = pkt_queue_get_pkt(broadcast_queue_head);

    logSend(PKT_DATA,
            pkt->hdr_mac.src_addr,
            pkt->hdr_mac.dst_addr,
            getPktSize(pkt),
            "DATA");

    /*submit the packet to lower layer*/
    memset(send_buf, 0, sizeof (Packet));
    memcpy(send_buf, pkt, sizeof (Packet));

    client_send_down(g_connFd, (Packet*) send_buf, PDU_SIZE(pkt->msg_len), g_moduleId, NULL, 0);

    free(pkt);
    pkt_queue_deque(broadcast_queue_head);

    s_aloha_pktq_len--;

	/*del by yuansong 2018-12-22
       if (!use_jitter && !pkt_queue_empty(broadcast_queue_head)) {
           broadcastmac_sendpkt(broadcast_jitter());
       }
       */
}

double uniform_0_1() {
    return (random() % 1000) / 1000.0;
}

unsigned long broadcast_jitter() {
    return (unsigned long) (broadcastmac_jitter_interval * uniform_0_1());
}

int parse_arguments(int argc, char ** argv) {
    int i = 0;
    int code_readcfg = -1;
    while (i < argc) {
        char * t = argv[i];
        if (strcmp(t, "-i") == 0) {
            i++;
            if (i < argc) {
                int moduleId = strtol(argv[i], NULL, 10);
                if (moduleId > MAX_MODULE_ID || moduleId < MIN_MODULE_ID) {
                    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
                    return FALSE;
                }
                g_moduleId = moduleId;
            }
        } else if (strcmp(t, "-c") == 0) {
            i++;
            if (i < argc) {
                code_readcfg = load_cfgfile(argv[i]);
            }
        } else if (strcmp(t, "-f") == 0) {
	    i ++;
	    if (i < argc) {
		gLogFile = atoi(argv[i]);
	    }
	}
        i++;
    }
    return g_moduleId <= MAX_MODULE_ID && g_moduleId >= MIN_MODULE_ID && (!code_readcfg);
}

/**
 * * Print the usage of the program.
 * */
void print_usage(const char *progName) {
    printf("USAGE: %s -c <config file> [-f <log file outoput flag>]\n", progName);
}

/**
 * * Signal handler.
 * *
 * * @param sig Signal ID.
 * */
void signal_handler(int sig) {
    int type = 0;
    log_info("Received signal (%d)", sig);

    if (g_connFd > -1) {
        client_close(type, g_connFd, NULL, 0);
        g_connFd = -1;
    }
}

/**
 * * Clean up allocated resources.
 * */
void clean_up(void) {
    int type = 0;
    log_info("Cleaning up ...");

    if (g_connFd > -1) {
        client_close(type, g_connFd, NULL, 0);
    }

    int rc = shmdt(g_coreSharedData);
    if (rc == -1) {
        log_error("Unable to detach shared data: %s", strerror(errno));
    }

    logInfo("Stopping S_ALOHA");
    release_broadcastmac();
    close_logger();
}

int load_cfgfile(const char* configFile) {
    char* token;
    char local_buff[sizeof (struct pdu_buff)];

    /*get the parameters of s_aloha*/
    FILE* s_aloha_cfg = fopen(configFile, "r");
    if (!s_aloha_cfg) {
        logError("Fail to find the configuration file of S_ALOHA");
        exit(EXIT_FAILURE);
    }
    memset(local_buff, 0, sizeof (local_buff));
    while (fgets(local_buff, sizeof (local_buff), s_aloha_cfg)) {
        if (NULL == (token = strtok(local_buff, " :"))) {
            logError("Wrong configration file format! The format should be\n Jitter_Interval : Max_Queue_Len");
            exit(1);
        }
        if (*token == '#') continue;
        //broadcastmac_jitter_interval = atoi(token);
        broadcastmac_jitter_interval = 20000;
		slot_len = atoi(token);

        if (NULL == (token = strtok(NULL, " :"))) {
            logError("Wrong configration file format! The format should be\n Jitter_Interval : Max_Queue_Len");
            exit(1);
        }
        //s_aloha_max_pktq_len = atoi(token);
        s_aloha_max_pktq_len = 50;
		tx_slot_num = atoi(token);

        break;
    }
    logInfo("Jitter_Interval: %d, Max_Queue_Len: %d", broadcastmac_jitter_interval, s_aloha_max_pktq_len);
    if (broadcastmac_jitter_interval < 100000)
        use_jitter = 0;
    else
        use_jitter = 1;
    fclose(s_aloha_cfg);
    return 0;
}
