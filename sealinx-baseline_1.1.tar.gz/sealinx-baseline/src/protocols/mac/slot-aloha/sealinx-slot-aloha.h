/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 * Modified by haining 02/15/2015 -- to SeaLinx 1.0
 */

#ifndef __SEALINX_BCMAC_H__
#define __SEALINX_BCMAC_H__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/un.h>
#include <unistd.h>
#include <err.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>
#include <sys/shm.h>

#include <sealinx.h>
#include "sealinx_pktq.h"
#include "sealinx_timer.h"
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>

extern unsigned short mac_broadcast_addr;

extern unsigned short my_mac_addr;

extern unsigned long broadcastmac_jitter_interval;

extern sealinx_timer_t broadcast_delay_timer;

extern struct pkt_elem* broadcast_queue_head;

int broadcast();
void* broadcast_protocol();

int init_broadcastmac();
void release_broadcastmac();

void broadcastmac_tx_process(Packet* pkt);

void broadcastmac_recv_process(Packet* pkt);

double uniform_0_1();
unsigned long broadcast_jitter();

void schedule_send(unsigned long delay);

void broadcastmac_delay_timer_process(void* arg);

/*send the first packet in the queue*/
void broadcastmac_sendpkt();

int parse_arguments(int argc, char** argv);
void print_usage(const char*progName);
void signal_handler(int sig);
void clean_up(void);

#endif

