/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * Internal message definitions.
 *
 * @author son.
 */

#ifndef __SEALINX_IMSG_H__
#define __SEALINX_IMSG_H__

#include <sealinx_system.h>

/**
 * This message allows a module to register itself with the core.
 * This messages must be sent to the core right after the connection 
 * is established.
 */
typedef struct {
    /**
     * The layer on which the module is operating.
     */
	LayerId layerId;

    /**
     * ID of the module to distinguish itself with the other modules
     * on the same layer.
     */
	ModuleId moduleIds[NUM_LAYERS];
} __attribute__ ((packed)) ModuleRegistration;

/**
 * This message is the response of the server to a client registration.
 */
typedef struct {
    /**
     * The key to access shared memory by the core.
     */
	int coreShareMemId;
} __attribute__ ((packed)) RegistrationResponse;

/**
 * Type of an internal message.
 */
typedef uint8_t InternalMessageType;

/**
 * Type of an internal message: Data message.
 */
#define IMSG_TYPE_DATA 0x01

/**
 * Type of an internal message: Control message.
 */
#define IMSG_TYPE_CONTROL 0x02

/**
 * Direction of an internal message.
 */
typedef int8_t InternalMessageDirection;

/**
 * Check if a message is from the upper layer.
 *
 * @param header The message header.
 */
#define from_upper_layer(header) ((header).direction == IMSG_DIRECTION_DOWN)

/**
 * Check if a message is from the lower layer.
 *
 * @param header The message header.
 */
#define from_lower_layer(x) ((x).direction == IMSG_DIRECTION_UP)

/**
 * Direction of an internal message: to the immediate upper layer.
 */
#define IMSG_DIRECTION_UP 1

/**
 * Direction of an internal message: to the immediate lower layer.
 */
#define IMSG_DIRECTION_DOWN -1

/**
 * Length of an internal message.
 */
typedef uint16_t InternalMessageLength;

/**
 * Maximum data length.
 */
//#define IMSG_MAX_DATA_LENGTH 5120
#define IMSG_MAX_DATA_LENGTH (1024*13)

/**
 * Common header format of internal messages (those that are 
 * sent/received inside the stack.
 */
typedef struct {
    /**
     * Type of the message.
     */
	InternalMessageType type;

    /**
     * direction of the message.
     */
	InternalMessageDirection direction;

    /**
     * Length of the following data.
     */
	InternalMessageLength dataLength;

    /**
     * ID of the module to that the message is going to be dispatched.
     */
	ModuleId moduleId;
} __attribute__ ((packed)) InternalMessageHeader;

typedef struct {
	InternalMessageHeader header;
	char buffer[IMSG_MAX_DATA_LENGTH];
} SealinxPacketStruct;

/**
 * This message is the socket number.
 */
typedef struct {
    /**
     * Socket number.
     */
	int number;
} __attribute__ ((packed)) SocketNUM;

#ifdef __cplusplus
extern "C" {
#endif				/* __cplusplus */

/**
 * Verify an internal message header.
 * 
 * @param imh The header.
 * @return TRUE if the header is valid; FALSE, otherwise.
 */
	int verify_internal_message_header(InternalMessageHeader * imh);

	int get_port_num(int macId, int netId, int attempt);
	int hash(int key);
/**
 * User API to connect to the core.
 *
 * @param type The connect type, reserved.
 * @param layerId The layer that the module is working.
 * @param moduleIds The array of IDs of module under (including) this module.
 * @param serverResponse Response from the server.
 */
	int client_connect(int type, LayerId layerId, ModuleId * moduleIds,
			   RegistrationResponse * serverResponse, char *reserve,
			   int len);

/**
 * User API to shutdown the connection to the core.
 *
 * @param type The connect type, reserved.
 * @param connFd The file descriptor of the connection to the core.
 * @param how The parameter for the shutdown process.
 */
	int client_close(int type, int connFd, char *reserve, int len);

 /**
 * Connect a module to the core.
 *
 * @param host The host that the core reside.
 * @param port The port that the core is listening on.
 * @param layerId The layer that the module is working.
 * @param moduleIds The array of IDs of module under (including) this module.
 * @param serverResponse Response from the server.
 * @return socket file descriptor if the operation is successful; 
 * -1, otherwise.
 */
	int connect_to_core(const char *host, int port,
			    LayerId layerId, ModuleId * moduleIds,
			    RegistrationResponse * serverResponse);

/**
 * Read from the core module.
 *
 * @param connectid Socket to the core module.
 * @param outData The buffer holding output data.
 * @param maxSizeData The maximum size that outData can afford.
 * @param dataHeader Header of the data. If NULL is passed into 
 * this function, the header is not returned through this parameter.
 * @retval > 0 Size of the received data if it is successfully read.
 * @retval 0 if the socket is orderly closed by the core module.
 * @retval -2 if the data is not complete or the received data is
 * larger than the buffer.
 * @retval -1 if a system error occurs.
 */
	int client_read(int connectid, void *outData, int maxSizeData,
			InternalMessageHeader * dataHeader, char *reserve,
			int len);

/**
 * Send data to the lower layer.
 *
 * @param connectid Socket to the core module.
 * @param data The buffer holding data to be sent.
 * @param dataLength Length of the data.
 * @param src The source module.
 * @return same as those of send_to_core.
 */
	int client_send_down(int connectid, void *data, int dataLength,
			     ModuleId src, char *reserve, int len);

/**
 * Send data to the upper layer.
 *
 * @param connectid Socket to the core module.
 * @param data The buffer holding data to be sent.
 * @param dataLength Length of the data.
 * @param src The source module.
 * @return same as those of send_to_core.
 */
	int client_send_up(int connectid, void *data, int dataLength,
			   ModuleId src, char *reserve, int len);

/**
 * Creat the common shared memory to store socket number.
 *
 */
	int init_common_shared_memory(void);

/**
 * Write to the core module.
 *
 * @param connectid Socket to the core module.
 * @param data The buffer holding data to be sent.
 * @param dataHeader Header of the data.
 * @retval non-negative Size of the byte written to the core.
 * @retval -2 if the data or its header is not complete.
 * @retval -1 if a system error occurs.
 */
	int send_to_core(int connectid, void *data, InternalMessageHeader * dataHeader,
                 char *reserve, int len);

#ifdef __cplusplus
}
#endif				/* __cplusplus */
#endif				/* __SEALINX_IMSG_H__ */
