/**
 * @file sealinx_serial.h
 * @copyright Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT
 * LLC.  All rights reserved. Proprietary property of AquaSeNT LLC.
 * @author james
 */

#ifndef __SEALINX_SERIAL_H__
#define __SEALINX_SERIAL_H__

#define SERIAL_CONFIG_FILE	"config_ser.cfg"
#define SERIAL_BUFFER_SIZE	2048
#define SERIAL_TIMEOUT	1
#define ARRAY_LEN(x)	(sizeof(x) / sizeof(x[0]))
#define NAME_LENGTH 256
#define NMEA_BUFFER_SIZE (1024*2)

#define serial_open _rm_serial_open
#define serial_close _rm_serial_close
#define serial_read _rm_serial_read
#define serial_write _rm_serial_write

#ifdef	__cplusplus
extern "C" {
#endif
	/* Open the serial port, return the file descriptor */
	int _rm_serial_open(void);
	/* Close the serial port indicated by @fd */
	void _rm_serial_close(int fd);
	/* Read from the serial port
	 * Store the received data into a @buffer with @len bytes
	 * Return the number of bytes read from serial port
	 * Return -1 on errors */
	int _rm_serial_read(int fd, char *buffer, int len);
	/* Write @len bytes data in @buffer to serial port
	 * Return the number of bytes written to serial port
	 * or -1 on errors */
	int _rm_serial_write(int fd, char *buffer, int len);
#ifdef	__cplusplus
}
#endif
#endif
