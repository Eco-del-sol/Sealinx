/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author son
 */

#ifndef __SEALINX_SERIAL_VM_H__
#define __SEALINX_SERIAL_VM_H__

#define SERIAL_CONFIG_FILE	"config_ser.cfg"
#define SERIAL_BUFFER_SIZE	2048
#define SERIAL_TIMEOUT	1
#define ARRAY_LEN(x)	(sizeof(x) / sizeof(x[0]))
#define NAME_LENGTH 256
#define NMEA_BUFFER_SIZE (1024*2)

extern char log_name[NAME_LENGTH];

#define BUFFER_SIZE (1024*2)

#define TYPE_INIT 1
#define TYPE_DATA 2

//extern int modem_addr_local;

typedef struct {
	unsigned char type;
	unsigned char from;
	unsigned short len;
} __attribute__ ((__packed__)) PacketHeader;

typedef struct {
	unsigned char modemId;
	double posX;
	double posY;
	double posZ;
} __attribute__ ((__packed__)) InitPacket;

#define serial_open _vm_serial_open
#define serial_close _vm_serial_close
#define serial_read _vm_serial_read
#define serial_write _vm_serial_write

#ifdef	__cplusplus
extern "C" {
#endif
	//void advertise(int sockfd, int modemId, double x, double y, double z);

	//int internalModemSend(int sockfd, PacketHeader *header, char *data);

	int _vm_serial_write(int sockfd, char *data, int dataLen);

	int _vm_serial_read(int sockfd, char *data, int dataLen);

	int _vm_serial_open(char *svrAddr, int svrPort, int modemId,
			    double x, double y, double z);

	void _vm_serial_close(int sockfd);

#ifdef	__cplusplus
}
#endif
#endif
