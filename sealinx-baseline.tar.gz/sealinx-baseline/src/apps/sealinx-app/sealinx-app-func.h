#ifndef _SEALINX_APP_FUNC_H
#define _SEALINX_APP_FUNC_H

#include <stdio.h>
#include <signal.h>
#include <math.h>
#include <pthread.h>
#include <stdlib.h>
#include <glib.h>
#include <sys/time.h>
#include <sys/un.h>
#include <err.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <errno.h>
#include <sys/shm.h>
#include <sys/select.h>
#include <stdint.h>
#include <sealinx_trace.h>
#include "sealinx_shmem.h"
#include "sealinx_imsg.h"
#include "sealinx_pktq.h"
#include "sealinx_timer.h"
#include "sealinx_serial.h"
#include <sealinx_system.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>
#include <sealinx_common.h>
#include <sealinx.h>
#include <sealinx_pktq.h>
#include <sealinx_timer.h>
#include <modem_info.h>

#include "sealinx_mfifo.h"
#include "sealinx_serial_app.h"
#include "sealinx_utils.h"



#define PDU_DATA_LEN   		4096
#define MAX_BUFF_LEN		1024*128*2
#define MAX_PATH_STR_LEN	120
#define MAX_MFIFO_LEN 		1024*512
#define MAX_SER_LEN			1024*512
#define MAX_SOCKET_LEN 		1024*512


#define LOG_DISPLAY(fmt, ... )    printf("[%s][ %s ][ %d ][ %s ] ["fmt"]\n",time_display_locate(),DEFAULT_LOG_ID,__LINE__,__FUNCTION__,##__VA_ARGS__)
#define LOG_LINE_FUNCTION()       printf("[%s][ %s ][ %d ][ %s ]\n",time_display_locate(),DEFAULT_LOG_ID,__LINE__,__FUNCTION__)

#define HEX(a) (((a) < 10) ? (a) + '0' : (a)-10 + 'A')


int8_t * time_display_locate(void);

void *process_recv_from_serial(void *param);

void *process_recv_from_down(void *param);

void *process_send(void *param);



#endif /* _SEALINX_APP_FUNC_H */


