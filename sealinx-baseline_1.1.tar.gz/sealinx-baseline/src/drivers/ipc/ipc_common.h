#ifndef IPC_COMMON_H
#define IPC_COMMON_H

#ifdef __cplusplus
extern "C" {
#endif

#include <sealinx_pdu.h>
#include <modem_info.h>

#define IpcMain_LogInfor_Len 300

typedef enum {
    FromCore = 0,
    FromModem,
} PrintType;

int ipcCommon_pduToAcio(PduBuff *pdu, char *acio, int *len, Modem_Phy_Params *phy);
int ipcCommon_acioToPdu(char *acio, int len, Modem_Phy_Params *phy, float effsnr, PduBuff *pdu);
void ipcCommon_printPdu(PduBuff *pdu, PrintType type);
void ipcCommon_printAcio(char *acio, Modem_Phy_Params *phy, PrintType type);

#ifdef __cplusplus
}
#endif

#endif
