/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author son
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <errno.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/stat.h>

#include "sealinx_log.h"
#include "sealinx_imsg.h"
#include "sealinx_common.h"
#include <sealinx_shmem.h>

/** Common shared data with other components. */
CommonSharedData *g_comSharedData;
/**
 * Verify an internal message header.
 *
 * @param imh The header.
 * @return TRUE if the header is valid; FALSE, otherwise.
 */
int verify_internal_message_header(InternalMessageHeader * imh)
{
	if (imh->direction != IMSG_DIRECTION_UP
	    && imh->direction != IMSG_DIRECTION_DOWN) {
		log_error("Invalid data direction (%d)", (int)imh->direction);
		return FALSE;
	}
	if (imh->type != IMSG_TYPE_DATA && imh->type != IMSG_TYPE_CONTROL) {
		log_error("Invalid data type (%d)", (int)imh->type);
		return FALSE;
	}
	if (imh->dataLength > IMSG_MAX_DATA_LENGTH) {
		log_error("Invalid data length (%d)", (int)imh->dataLength);
		return FALSE;
	}
	if (imh->moduleId > MAX_MODULE_ID || imh->moduleId < MIN_MODULE_ID) {
		log_error("Invalid destination module ID (%d)",
			  (int)imh->moduleId);
		return FALSE;
	}
	return TRUE;
}

int get_port_num(int macId, int netId, int attempt)
{
	char temp[1 + MAX_LEN_NODE_ID];
	snprintf(temp, MAX_LEN_NODE_ID, "%d%d", macId, netId);
	int port = atoi(temp);
	log_info("nodeID: %s %d", temp, port);
	int key1 = macId % 100 + 100 * (netId % 10);
	int key2 = macId % 100 + 100 * (netId / 10 % 10);
	int key3 = macId / 10 + netId / 100;
	switch (attempt) {
	case 1:
		port = hash(key1);
		break;
	case 2:
		port = hash(key2);
		break;
	case 3:
		port = hash(key3);
		break;
	default:
		port = 10000 + 40 * (rand() % 1000);
		break;
	}
	log_info("key is: %d %d %d port is %d", key1, key2, key3, port);
	return port;
}

int hash(int key)
{
	int ans;
	ans = (key << 5) | (key >> 3);
	ans = ans & 0x3FF;
	return 10000 + 40 * ans;
}

/**
 * Creat the common shared memory to store socket number.
 *
 */
int init_common_shared_memory(void)
{
	key_t g_comShMemKey = generate_key(COMMON_SHARED_MEM_KEY);
	log_info("COMMON SHMKEY = %d \n", g_comShMemKey);
	if (g_comShMemKey == (key_t) - 1) {
//        fprintf(stderr, "Unable to generate key for shared memory\n");
		return FALSE;
	}
	int g_comShMemId = shmget(g_comShMemKey, sizeof(CommonSharedData),
				  IPC_CREAT | S_IRUSR | S_IWUSR);
	log_info("COMMON SHM = %d \n", g_comShMemId);

	if (g_comShMemId < 0) {
//        fprintf(stderr, "Unable to initialize the shared memory: %s\n",
//                strerror(errno));
		return FALSE;
	}

	g_comSharedData = (CommonSharedData *) shmat(g_comShMemId, NULL, 0);
	if (g_comSharedData == (CommonSharedData *) - 1) {
//        fprintf(stderr, "Unable to attach the shared memory: %s\n",
//                strerror(errno));
		return FALSE;
	}
	return g_comShMemId;
}

/**
 * User API to connect to the core.
 *
 * @param type The connect type, reserved.
 * @param layerId The layer that the module is working.
 * @param moduleIds The array of IDs of module under (including) this module.
 * @param serverResponse Response from the server.
 */
int client_connect(int type, LayerId layerId, ModuleId * moduleIds,
		   RegistrationResponse * serverResponse, char *reserve,
		   int len)
{
	const char *host = "localhost";
	int port;
	int connectid;
	port = 0;
	int nodeID = logger_get_node_id();

	int g_comSharedMemId = init_common_shared_memory();
	log_info("common share id = %d", g_comSharedMemId);
	port = g_comSharedData->skt_num;
//    log_info("socket: %d",port);
	connectid =
	    connect_to_core(host, port, layerId, moduleIds, serverResponse);
	if (connectid < 0) {
		log_error("Unable to create socket: %s", strerror(errno));
		return -1;
	}
	return connectid;
}

/**
 * User API to shutdown the connection to the core.
 *
 * @param type The connect type, reserved.
 * @param connFd The file descriptor of the connection to the core.
 * @param how The parameter for the shutdown process.
 */
int client_close(int type, int connFd, char *reserve, int len)
{
	return shutdown(connFd, SHUT_RDWR);
}

/**
 * Connect a module to the core.
 *
 * @param host The host that the core reside.
 * @param port The port that the core is listening on.
 * @param layerId The layer that the module is working.
 * @param moduleIds The array of IDs of module under (including) this module.
 * @param serverResponse Response from the server.
 * @return socket file descriptor if the operation is successful;
 * -1, otherwise.
 */
int connect_to_core(const char *host, int port,
		    LayerId layerId, ModuleId * moduleIds,
		    RegistrationResponse * serverResponse)
{
	int connectid = socket(AF_INET, SOCK_STREAM, 0);
	if (connectid < 0) {
		log_error("Unable to create socket: %s", strerror(errno));
		return -1;
	}

	struct sockaddr_in servAddr;
	struct hostent *server = gethostbyname(host);
	if (server == NULL) {
		log_error("Unable to resolve '%s'", host);
		return -1;
	}

	memset(&servAddr, 0, sizeof(servAddr));
	servAddr.sin_family = AF_INET;
	memcpy(&servAddr.sin_addr.s_addr, server->h_addr, server->h_length);
	servAddr.sin_port = htons(port);
	if (connect(connectid, (struct sockaddr *)&servAddr, sizeof(servAddr)) <
	    0) {
		log_error("Unable to connect to core: %s", strerror(errno));
		return -1;
	}

	ModuleRegistration mr;
	mr.layerId = layerId;
	if (moduleIds != NULL)
		memcpy(mr.moduleIds, moduleIds, sizeof(mr.moduleIds));

	int nBytes = send(connectid, &mr, sizeof(mr), 0);
	if (nBytes == -1) {
		log_error("Unable to send registration information core: %s",
			  strerror(errno));
		return -1;
	}

	RegistrationResponse rr;
	nBytes = recv(connectid, &rr, sizeof(rr), 0);
	if (nBytes == -1) {
		log_error("Unable to receive response from core: %s",
			  strerror(errno));
		return -1;
	}
	if (serverResponse != NULL)
		memcpy(serverResponse, &rr, sizeof(rr));

	return connectid;
}

/**
 * Read from the core module.
 *
 * @param connectid Socket to the core module.
 * @param outData The buffer holding output data.
 * @param maxSizeData The maximum size that outData can afford.
 * @param dataHeader Header of the data. If NULL is passed into
 * this function, the header is not returned through this parameter.
 * @retval > 0 Size of the received data if it is successfully read.
 * @retval 0 if the socket is orderly closed by the core module.
 * @retval -2 if the data is not complete or the received data is
 * larger than the buffer.
 * @retval -1 if a system error occurs.
 */
int client_read(int connectid, void *outData, int maxSizeData,
		InternalMessageHeader * dataHeader, char *reserve, int len)
{
	InternalMessageHeader imh;

	int nBytesRead =
	    recv(connectid, &imh, sizeof(InternalMessageHeader), 0);
	if (nBytesRead == -1) {
		log_error("Unable to read message header: %s", strerror(errno));
		return -1;
	}
	if (nBytesRead == 0)
		return 0;

	if (nBytesRead < sizeof(InternalMessageHeader)) {
		log_error("Error while reading message header "
			  "(%d bytes received vs %d bytes expected)",
			  nBytesRead, sizeof(InternalMessageHeader));
		return -2;
	}
	if (imh.dataLength > maxSizeData) {
		log_error("Size of buffer is smaller than received data "
			  "(%d vs %d)", maxSizeData, imh.dataLength);
		int l = imh.dataLength;
		while (l > 0) {
			nBytesRead = recv(connectid, outData, maxSizeData, 0);
			if (nBytesRead == -1) {
				log_error("Unable to read data: %s",
					  strerror(errno));
				return -1;
			} else if (nBytesRead == 0) {
				return 0;
			}
			l -= maxSizeData;
		}
		return -2;
	}
	nBytesRead = recv(connectid, outData, imh.dataLength, 0);
	if (nBytesRead == -1) {
		log_error("Unable to read data: %s", strerror(errno));
		return -1;
	}

	if (nBytesRead == 0)
		return 0;

	if (nBytesRead < imh.dataLength) {
		log_error("Data is not complete (%d received vs %d expected)",
			  nBytesRead, imh.dataLength);
		return -2;
	}
	if (dataHeader != NULL)
		memcpy(dataHeader, &imh, sizeof(InternalMessageHeader));

	return nBytesRead;
}

/**
 * Write to the core module.
 *
 * @param connectid Socket to the core module.
 * @param data The buffer holding data to be sent.
 * @param dataHeader Header of the data.
 * @retval non-negative Size of the byte written to the core.
 * @retval -2 if the data or its header is not complete.
 * @retval -1 if a system error occurs.
 */
int send_to_core(int connectid, void *data, InternalMessageHeader * dataHeader,
		 char *reserve, int len)
{
	int nBytesWritten =
	    send(connectid, dataHeader, sizeof(InternalMessageHeader), 0);
	if (nBytesWritten == -1) {
		log_error("Unable to send message header: %s", strerror(errno));
		return -1;
	}
	if (nBytesWritten < sizeof(InternalMessageHeader)) {
		log_error("Error while writing message header "
			  "(%d bytes received vs %d bytes expected)",
			  nBytesWritten, sizeof(InternalMessageHeader));
		return -2;
	}
	nBytesWritten = send(connectid, data, dataHeader->dataLength, 0);
	if (nBytesWritten == -1) {
		log_error("Unable to write data: %s", strerror(errno));
		return -1;
	}
	if (nBytesWritten < dataHeader->dataLength) {
		log_error
		    ("Data is not fully written (%d received vs %d expected)",
		     nBytesWritten, dataHeader->dataLength);
		return -2;
	}
	return nBytesWritten;
}

/**
 * Send data to the lower layer.
 *
 * @param connectid Socket to the core module.
 * @param data The buffer holding data to be sent.
 * @param dataLength Length of the data.
 * @param src The source module.
 * @return same as those of send_to_core.
 */
int client_send_down(int connectid, void *data, int dataLength, ModuleId src,
		     char *reserve, int len)
{
	InternalMessageHeader imh;
	imh.type = IMSG_TYPE_DATA;
	imh.dataLength = dataLength;
	imh.direction = IMSG_DIRECTION_DOWN;
	imh.moduleId = src;

	return send_to_core(connectid, data, &imh, NULL, 0);
}

/**
 * Send data to the upper layer.
 *
 * @param connectid Socket to the core module.
 * @param data The buffer holding data to be sent.
 * @param dataLength Length of the data.
 * @param src The source module.
 * @return same as those of send_to_core.
 */
int client_send_up(int connectid, void *data, int dataLength, ModuleId src,
		   char *reserve, int len)
{
	InternalMessageHeader imh;
	imh.type = IMSG_TYPE_DATA;
	imh.dataLength = dataLength;
	imh.direction = IMSG_DIRECTION_UP;
	imh.moduleId = src;

	return send_to_core(connectid, data, &imh, NULL, 0);
}
