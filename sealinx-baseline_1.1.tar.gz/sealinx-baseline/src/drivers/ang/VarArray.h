#ifndef _VAR_ARRAY_H_
#define _VAR_ARRAY_H_

#define VAR_ARRAY_SECTION_LEN	100

#include "List.h"

typedef struct VAR_ARRAY {
	ListHead node;
	int pos;
	char data[0];
} VarArray;

VarArray *VarArray_create();

void VarArray_delete(VarArray * va);

int VarArray_getLen(VarArray * va);

/*
 * @param: offset: negative numbers means counting from the end
 */
int VarArray_write(VarArray * va, const char *buf, int len, int offset);

int VarArray_read(VarArray * va, char *buf, int len, int offset);

#define VarArray_append(va, buf, len)	VarArray_write(va, buf, len, -1)

#endif /* _VAR_ARRAY_H_ */
