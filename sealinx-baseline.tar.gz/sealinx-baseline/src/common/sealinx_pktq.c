/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author yibo
 */

#include <string.h>
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>

#include "sealinx_pktq.h"

pthread_mutex_t pkt_queue_mutex = PTHREAD_MUTEX_INITIALIZER;

void pkt_queue_init(struct pkt_elem **head)
{
	*head = (struct pkt_elem *)malloc(sizeof(struct pkt_elem));
	if (*head == NULL) {
		fprintf(stderr, "Memory allocation fails\n");
		exit(0);
	}
	(*head)->next = NULL;
	(*head)->pkt = NULL;
}

void pkt_queue_insert_pkt(Packet * pkt, struct pkt_elem *head)
{
	struct pkt_elem *pos = head;
	Packet *tmp_pkt = (Packet *) malloc(sizeof(Packet));
	if (tmp_pkt == NULL) {
		fprintf(stderr, "Memory allocation fails\n");
		exit(0);
	}
	memset(tmp_pkt, 0, sizeof(Packet));
	memcpy(tmp_pkt, pkt, sizeof(Packet));

	pthread_mutex_lock(&pkt_queue_mutex);

	struct pkt_elem *tmp =
	    (struct pkt_elem *)malloc(sizeof(struct pkt_elem));
	if (tmp == NULL) {
		fprintf(stderr, "Memory allocation fails\n");
		exit(0);
	}
	tmp->next = NULL;
	tmp->pkt = tmp_pkt;

	while (pos->next != NULL) {
		pos = pos->next;
	}

	pos->next = tmp;

	pthread_mutex_unlock(&pkt_queue_mutex);
}

int pkt_queue_getLen (struct pkt_elem *head)
{
    int qLen = 0;
    
    struct pkt_elem *tmp = NULL;
	struct pkt_elem *pos = head->next;

	pthread_mutex_lock(&pkt_queue_mutex);
	while (pos != NULL) {
		tmp = pos;
		pos = pos->next;
		qLen = qLen + 1;
	}
	pthread_mutex_unlock(&pkt_queue_mutex);
	
	return qLen;
}

Packet *pkt_queue_get_pkt(struct pkt_elem *head)
{
	Packet *pkt = NULL;
	struct pkt_elem *tmp = NULL;

	pthread_mutex_lock(&pkt_queue_mutex);

	pkt = (Packet *) malloc(sizeof(Packet));
	if (pkt == NULL) {
		fprintf(stderr, "Memory allocation fails\n");
		exit(0);
	}
	if (head->next != NULL) {
		tmp = head->next;

		memset(pkt, 0, sizeof(Packet));
		memcpy(pkt, tmp->pkt, sizeof(Packet));
	}

	pthread_mutex_unlock(&pkt_queue_mutex);

	return pkt;
}

void pkt_queue_deque(struct pkt_elem *head)
{
	struct pkt_elem *tmp = NULL;

	pthread_mutex_lock(&pkt_queue_mutex);

	if (head->next != NULL) {
		tmp = head->next;
		head->next = tmp->next;

		free(tmp->pkt);
		free(tmp);
	}

	pthread_mutex_unlock(&pkt_queue_mutex);
}

void pkt_queue_free(struct pkt_elem *head)
{
	struct pkt_elem *tmp = NULL;
	struct pkt_elem *pos = head->next;

	pthread_mutex_lock(&pkt_queue_mutex);

	while (pos != NULL) {
		tmp = pos;
		pos = pos->next;
		free(tmp->pkt);
		free(tmp);
	}

	free(head);

	pthread_mutex_unlock(&pkt_queue_mutex);
}

int pkt_queue_empty(struct pkt_elem *head)
{
	int is_empty = 1;

	pthread_mutex_lock(&pkt_queue_mutex);

	if (head->next != NULL)
		is_empty = 0;

	pthread_mutex_unlock(&pkt_queue_mutex);

	return is_empty;
}

unsigned short pkt_queue_get_mac_recver_addr(struct pkt_elem *head)
{
	unsigned short recver_addr = 0;

	pthread_mutex_lock(&pkt_queue_mutex);

	if (head->next != NULL) {
		recver_addr = head->next->pkt->hdr_mac.dst_addr;
	}

	pthread_mutex_unlock(&pkt_queue_mutex);

	return recver_addr;
}

unsigned short pkt_queue_get_net_recver_addr(struct pkt_elem *head)
{
	unsigned short recver_addr = 0;

	pthread_mutex_lock(&pkt_queue_mutex);

	if (head->next != NULL) {
		recver_addr = head->next->pkt->hdr_net.dst_addr;
	}

	pthread_mutex_unlock(&pkt_queue_mutex);

	return recver_addr;
}

void pkt_queue_get_pktburst(struct SentPktSet *pktset, int max_burst,
			    struct pkt_elem *head)
{
	pktset->burst = 0;
	unsigned short recver_addr;
	struct pkt_elem *pos;

	pthread_mutex_lock(&pkt_queue_mutex);

	pos = head->next;

	if (pos != NULL) {
		recver_addr = pos->pkt->hdr_mac.dst_addr;
	}

	while (pos != NULL && pktset->burst < max_burst) {
		if (recver_addr == pos->pkt->hdr_mac.dst_addr) {
			pktset->pkts[pktset->burst] = pos->pkt;
			pktset->burst++;
		}
		pos = pos->next;
	}

	pthread_mutex_unlock(&pkt_queue_mutex);

}

/*release packet outside this function*/
void pkt_queue_del_pkt(struct pkt_elem *head, Packet * pkt)
{
	struct pkt_elem *pos = head->next;
	struct pkt_elem *pre_pos = head;

	pthread_mutex_lock(&pkt_queue_mutex);

	while (pos != NULL) {
		if (pos->pkt == pkt) {
			pre_pos->next = pos->next;
			free(pos->pkt);
			free(pos);
			break;
		}

		pos = pos->next;
		pre_pos = pre_pos->next;
	}

	pthread_mutex_unlock(&pkt_queue_mutex);

}
