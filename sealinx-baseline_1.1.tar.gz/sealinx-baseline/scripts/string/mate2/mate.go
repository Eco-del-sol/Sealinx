package main

import (
	"fmt"
	"log"
	"os"

	"mate2/adapter"
	"mate2/sim"
)

func main() {
	go adapter.Start()
	sim.Run()
}

// build info
var (
	goVersion   string
	buildTime   string
	author      string
	codeVersion string
)

func init() {
	if len(os.Args) == 2 && os.Args[1] == "-v" {
		fmt.Println(goVersion)
		fmt.Println("Build at:", buildTime)
		fmt.Println("Author:", author)
		fmt.Println("Code version:", codeVersion)
		os.Exit(0)
	}
	log.SetOutput(os.Stdout)
	log.SetFlags(log.Lmicroseconds)
	// log.SetFlags(log.Lmicroseconds | log.Lshortfile)
}
