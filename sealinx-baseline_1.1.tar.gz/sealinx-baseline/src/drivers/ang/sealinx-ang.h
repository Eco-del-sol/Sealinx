/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * OFDM modem driver.
 *
 * @author
 */

#ifndef __SEALINX_OFDM_CMD_H__
#define __SEALINX_OFDM_CMD_H__

#define DEFAULT_CONN_FILE_NAME "config_conn.cfg"

#define DEFAULT_CFG_FILE_NAME "config_ofdm.cfg"

/** ID of OFDM modem driver. */
#define OFDM_DRIVER_ID 22

/** Default log identity for this module. */
#define DEFAULT_LOG_ID "PHY_OFDM"

/** Default path to the folder consisting log files. */
#define DEFAULT_LOG_FOLDER "logs/"

typedef struct {
	unsigned char signature[2];
	unsigned short length;
	unsigned int crc;
	unsigned char data[0];
} __attribute__ ((__packed__)) PhysicalDataPacket;

/**
 * Prepares the raw data stream of a PDU to send.
 *
 * @param pdu The PDU.
 * @param sendBuffer The raw data stream buffer.
 * @return Length of the raw data stream.
 */
int serialize_pdu(PduBuff * pdu, char *sendBuffer);

/**
 * Deserializes raw data into a PDU.
 *
 * @param bp The raw data.
 * @param pdu The PDU.
 */
void deserialize_raw_data(char *bp, struct pdu_buff *pdu);
struct mdm_phy_ops {
	int (*init) (void);
	void (*close) (void);
	int (*isInitialized) (void);
	int (*run) (void);
	int (*get) (PduBuff *);
	int (*put) (PduBuff *);
	int (*report) (int *);
};

#endif /* __SEALINX_OFDM_CMD_H__ */
