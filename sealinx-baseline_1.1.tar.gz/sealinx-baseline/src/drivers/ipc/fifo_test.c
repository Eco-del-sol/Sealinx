#include <stdio.h>
#include "fifo.h"

#define uint8_t unsigned char
#define uint16_t unsigned short
#define uint32_t unsigned long

struct _Test
{
    uint8_t a;
    uint16_t b;
};

int main()
{
    // fifo1操作
    struct _Test arr;
    int fifo1 = fifo_create(10, sizeof(struct _Test));
    for (uint8_t i = 0; i < 10; i++)
    {
        arr.a = i;
        arr.b = 100 + i;
        if (fifo_writeable(fifo1))
        {
            fifo_write(fifo1, (void *)&arr);
            printf("可写：%d 可读：%d\n", fifo_writeable_item_count(fifo1), fifo_readable_item_count(fifo1));
        }
    }

    while (1)
    {
        if (fifo_readable(fifo1) == false)
        {
            break;
        }
        fifo_read(fifo1, (void *)&arr);
        printf("read:%d %d\n", arr.a, arr.b);
    }

    // fifo2操作
    int fifo2 = fifo_create(100, 1);
    char str_arr[100] = {0};
    memcpy(str_arr, "jdh", 3);
    fifo_write_batch(fifo2, str_arr, 3);

    printf("fifo2可写：%d 可读：%d\n", fifo_writeable_item_count(fifo2), fifo_readable_item_count(fifo2));

    str_arr[0] = 0;
    fifo_read_batch(fifo2, str_arr, fifo_readable_item_count(fifo2));
    printf("read:%s\n", str_arr);

    getchar();
    return 0;
}
