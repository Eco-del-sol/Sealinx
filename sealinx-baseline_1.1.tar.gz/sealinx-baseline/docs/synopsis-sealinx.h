/**
\page overview_page Overview of Sealinx
 
Sealinx is a framework for underwater networking with a layer-based
design. Sealinx has the following components:

 - Application layer
 - Transport layer
 - Network layer
 - MAC layer
 - Physical layer
 - Core component

An example script to run Sealinx with all dummy protocol follows:
\code{.sh}
#!/bin/bash
 
if [ $# -lt 2 ]; then
    echo "$0 <port number> [send|recv]"
    exit 1
fi
 
PORT=$1
TYPE=$2
./sealinx-core -p $PORT &
sleep 1
#./aquanet-benthos -p $PORT -g &
./sealinx-mac -i 2 -p $PORT &
./sealinx-net -i 3 -p $PORT -m 2 &
./sealinx-tra -i 4 -p $PORT -m 2 -n 3 &
 
if [ "$TYPE" = "send" ]; then
    sleep 20
    ./sealinx-tx-poi -i 5 -p $PORT -m 2 -n 3 -t 4 -l 200 -r 0.05 -d 2 &
else
    ./sealinx-tx-poi -i 5 -p $PORT -m 2 -n 3 -t 4 &
fi
\endcode
 */
