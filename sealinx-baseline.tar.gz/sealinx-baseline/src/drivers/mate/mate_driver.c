#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <signal.h>
#include <glib.h>
#include <arpa/inet.h>

#include "sealinx.h"
#include "sealinx_utils.h"
#include "sealinx_system.h"
#include "sealinx_common.h"
#include "sealinx_imsg.h"
#include "sealinx_shmem.h"
#include "mate_driver.h"

#define CFGMAC     "settings.ini"
#define MACADDR    "MacAddress"
#define GROUP      "General Settings"
#define CFGSOCKET  "config_socket.cfg"

int sockfd;
struct sockaddr_in server_addr;
char server_ip[16];
unsigned int server_port;

int modem_id;

static Modem_Ops gs_ops;
static pthread_t modem_recv_id;
static void *modem_recv(void *param);

static int load_cfgfile(const char *cfg_file) {
    char *token;
    char buf[80];

    FILE *cfg = fopen(cfg_file, "r");
    if (!cfg) {
        log_error("Fail to open the configuration file: %s", CFGSOCKET);
        return -1;
    }
    memset(buf, 0, sizeof(buf));

    while (fgets(buf, sizeof(buf), cfg)) {
        if (*buf == '#')
            continue;
        if (NULL == (token = strtok(buf, " :"))) {
            log_error("the configuration format should be:\nip : port\n");
            return -1;
        }
        strcpy(server_ip, token);
        if (NULL == (token = strtok(NULL, " :"))) {
            log_error("the configuration format should be:\nip : port\n");
            return -1;
        }
        server_port = atoi(token);
    }
    log_info("The server addr is %s:%d", server_ip, server_port);
    return 0;
}

static int get_mac_id(int *modem_id) {
    GKeyFile *key_file = g_key_file_new();
    GError *error = NULL;

    if (g_key_file_load_from_file(key_file, CFGMAC, G_KEY_FILE_NONE, &error)) {
        *modem_id = g_key_file_get_integer(key_file, GROUP, MACADDR, &error);
        if (error != NULL) {
            log_info("Unable to load MAC Address from %s: %s", CFGMAC, error->message);
            error = NULL;
            return -1;
        }
        return 0;
    } else {
        log_info("Unable to load config file: %s: %s", CFGMAC, error->message);
        return -1;
    }
}

static int socket_init() {
    socklen_t socklen = sizeof(server_addr);
    memset(&server_addr, 0, sizeof(server_addr));
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        log_error("create socket error");
        return -1;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(server_port);
    inet_pton(AF_INET, server_ip, &server_addr.sin_addr);

    if ((connect(sockfd, (struct sockaddr *)&server_addr, socklen)) < 0) {
        log_info("can't connect to server");
        return -1;
    }
    return 0;
}

static void socket_close() {
    close(sockfd);
}

static int socket_recv(Socket_Pkt *rx) {
    int len = recv(sockfd, rx, sizeof(*rx), 0);
    log_info("socket recv len: %d", len);
    if (len <= 0)
        return -1;

    return 0;
}

static int socket_send(Socket_Pkt *tx) {
    int ret = send(sockfd, tx, sizeof(*tx), 0);
    log_info("socket send len: %d", ret);
    if (ret <= 0)
        return -1;

    return 0;
}

static int socket_report_id(int *node) {
    if (send(sockfd, node, sizeof(*node), 0) <= 0) {
        log_error("report modem node error");
        return -1;
    }
    return 0;
}

int modem_init(Modem_Ops *ops) {
    if (load_cfgfile(CFGSOCKET) != 0) {
        log_error("Can not load configfile: %s", CFGSOCKET);
        return -1;
    }

    if (socket_init() != 0) {
        log_error("Can not init socket");
        return -1;
    }

    if (get_mac_id(&modem_id) != 0) {
        log_error("Can not get modem id");
        return -1;
    }

    gs_ops = *ops;

    return 0;
}

int modem_close() {
    socket_close(sockfd);
    return 0;
}

int modem_start() {
    if (gs_ops.rx_start_hook)
        gs_ops.rx_start_hook();

    if (0 != socket_report_id(&modem_id)) {
        log_error("report id error");
    }
    pthread_create(&modem_recv_id, NULL, modem_recv, NULL);
    return 0;
}

int modem_stop() {
    pthread_cancel(modem_recv_id);

    if (gs_ops.rx_stop_hook)
        gs_ops.rx_stop_hook();

    return 0;
}

int modem_run() {
    pthread_join(modem_recv_id, NULL);
}

int modem_send(Modem_Phy_Params *phy, int size, const void *data) {
    int err;
    Socket_Pkt *tx;

    tx = (Socket_Pkt *)malloc(sizeof(Socket_Pkt));
    if (!tx) {
        printf("Failed to create Socket_Pkt packet\n");
        return -1;
    }

    tx->phy.dst = phy->dst;
    tx->phy.src = modem_id; // or phy->src
    tx->phy.mode = phy->mode;
    tx->phy.type = phy->type;
    tx->phy.guard_time = phy->guard_time;
    tx->phy.power_level = phy->power_level;
    tx->payload_size = size;
    memcpy(tx->payload, data, size);

    err = socket_send(tx);
    if (err)
        log_error("Send socket error");

    free(tx);
    return err;
}

static void *modem_recv(void *param) {
    int ret;

    while (1) {
        Socket_Pkt *rx;
        rx = (Socket_Pkt *)malloc(sizeof(Socket_Pkt));
        while (socket_recv(rx))
            usleep(50 * 1000);
        gs_ops.rxcb(rx->phy, rx->payload_size, rx->payload);
        
        free(rx);
    }
    return NULL;
}
