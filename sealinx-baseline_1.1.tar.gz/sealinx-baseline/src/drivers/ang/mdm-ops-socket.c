#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>

#include "sealinx.h"
#include "sealinx_utils.h"
#include "sealinx_imsg.h"
#include "sealinx_pdu.h"
#include "sealinx_log.h"
#include "sealinx-ang.h"
#include "ang.h"

char *cfg_file = "./config_socket.cfg";

int sockfd;
int socket_flag = 0;
struct sockaddr_in server_addr;
char server_ip[16];
unsigned int server_port;

static int load_cfgfile(const char *cfg_file)
{
	char *token;
	char buf[80];

	FILE *cfg = fopen(cfg_file, "r");
	if (!cfg) {
		log_error("Fail to open the configuration file of ip_port");
		return -1;
	}
	memset(buf, 0, sizeof(buf));

	while (fgets(buf, sizeof(buf), cfg)) {
		if (*buf == '#')
			continue;
		if (NULL == (token = strtok(buf, " :"))) {
			log_info
			    ("the configuration format should be:\nip : port\n");
			return -1;
		}
		strcpy(server_ip, token);
		if (NULL == (token = strtok(NULL, " :"))) {
			log_info
			    ("the configuration format should be:\nip : port\n");
			return -1;
		}
		server_port = atoi(token);
	}
	log_info("The server_ip:server_port is %s : %d\n", server_ip,
		 server_port);
	return 0;
}

static int socket_init()
{
	socklen_t socklen = sizeof(server_addr);

	if (load_cfgfile(cfg_file) < 0) {
		log_error("error to read configuration file");
		return -1;
	}
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		log_error("create socket error");
		return -1;
	}

	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(server_port);
	inet_pton(AF_INET, server_ip, &server_addr.sin_addr);

	if ((connect(sockfd, (struct sockaddr *)&server_addr, socklen)) < 0) {
		log_info("can't connect to server");
		return -1;
	}
	socket_flag = 1;
	return 0;
}

static void socket_close()
{
	close(sockfd);
}

static int socket_isInitialized()
{
	return socket_flag;
}

static int socket_run()
{
	/* Nothing to do... */
	return 0;
}

static int socket_get(PduBuff * pdu)
{
	int len = recv(sockfd, pdu, sizeof(*pdu), 0);
	if (len <= 0)
		return -1;

	return 0;
}

static int socket_put(PduBuff * pdu)
{
	int len;
	len = send(sockfd, pdu, sizeof(*pdu), 0);
	if (len <= 0)
		return -1;

	return 0;
}

static int socket_report(int *node)
{
	if (send(sockfd, node, sizeof(*node), 0) <= 0) {
		log_error("report modem node error");
		return -1;
	}
	return 0;
}

struct mdm_phy_ops G_MDM_DRV_OPS = {
	.init = socket_init,
	.close = socket_close,
	.isInitialized = socket_isInitialized,
	.run = socket_run,
	.get = socket_get,
	.put = socket_put,
	.report = socket_report,
};

struct mdm_phy_ops *gMdmDrvOps = &G_MDM_DRV_OPS;
