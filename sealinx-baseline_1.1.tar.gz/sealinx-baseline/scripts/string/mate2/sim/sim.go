package sim

import (
	"log"
	"time"

	"mate2/com"
	"mate2/modems"
	"mate2/nodes"
)

// acousticSpeed is the sound speed running under the water
const acousticSpeed = 1500.0

//StartupTime records the startup time for simulation
var StartupTime time.Time

var nodelist = nodes.NodeList
var actives = modems.Actives

var id uint32

// RunningTime returns the simulation running time
func RunningTime() time.Duration {
	return time.Since(StartupTime)
}

func init() {
	StartupTime = time.Now()
}

// Run receive all waves from the channel
func Run() {
	for wave := range com.SimChannel {
		id++
		wave.ID = id
		w := wave // **new** wave object to be send
		w.BirthPoint = nodelist[w.ModemID].Point
		log.Printf("\t\033[34mSIM: get wave: %d (%d--%d->%d) at (%.1f, %.1f)\033[0m",
			w.ID, w.Src, w.Length, w.Dst, w.BirthPoint.X, w.BirthPoint.Y)
		go propagation(&w)
	}
}

func propagation(w *com.Wave) {
	for id, mdm := range actives {
		if id == w.ModemID {
			continue
		}
		go send2node(w, id, mdm)
	}
}

// send to mdm, id
func send2node(w *com.Wave, id int32, mdm modems.Modem) {
	d0 := w.BirthPoint.Distance(&nodelist[id].Point)
	d1 := d0 - nodes.MaxKnot*d0/acousticSpeed
	if d1 > float64(w.DeathLine) {
		return
	} else if d1 < 0 {
		d1 = 0
	}
	t1 := d1 / acousticSpeed * 1e9 // ns
	time.Sleep(time.Duration(t1))

	d2 := w.BirthPoint.Distance(&nodelist[id].Point)
	if d2 > float64(w.DeathLine) {
		return
	}
	t2 := (d2 - d1) / acousticSpeed * 1e9 // ns
	time.Sleep(time.Duration(t2))
	log.Printf("\033[34mSIM: \033[36mMDM%d\033[34m <-- wave: %d ~ %.1fM - %v ~\033[0m",
		id, w.ID, d2, time.Duration(t1+t2))
	mdm.GetWaveCh <- *w // send wave to modem from channel
}
