/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author son
 */

#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <time.h>

#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <errno.h>

#include "sealinx_utils.h"
#include "sealinx_log.h"

/*array crc init var*/
static uint32_t crc32_tab[] = {
	0x00000000L, 0x77073096L, 0xee0e612cL, 0x990951baL, 0x076dc419L,
	0x706af48fL, 0xe963a535L, 0x9e6495a3L, 0x0edb8832L, 0x79dcb8a4L,
	0xe0d5e91eL, 0x97d2d988L, 0x09b64c2bL, 0x7eb17cbdL, 0xe7b82d07L,
	0x90bf1d91L, 0x1db71064L, 0x6ab020f2L, 0xf3b97148L, 0x84be41deL,
	0x1adad47dL, 0x6ddde4ebL, 0xf4d4b551L, 0x83d385c7L, 0x136c9856L,
	0x646ba8c0L, 0xfd62f97aL, 0x8a65c9ecL, 0x14015c4fL, 0x63066cd9L,
	0xfa0f3d63L, 0x8d080df5L, 0x3b6e20c8L, 0x4c69105eL, 0xd56041e4L,
	0xa2677172L, 0x3c03e4d1L, 0x4b04d447L, 0xd20d85fdL, 0xa50ab56bL,
	0x35b5a8faL, 0x42b2986cL, 0xdbbbc9d6L, 0xacbcf940L, 0x32d86ce3L,
	0x45df5c75L, 0xdcd60dcfL, 0xabd13d59L, 0x26d930acL, 0x51de003aL,
	0xc8d75180L, 0xbfd06116L, 0x21b4f4b5L, 0x56b3c423L, 0xcfba9599L,
	0xb8bda50fL, 0x2802b89eL, 0x5f058808L, 0xc60cd9b2L, 0xb10be924L,
	0x2f6f7c87L, 0x58684c11L, 0xc1611dabL, 0xb6662d3dL, 0x76dc4190L,
	0x01db7106L, 0x98d220bcL, 0xefd5102aL, 0x71b18589L, 0x06b6b51fL,
	0x9fbfe4a5L, 0xe8b8d433L, 0x7807c9a2L, 0x0f00f934L, 0x9609a88eL,
	0xe10e9818L, 0x7f6a0dbbL, 0x086d3d2dL, 0x91646c97L, 0xe6635c01L,
	0x6b6b51f4L, 0x1c6c6162L, 0x856530d8L, 0xf262004eL, 0x6c0695edL,
	0x1b01a57bL, 0x8208f4c1L, 0xf50fc457L, 0x65b0d9c6L, 0x12b7e950L,
	0x8bbeb8eaL, 0xfcb9887cL, 0x62dd1ddfL, 0x15da2d49L, 0x8cd37cf3L,
	0xfbd44c65L, 0x4db26158L, 0x3ab551ceL, 0xa3bc0074L, 0xd4bb30e2L,
	0x4adfa541L, 0x3dd895d7L, 0xa4d1c46dL, 0xd3d6f4fbL, 0x4369e96aL,
	0x346ed9fcL, 0xad678846L, 0xda60b8d0L, 0x44042d73L, 0x33031de5L,
	0xaa0a4c5fL, 0xdd0d7cc9L, 0x5005713cL, 0x270241aaL, 0xbe0b1010L,
	0xc90c2086L, 0x5768b525L, 0x206f85b3L, 0xb966d409L, 0xce61e49fL,
	0x5edef90eL, 0x29d9c998L, 0xb0d09822L, 0xc7d7a8b4L, 0x59b33d17L,
	0x2eb40d81L, 0xb7bd5c3bL, 0xc0ba6cadL, 0xedb88320L, 0x9abfb3b6L,
	0x03b6e20cL, 0x74b1d29aL, 0xead54739L, 0x9dd277afL, 0x04db2615L,
	0x73dc1683L, 0xe3630b12L, 0x94643b84L, 0x0d6d6a3eL, 0x7a6a5aa8L,
	0xe40ecf0bL, 0x9309ff9dL, 0x0a00ae27L, 0x7d079eb1L, 0xf00f9344L,
	0x8708a3d2L, 0x1e01f268L, 0x6906c2feL, 0xf762575dL, 0x806567cbL,
	0x196c3671L, 0x6e6b06e7L, 0xfed41b76L, 0x89d32be0L, 0x10da7a5aL,
	0x67dd4accL, 0xf9b9df6fL, 0x8ebeeff9L, 0x17b7be43L, 0x60b08ed5L,
	0xd6d6a3e8L, 0xa1d1937eL, 0x38d8c2c4L, 0x4fdff252L, 0xd1bb67f1L,
	0xa6bc5767L, 0x3fb506ddL, 0x48b2364bL, 0xd80d2bdaL, 0xaf0a1b4cL,
	0x36034af6L, 0x41047a60L, 0xdf60efc3L, 0xa867df55L, 0x316e8eefL,
	0x4669be79L, 0xcb61b38cL, 0xbc66831aL, 0x256fd2a0L, 0x5268e236L,
	0xcc0c7795L, 0xbb0b4703L, 0x220216b9L, 0x5505262fL, 0xc5ba3bbeL,
	0xb2bd0b28L, 0x2bb45a92L, 0x5cb36a04L, 0xc2d7ffa7L, 0xb5d0cf31L,
	0x2cd99e8bL, 0x5bdeae1dL, 0x9b64c2b0L, 0xec63f226L, 0x756aa39cL,
	0x026d930aL, 0x9c0906a9L, 0xeb0e363fL, 0x72076785L, 0x05005713L,
	0x95bf4a82L, 0xe2b87a14L, 0x7bb12baeL, 0x0cb61b38L, 0x92d28e9bL,
	0xe5d5be0dL, 0x7cdcefb7L, 0x0bdbdf21L, 0x86d3d2d4L, 0xf1d4e242L,
	0x68ddb3f8L, 0x1fda836eL, 0x81be16cdL, 0xf6b9265bL, 0x6fb077e1L,
	0x18b74777L, 0x88085ae6L, 0xff0f6a70L, 0x66063bcaL, 0x11010b5cL,
	0x8f659effL, 0xf862ae69L, 0x616bffd3L, 0x166ccf45L, 0xa00ae278L,
	0xd70dd2eeL, 0x4e048354L, 0x3903b3c2L, 0xa7672661L, 0xd06016f7L,
	0x4969474dL, 0x3e6e77dbL, 0xaed16a4aL, 0xd9d65adcL, 0x40df0b66L,
	0x37d83bf0L, 0xa9bcae53L, 0xdebb9ec5L, 0x47b2cf7fL, 0x30b5ffe9L,
	0xbdbdf21cL, 0xcabac28aL, 0x53b39330L, 0x24b4a3a6L, 0xbad03605L,
	0xcdd70693L, 0x54de5729L, 0x23d967bfL, 0xb3667a2eL, 0xc4614ab8L,
	0x5d681b02L, 0x2a6f2b94L, 0xb40bbe37L, 0xc30c8ea1L, 0x5a05df1bL,
	0x2d02ef8dL
};

/**
 * Return a 32-bit CRC of the contents of the buffer.
 *
 *@inData data of input
 *@len length of input string
 *@return value of 32 bits
 */
uint32_t sl_crc32(const char *inData, uint len)
{
	uint i;
	uint32_t crc32val;

	uint8_t *s = (uint8_t *) inData;

	crc32val = 0;
	for (i = 0; i < len; i++)
		crc32val =
		    crc32_tab[(crc32val ^ s[i]) & 0xff] ^ (crc32val >> 8);

	return crc32val;
}

/**
 *subtract substring from string
 *
 *@s string mother
 *@find string will find
 *@slen length of find
 *@return string
 */
char *strnstr(const char *s, const char *find, size_t slen)
{
	char c, sc;
	size_t len;

	if ((c = *find++) != '\0') {
		len = strlen(find);
		do {
			do {
				if (slen-- < 1 || (sc = *s++) == '\0')
					return (NULL);
			} while (sc != c);
			if (len > slen)
				return (NULL);
		} while (strncmp(s, find, len) != 0);
		s--;
	}
	return ((char *)s);
}

/**
 *find strar pointer of string in memory
 *
 *@mem memory of mem
 *@str string of char
 *@slen length of string
 *@return string of start
 */
char *strInMem(const char *mem, const char *str, size_t slen)
{
	const char *endMem = mem + slen;
	char *cmem = (char *)mem;
	int l = strlen(str);
	while (endMem - cmem >= l) {
		if (memcmp(cmem, str, l) == 0) {
			return cmem;
		}
		cmem++;
	}
	return NULL;
}

/*
struct of context
*/
typedef struct {
	unsigned char cksum[16];
	unsigned char state[48];
	unsigned char buffer[16];

	unsigned char ipad[64];
	unsigned char opad[64];
	int left;
} md2_context;

/*PI array*/
static const unsigned char PI_SUBST[256] = {
	0x29, 0x2E, 0x43, 0xC9, 0xA2, 0xD8, 0x7C, 0x01, 0x3D, 0x36,
	0x54, 0xA1, 0xEC, 0xF0, 0x06, 0x13, 0x62, 0xA7, 0x05, 0xF3,
	0xC0, 0xC7, 0x73, 0x8C, 0x98, 0x93, 0x2B, 0xD9, 0xBC, 0x4C,
	0x82, 0xCA, 0x1E, 0x9B, 0x57, 0x3C, 0xFD, 0xD4, 0xE0, 0x16,
	0x67, 0x42, 0x6F, 0x18, 0x8A, 0x17, 0xE5, 0x12, 0xBE, 0x4E,
	0xC4, 0xD6, 0xDA, 0x9E, 0xDE, 0x49, 0xA0, 0xFB, 0xF5, 0x8E,
	0xBB, 0x2F, 0xEE, 0x7A, 0xA9, 0x68, 0x79, 0x91, 0x15, 0xB2,
	0x07, 0x3F, 0x94, 0xC2, 0x10, 0x89, 0x0B, 0x22, 0x5F, 0x21,
	0x80, 0x7F, 0x5D, 0x9A, 0x5A, 0x90, 0x32, 0x27, 0x35, 0x3E,
	0xCC, 0xE7, 0xBF, 0xF7, 0x97, 0x03, 0xFF, 0x19, 0x30, 0xB3,
	0x48, 0xA5, 0xB5, 0xD1, 0xD7, 0x5E, 0x92, 0x2A, 0xAC, 0x56,
	0xAA, 0xC6, 0x4F, 0xB8, 0x38, 0xD2, 0x96, 0xA4, 0x7D, 0xB6,
	0x76, 0xFC, 0x6B, 0xE2, 0x9C, 0x74, 0x04, 0xF1, 0x45, 0x9D,
	0x70, 0x59, 0x64, 0x71, 0x87, 0x20, 0x86, 0x5B, 0xCF, 0x65,
	0xE6, 0x2D, 0xA8, 0x02, 0x1B, 0x60, 0x25, 0xAD, 0xAE, 0xB0,
	0xB9, 0xF6, 0x1C, 0x46, 0x61, 0x69, 0x34, 0x40, 0x7E, 0x0F,
	0x55, 0x47, 0xA3, 0x23, 0xDD, 0x51, 0xAF, 0x3A, 0xC3, 0x5C,
	0xF9, 0xCE, 0xBA, 0xC5, 0xEA, 0x26, 0x2C, 0x53, 0x0D, 0x6E,
	0x85, 0x28, 0x84, 0x09, 0xD3, 0xDF, 0xCD, 0xF4, 0x41, 0x81,
	0x4D, 0x52, 0x6A, 0xDC, 0x37, 0xC8, 0x6C, 0xC1, 0xAB, 0xFA,
	0x24, 0xE1, 0x7B, 0x08, 0x0C, 0xBD, 0xB1, 0x4A, 0x78, 0x88,
	0x95, 0x8B, 0xE3, 0x63, 0xE8, 0x6D, 0xE9, 0xCB, 0xD5, 0xFE,
	0x3B, 0x00, 0x1D, 0x39, 0xF2, 0xEF, 0xB7, 0x0E, 0x66, 0x58,
	0xD0, 0xE4, 0xA6, 0x77, 0x72, 0xF8, 0xEB, 0x75, 0x4B, 0x0A,
	0x31, 0x44, 0x50, 0xB4, 0x8F, 0xED, 0x1F, 0x1A, 0xDB, 0x99,
	0x8D, 0x33, 0x9F, 0x11, 0x83, 0x14
};

/*
 * MD2 context setup
 *
 *@ctx contex of md2
 */
void md2_starts(md2_context * ctx)
{
	memset(ctx->cksum, 0, 16);
	memset(ctx->state, 0, 46);
	memset(ctx->buffer, 0, 16);
	ctx->left = 0;
}

/**
 *MD2 process 
 *
 *@ctx contex of md2
 */
static void md2_process(md2_context * ctx)
{
	int i, j;
	unsigned char t = 0;

	for (i = 0; i < 16; i++) {
		ctx->state[i + 16] = ctx->buffer[i];
		ctx->state[i + 32] =
		    (unsigned char)(ctx->buffer[i] ^ ctx->state[i]);
	}

	for (i = 0; i < 18; i++) {
		for (j = 0; j < 48; j++) {
			ctx->state[j] =
			    (unsigned char)(ctx->state[j] ^ PI_SUBST[t]);
			t = ctx->state[j];
		}
		t = (unsigned char)(t + i);
	}

	t = ctx->cksum[15];

	for (i = 0; i < 16; i++) {
		ctx->cksum[i] =
		    (unsigned char)(ctx->
				    cksum[i] ^ PI_SUBST[ctx->buffer[i] ^ t]);
		t = ctx->cksum[i];
	}
}

/**
 * MD2 process buffer
 *
 *@ctx context of generate
 *@input string of generate
 *@ilen length of input string
 */
void md2_update(md2_context * ctx, const unsigned char *input, int ilen)
{
	int fill;

	while (ilen > 0) {
		if (ctx->left + ilen > 16)
			fill = 16 - ctx->left;
		else
			fill = ilen;

		memcpy(ctx->buffer + ctx->left, input, fill);

		ctx->left += fill;
		input += fill;
		ilen -= fill;

		if (ctx->left == 16) {
			ctx->left = 0;
			md2_process(ctx);
		}
	}
}

/**
 * MD2 final digest
 *
 *@ctx context of generate
 *@output string of generate
 */
void md2_finish(md2_context * ctx, unsigned char output[16])
{
	int i;
	unsigned char x;

	x = (unsigned char)(16 - ctx->left);

	for (i = ctx->left; i < 16; i++)
		ctx->buffer[i] = x;

	md2_process(ctx);

	memcpy(ctx->buffer, ctx->cksum, 16);
	md2_process(ctx);

	memcpy(output, ctx->state, 16);
}

/*
 * output = MD2( input buffer )
 *
 *@param input string of init string
 *@ilen of length of md
 *@output string of generate
 */
void md2(const unsigned char *input, int ilen, unsigned char output[16])
{
	md2_context ctx;

	md2_starts(&ctx);
	md2_update(&ctx, input, ilen);
	md2_finish(&ctx, output);

	memset(&ctx, 0, sizeof(md2_context));
}

/**
 *sleep 
 *
 *@param milisec will wake after milisec
 *@return 1
 */
int msleep(unsigned long milisec)
{
	struct timespec req = { 0 };
	time_t sec = (int)(milisec / 1000);
	milisec = milisec - (sec * 1000);
	req.tv_sec = sec;
	req.tv_nsec = milisec * 1000000L;
	while (nanosleep(&req, &req) == -1)
		continue;
	return 1;
}

/**
 *make dir
 *
 *@param path of will make
 *@mode right of path
 *@return 0 on failed, otherwise ~0
 */
int do_mkdir(const char *path, mode_t mode)
{
	struct stat st;
	int status = 0;

	if (stat(path, &st)) {
		/* Directory does not exist */
		if (mkdir(path, mode) != 0) {
			status = -1;
		}
	} else if (!S_ISDIR(st.st_mode)) {
		errno = ENOTDIR;
		status = -1;
	}

	return status;
}

/**
 *make path
 *
 *@param path of will make
 *@mode right of path
 *@return 0 on failed, otherwise ~0
 */
int mkpath(const char *path, mode_t mode)
{
	char *pp;
	char *sp;
	int status;
	char *copypath = strdup(path);

	status = 0;
	pp = copypath;
	while (status == 0 && (sp = strchr(pp, '/')) != 0) {
		if (sp != pp) {
			*sp = '\0';
			status = do_mkdir(copypath, mode);
			*sp = '/';
		}
		pp = sp + 1;
	}

	if (status == 0)
		status = do_mkdir(path, mode);

	free(copypath);
	return status;
}

void convert_to_hex()
{
}

/**
 * Simplify a Unix path to a directory. For example "/abc/def/../uvw" will become "/abc/uvw/".
 *
 *@param path of simplifying 
 *@return string of path
 */
int simplify_dir_path(char *path)
{
	if (path == NULL)
		return -1;

	int i = 0;
	int p = 0;
	int n = strlen(path);

	while (i < n) {
		int j = i + 1;
		while (j < n && path[j] == '.')
			j++;
		if (j - i == 3 && (j == n || path[j] == '/')) {
			if (p)
				do {
					--p;
				} while (p && path[p] != '/');
			i = j;
		} else if (j - i <= 2 && (j == n || path[j] == '/')) {
			i = j;
		} else {
			do {
				path[p++] = path[i++];
			} while (i < n && path[i] != '/');
		}
	}

	if (p == 0 || path[p - 1] != '/')
		path[p++] = '/';

	path[p] = '\0';
	return p;
}

/**
 * Return address of n-th term in the command line.
 * Note this function destroys char *cmd.
 * find_cmd_term("hello world I love you!", 2); will return with "hello world\0I love you!"
 *@param cmd string of command
 *@param n number of number
 *@return string of terminal
 */
char *find_cmd_term(char *cmd, int n)
{
	if (n <= 0 || cmd == NULL)
		return NULL;

	int cmdLen = strlen(cmd);
	int i;
	int p = 0;
	for (i = 0; i < cmdLen - 1; i++) {
		if (cmd[i] == ' ') {
			if (n == 1) {
				cmd[i] = '\0';
				return (char *)(cmd + p);
			} else if (cmd[i + 1] != ' ') {
				p = i + 1;
				n = n - 1;
			}
		}
	}
	return (char *)(cmd + p);
}

/**
 * Print out when (date and time) this executable is compiled  
 * It also show the git hub version (hash value) of the file 
 * No input or return values
 */
extern char *__progname;
void print_ver(void)
{
	log_info("Software:\t%s", __progname);
	log_info("Build time:\t%s %s", __DATE__, __TIME__);
	log_info("Version:\t%s", SEALINX_VERSION);
}
