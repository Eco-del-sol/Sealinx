#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <err.h>
#include <errno.h>
#include <signal.h>
#include <pthread.h>
#include <termios.h>
#include <sys/time.h>
#include <sys/shm.h>
#include <time.h>
#include <math.h>
#include <glib.h>
#include <ctype.h>

#include "sealinx.h"
#include "sealinx_utils.h"
#include "sealinx_system.h"
#include "sealinx_common.h"
#include "sealinx_imsg.h"
#include "sealinx_shmem.h"
#include "mate_driver.h"
#include "modem_info.h"

#define MATE_DRIVER_ID 33

/** File descriptor of the connection to the core. */
int g_connFd = -1;
char *g_logFolder = "logs/";
char *g_logId = "DRIVER";
int g_logFile = 1;

/** ID of the shared memory by the core module */
int g_coreSharedMemId = 0;

/** Shared data by the core module. */
CoreSharedData *g_coreSharedData = NULL;
int g_running = 0;      /* Flag of initialized */

pthread_t core_thread_id;

int pdu_pack(char *pkt, PduBuff *pbuf, int *len) {
    int pktLen = 0;

    if ((!pkt) || (!pbuf))
        return -1;

    /* payload_len + mac_data + '|' + net_data + '|' + tra_data + '|' + payload */

    /* Frame length, length of payload */
    memcpy(pkt, &(pbuf->msg_len), sizeof(pbuf->msg_len));
    pkt += sizeof(pbuf->msg_len);
    pktLen += sizeof(pbuf->msg_len);

    /* Mac header */
    memcpy(pkt, &(pbuf->hdr_mac), pbuf->hdr_mac.hdr_len);
    pkt += pbuf->hdr_mac.hdr_len;
    pktLen += pbuf->hdr_mac.hdr_len;

    /* Net header */
    *pkt++ = '|';   /* Use '|'(0x7C > hdr_len) to seperate headers */
    pktLen++;
    memcpy(pkt, &(pbuf->hdr_net), pbuf->hdr_net.hdr_len);
    pkt += pbuf->hdr_net.hdr_len;
    pktLen += pbuf->hdr_net.hdr_len;

    /* Tra header */
    *pkt++ = '|';    /* Use ':' to seperate headers */
    pktLen++;
    memcpy(pkt, &(pbuf->hdr_tra), pbuf->hdr_tra.hdr_len);
    pkt += pbuf->hdr_tra.hdr_len;
    pktLen += pbuf->hdr_tra.hdr_len;

    /* Payload */
    *pkt++ = '|';    /* Use ':' to seperate headers and payload */
    pktLen++;
    memcpy(pkt, &(pbuf->pkt_data), pbuf->msg_len);
    pkt += pbuf->msg_len;
    pktLen += pbuf->msg_len;
///not used
///    *pkt++ = '|';    /* Use ':' to mark the end of payload */
///    pktLen++;

    *len = pktLen;

    return 0;
}

int pdu_unpack(char *payload, PduBuff *pbuf, int len) {
    uint16_t msg_len = 0;
    uint8_t header_len = 0;

    /* Notes: the pkt_type and pkt_state of Pdubuff not used in physical layer. */
    /* payload_len + mac_data + '|' + net_data + '|' + tra_data + '|' + payload */

    if ((!payload) || (!pbuf))
        return -1;

    memset(pbuf, 0x00, sizeof(PduBuff));
    /* Frame length */
    memcpy(&msg_len, payload, sizeof(pbuf->msg_len));
    payload += sizeof(pbuf->msg_len);
    pbuf->msg_len = msg_len;
    if (pbuf->msg_len > MAX_DATA_PAYLOAD_SIZE)
        return -1;

    /* MAC header */
    if (*payload != '|') { /* If MAC header is not NULL */
        memcpy(&header_len, payload, sizeof(pbuf->hdr_mac.hdr_len));
        if (header_len > MAX_HEADER_SIZE_MAC)
            return -1;
        memcpy(&(pbuf->hdr_mac), payload, header_len);
        payload += header_len;
    }
    if (*payload != '|')
        return -1;
    payload++;   /* Jump over the '|' between MAC and NET headers */

    /* NET header */
    if (*payload != '|') { /* If NET header is not NULL */
        memcpy(&header_len, payload, sizeof(pbuf->hdr_net.hdr_len));
        if (header_len > MAX_HEADER_SIZE_NET)
            return -1;
        memcpy(&(pbuf->hdr_net), payload, header_len);
        payload += header_len;
    }
    if (*payload != '|')
        return -1;
    payload++;  /* Jump over the '|' between NET and TRA headers */

    /* TRA header */
    if (*payload != '|') { /* If TRA header is not NULL */
        memcpy(&header_len, payload, sizeof(pbuf->hdr_tra.hdr_len));
        if (header_len > MAX_HEADER_SIZE_TRA)
            return -1;
        memcpy(&(pbuf->hdr_tra), payload, header_len);
        payload += header_len;
    }
    if (*payload != '|')
        return -1;
    payload++;   /* Jump over the '|' between TRA header and APP payload */

    /* Frame data */
    if (pbuf->msg_len !=
            (len - sizeof(pbuf->msg_len) - pbuf->hdr_mac.hdr_len -
            pbuf->hdr_net.hdr_len - pbuf->hdr_tra.hdr_len - 3))
        return -1;
    memcpy(&(pbuf->pkt_data), payload, msg_len);

    return 0;
}

int read_from_core(void)
{
    char buffer[IMSG_MAX_DATA_LENGTH];
    char packet[IMSG_MAX_DATA_LENGTH];
    InternalMessageHeader dataHeader;
    int nBytesRead;
    nBytesRead = client_read(g_connFd, buffer, IMSG_MAX_DATA_LENGTH, &dataHeader, NULL, 0);
    if (-1 == nBytesRead) {
        log_error("Error reading from core: %s", strerror(errno));
        return -1;
    }

    logReceiveFromStack(nBytesRead, "");
    if (0 == nBytesRead) {
        log_info("Core connection closed, read a 0 data");
        return -1;
    }
    log_info("Core connection get data %d", nBytesRead);

    PduBuff *pbuf = (PduBuff *)buffer;
    ModemInfo *pPhyInfo = (ModemInfo *)pbuf->phy;
    
    if (from_upper_layer(dataHeader)) {
        switch (pPhyInfo->type) {
        case Modem_Info_Tx:
            log_info("Drivers receive Modem_Info_Tx");
            int len = 0;

            pdu_pack(packet, pbuf, &len);
            Modem_Phy_Params phy = {0, 1, 1, 0, 150, 100};
            if (!(pbuf->hdr_mac.dst_addr < 0))
            	phy.dst = pbuf->hdr_mac.dst_addr;
            if (!(pbuf->hdr_mac.src_addr < 0))
                phy.src = pbuf->hdr_mac.src_addr;
            if (!(pPhyInfo->tx.phy_param.mode < 0))
                phy.mode = pPhyInfo->tx.phy_param.mode;
            if (!(pPhyInfo->tx.phy_param.type < 0))
                phy.type = pPhyInfo->tx.phy_param.type;
            if (!(pPhyInfo->tx.phy_param.guard_time < 0))
                phy.guard_time = pPhyInfo->tx.phy_param.guard_time;
            if (!(pPhyInfo->tx.phy_param.power_level < 0))
                phy.power_level = pPhyInfo->tx.phy_param.power_level;
            
            int err = modem_send(&phy, len, packet);
            if (err)
                log_error("Modem send error: %d\n", err);
            
            break;
            
        case Modem_Config_Set:
            log_info("Drivers receive Modem_Config_Set");
            break;
            
        case Modem_Config_Get:
            log_info("Drivers receive Modem_Config_Get");
            break;
            
        case Modem_Range:
            log_info("Drivers receive Modem_Range");
            log_info("Destination: %d", pPhyInfo->range.remoteId);
            break;
        
        default:
            log_error("Drivers receive command error: %d\n", pPhyInfo->type);
            return -1;
        }
    } else {
        log_error("ERROR: NO lower layer in driver!");
        return -1;
    }
    return 0;
}

void *core_thread(void *data)
{
    int ret = -1;
    while (g_running) {
        ret = read_from_core();
        if (ret) {
            log_error("ERROR core_thread break!");
            break;
        }
        usleep(5*1000);
    }
    return NULL;
}

static int driver_init() {
    int type = 0;
        /* Init logger. */
    if (!init_logger(g_logFolder, g_logId, g_logFile, TRUE, NULL, 0)) {
        fprintf(stderr, "Fail to init the log module.");
        return FALSE;
    }

    /* Init core. */
    RegistrationResponse serverResponse;
    g_connFd = client_connect(type, LAYER_PHYSICAL, NULL, &serverResponse, NULL, 0);
    if (g_connFd == -1) {
        log_error("ERROR CANT connect to core");
        return FALSE;
    }
    g_coreSharedMemId = serverResponse.coreShareMemId;
    log_info("Init: g_connFd %d, g_coreSharedMemId %d", g_connFd, g_coreSharedMemId);
    g_coreSharedData = (CoreSharedData *)shmat(g_coreSharedMemId, NULL, 0);
    if (g_coreSharedData == (CoreSharedData *) - 1) {
        log_error("Unable to attach the shared memory: %s", strerror(errno));
        return FALSE;
    }
    logger_set_node_id(g_coreSharedData->macAddr, g_coreSharedData->netAddr);
    log_info("Mac address: %d, net address: %d",
         (int)g_coreSharedData->macAddr,
         (int)g_coreSharedData->netAddr);

    g_running = TRUE;
    return TRUE;
}

static int driver_close() {
    g_running = FALSE;
    if (g_connFd > -1) {
        log_info("Close connection to core");
        g_connFd = -1;
    }
    if (g_coreSharedData) {
        if (shmdt(g_coreSharedData) == -1) {
            log_error("Unable to detach shared data: %s", strerror(errno));
        }
    }
    return TRUE;
}

static void clean_up() {
    driver_close();
    sleep(1);
    modem_stop();
    modem_close();
}

static void signal_handler(int sig) {
    if (sig != SIGINT)
        return;

    g_running = FALSE;
    usleep(1000*100);
}

/**
 * Main program.
 *
 * @param argc Number of arguments.
 * @param argv The arguments.
 * @retval EXIT_SUCCESS If the program exits normally.
 * @retval EXIT_FAILURE If an error occurs.
 */
void rx(Modem_Phy_Params phy, int len, char *payload) {
    int ret = 0;
    PduBuff *pdu;
    pdu = (PduBuff *)malloc(sizeof(PduBuff));
    memset(pdu, 0, sizeof(PduBuff));
    
    ret = pdu_unpack(payload, pdu, len);
    ModemInfo *pPhyInfo = (ModemInfo *)pdu->phy;
    
    pPhyInfo->type = Modem_Info_Rx;
    pPhyInfo->rx.phy_param.dst = phy.dst;
    pPhyInfo->rx.phy_param.src = phy.src;
    pPhyInfo->rx.phy_param.mode = phy.mode;
    pPhyInfo->rx.phy_param.type = phy.type;
    pPhyInfo->rx.phy_param.guard_time = phy.guard_time;
    pPhyInfo->rx.phy_param.power_level = phy.power_level;

    if (g_connFd != -1) {
        ret = client_send_up(g_connFd, pdu, sizeof(PduBuff),
                             MATE_DRIVER_ID, NULL, 0);
    }
    if (ret < 0)
        log_error("ERROR client send up failed");

    log_info("Send pdu to core succcessfull.");
    return;
}

Modem_Ops ops = {
    .rxcb = rx,
    .rx_start_hook = NULL,
    .rx_stop_hook = NULL
};

int main(int argc, char **argv) {
    int opt;

    while ((opt = getopt(argc, argv, "f:v")) != -1) {
        switch(opt) {
        case 'v':
            log_info("build time: %s %s", __DATE__, __TIME__);
            log_info("SEALINX_VERSION: %s", SEALINX_VERSION);
            exit(0);
        case 'f':
            g_logFile = atoi(optarg);
            break;
        }
    }

    atexit(clean_up);
    signal(SIGINT, signal_handler);

    if (modem_init(&ops) != 0) {
        log_error("Failed to init modem!");
        return EXIT_FAILURE;
    }

    if (!driver_init()) {
        log_error("Modem driver init error!");
        return EXIT_FAILURE;
    }

    modem_start();
    pthread_create(&core_thread_id, NULL, core_thread, NULL);
    pthread_join(core_thread_id, NULL);
    modem_run();

    modem_stop();
    modem_close();
    driver_close();
    return 0;
}
