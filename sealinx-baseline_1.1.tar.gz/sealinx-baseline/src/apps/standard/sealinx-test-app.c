/**
 * Sealinx app test about packet lose & data rate.
 *
 * @Author	Jifeng Zhu
 * @Date	2019-07-23
 * @Version	0.1
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/un.h>
#include <unistd.h>
#include <sys/select.h>
#include <err.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>
#include <sys/shm.h>
#include <sys/time.h>
#include <math.h>

#include <sealinx.h>
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>
#include <modem_info.h>

#include "sealinx-test-app.h"

/** Log identity for this module. */
char * gLogId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char * gLogFolder = DEFAULT_LOG_FOLDER;

/** Config file name. */
char *g_configFileName;

/** File descriptor of the connection to the core. */
int g_connFd;

/** ID of the current module. */
ModuleId g_moduleId;

/** ID of the MAC module. */
ModuleId g_macId;

/** ID of the network module. */
ModuleId g_netId;

/** ID of the transport module. */
ModuleId g_transId;

/** Shared data by the core module. */
CoreSharedData *g_coreSharedData;

/** Key of the shared memory by the core. */
int g_coreSharedMemId;

/** Block number of data. */
int g_blockNum;

/** tx_mode of modem. */
int g_txmode;

/** Destination node. */
int g_destNode;

/** Sender send times. */
int g_sendNum;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 1;

/** Receiver times. */
int g_recvNum;

int g_running;

int g_guardTime;
int g_powerLevel;
int g_interval;

struct timeval firstRT;
unsigned long long firstRecvTime;
int totalDataLen;


/**
 * Clean up allocated resources.
 */
void clean_up(void) {
    int type = 0;
    log_info("Cleaning up ...");

    if (g_connFd > -1) {
        client_close(type, g_connFd, NULL, 0);
    }

    if (g_coreSharedData) {
        int rc = shmdt(g_coreSharedData);
        if (rc == -1) {
            log_error("Unable to detach shared data: %s", strerror(errno));
        }
    }

    close_logger();
}

/**
 * Signal handler.
 *
 * @param sig Signal ID.
 */
void signal_handler(int sig) {
    int type = 0;
    log_info("Received signal (%d)", sig);

    g_running = FALSE;

    if (g_connFd > -1) {
        client_close(type, g_connFd, NULL, 0);
        g_connFd = -1;
    }
}

/**
 * Parse command line arguments.
 *
 * @param argc Number of arguments
 * @param argv The arguments
 * @return TRUE if the argument can be parse; FALSE, otherwise.
 */
int parse_arguments(int argc, char ** argv) {
    int c;
    int moduleId;
    int macId;
    int netId;
    int transId;

    g_destNode = -1;
    g_blockNum = 0;
    g_txmode = 1;
    g_sendNum = 0;
    g_configFileName = DEFAULT_CFG_FILE_NAME;

    while ((c = getopt (argc, argv, "i:m:n:t:c:f:x:b:d:l:v")) != -1) {
        switch (c) {
        case 'i':
        	moduleId = atoi(optarg);
            if (moduleId > MAX_MODULE_ID || moduleId < MIN_MODULE_ID) {
                fprintf(stderr, "Invalid module ID (%s)\n", optarg);
                return FALSE;
            }
            g_moduleId = moduleId;
            break;

        case 'm':
        	macId = atoi(optarg);
            if (macId > MAX_MODULE_ID || macId < MIN_MODULE_ID) {
                fprintf(stderr, "Invalid module ID (%s)\n", optarg);
                return FALSE;
            }
            g_macId = macId;
            break;

        case 'n':
        	netId = atoi(optarg);
            if (netId > MAX_MODULE_ID || netId < MIN_MODULE_ID) {
                fprintf(stderr, "Invalid module ID (%s)\n", optarg);
                return FALSE;
            }
            g_netId = netId;
            break;

        case 't':
        	transId = atoi(optarg);
            if (transId > MAX_MODULE_ID || transId < MIN_MODULE_ID) {
                fprintf(stderr, "Invalid module ID (%s)\n", optarg);
                return FALSE;
            }
            g_transId = transId;
            break;

        case 'c':
        	g_configFileName = optarg;
            break;

        case 'f':
        	gLogFile = atoi(optarg);
            break;

        case 'x':
        	g_txmode = atoi(optarg);
            break;

        case 'b':
        	g_blockNum = atoi(optarg);
            break;

        case 'd':
        	g_destNode = atoi(optarg);
            break;

        case 'l':
        	g_sendNum = atoi(optarg);
            break;

		case 'v':
			log_info("build time: %s %s", __DATE__, __TIME__);
			log_info("SEALINX_VERSION: %s", SEALINX_VERSION);
			exit(0);

		case '?':
			return FALSE;
		}
	}

    return g_moduleId >= MIN_MODULE_ID && g_moduleId <= MAX_MODULE_ID &&
            g_macId >= MIN_MODULE_ID && g_macId <= MAX_MODULE_ID &&
            g_netId >= MIN_MODULE_ID && g_netId <= MAX_MODULE_ID &&
            g_transId >= MIN_MODULE_ID && g_transId <= MAX_MODULE_ID;
}

/**
 * Print the usage of the program.
 */
void print_usage(const char *progName) {
    printf("USAGE: %s -i <module id> -m <mac protocol id> -n <network protocol id> "
            "-t <transport protocol id> -c <configure file name> "
            "-x <tx mode> -b <block num> -d <dest node> -x <send number> "
            "[-f <log file outoput flag>]\n", progName);
}

/**
 * Initialize the program.
 */
int init_test(void) {
    int type = 0;
    ModuleId moduleIds[NUM_LAYERS];
    moduleIds[LAYER_MAC] = g_macId;
    moduleIds[LAYER_NETWORK] = g_netId;
    moduleIds[LAYER_TRANSPORT] = g_transId;
    moduleIds[LAYER_APPLICATION] = g_moduleId;

    g_running = TRUE;
    g_recvNum = 0;
    totalDataLen = 0;

    if (!init_logger(gLogFolder, gLogId, gLogFile, TRUE, moduleIds, 4)) {
        fprintf(stderr, "Unable to init the log module.");
        return FALSE;
    }

    RegistrationResponse serverResponse;
    g_connFd = client_connect(type, LAYER_APPLICATION, moduleIds, &serverResponse, NULL, 0);
    g_coreSharedMemId = serverResponse.coreShareMemId;
    log_info("Key of shared memory by the core: %d", g_coreSharedMemId);

    g_coreSharedData = (CoreSharedData *) shmat(g_coreSharedMemId, NULL, 0);
    if (g_coreSharedData == (CoreSharedData *) - 1) {
        fprintf(stderr, "Unable to attach the shared memory: %s",
                strerror(errno));
        return FALSE;
    }

    logger_set_node_id(g_coreSharedData->macAddr, g_coreSharedData->netAddr);
    log_info("Mac address: %d, net address: %d",
            (int) g_coreSharedData->macAddr, (int) g_coreSharedData->netAddr);

    log_info("APP-TEST g_txmode   = %d", g_txmode);
    log_info("APP-TEST g_blockNum = %d", g_blockNum);
	log_info("APP-TEST g_destNode = %d", g_destNode);
	log_info("APP-TEST g_sendNum  = %d", g_sendNum);

    return TRUE;
}

/**
 * Read configuration file.
 */
static int get_parameters_from_cfgfile()
{
	char *token;
	char local_buff[1000];

	FILE *app_cfg = fopen(g_configFileName, "r");
	//FILE *app_cfg = fopen("config_test_app.cfg", "r");

	if (!app_cfg) {
		logError("No Configuration File found: %s", strerror(errno));
		return -1;
	}

	memset(local_buff, 0, sizeof(local_buff));

	while (fgets(local_buff, sizeof(local_buff), app_cfg)) {
		token = strtok(local_buff, " :");
		if (*token == '#')
			continue;

		if (token == NULL)
			continue;
		g_guardTime = atoi(token);
		token = strtok(NULL, " :");

		if (token == NULL)
			continue;
		g_powerLevel = atoi(token);
		token = strtok(NULL, " :");

		if (token == NULL)
			continue;
		g_interval = atoi(token);
	}

	fclose(app_cfg);

	log_info(">> Begin parameters");
	logInfo("g_guardTime:    %d", g_guardTime);
	logInfo("g_powerLevel:   %d", g_powerLevel);
	logInfo("g_interval:     %d", g_interval);
	log_info(">> End parameters");

	return 1;
}

int getPktLen ()
{
    int length;

    switch (g_txmode) {
    case 1:
        length = 38*g_blockNum;
        break;
    case 2:
        length = 80*g_blockNum;
        break;
    case 3:
        length = 122*g_blockNum;
        break;
    case 4:
        length = 164*g_blockNum;
        break;
    case 5:
        length = 248*g_blockNum;
        break;
    case 11:
        length = 8*g_blockNum;
        break;
    case 12:
        length = 18*g_blockNum;
        break;
    case 21:
        length = 3*g_blockNum;
        break;
    default:
        logError("The txmode is wrong");
    		exit(1);

    }

    log_info("msg_len: %d", length);
    return length;
}

int getPktTxInterval_um()
{
    int time;
    time = (((0.17 + 0.15) * g_blockNum + 0.48 + 0.52)*1000+1500)*1000;
    return time;
}

int MakeSendDataPacket(uint8_t seqNum)
{
	int pktLen = 0;
	struct timeval curtime;
	unsigned long long sendTime;

	char buff[IMSG_MAX_DATA_LENGTH];
	memset(buff, 0, IMSG_MAX_DATA_LENGTH);
	PduBuff *pdu = (PduBuff*)buff;

	ModemInfo *pPhyInfo;
    pPhyInfo = (ModemInfo *)pdu->phy;

	char tmpBuff[IMSG_MAX_DATA_LENGTH];

	PayloadData *msg_data;
	msg_data = (PayloadData *)malloc(sizeof(PayloadData));
	memset(msg_data, 0, sizeof(PayloadData));

	pktLen = getPktLen()-17;
    if(pktLen < 0)
    {
        log_info("pktLen is %d(<0), exit", pktLen);
        exit(0);
    }
	log_info("pktLen: %d", pktLen);
	pdu->msg_len = pktLen;
    if(pktLen < 10)
    {
        memcpy(pdu->pkt_data, &seqNum, 1);
        pdu->msg_len = 1;
        log_info("pktNum: %d", seqNum);
        gettimeofday(&curtime, NULL);
        sendTime = (unsigned long long)curtime.tv_sec * 1000 + curtime.tv_usec / 1000;
        log_info("sendTime: %lld", sendTime);
    }else
    {
        msg_data->sendNum = g_sendNum;
    	msg_data->pktNum  = seqNum;
    	//msg_data->sendTime = time(NULL);
    	gettimeofday(&curtime, NULL);
    	sendTime = (unsigned long long)curtime.tv_sec * 1000 + curtime.tv_usec / 1000;
    	msg_data->sendTime = sendTime;
    	//memset(tmpBuff, 'A', pktLen-(4*sizeof(int)));
    	//memcpy(msg_data->data, tmpBuff, pktLen-(4*sizeof(int)));
    	msg_data->data_len = pdu->msg_len;
    	memset(tmpBuff, 'A', pktLen-(2*sizeof(uint8_t)+sizeof(unsigned long long)));
    	memcpy(msg_data->data, tmpBuff, pktLen-(2*sizeof(uint8_t)+sizeof(unsigned long long)));

    	log_info("sendNum : %d", msg_data->sendNum);
    	log_info("pktNum  : %d", msg_data->pktNum);
    	log_info("sendTime: %d", msg_data->sendTime);
    	log_info("data_len: %d", msg_data->data_len);
    	printf("payload: %s\n", msg_data->data);

    	memcpy(pdu->pkt_data, msg_data, pdu->msg_len);
    }

    pdu->hdr_tra.hdr_len = sizeof(pdu->hdr_tra)-sizeof(pdu->hdr_tra.tra_data);
	pdu->hdr_tra.service_type = g_moduleId;

	pdu->hdr_net.src_addr = g_coreSharedData->netAddr;
	pdu->hdr_net.dst_addr = g_destNode;
	pdu->hdr_net.hdr_len = sizeof(pdu->hdr_net)-sizeof(pdu->hdr_net.net_data);

	pdu->bInternal = 0;

	pPhyInfo->type = Modem_Info_Tx;
	pPhyInfo->tx.phy_param.dst  = -1;
	pPhyInfo->tx.phy_param.src  = -1;
	pPhyInfo->tx.phy_param.mode = g_txmode;
	pPhyInfo->tx.phy_param.type = Modem_Type_DATA;
	pPhyInfo->tx.phy_param.guard_time  = g_guardTime;
	pPhyInfo->tx.phy_param.power_level = g_powerLevel;

	log_send(PKT_DATA,
	         pdu->hdr_net.src_addr,
             pdu->hdr_net.dst_addr,
             pdu->msg_len,
	         "TEST_SEND_DATA");

	client_send_down(g_connFd, pdu, sizeof(PduBuff), g_moduleId, NULL, 0);

	free(msg_data);
	return 1;
}

void *TestSender(void *param)
{
	log_info("APP-TEST Enter into TestSender function!");
	int interval;
	uint8_t i;

	interval = getPktTxInterval_um();
	log_info("interval: %d", interval);
#if 1
	for (i=0; i<g_sendNum; i++){
		MakeSendDataPacket(i);
		if (g_interval == 1) {
		    usleep(interval);
		}
	}
#else
    i = 0;
    while (g_running) {
        MakeSendDataPacket(i);
		usleep(interval);
		i++;
    }
#endif
	return NULL;
}

void processIncomingPkt (PduBuff *pdu)
{
    log_info("TEST_APP Receive data from TRA layer");

    struct timeval curtime;
    gettimeofday(&curtime, NULL);
	unsigned long long recvTime;
    //int now;
    float pkt_loss;
    float data_rate;
    float single_data_rate;
    unsigned long long delay;
    int lostNum;

    log_receive(PKT_DATA,
                pdu->hdr_net.src_addr,
                pdu->hdr_net.dst_addr,
                pdu->msg_len,
                "DATA");
    if(pdu->msg_len == 1)
    {
        uint8_t tmpPktNum = 0;
        memcpy(&tmpPktNum, pdu->pkt_data, 1);
        log_info("pktNum:  %d",tmpPktNum);
        recvTime = (unsigned long long)curtime.tv_sec * 1000 + curtime.tv_usec / 1000;
        log_info("recvtime: %lld", recvTime);
        return;
    }

    PayloadData *recv_msg;
    recv_msg = (PayloadData *)malloc(sizeof(PayloadData));
    memset(recv_msg, 0, sizeof(PayloadData));

    memcpy(recv_msg, pdu->pkt_data, pdu->msg_len);

    log_info("sendNum: %d", recv_msg->sendNum);
    log_info("pktNum:  %d", recv_msg->pktNum);
    printf("payload: %s\n", recv_msg->data);

    if (recv_msg->pktNum == 0) {
        g_recvNum = 0;
        totalDataLen = 0;
    }

    g_recvNum = g_recvNum + 1;

    log_info("Total Packets Number: %d", recv_msg->sendNum);
    log_info("recvNum/sendNum:      %d/%d", g_recvNum, recv_msg->pktNum+1);
    lostNum = recv_msg->pktNum+1-g_recvNum;
    log_info("lostNum:              %d", lostNum);
    pkt_loss = (float)((lostNum*1.0)/(recv_msg->pktNum+1));
    log_info("Paket Loss Rate:      %.2f", pkt_loss);
	recvTime = (unsigned long long)curtime.tv_sec * 1000 + curtime.tv_usec / 1000;
    //delay = now - recv_msg->sendTime;
    delay = recvTime - recv_msg->sendTime;
    log_info("Pkt delay:            %lld ms", delay);
    single_data_rate = (float)(pdu->msg_len*8/(delay/1000.0));
    log_info("Single Pkt Rate:      %.3f bps", single_data_rate);
#if 0
    //now = time(NULL);
    gettimeofday(&curtime, NULL);
	recvTime = (unsigned long long)curtime.tv_sec * 1000 + curtime.tv_usec / 1000;
    //delay = now - recv_msg->sendTime;
    delay = recvTime - recv_msg->sendTime;
    log_info("Total delay:          %lld ms", delay);
    data_rate = (float)(pdu->msg_len*8/(delay/1000.0));
    log_info("User Data Rate:       %.2f bps", data_rate);
#else
    if (g_recvNum == 1) {
        gettimeofday(&firstRT, NULL);
	    firstRecvTime = (unsigned long long)firstRT.tv_sec * 1000 + firstRT.tv_usec / 1000;

	    gettimeofday(&curtime, NULL);
	    recvTime = (unsigned long long)curtime.tv_sec * 1000 + curtime.tv_usec / 1000;
        delay = recvTime - recv_msg->sendTime;
        log_info("Total delay:          %lld ms", delay);
        data_rate = (float)(pdu->msg_len*8/(delay/1000.0));
        log_info("User Data Rate:       %.3f bps", data_rate);

    } else {
        gettimeofday(&curtime, NULL);
	    recvTime = (unsigned long long)curtime.tv_sec * 1000 + curtime.tv_usec / 1000;
	    totalDataLen = totalDataLen + pdu->msg_len;
	    delay = recvTime - firstRecvTime;
	    log_info("Total delay:          %lld ms", delay);
	    data_rate = (float)(totalDataLen*8/(delay/1000.0));
	    log_info("User Data Rate:       %.3f bps", data_rate);
    }
#endif
    free(recv_msg);
}

void start_listener(void)
{
    char buffer[IMSG_MAX_DATA_LENGTH];
    InternalMessageHeader dataHeader;
    PduBuff *pbuf = (PduBuff *) buffer;

    int nBytesRead;

	log_info("###Enter int TEST_APP start_listener###");
    while (g_running) {
        nBytesRead = client_read(g_connFd, buffer, IMSG_MAX_DATA_LENGTH, &dataHeader, NULL, 0);

        if (nBytesRead == -1) {
            log_error("System error occurred");
            break;
        }
        if (nBytesRead == -2) {
            log_warning("Data was not successfully received");
            continue;
        }
        if (nBytesRead == 0) {
            logInfo("Connection closed by the core module");
            break;
        }

        if (from_lower_layer(dataHeader)) {
			processIncomingPkt(pbuf);
        } else if (from_upper_layer(dataHeader)) {
            log_warning("There is no layer higher than this one");
        } else {
            log_error("Packet state error");
            continue;
        }
    }
}


/**
 * Main program.
 *
 * @param argc Number of parameters.
 * @param argv Array of parameters.
 */
int main(int argc, char ** argv)
{
# if 1
	atexit(clean_up);
    signal(SIGINT, signal_handler);

    if (!parse_arguments(argc, argv)) {
        print_usage(argv[0]);
        return EXIT_FAILURE;
    }

    if (!init_test()) {
        return EXIT_FAILURE;
    }
#endif
    get_parameters_from_cfgfile();
#if 1
    int isSender = g_destNode;

	log_info("APP-TEST isSender = %d in main function", isSender);

    pthread_t sendThreadId;
    if (isSender > 0) {
		log_info("Enter sending mode");
        pthread_create(&sendThreadId, NULL, TestSender, NULL);
        pthread_join(sendThreadId, NULL);
    } else {
        log_info("Enter Receiving mode");
        start_listener();
    }

    return EXIT_SUCCESS;
#endif
}
