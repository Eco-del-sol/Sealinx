#!/bin/bash
echo "autoreconfig ..."
autoreconf -i --force --verbose

echo "Building PC version"
./configure

make clean
make
make install
 
