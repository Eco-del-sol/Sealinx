/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author son
 */

#ifndef __SEALINX_UTILS_H__
#define __SEALINX_UTILS_H__

#include <stdint.h>

#define max(a, b) ((a) < (b) ? (b) : (a))

#ifdef	__cplusplus
extern "C" {
#endif

	uint32_t sl_crc32(const char *s, uint32_t len);
	char *strnstr(const char *s, const char *find, size_t slen);
	char *strInMem(const char *mem, const char *str, size_t slen);
	void md2(const unsigned char *input, int ilen,
		 unsigned char output[16]);
	int msleep(unsigned long milisec);
	int mkpath(const char *path, mode_t mode);
	int simplify_path(char *path);
	char *find_cmd_term(char *, int);
	int simplify_dir_path(char *path);
	void print_ver(void);

#ifdef	__cplusplus
}
#endif
#endif
