/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * OFDM modem driver.
 *
 * @author son
 */  
    
#ifndef __SEALINX_OFDM_CMD_H__
#define __SEALINX_OFDM_CMD_H__
    
#define DEFAULT_CONN_FILE_NAME "config_conn.cfg"
    
#define DEFAULT_CFG_FILE_NAME "config_ofdm.cfg"
    
/** ID of OFDM modem driver. */ 
#define OFDM_DRIVER_ID 22
    
/** Default log identity for this module. */ 
#define DEFAULT_LOG_ID "PHY_OFDM"
    
/** Default path to the folder consisting log files. */ 
#define DEFAULT_LOG_FOLDER "logs/"
    
#endif	/* __SEALINX_OFDM_CMD_H__ */
