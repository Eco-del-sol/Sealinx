/**
 * Two level network TRA layer.
 * Unpack jumbo packets to transport
 * Pack jumbo packets depend of different src_node
 * Select retransmission
 *
 * @Author  Jifeng Zhu
 * @Date    2020-03-05
 * @Version 0.1
 */

#include <sys/socket.h>
#include <sys/select.h>
#include <sys/un.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <glib.h>
#include <signal.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <err.h>
#include <sealinx.h>
#include <sys/time.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/shm.h>

#include <sealinx.h>
#include <sealinx_utils.h>
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>
#include <sealinx_log.h>
#include <sealinx_defs.h>
#include <modem_info.h>

#include "list.h"
#include "sealinx-tra-tln.h"


/** Log identity for this module. */
char *gLogId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char *gLogFolder = DEFAULT_LOG_FOLDER;

/** File descriptor of the connection to the core. */
int g_connFd;

/** ID of the current module. */
ModuleId g_moduleId;

/** ID of the MAC module. */
ModuleId g_macId;

/** ID of the network module. */
ModuleId g_netId;

/** Shared data by the core module. */
CoreSharedData *g_coreSharedData;

/** ID of the shared memory by the core. */
int g_coreSharedMemId;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 0;

/** Name of the configure file. */
char *g_cfgFileName;

int g_running;

enum States {
    IDLE     = 0,
    TRANSFER = 1,
    ACK      = 2, 
    DONE     = 3,
    ERROR    = 4
};

struct _Packet {
	DatPacket packet;
    char bReceived;
};

struct TraController {
    struct list_head node;
    enum States state;
    uint32_t remote_net_addr;
    uint32_t origin_net_addr;
    uint32_t service_type;
    uint32_t app_unpack_flag;
    uint32_t tra_unpack_flag;
    uint32_t pkt_type;
    uint32_t tx_mode;
    uint32_t group;
    uint32_t n_packets;
    struct _Packet *packets;
};

static LIST_HEAD(gs_senders);
static LIST_HEAD(gs_receivers);
static uint32_t gs_group;

int g_getMacReqNxtGrp;
int TIMEOUT_SAFE_MARGIN;
int TARGET_BSID;
int g_blockNum;

uint8_t g_senderDstAddr;
uint8_t g_bsFlag;


/*for test the group capacity 0xFF and 0xFFFF*/
#define packetIsNotOfReceiverGroup(sr, g)       \
    (((sr)->group < (g)) || (((g) == 0) && ((sr)->group == 0xFF)))


static int printTraHdrInfo (PduBuff *pbuf) 
{
    log_info("Print Tra Layer Header Information");
    TraInfo *ti = (TraInfo *)pbuf->hdr_tra.tra_data;
    log_info("Tra_Hdr_Len:   %d", pbuf->hdr_tra.hdr_len);
    log_info("Tra_Type:      %d", pbuf->hdr_tra.tra_type);
    log_info("Tra_Ser_Type:  %d", pbuf->hdr_tra.service_type);
    log_info("Tra_appUnpack: %d", ti->appUnpack);
    log_info("Tra_traUnpack: %d", ti->traUnpack);
    return 1;
}

static int processNxtGroupUnpackPkt (struct TraController *sender, uint8_t targetNodeId);
static struct TraController *find_traController_sender(struct list_head *queue, uint32_t nid);

/**
 * Clean up allocated resources.
 */
static void clean_up(void)
{
	int type = 0;
    log_info("Cleaning up ...");

    if (g_connFd > -1)
        client_close(type, g_connFd, NULL, 0);

    if (g_coreSharedData) {
        int rc = shmdt(g_coreSharedData);
        if (rc == -1)
            log_error("Unable to detach shared data: %s", strerror(errno));
    }

	close_logger();
}

/**
 * Signal handler.
 *
 * @param sig Signal ID.
 */
static void signal_handler(int sig)
{
	int type = 0;
    log_info("Received signal (%d)", sig);

    g_running = FALSE;

    if (g_connFd > -1) {
        client_close(type, g_connFd, NULL, 0);
        g_connFd = -1;
    }
}

/**
 * Parse command line arguments.
 *
 * @param argc Number of arguments
 * @param argv The arguments
 * @return TRUE if the argument can be parse; FALSE, otherwise.
 */
static int parse_arguments(int argc, char **argv)
{
	int c;
    int moduleId;
    int macId;
    int netId;

	while ((c = getopt (argc, argv, "i:m:n:c:f:v")) != -1) {
        switch (c) {
        case 'i':
        	moduleId = atoi(optarg);
            if (moduleId > MAX_MODULE_ID || moduleId < MIN_MODULE_ID) {
                fprintf(stderr, "Invalid module ID (%s)\n", optarg);
                return FALSE;
            }
            g_moduleId = moduleId;
            break;

        case 'm':
        	macId = atoi(optarg);
            if (macId > MAX_MODULE_ID || macId < MIN_MODULE_ID) {
                fprintf(stderr, "Invalid module ID (%s)\n", optarg);
                return FALSE;
            }
            g_macId = macId;
            break;

        case 'n':
        	netId = atoi(optarg);
            if (netId > MAX_MODULE_ID || netId < MIN_MODULE_ID) {
                fprintf(stderr, "Invalid module ID (%s)\n", optarg);
                return FALSE;
            }
            g_netId = netId;
            break;

        case 'c':
        	g_cfgFileName = optarg;
            break;

        case 'f':
        	gLogFile = atoi(optarg);
            break;

		case 'v':
			log_info("build time: %s %s", __DATE__, __TIME__);
			log_info("SEALINX_VERSION: %s", SEALINX_VERSION);
			exit(0);

		case '?':
			return FALSE;
		}
	}
	
	return g_moduleId >= MIN_MODULE_ID && g_moduleId <= MAX_MODULE_ID && 
	       g_macId >= MIN_MODULE_ID && g_macId <= MAX_MODULE_ID && 
	       g_netId >= MIN_MODULE_ID && g_netId <= MAX_MODULE_ID;
}

/**
 * Print the usage of the program.
 */
static void print_usage(const char *progName)
{
	printf("USAGE: %s "
	       "-i <module id> -m <mac protocol id> -n <network protocol id> [-f <log file outoput flag>]\n",
	       progName);
}

/**
 * Initialize the program.
 */
static int init_tra_tln(void)
{
	int type = 0;
	ModuleId moduleIds[NUM_LAYERS];
	moduleIds[LAYER_MAC] = g_macId;
	moduleIds[LAYER_NETWORK] = g_netId;
	moduleIds[LAYER_TRANSPORT] = g_moduleId;
	
	if (!init_log(gLogFolder, gLogId, gLogFile, TRUE, g_moduleId)) {
		fprintf(stderr, "Unable to init the log module.");
		return FALSE;
	}
	
	RegistrationResponse serverResponse;
	
	g_connFd = client_connect(type, LAYER_TRANSPORT, moduleIds, &serverResponse, NULL, 0);
	
	g_coreSharedMemId = serverResponse.coreShareMemId;
	
	log_info("Key of shared memory by the core: %d", g_coreSharedMemId);

	g_coreSharedData = (CoreSharedData *) shmat(g_coreSharedMemId, NULL, 0);
	if (g_coreSharedData == (CoreSharedData *) - 1) {
		fprintf(stderr, "Unable to attach the shared memory: %s",
			strerror(errno));
		return FALSE;
	}
	
	g_running = 1;
	
	logger_set_node_id(g_coreSharedData->macAddr, g_coreSharedData->netAddr);
	log_info("Mac address: %d, net address: %d", (int)g_coreSharedData->macAddr, 
                                                 (int)g_coreSharedData->netAddr);
	
	if ((g_coreSharedData->netAddr)%10 == 9) {
	    log_info("This Node is BaseStation");
	    g_bsFlag = 1;
	} else {
	    log_info("This Node is Terminal");
	    g_bsFlag = 0;
	}
	
	return TRUE;
}

/** 
 * Get MAC_PACKET_SLOT_DURATION, TIMEOUT_SAFE_MARGIN and TOTAL_NODES from config file
 */
static int getParamFromCfgfile()
{
	char *token;
	char *param_name;
	char local_buff[1000];
	
	FILE *tra_cfg = fopen(g_cfgFileName, "r");
	
	if (!tra_cfg) {
		logError("No Configure File Found %s", strerror(errno));
		return -1;
	}
	
	memset(local_buff, 0, sizeof(local_buff));
	
	while (fgets(local_buff, sizeof(local_buff), tra_cfg)) {
		token = strtok(local_buff, " :");
		if (*token == '#')
			continue;
		if (token == NULL)
			continue;
		g_getMacReqNxtGrp = atoi(token);
		
		token = strtok(NULL, " :");
		if (token == NULL)
			continue;
		TIMEOUT_SAFE_MARGIN = atoi(token);
		
		token = strtok(NULL, " :");
		if (token == NULL)
			continue;
		TARGET_BSID = atoi(token);
		
		token = strtok(NULL, " :");
		if (token == NULL)
			continue;
		g_blockNum = atoi(token);
	}
	
	fclose(tra_cfg);
	
	logInfo("GET_MAC_REQ   : %d", g_getMacReqNxtGrp);       //-1: ignore request, 1: process request
	logInfo("SAFE_MARGIN   : %d", TIMEOUT_SAFE_MARGIN);
    logInfo("TARGET_BSID   : %d", TARGET_BSID);
	logInfo("BLOCK_NUM     : %d", g_blockNum);
	
	return 1;
}

/**
 * Get the max packet size based on the tx_mode.
 */
static int getMaxPktLen (int tx_mode)
{
    int length;
    
    switch (tx_mode) {
    case 1:
        length = 38*g_blockNum;
        break;
    case 2:
        length = 80*g_blockNum;
        break;
    case 3:
        length = 122*g_blockNum;
        break;
    case 4:
        length = 164*g_blockNum;
        break;
    case 5:
        length = 248*g_blockNum;
        break;
    case 11:
        length = 8*g_blockNum;
        break;
    case 12:
        length = 18*g_blockNum;
        break;
    case 21:
        length = 3*g_blockNum;
        break;
    default:
        logError("The txmode is wrong");
            exit(1);
    }
    
    log_info("Max Pkt Len: %d", length);
    return length;
}

/*
 * Sender fucntions
 */
static struct TraController *sender_create(PduBuff *pdu)
{
    uint32_t nid;
    uint32_t oid;
    uint32_t service_type;
    uint32_t app_unpack_flag;
    uint32_t tra_unpack_flag;
    uint32_t pkt_type;
    uint32_t txmode;
    uint32_t n_packets;
    uint8_t *data;
    int len;
    
    struct TraController *sender;
    int i;
    int MaxPktSize;
    
    ModemInfo *pPhyInfo = (ModemInfo *)pdu->phy;
    TraInfo *ti = (TraInfo *) pdu->hdr_tra.tra_data;
    ProtocolInfo *pi = (ProtocolInfo *) pdu->hdr_net.net_data;
    
    nid = pdu->hdr_net.dst_addr;
    oid = pdu->hdr_net.src_addr;
    service_type = pdu->hdr_tra.service_type;
    data = pdu->pkt_data;
    len = pdu->msg_len;
    app_unpack_flag = ti->appUnpack;
    tra_unpack_flag = ti->traUnpack;
    pkt_type = pi->pktType;
    txmode = pPhyInfo->tx.phy_param.mode;
    MaxPktSize = getMaxPktLen(txmode);
    n_packets = (len + MaxPktSize - 1) / MaxPktSize;

    sender = malloc(sizeof(struct TraController));
    if (!sender) {
        log_info("-----sender malloc error-------------");
        return NULL;
    }
        

    sender->packets = malloc(n_packets * sizeof(struct _Packet));
    if (!sender->packets) {
        log_info("++++++++++++++sender malloc error++++++++++++++++");
        goto free_sender;
    }
        
    
    sender->remote_net_addr = nid;
    sender->origin_net_addr = oid;
    sender->service_type    = service_type;
    sender->app_unpack_flag = app_unpack_flag;
    sender->tra_unpack_flag = tra_unpack_flag;
    sender->pkt_type        = pkt_type;
    sender->tx_mode         = txmode;
    sender->group           = gs_group ++;
    sender->n_packets       = n_packets;
    for (i=0; i<sender->n_packets; i++) {
        DatPacket *pkt = &sender->packets[i].packet;
        pkt->id = i;
        pkt->Nid = ~i;
        pkt->n_pkt_left = n_packets-1 - i;
        pkt->current_pkt_len = (i == sender->n_packets-1) ? len - i*MaxPktSize : MaxPktSize;
        pkt->group = sender->group;
        memcpy(pkt->payload, &data[i*MaxPktSize], pkt->current_pkt_len);
        sender->packets[i].bReceived = 0;
    }
    
    sender->state = IDLE;

    return sender;

free_packets:
    free(sender->packets);
free_sender:
    free(sender);
    return NULL;
}

/**
 * Sender send packets
 * return: 0 if succeed otherwise -1 
 */
static int sender_transfer_packets(struct TraController *sender)
{
    int i;

    char buff[IMSG_MAX_DATA_LENGTH];
    memset(buff, 0, IMSG_MAX_DATA_LENGTH);
    PduBuff *pdu = (PduBuff*)buff;
    
    g_senderDstAddr = sender->remote_net_addr;
    
    for (i=0; i<sender->n_packets; i++) {
        if (!sender->packets[i].bReceived) {
            /* add net header info */
            pdu->hdr_net.src_addr = sender->origin_net_addr;
            pdu->hdr_net.dst_addr = sender->remote_net_addr;
            ProtocolInfo *pi = (ProtocolInfo *)pdu->hdr_net.net_data;
            pi->pktType = sender->pkt_type;
            
            /* add tra header info */
            pdu->hdr_tra.hdr_len = sizeof(pdu->hdr_tra)
                                 - sizeof(pdu->hdr_tra.tra_data)
                                 + sizeof(TraInfo);
            pdu->hdr_tra.tra_type = g_moduleId;
            pdu->hdr_tra.service_type = sender->service_type;
            TraInfo *ti = (TraInfo *)pdu->hdr_tra.tra_data;
            ti->appUnpack = sender->app_unpack_flag;
            ti->traUnpack = sender->tra_unpack_flag;            
            
            pdu->msg_len = GetDatPacketSize(&sender->packets[i].packet);
            memcpy(pdu->pkt_data, &sender->packets[i].packet, pdu->msg_len);
                
            logInfo("SENDER PACKETS | GROUP:%d | PKT ID:%d | TOTAL:%d | PKT SIZE:%d ", 
                                            sender->group, i, sender->n_packets, pdu->msg_len);
            
            pdu->bInternal = 0;

            ModemInfo *pPhyInfo = (ModemInfo *)pdu->phy;
            pPhyInfo->type = Modem_Info_Tx;
            pPhyInfo->tx.phy_param.dst  = -1;
            pPhyInfo->tx.phy_param.src  = -1;
            pPhyInfo->tx.phy_param.mode = sender->tx_mode;
            pPhyInfo->tx.phy_param.type = Modem_Type_DATA;
            pPhyInfo->tx.phy_param.guard_time  = -1;
            pPhyInfo->tx.phy_param.power_level = -1;
            
            log_send(PKT_DATA,
                     pdu->hdr_net.src_addr,
                     pdu->hdr_net.dst_addr,
                     pdu->msg_len+pdu->hdr_tra.hdr_len,
                     "DATA");
            
            /* send the group of packets down */
            client_send_down(g_connFd, pdu, sizeof(PduBuff), g_moduleId, NULL, 0);
        }
    }
    return 0;
}

/**
 * Sender behavior 
 */
static int sender_run(struct TraController *sender)
{
    logInfo("Enter Sender Run, sender->state:%d, sender->n_packets:%d", sender->state, sender->n_packets);
    
    switch (sender->state) {
    case IDLE:
        if (sender->n_packets)
            sender->state = TRANSFER;

    case TRANSFER:
        logInfo("TRANSFER---sender->state:%d", sender->state);
        sender_transfer_packets(sender);
        log_info("send DONE");
        sender->state = ACK;
        
        if (g_getMacReqNxtGrp == -1) {
            /* TODO: ignore the request next group data cmd, and tx next group directly*/
            usleep(100*1000);
            processNxtGroupUnpackPkt(sender, g_senderDstAddr);
        }
        
        break;
    
    case ACK:
        logInfo("ACK---sender->state:%d", sender->state);
        sender->state = DONE;
        break;
    
    case DONE:
        logInfo("DONE---sender->state:%d", sender->state);
        break;
    
    case ERROR:
        logInfo("ERROR---sender->state:%d", sender->state);
        break;
    
    default:
        sender->state = ERROR;
    }

    return sender->state;
}

/** 
 * Process packet which need to be unpacked.
 */
static int processUnpackPkt (struct TraController *sender, PduBuff *pbuf)
{
    logInfo("Process packet need to be Unpacked.");

    int start_now;
    start_now = list_empty(&gs_senders);
    
    sender = sender_create(pbuf);
    if (!sender) {
        log_error("Failed to create sender: %d\n", pbuf->msg_len);
        return FALSE;
    }
    
    list_add_tail(&sender->node, &gs_senders);
    if (start_now) {
        sender_run(sender);
    }

    return TRUE;
}

/**
 * service type with one group of packets from the same net id does not change
 */
static struct TraController *find_traController_recver(struct list_head *queue, uint32_t nid, int groupId)
{
    struct TraController *target, *iter;

    list_for_each_entry(iter, queue, node) {
        if ((iter->remote_net_addr == nid) && (iter->group == groupId)) {
            return iter;
        }
    }
    return NULL;
}

static struct TraController *find_traController_sender(struct list_head *queue, uint32_t nid)
{
    struct TraController *target, *iter;
    
    list_for_each_entry(iter, queue, node) {
        if ((iter->remote_net_addr == nid)) {
            return iter;
        }
    }
    return NULL;
}

/*
 * Receiver functions
 */
static struct TraController *receiver_create(PduBuff *pbuf, DatPacket *dpkt)
{
    int i;
    uint32_t nid;
    uint32_t oid;
    uint32_t service_type;
    uint32_t app_unpack_flag;
    uint32_t tra_unpack_flag;
    uint32_t pkt_type;
    uint32_t group;
    uint32_t n_packets;
    struct TraController *receiver;

    nid             = pbuf->hdr_net.src_addr;
    oid             = pbuf->hdr_net.dst_addr;
    service_type    = pbuf->hdr_tra.service_type;
    app_unpack_flag = pbuf->hdr_tra.tra_data[0];
    tra_unpack_flag = pbuf->hdr_tra.tra_data[1];
    pkt_type        = pbuf->hdr_net.net_data[0];
    group           = dpkt->group;
    n_packets       = GetTotalPackets(dpkt);

    receiver = malloc(sizeof(*receiver));
    if (!receiver)
        return NULL;
    memset(receiver, 0, sizeof(*receiver));
    
    receiver->packets = malloc(n_packets * sizeof(*receiver->packets));
    if (!receiver->packets)
        goto free_receiver;
    memset(receiver->packets, 0, n_packets * sizeof(*receiver->packets));
    
    receiver->remote_net_addr = nid;
    receiver->origin_net_addr = oid;
    receiver->service_type    = service_type;
    receiver->app_unpack_flag = app_unpack_flag;
    receiver->tra_unpack_flag = tra_unpack_flag;
    receiver->pkt_type        = pkt_type;
    receiver->group           = group;
    receiver->n_packets       = n_packets;
    for (i=0; i<receiver->n_packets; i++)
        receiver->packets[i].bReceived = 0;
    
    receiver->state = IDLE;
    
    return receiver;

free_packets:
    free(receiver->packets);
free_receiver:
    free(receiver);
    return NULL;
}

static int receiver_newTransfer(struct TraController *receiver, PduBuff *pbuf, DatPacket *dpkt)
{
    int i;
    uint32_t service_type;
    uint32_t app_unpack_flag;
    uint32_t tra_unpack_flag;
    uint32_t pkt_type;
    uint32_t group;
    uint32_t n_packets;

    service_type    = pbuf->hdr_tra.service_type;
    app_unpack_flag = pbuf->hdr_tra.tra_data[0];
    tra_unpack_flag = pbuf->hdr_tra.tra_data[1];
    pkt_type        = pbuf->hdr_net.net_data[0];
    group           = dpkt->group;
    n_packets       = GetTotalPackets(dpkt);

    free(receiver->packets);
    receiver->packets = malloc(n_packets * sizeof(*receiver->packets));
    if (!receiver->packets)
        goto free_receiver;
    memset(receiver->packets, 0, n_packets * sizeof(*receiver->packets));

    receiver->service_type   = service_type;
    receiver->app_unpack_flag = app_unpack_flag;
    receiver->tra_unpack_flag = tra_unpack_flag;
    receiver->pkt_type        = pkt_type;
    receiver->group           = group;
    receiver->n_packets       = n_packets;
    for (i=0; i<receiver->n_packets; i++)
        receiver->packets[i].bReceived = 0;
    
    receiver->state = IDLE;
    
    return 0;

free_receiver:
    free(receiver);
    return -1;
}

/* Return: 
 * 1 if all packets after the incoming one have been received.
 * otherwise 0  
 */
static int receiver_process_packet(struct TraController *receiver, DatPacket *pkt)
{
    int id, i, bAllReceived = 1;
    
    if (!ValidatePacket(pkt))
        return -1;

    id = pkt->id; 
    if (!receiver->packets[id].bReceived) {
        memcpy(&receiver->packets[id].packet, pkt, GetDatPacketSize(pkt));
        receiver->packets[id].bReceived = 1;
    }
    
    for (i=0; i<receiver->n_packets; i++) {
        if (!receiver->packets[i].bReceived) {
            bAllReceived = 0;
            break;
        }
    }
    
    return bAllReceived;
}

/*
 * Receiver's state machine
 * Return: 0 if no error; 1 if tranfer done, otherwise -1;
 */
static int receiver_run(struct TraController *receiver, DatPacket *pkt)
{
    int bAllReceived;

    switch (receiver->state) {
    case IDLE:
        logInfo("IDLE---receiver->state:%d", receiver->state);
        if (pkt)
            receiver->state = TRANSFER;
            /* Intentionally leave out 'break' */
    
    case TRANSFER:
        logInfo("TRANSFER---receiver->state:%d", receiver->state);
        bAllReceived = receiver_process_packet(receiver, pkt);
        if (!bAllReceived) /* receive all packets of same group*/
            break;
        /* else: going directly into state ACK*/
    case DONE: /* in state DONE, receiver's still sending ACK if there is incomming packet*/
        logInfo("DONE---receiver->state:%d", receiver->state);
    
    case ACK:
        logInfo("ACK---receiver->state:%d", receiver->state);
        receiver->state = DONE;
        break;
    
    case ERROR:
        logInfo("ERROR---receiver->state:%d", receiver->state);
        break;
    
    default:
        receiver->state = ERROR;
    }

    return receiver->state;
}

/**
 * Pack packet and send up to app layer.
 */
static int receiver_report_data(struct TraController *receiver, PduBuff *pdu)
{
    int i;
/*
    char buff[IMSG_MAX_DATA_LENGTH];
    memset(buff, 0, IMSG_MAX_DATA_LENGTH);
    PduBuff *pdu = (PduBuff*)buff;
*/
    pdu->hdr_net.src_addr = receiver->remote_net_addr;
    pdu->hdr_net.dst_addr = receiver->origin_net_addr;
    ProtocolInfo *pi = (ProtocolInfo *)pdu->hdr_net.net_data;
    pi->pktType = receiver->pkt_type;
    pdu->hdr_net.hdr_len  = sizeof(pdu->hdr_net)
                          - sizeof(pdu->hdr_net.net_data)
                          + sizeof(ProtocolInfo);
    
    pdu->hdr_tra.tra_type = g_moduleId;
    pdu->hdr_tra.service_type = receiver->service_type;
    TraInfo *ti = (TraInfo *)pdu->hdr_tra.tra_data;
    ti->appUnpack = receiver->app_unpack_flag;
    ti->traUnpack = receiver->tra_unpack_flag;
    pdu->hdr_tra.hdr_len = sizeof(struct type_tra_hdr)
                         - sizeof(pdu->hdr_tra.tra_data)
                         + sizeof(TraInfo);
    
    memset(pdu->pkt_data, 0, MAX_DATA_PAYLOAD_SIZE);
    pdu->msg_len = 0;
    for (i=0; i<receiver->n_packets; i++) {
        memcpy(&pdu->pkt_data[pdu->msg_len], receiver->packets[i].packet.payload, 
                    receiver->packets[i].packet.current_pkt_len);
        pdu->msg_len += receiver->packets[i].packet.current_pkt_len;
    }
    
    log_receive(PKT_DATA,
                pdu->hdr_net.src_addr,
                pdu->hdr_net.dst_addr,
                pdu->msg_len+pdu->hdr_tra.hdr_len,
                "DATA");
    
    client_send_up(g_connFd, pdu, sizeof(PduBuff), g_moduleId, NULL, 0);
    return 0;   
}

/** 
 * Service type with one group of packets from the same net id does not change
 */
static int remove_traController(struct list_head *queue, struct TraController *target)
{
    struct TraController *iter;

    list_for_each_entry(iter, queue, node) {
        if (iter == target) {
            list_del(&target->node);
            return 0;
        }
    }
    return -1;
}

static void receiver_delete(struct TraController *receiver)
{
    free(receiver->packets);
    free(receiver);
}

static void sender_delete(struct TraController *sender)
{
    free(sender->packets);
    free(sender);
}

/**
 * Process packet which need to be packed. 
 */
static int processPackPkt (struct TraController *receiver, PduBuff *pbuf)
{
    logInfo("Process packet need to be packed.");

    int bReport;
    int ret;

    DatPacket *dpkt = (DatPacket *)pbuf->pkt_data;

    receiver = find_traController_recver(&gs_receivers, pbuf->hdr_net.src_addr, dpkt->group);
    logInfo("RECEIVER PACKETS | GROUP:%d | ID:%d | LEFT:%d | PKT SIZE:%d", 
                                dpkt->group, dpkt->id, dpkt->n_pkt_left, pbuf->msg_len);
    
    if (!receiver) {
        receiver = receiver_create(pbuf, dpkt);
        list_add_tail(&receiver->node, &gs_receivers);
    } 
/*
    else if (packetIsNotOfReceiverGroup(receiver, dpkt->group)) {
        //the send has been working on the next group, the receiver must be in DONE 
        receiver_newTransfer(receiver, pbuf, dpkt); 
    }
*/
    bReport = !(receiver->state == DONE);
    ret = receiver_run(receiver, dpkt);
    if (ret == DONE && bReport) {
        logInfo("RECEIVER DONE");
        receiver_report_data(receiver, pbuf);
        remove_traController(&gs_receivers, receiver);
        receiver_delete(receiver);
        return 1;
    } else if (ret == ERROR) {
        log_error("RECEIVER ERROR");
        remove_traController(&gs_receivers, receiver);
        receiver_delete(receiver);
        return 1;
    }
}

/**
 * Process packet which do not need to be packed. 
 */
static int processNxtGroupUnpackPkt (struct TraController *sender, uint8_t targetNodeId)
{
    logInfo("Process REQ_TX_NEXT_DATA");
    int ret;

    log_info("----------------------------targetNodeId %d", targetNodeId);
    sender = find_traController_sender(&gs_senders, targetNodeId);

    if (!sender) {
        log_info("Cannot find next group");
        return 0;
    }

    ret = sender_run(sender);
    if (ret == DONE) {
        logInfo("SENDING DONE");
        remove_traController(&gs_senders, sender);
        sender_delete(sender);
        if (!list_empty(&gs_senders)) { /* another round */
            sender = list_first_entry(&gs_senders, struct TraController, node);
            sender_run(sender);
        }
    } else if (ret == ERROR) {
        log_error("SENDING ERROR");
    }

    return 1;
}

/**
 * Listen from core 
 */
static void *listen_from_core(void *param)
{
    char buffer[IMSG_MAX_DATA_LENGTH];
    InternalMessageHeader dataHeader;
    PduBuff *pbuf;
    ProtocolInfo *pi;
    TraInfo *ti;
    ModemInfo *pPhyInfo;

    struct TraController *sender, *receiver;
    int nBytesRead;
    int maxPktSize;
    int txMode;  

    while (g_running) {
        memset(buffer, 0, IMSG_MAX_DATA_LENGTH);
        nBytesRead = client_read(g_connFd, buffer, IMSG_MAX_DATA_LENGTH, &dataHeader, NULL, 0);
        if (nBytesRead == -1) {
            log_error("System error occurred");
            break;
        }
        if (nBytesRead == -2) {
            log_warning("Data was not successfully received");
            continue;
        }
        if (nBytesRead == 0) {
            logInfo("Connection closed by the core module");
            break;
        }
        if (nBytesRead > 0) {
            pbuf = (PduBuff *)buffer;
            ti = (TraInfo *) pbuf->hdr_tra.tra_data;
            pi = (ProtocolInfo *) pbuf->hdr_net.net_data;
            pPhyInfo = (ModemInfo *)pbuf->phy;
        }
        
        if (from_upper_layer(dataHeader)) {
            log_info("----Receive DATA FROM APP LAYER----");

            if ((ti->appUnpack==1) && (ti->traUnpack==1)) {
                /* Unpack in app layer, must unpack in tra layer. */
                processUnpackPkt(sender, pbuf);
            } else {
                /* Not unpack in app layer, judging the payload length. */
                if (pbuf->bInternal == 0) {
                    txMode = pPhyInfo->tx.phy_param.mode;
                    log_info("Tx_Mode from Up layer: %d", txMode);
                    maxPktSize = getMaxPktLen(txMode);
                    
                    if (pbuf->msg_len > maxPktSize) {
                        /* TODO: unpack the payload and send down. */
                        ti->traUnpack = 1;
                        processUnpackPkt(sender, pbuf);
                    } else {
                        /* TODO: send pbuf down directly. */
                        ti->traUnpack = 0;
                        pbuf->hdr_tra.hdr_len = sizeof(pbuf->hdr_tra)
                                              - sizeof(pbuf->hdr_tra.tra_data)
                                              + sizeof(TraInfo);
                        pbuf->hdr_tra.tra_type = g_moduleId;
                        
                        log_send(PKT_DATA,
                                 pbuf->hdr_net.src_addr,
                                 pbuf->hdr_net.dst_addr,
                                 pbuf->msg_len+pbuf->hdr_tra.hdr_len,
                                 "DATA");
                        client_send_down(g_connFd, pbuf, sizeof(PduBuff), g_moduleId, NULL, 0);
                    }
                } else {
                    pbuf->hdr_tra.tra_type = g_moduleId;
                    log_send(PKT_DATA,
                             pbuf->hdr_net.src_addr,
                             pbuf->hdr_net.dst_addr,
                             pbuf->msg_len+pbuf->hdr_tra.hdr_len,
                             "DATA");
                    client_send_down(g_connFd, pbuf, sizeof(PduBuff), g_moduleId, NULL, 0);
                }
            }
        } else if (from_lower_layer(dataHeader)) {
            log_info("----Receive DATA FROM NET LAYER----");
            //printTraHdrInfo(pbuf);
            
            if (ti->traUnpack == 1) {
                /* TODO: pack the payload and send up. */
                processPackPkt(receiver, pbuf);
            } else {
                if (pi->pktType == REQ_TX_NEXT_DATA) {
                    if (g_getMacReqNxtGrp == 1) {
                        /* need to process request next unpacked packet cmd. */
                        //processNxtGroupUnpackPkt (sender, pbuf->hdr_net.src_addr);
                        processNxtGroupUnpackPkt (sender, g_senderDstAddr);
                    }
                } else {
                    /* TODO: send pbuf up directly. */
                    logInfo("Packet donot need to be packed.");
                    log_receive(PKT_DATA,
                                pbuf->hdr_net.src_addr,
                                pbuf->hdr_net.dst_addr,
                                pbuf->msg_len+pbuf->hdr_tra.hdr_len,
                                "DATA");
                    client_send_up(g_connFd, pbuf, sizeof(PduBuff), g_moduleId, NULL, 0);
                } 
            }
        } else {
            log_error("Packets state error!");
            continue;
        }
    }
    return NULL;
}

/**
 * Main program.
 *
 * @param argc Number of parameters.
 * @param argv Array of parameters.
 */
int main(int argc, char **argv)
{	
	atexit(clean_up);
	signal(SIGINT, signal_handler);	
	
	if (!parse_arguments(argc, argv)) {
		print_usage(argv[0]);
		return EXIT_FAILURE;
	}
	
	if (!init_tra_tln())
		return EXIT_FAILURE;
		
	getParamFromCfgfile();
	
	pthread_t read_thread_id;
	pthread_create(&read_thread_id, NULL, listen_from_core, NULL);
    pthread_join(read_thread_id, NULL);

    return EXIT_SUCCESS;
}
