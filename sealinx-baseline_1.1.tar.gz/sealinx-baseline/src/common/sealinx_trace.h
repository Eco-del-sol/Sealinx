/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author yibo
 */

#ifndef __SEALINX_TRACE_H__
#define __SEALINX_TRACE_H__

#include "sealinx_log.h"
#include "sealinx_pdu.h"

#ifdef	__cplusplus
extern "C" {
#endif
	void pkt_trace(const char *cmd, char event,
		       unsigned short node_addr, char *layer,
		       int pkt_id, unsigned short src_addr,
		       unsigned short dst_addr,
		       char *packet_type, int pkt_size);

	int getPktSize(struct pdu_buff *packet);

	unsigned short getPktSrc(struct pdu_buff *packet);

	unsigned short getPktDst(struct pdu_buff *packet);

	unsigned short getPktID(struct pdu_buff *packet);

	unsigned short getPktID_APP(char *buf);

#ifdef	__cplusplus
}
#endif
#endif
