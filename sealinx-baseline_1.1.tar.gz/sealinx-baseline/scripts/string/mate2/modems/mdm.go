package modems

import (
	"errors"
	"log"
	"math/rand"
	"strconv"
	"sync"
	"time"

	"github.com/BurntSushi/toml"
	"github.com/looplab/fsm"
	"mate2/com"
)

var (
	hwReadyTime time.Duration = time.Millisecond * 120
	encodeTime  time.Duration = time.Millisecond * 130
	resumeTime  time.Duration = time.Millisecond * 16

	decodeTime time.Duration = time.Millisecond * 260

	preambleTime time.Duration = time.Millisecond * 480
	blockTime    time.Duration = time.Millisecond * 170
)

type waveList map[*com.Wave]bool

// Actives ...
var Actives = make(map[int32]Modem)

// Modem ...
type Modem struct {
	ID         int32
	RangeLimit int32
	Per        map[int32]rate
	GetPktCh   chan com.Packet
	GetWaveCh  chan com.Wave
	waves      waveList
	waveLock   *sync.RWMutex
	FSM        *fsm.FSM
}

// New ...
func New(id int32) (mdm Modem, err error) {
	mdm.ID = id
	mdm.Per = make(map[int32]rate)
	mdm.GetPktCh = make(chan com.Packet, 15) // recv channel, get pkt from adp
	mdm.GetWaveCh = make(chan com.Wave, 15)  // recv channel, get wave from sim
	mdm.waves = make(waveList)               // initialized a pktlist for mdm
	mdm.FSM = fsm.NewFSM(
		"idle",
		fsm.Events{
			{Name: "tx", Src: []string{"idle"}, Dst: "sending"},
			{Name: "rx", Src: []string{"idle"}, Dst: "recving"},
			{Name: "txdone", Src: []string{"sending"}, Dst: "idle"},
			{Name: "rxdone", Src: []string{"recving"}, Dst: "idle"},
		},
		fsm.Callbacks{
			"enter_state": func(e *fsm.Event) { mdm.enterState(e) },
		},
	)
	mdm.waveLock = new(sync.RWMutex)
	if err = mdm.configModem(); err != nil {
		return mdm, err
	}
	return mdm, err
}

func (mdm *Modem) enterState(e *fsm.Event) {
	// log.Printf("\033[37m  MDM%d: state %s --> %s\033[0m",
	// 	mdm.ID, e.Src, e.Dst)
}

func (mdm *Modem) isClean() bool {
	mdm.waveLock.RLock()
	defer mdm.waveLock.RUnlock()
	return len(mdm.waves) == 0
}

func (mdm *Modem) processingWaves() int {
	mdm.waveLock.RLock()
	defer mdm.waveLock.RUnlock()
	return len(mdm.waves)
}

func (mdm *Modem) addWave(wave *com.Wave) {
	mdm.waveLock.Lock()
	defer mdm.waveLock.Unlock()
	mdm.waves[wave] = true
}

func (mdm *Modem) delWave(wave *com.Wave) {
	mdm.waveLock.Lock()
	defer mdm.waveLock.Unlock()
	delete(mdm.waves, wave)
}

// Run ...
func (mdm *Modem) Run(out chan<- com.Packet) { // use send-only channel here??
	// get pkts from GetPkt channel
	go mdm.getPkt()

	// get waves from simulation, GetWave channel
	mdm.getWave(out)
}

// getPkt get packet from adapter and encode packet to wave
func (mdm *Modem) getPkt() {
	for pkt := range mdm.GetPktCh {
		for mdm.FSM.Current() != "idle" {
			// on recving state while !mdm.isClean()
			// **NOTE: ** sleep here just for test
			// avoid seeing excessive output
			// the sending msg will be delay more ...
			// log.Printf("\t\033[33mMDM%d: ** %s **, waitting for send\033[0m",
			// 	mdm.ID, mdm.FSM.Current())
			// time.Sleep(time.Millisecond * 100)
		}
		mdm.FSM.Event("tx")
		if err := mdm.processPkt(&pkt); err != nil { // calc pkt times
			log.Println(err)
			continue
		}
		sendTime := hwReadyTime + encodeTime + pkt.TimeLen + resumeTime
		log.Printf("\t\033[33mMDM%d: sending pkt (%d--%d->%d) +%v\033[0m",
			mdm.ID, pkt.Src, pkt.Length, pkt.Dst, sendTime)

		time.Sleep(hwReadyTime)   // hardware preparation
		wave := mdm.pkt2wave(pkt) // encode: convert pkt to wave
		time.Sleep(encodeTime)
		com.SimChannel <- wave // send to simulation

		time.Sleep(wave.TimeLen + resumeTime) // sending && resume
		mdm.FSM.Event("txdone")
	}
}

func (mdm *Modem) processPkt(pkt *com.Packet) (err error) {
	if pkt.Length > com.ModeLen[pkt.Mode]*16 {
		log.Printf("\t\033[31mpktlen: %d, mode: %d\033[0m", pkt.Length, pkt.Mode)
		return errors.New("\t\033[31mPayload is too long!!!\033[0m")
	}
	blocks := pkt.Length / com.ModeLen[pkt.Mode]
	if pkt.Length%com.ModeLen[pkt.Mode] > 0 {
		blocks++
	}
	guardTime := time.Duration(pkt.GuardTime) * time.Millisecond
	pkt.TimeLen = preambleTime + (blockTime+guardTime)*time.Duration(blocks)

	return nil
}

func (mdm *Modem) pkt2wave(pkt com.Packet) (wave com.Wave) {
	wave.Packet = pkt
	wave.ModemID = mdm.ID
	wave.DeathLine = mdm.RangeLimit
	wave.SendTime = time.Now().UnixNano()
	return
}

func (mdm *Modem) getWave(out chan<- com.Packet) {
	for wave := range mdm.GetWaveCh {
		w := wave // new wave for modem to process
		w.RecvTime = time.Now().UnixNano()
		if mdm.FSM.Current() != "idle" || !mdm.isClean() {
			// The modem will NOT be triggered by these waves
			// But they will conflict with other waves
			log.Printf("\033[33mMDM%d(\033[4;37m%s\033[0;33m): wave: %d (%d--%d->%d) "+
				"[[\033[5;31mNOT TRIGGERED\033[0;33m]] +%v\033[0m",
				mdm.ID, mdm.FSM.Current(),
				w.ID, w.Src, w.Length, w.Dst, w.TimeLen)
		} else {
			w.Triggered = true
			mdm.FSM.Event("rx")
			// log.Printf("\033[33mMDM%d: get wave %d (%d--%d->%d)\033[0m",
			// 	mdm.ID, w.ID, w.Src, w.Length, w.Dst)
		}
		mdm.processWave(&w) // add wave to modem and do conflict handle

		// delete wave after the end of the "REAL WAVE"
		time.AfterFunc(w.TimeLen, func() {
			mdm.delWave(&w)
		})

		if !w.Triggered {
			continue
		}
		time.AfterFunc(preambleTime, func() {
			if !w.Error {
				time.Sleep(w.TimeLen + decodeTime - preambleTime)
			}
			mdm.uploadWave(out, &w) // send out to adapter
			mdm.FSM.Event("rxdone")
		})
	}
}

func (mdm *Modem) processWave(wave *com.Wave) {
	if !mdm.isClean() {
		for w := range mdm.waves {
			mdm.checkConflict(w, wave)
		}
	}
	mdm.addWave(wave) // Add wave to the modem waves buffer
	// log.Printf("\033[33mMDM%d: %d wave(s) are processing\033[0m",
	// 	mdm.ID, mdm.processingWaves())
}

func (mdm *Modem) uploadWave(out chan<- com.Packet, wave *com.Wave) {
	if wave.Error {
		log.Printf("\033[33mMDM%d: wave %d (%d--%d->%d) PKT [[\033[5;31mERROR\033[0;33m]] +%v\033[0m",
			mdm.ID, wave.ID, wave.Src, wave.Length, wave.Dst, wave.TimeLen-preambleTime)
	} else if wave.False {
		log.Printf("\033[33mMDM%d: wave %d (%d--%d->%d) PKT [[\033[5;35mFALSE\033[0;33m]]\033[0m",
			mdm.ID, wave.ID, wave.Src, wave.Length, wave.Dst)
	} else if err := mdm.checkPer(wave); err != nil {
		log.Printf("\033[33mMDM%d: wave %d (%d--%d->%d) [[\033[5;35m%s\033[0;33m]]\033[0m",
			mdm.ID, wave.ID, wave.Src, wave.Length, wave.Dst, err)
	} else {
		log.Printf("\033[33mMDM%d: wave %d (%d--%d->%d) PKT [[\033[5;32mGOOD\033[0;33m]]\033[0m",
			mdm.ID, wave.ID, wave.Src, wave.Length, wave.Dst)
		out <- wave.Packet // only "GOOD" pkt will be send out
	}
	// log.Printf("\033[33mMDM%d: %d wave(s) left\033[0m",
	// 	mdm.ID, mdm.processingWaves())
}

func (mdm *Modem) checkPer(wave *com.Wave) (err error) {
	rand.Seed(time.Now().UnixNano())
	for id, pers := range mdm.Per {
		if id == wave.Src {
			randNum := rand.Intn(100)
			if randNum < pers.Rate {
				err = errors.New("PER CACHED")
			}
		}
	}
	return
}

func (mdm *Modem) checkConflict(w1 *com.Wave, w2 *com.Wave) {
	t1 := time.Unix(0, w1.RecvTime)
	t2 := time.Unix(0, w2.RecvTime)
	if t2.Before(t1.Add(preambleTime)) {
		w1.Error = true
	} else {
		// means t2.Before(t1.Add(w1.TimeLen))
		w1.False = true
	}
}

type mdmCfg struct {
	RangeLimit int32
	Per        map[string]rate `toml:"from"`
}

type rate struct {
	Rate int `toml:"per"`
}

type tomlConfig struct {
	Modems map[string]mdmCfg
}

func (mdm *Modem) configModem() error {
	var config tomlConfig
	if _, err := toml.DecodeFile("config.toml", &config); err != nil {
		log.Printf("\033[31m%v\033[0m", err)
		return err
	}
	for s, m := range config.Modems {
		i, err := strconv.Atoi(s)
		if err != nil {
			panic(err)
		}
		if mdm.ID != int32(i) {
			continue
		}
		mdm.RangeLimit = m.RangeLimit

		for s, r := range m.Per {
			i, err := strconv.Atoi(s)
			if err != nil {
				return (err)
			}
			mdm.Per[int32(i)] = r
		}
		return nil
	}
	return errors.New("\033[31mNo such a modem in config file\033[0m")
}
