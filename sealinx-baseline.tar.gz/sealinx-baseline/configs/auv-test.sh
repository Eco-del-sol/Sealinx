#!/bin/bash
#/usr/bin/lad_omapl138 -g -l /home/root/end_user/lad.txt
/home/root/modem-scripts/fs_log.sh
/home/root/modem-scripts/loadDsp.sh
sleep 7

sealinx-core -f 1 &
sleep 1
sealinx-drivers-ipc -g 2 -f 1 & 
sleep 2
sealinx-mac -i 2 -f 1 &
sleep 2
sealinx-auvroute -i 3 -f 1 -m 2 -c config_auvroute.cfg &
sleep 2
sealinx-tra-tln -i 4 -f 1 -m 2 -n 3 -c config_tra_tln.cfg &
sleep 2
sealinx-auv-ter -i 5 -f 1 -m 2 -n 3 -t 4 -c config_auv_ter.cfg -p /dev/ttyS1 -b 115200 &
#sealinx-auv-bs -i 5 -f 1 -m 2 -n 3 -t 4 -c config_auv_bs.cfg -p /dev/ttyS1 -b 115200 &
