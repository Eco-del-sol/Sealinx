package adapter

import (
	"bytes"
	"encoding/binary"
	"log"
	"net"

	"github.com/BurntSushi/toml"
	"mate2/com"
	"mate2/modems"
)

type active struct {
	id  int32
	mdm modems.Modem
}

var (
	entering = make(chan active)
	leaving  = make(chan active)
)

func userManage() {
	for {
		select {
		case activeModem := <-entering:
			modems.Actives[activeModem.id] = activeModem.mdm
			log.Printf("\033[36mADP: add modem: %d\033[0m", activeModem.id)
		case activeModem := <-leaving:
			delete(modems.Actives, activeModem.id)
			log.Printf("\033[36mADP: delete modem: %d\033[0m", activeModem.id)
		}
	}
}

func handleConn(conn net.Conn) {
	defer conn.Close()

	mdmid, err := getModemID(conn)
	if err != nil {
		log.Printf("\033[31mADP: failed to get modem id\033[0m")
		return
	}

	mdm, err := modems.New(mdmid)
	if err != nil {
		log.Printf("\033[31mADP: %v\033[0m", err)
		return
	}

	activeModem := active{id: mdmid, mdm: mdm}
	// add activeModem to list
	entering <- activeModem

	// Receive packets from modem
	var adpGetPktCh = make(chan com.Packet, 5)
	go mdm.Run(adpGetPktCh) // Start a modem
	go writeToConn(conn, adpGetPktCh)

	var buf = make([]byte, binary.Size(com.AdpPkt{}))
	for {
		_, err := conn.Read(buf)
		if err != nil {
			// log.Printf("\033[31mADP: accept error:%d %v\033[0m", n, err)
			break
		}
		sendToModem(mdm.GetPktCh, buf)
	}
	// leaving & delete activeModem from list
	leaving <- activeModem
}

func writeToConn(conn net.Conn, in <-chan com.Packet) {
	for pkt := range in {
		buf := new(bytes.Buffer)
		err := binary.Write(buf, binary.LittleEndian, pkt.AdpPkt)
		if err != nil {
			log.Printf("\033[31mADP: can not read pkt: %v\033[0m", err)
			continue
		}
		conn.Write(buf.Bytes())
	}
}

func sendToModem(out chan<- com.Packet, buf []byte) {
	var adpPkt com.AdpPkt
	binary.Read(bytes.NewReader(buf), binary.LittleEndian, &adpPkt)
	var pkt com.Packet
	pkt.AdpPkt = adpPkt
	out <- pkt
}

func getModemID(conn net.Conn) (mdmid int32, err error) {
	var buf = make([]byte, 4)
	_, err = conn.Read(buf)
	if err != nil {
		return
	}
	// convert to bytes mdmid
	bufReader := bytes.NewReader(buf)
	binary.Read(bufReader, binary.LittleEndian, &mdmid)
	return
}

var server string

// Start the tcp server
func Start() {
	listener, err := net.Listen("tcp", server)
	if err != nil {
		log.Fatal(err)
	}

	go userManage()
	for {
		conn, err := listener.Accept()
		if err != nil {
			log.Print(err)
			continue
		}
		go handleConn(conn)
	}
}

type tomlConfig struct {
	Server string `toml:"server_addr"`
}

func init() {
	var config tomlConfig
	if _, err := toml.DecodeFile("config.toml", &config); err != nil {
		log.Printf("\033[36mADP: %v\033[0m", err)
		return
	}
	server = config.Server
}
