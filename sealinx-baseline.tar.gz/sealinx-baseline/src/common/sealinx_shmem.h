/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * Description of shared memory used that is supposed to be seen by all layers.
 *
 * @author son.
 */

#ifndef __COMMON_SEALINX_SHMEM_H__
#define __COMMON_SEALINX_SHMEM_H__

#include <sys/shm.h>

/**
 * Key for shared memory put in the core module.
 */
#define CORE_SHARED_MEM_KEY 1
#define COMMON_SHARED_MEM_KEY 2

/**
 * Shared memory by the core module.
 */
typedef struct {
    /**
     * MAC address.
     */
	int macAddr;

    /**
     * Network address.
     */
	int netAddr;

    /**
     * Packet size.
     */
	int packetSize;
} CoreSharedData;

/**
 * Shared memory by the all modules.
 */
typedef struct {

	int skt_num;

} CommonSharedData;

#ifdef  __cplusplus
extern "C" {
#endif

/**
 * Generate IPC key for a module based on its full path and the id of the IPC method.
 * 
 * @param ipcId the id of the IPC method.
 * @return The IPC key if successful. Otherwise, generate_ipc_key() shall return (key_t)-1 and set errno to indicate the error.
 */
	key_t generate_ipc_key(int ipcId);
	key_t generate_key(int ipcId);

#ifdef  __cplusplus
}
#endif
typedef struct {
	int semid, shmid;
	void *data;
	char *semKeyPath;
	char *shmKeyPath;
} SharedData;

#ifdef  __cplusplus
extern "C" {
#endif
	int initServerSharedData(char *semKeyPath, char *shmKeyPath, int key,
				 int sizeSharedData, SharedData * cipc);
	int releaseServerSharedData(SharedData * sipc);
	int initClientSharedData(char *semKeyPath, char *shmKeyPath, int key,
				 int sizeSharedData, SharedData * cipc);
	int releaseClientSharedData(SharedData * cipc);
	int binSemaphoreWait(SharedData * sd);
	int binSemaphorePost(SharedData * sd);
#ifdef  __cplusplus
}
#endif
#endif				/* __COMMON_SEALINX_SHMEM_H__ */
