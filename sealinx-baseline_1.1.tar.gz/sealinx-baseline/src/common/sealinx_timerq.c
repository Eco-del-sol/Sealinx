/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author yibo
 */  
    
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include "sealinx_timerq.h"
    
pthread_mutex_t timer_queue_mutex = PTHREAD_MUTEX_INITIALIZER;

/**
 * init the timer_queue
 */ 
void timer_queue_init(struct timer_q_elem **head)
{
	
	(*head) = (struct timer_q_elem *)malloc(sizeof(struct timer_q_elem));
	
	if (*head == NULL) {
		
		fprintf(stderr, "Memory allocation fails\n");
		
		exit(0);
	
	}
	
	(*head)->next = NULL;

}


/**
 * free the timer_queue
 */  
void timer_queue_free(struct timer_q_elem **head)
{
	
	struct timer_q_elem *tmp = NULL;	
	pthread_mutex_lock(&timer_queue_mutex);
	
	while (*head != NULL) {
		
		tmp = *head;
		
		*head = (*head)->next;
		
		free(tmp);	
	}	
 
	*head = NULL;
	
	pthread_mutex_unlock(&timer_queue_mutex);

}


/**
 * delete the timer_queue
 */ 
void timer_queue_delete(struct timer_q_elem *head, struct timer_q_elem *elem)
{
	
	struct timer_q_elem *pos, *pre_pos;
	pthread_mutex_lock(&timer_queue_mutex);
	
	pos = head->next;
	
	pre_pos = head;
	
	while (pos != NULL) {
		
		if (pos == elem) {
			
			pre_pos->next = pos->next;				
			break;
		
		}
		pos = pos->next;
		
		pre_pos = pre_pos->next;
	
}
	
 
	pthread_mutex_unlock(&timer_queue_mutex);

 
}


/**
 * insert the timer_queue
 */ 
void timer_queue_insert(struct timer_q_elem *head, struct timer_q_elem *elem)
{
	
	pthread_mutex_lock(&timer_queue_mutex);
	
 
	elem->next = head->next;
	
	head->next = elem;
	
 	pthread_mutex_unlock(&timer_queue_mutex);

} 
 
struct timer_q_elem *timer_queue_findtimerbypkt(struct timer_q_elem *head,
					Packet * pkt,
					int (*id_compare) (Packet*,Packet*))
{
	struct timer_q_elem *pos = head->next;
 
	while (pos != NULL) {
		/*compare the packet identification */ 
		if (pkt->hdr_net.dst_addr == pos->pkt.hdr_net.dst_addr 
			&&pkt->hdr_net.src_addr == pos->pkt.hdr_net.src_addr 
			&&id_compare(pkt, &pos->pkt)) {
			return pos;
			}
	
	}
	
 
	return NULL;

}


 
