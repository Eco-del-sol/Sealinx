#include <sys/socket.h>

#include "sealinx.h"
#include "sealinx_utils.h"
#include "sealinx_imsg.h"
#include "sealinx_pdu.h"
#include "sealinx_log.h"
#include "sealinx-ang.h"
#include "ang.h"

static Modem *hModem;
#define OFDM_INTERNAL_BUFSIZE   2048

static int m_init()
{
	hModem = ofdm_init(OFDM_INTERNAL_BUFSIZE);

	if (!ofdm_to_cmd(hModem))
		return -1;

	char *reg = "TXDONE";
	int val = 1;
	if (ofdm_configure(hModem, reg, NULL, &val) == 0) {
		log_info("ofdm_configure txdone success");
	} else {
		log_info("ofdm_configure txdone failed");
		return -1;
	}

	if (ofdm_configure(hModem, "DEBUG", "R", &val) == 0) {
		log_info("ofdm_configure receive debug on success");
	} else {
		log_info("ofdm_configure receive debug on failed");
		return -1;
	}
	val = 0;
	if (ofdm_configure(hModem, "DEBUG", "T", &val) == 0) {
		log_info("ofdm_configure transmit debug off success");
	} else {
		log_info("ofdm_configure transmit debug off failed");
		return -1;
	}

	return 0;
}

static void m_close()
{
	ofdm_free(hModem);
}

static int m_isInitialized()
{
	return hModem->initialized;
}

static int m_run()
{
	ofdm_run(hModem);

	return 0;
}

static int m_get(PduBuff * pdu)
{
	OfdmData *od;
	PhysicalDataPacket *pdp;
	int quality, crc;

	od = ofdm_fetch_data(hModem);
	if (!od)
		return -1;

#ifdef ENABLE_PHY_SIG_QUALITY_REPORT
	{
		int rsp_retry = 0;
		DelimitedData *dd;
		do {
			dd = ofdm_fetch_debugdata(hModem);
			if (!dd)
				usleep(500000);	/* 500 ms */
			rsp_retry++;
		} while (!dd && rsp_retry < 60);

		if (dd) {
			int i = 0;
			while (i < dd->len && dd->buf[i] != ':') {;
			}
			if (i >= dd->len) {
				log_info("WARNING: No valid data in EFFSNR");
				quality = 0;
			} else {
				quality = strtol(&dd->buf[i], NULL, 10);
				log_info("PHY SIGNAL QUALITY: %d", *quality);
			}
			free(dd);
		} else {
			quality = 0;
		}
	}
#else
	quality = 0;
#endif
	pdp = (PhysicalDataPacket *) od->data;
	crc = sl_crc32((char *)pdp->data, pdp->length);
	if (pdp->crc == crc) {
		deserialize_raw_data((char *)pdp->data, pdu);
//		pdu->phy.phy_recv.effsnr = quality;
	} else {
		log_info("WARN: Checksum failed on physical packet");
		return -1;
	}

	return 0;
}

static int m_put(PduBuff * pdu)
{
	char sendBuffer[IMSG_MAX_DATA_LENGTH * 4];
	int len;

	len = serialize_pdu(pdu, sendBuffer);
//	ofdm_transmit(hModem, pdu->phy.phy_send.mode, sendBuffer, len);
	return 0;
}

static int m_report(int *node)
{
	return 0;
}

struct mdm_phy_ops G_MDM_DRV_OPS = {
	.init = m_init,
	.close = m_close,
	.isInitialized = m_isInitialized,
	.run = m_run,
	.get = m_get,
	.put = m_put,
	.report = m_report,
};

struct mdm_phy_ops *gMdmDrvOps = &G_MDM_DRV_OPS;
