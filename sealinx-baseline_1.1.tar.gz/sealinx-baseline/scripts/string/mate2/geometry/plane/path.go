package plane

import (
// "math"
)

// Path is a straight line segment connecting multiple points
type Path []Point

// Distance return the lenth of the Path
func (path Path) Distance() float64 {
	sum := 0.0
	for i := range path {
		if i > 0 {
			sum += path[i-1].Distance(&path[i])
		}
	}
	return sum
}
