/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author yibo
 */

#ifndef __SEALINX_PKTLIST_H__
#define __SEALINX_PKTLIST_H__

enum pkt_recved_status {
	NEVER,
	ONCE,
	MULTI_TIMES
};

struct pkt_id_elem {
	unsigned short int src;
	unsigned short int dst;
	unsigned short int pkt_id;
	unsigned short int recved_times;
	struct pkt_id_elem *next;
};

#ifdef	__cplusplus
extern "C" {
#endif
	void init_pkt_id_list(struct pkt_id_elem *header);

	void pkt_id_list_insert(struct pkt_id_elem *header,
				struct pkt_id_elem *elem);

	void pkt_id_list_del(struct pkt_id_elem *header,
			     struct pkt_id_elem *elem);

	void pkt_id_list_free(struct pkt_id_elem *header);

	struct pkt_id_elem *pkt_id_list_find(struct pkt_id_elem *header,
					     struct pkt_id_elem *elem);

#ifdef	__cplusplus
}
#endif
#endif
