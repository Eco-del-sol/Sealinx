# How To

## 环境

### 安装go:

```bash
apt install golang
```
建议到[官网](https://golang.org/dl/)下载安装最新版本(1.12.4以上),
或在公司NAS上[下载](http://sz.smartoceantech.com:5000/sharing/5LfyEnx40).

并以参考[官方教程](https://golang.org/doc/install)进行安装。
(如：解压到`/usr/local`下，并添加`/usr/local/go/bin`到`$PATH`中。)


### 下载代码

```bash
git clone git@192.168.1.170:sealinx/mate2.git
```

## 配置文件

源码中提供的配置文件模板名为：`config.toml.dft`  
你需要根据模板定制配置文件：`config.toml`，故：

```bash
cp config.toml.dft config.toml
```

然后在`config.toml`中自定义配置。

## 编译与运行

go可以像脚本文件一样直接执行，如：
```bash
go run mate2.go
```

也可以直接使用`make`编译出bin文件.
