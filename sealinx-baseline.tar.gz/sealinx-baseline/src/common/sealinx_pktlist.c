/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author yibo
 */

#include <pthread.h>
#include <stdlib.h>

#include "sealinx_pktlist.h"

pthread_mutex_t pkt_id_list_mutex = PTHREAD_MUTEX_INITIALIZER;

/**
 * Init pkt_id_list.
 */
void init_pkt_id_list(struct pkt_id_elem *header)
{
	header->next = NULL;
}

/**
 * Insert an elem into pkt_id_list.
 * @param header The list to insert.
 * @param elem   The elem to insert.
 */
void pkt_id_list_insert(struct pkt_id_elem *header, struct pkt_id_elem *elem)
{
	pthread_mutex_lock(&pkt_id_list_mutex);

	elem->next = header->next;
	header->next = elem;

	pthread_mutex_unlock(&pkt_id_list_mutex);
}

/**
 * Delete an elem from pkt_id_list.
 * @param header The list.
 * @param elem   The elem to delete.
 */
void pkt_id_list_del(struct pkt_id_elem *header, struct pkt_id_elem *elem)
{
	struct pkt_id_elem *pos = header->next;
	struct pkt_id_elem *pre_pos = header;

	pthread_mutex_lock(&pkt_id_list_mutex);

	while (pos != NULL) {
		if (elem->dst == pos->dst &&
		    elem->src == pos->dst && elem->pkt_id == pos->pkt_id) {
			pre_pos->next = pos->next;
			free(pos);
			break;
		}

		pos = pos->next;
		pre_pos = pre_pos->next;
	}

	pthread_mutex_unlock(&pkt_id_list_mutex);
}

void pkt_id_list_free(struct pkt_id_elem *header)
{
	struct pkt_id_elem *pos = header->next;
	struct pkt_id_elem *tmp = pos;

	pthread_mutex_lock(&pkt_id_list_mutex);

	while (pos != NULL) {
		tmp = pos;
		pos = pos->next;

		free(tmp);
	}
	header->next = NULL;

	pthread_mutex_unlock(&pkt_id_list_mutex);
}

/**
 * Find the elem from pkt_id_list.
 * @param  header The list.
 * @param  elem   The elem to find.
 * @return        The pointer to the elem.
 */
struct pkt_id_elem *pkt_id_list_find(struct pkt_id_elem *header,
				     struct pkt_id_elem *elem)
{
	struct pkt_id_elem *pos = header->next;

	pthread_mutex_lock(&pkt_id_list_mutex);

	while (pos != NULL) {
		if (elem->dst == pos->dst &&
		    elem->src == pos->src && elem->pkt_id == pos->pkt_id) {

			break;
		}

		pos = pos->next;
	}

	pthread_mutex_unlock(&pkt_id_list_mutex);
	return pos;
}
