/**
 * SDDA_BS_MAC
 * date: 2019-2-28
 * author: xiaohe-pan
 */

#include <sys/time.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <sys/un.h>
#include <err.h>
#include <sys/select.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <unistd.h>
#include <stdint.h>
#include <math.h>

#include <sealinx.h>
#include <sealinx_trace.h>
#include <modem_info.h>

#include "sdda.h"
#include "ter.h"
#include "bs.h"
#include "com.h"


#define DEFAULT_LOG_ID "SDDA_BS"

#define DEFAULT_LOG_FOLDER "logs/"

#define DEFAULT_PHY_TXMODE 1

#define SEALINX_P_SDDA_RTS 0x1002

#define SEALINX_P_SDDA_CTS 0x1003

#define SEALINX_P_SDDA_ACK 0x1004

#define SEALINX_P_SDDA_DATA 0x1005

#define SEALINX_P_SDDA_TR 0x2000

#define MAX_QUEUE_LEN 100

int queue_len = 0;
int cmd_seqnum = 0;

/** Time to start sending TR */
time_t tr_send_time;

int total_pktLen = 0;

/** Log identity for this module. */
char *gLogId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char *gLogFolder = DEFAULT_LOG_FOLDER;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 1;

/** File descriptor of the connection to the core. */
int g_connFd;

/** ID of the current module. */
ModuleId g_moduleId;

/** Shared data by the core module. */
CoreSharedData *g_coreSharedData;

/** ID of the shared memory by the core module. */
int g_coreSharedMemId;

ArpTable arpTable = NULL;


uint16_t my_mac_addr;








int max_upload_dataNum;

int max_queue_len;

/** max propagation delay */
double max_tp;
/** the max propagation delay of the terminals to send data */
double max_tp_data;
/** the min propagation delay of the terminals to send data */
double min_tp_data;
/** the number of the terminals to send data */
int num_nodes_data;

/** overhead introduced by the driver and stack */
int overhead_bytes = 14;

uint8_t lastRTSWTime;

double tr_duration;

double cts_duration;

status_bs status;

status_bs bs_status;
status_channel ter_status;
sealinx_timer_t tr_timer;

sealinx_timer_t wrts_timer;

sealinx_timer_t wdata_timer;

sealinx_timer_t send_cmd_second_timer;

sealinx_timer_t measure_range_timer;




pthread_mutex_t qlen_mutex = PTHREAD_MUTEX_INITIALIZER;



//TODO: //////////////////////////////////////terminal
void operate_prio_queue_len(int ctl)
{
    pthread_mutex_lock(&qlen_mutex);
    if (ctl)
        prio_queue_len++;
    else
        prio_queue_len--;
    pthread_mutex_unlock(&qlen_mutex);
}

int get_rts_chance_moment(char *buf)
{
    int offset = 0;
    int tmpID = 0;
    int tmpWTime = 0;
    int i;

    for (i = 0; i < terminal_num; i++)
    {
        memcpy(&tmpID, buf + offset, sizeof(uint8_t));
        offset += sizeof(uint8_t);
        if (tmpID == my_mac_addr)
        {
            memcpy(&tmpWTime, buf + offset, sizeof(uint8_t));
            break;
        }
        offset += sizeof(uint8_t);
    }
    if (i == terminal_num)
    {
        return -1;
    }
    return tmpWTime;
}

double getNPktTxTime(uint8_t pktTxmode, size_t len)
{
    int block_num;
    double pktTxTime;
    len += overhead_bytes;

    block_num = getPktBlockNum(len, pktTxmode);

    pktTxTime = (0.17 + block_guard_time) * block_num + 0.48 + 0.52;
    return pktTxTime;
}

/** Get the tx time of the data to send */
uint16_t getDATATxTime()
{
    uint8_t pktTxmode = txmode;
    int i = 0;
    Packet *pkts[max_queue_len];
    struct pkt_elem *pos;
    pthread_mutex_lock(&qlen_mutex);
    if (flag == 1)
    {
        pos = priority_pkt_queue->next;
        while (pos != NULL)
        {
            pkts[i] = pos->pkt;
            i++;
            pos = pos->next;
        }
    }
    else
    {
        pos = sdda_pkt_queue_head->next;
        while (pos != NULL && i < max_upload_dataNum)
        {
            pkts[i] = pos->pkt;
            i++;
            pos = pos->next;
        }
    }
    pthread_mutex_unlock(&qlen_mutex);
    burst = i;
    double pkt_interval = 0.5;
    double txTime = 0;
    //    txTime = getfirstpkttxtime(getPktSize(pkts[0]));
    curPktNum = get_mac_pkt_seq(pkts[0]);
    for (i = 0; i < burst; i++)
    {
        if (pkts[i]->bInternal == 0)
        {
            ModemInfo *pPhyInfo;
            pPhyInfo = (ModemInfo *)pkts[i]->phy;
            pktTxmode = pPhyInfo->tx.phy_param.mode;
        }
        txTime += getNPktTxTime(pktTxmode, getPktSize(pkts[i]));
    }
    txTime += (burst - 1) * pkt_interval;
    log_info("Packet-Number %d, dataTxTime %f\r\n", burst, txTime);
    return (uint16_t)ceil(txTime + 1);
}

Packet *make_rts()
{
    time_t rts_send_time;
    Packet *rts = (Packet *)malloc(sizeof(Packet));

    if (NULL == rts)
    {
        logError("Memory allocation for RTS failed");
        exit(0);
    }

    make_empty_pkt(rts, my_mac_addr);
    setPhyTxParam(rts->phy, -1, -1, txmode, Modem_Type_DATA, -1, -1);

    rts->hdr_mac.hdr_len = sizeof(rts->hdr_mac) - sizeof(rts->hdr_mac.mac_data) + sizeof(struct mac_cmn_subhdr) + sizeof(struct mac_wTime_subhdr) + sizeof(struct mac_ctrl_subhdr);
    rts->hdr_mac.dst_addr = BS_MAC_ADDR;
    set_mac_pkt_type(rts, SEALINX_P_SDDA_RTS);
    set_mac_pkt_dataTime(rts, getDATATxTime());
    time(&rts_send_time);
    set_mac_pkt_wTimeTRtoRTS(rts, (uint16_t)difftime(rts_send_time, tr_recv_time));

    return rts;
}

void process_cts(Packet *cts)
{
    if (status == WAIT_CTS)
    {
        int send_data_moment;
        send_data_moment = get_data_chance_moment(cts->hdr_mac.mac_data + sizeof(struct mac_cmn_subhdr));
        if (send_data_moment < 0)
        {
            log_info("Don't find the moment to send data\r\n");
            status = INVALID_STATUS;
            return;
        }
        log_info("Send data after %ds\r\n", send_data_moment);
        status = WAIT_SENDING_DATA;

        sealinx_timer_init(&txdata_timer, SEALINX_TIMER_IDLE, send_data_moment, 0, process_txdata_timer, NULL);
        if (!sealinx_timer_start(&txdata_timer))
        {
            log_info("Start txdata_timer failed.\r\n");
            status = INVALID_STATUS;
            return;
        }
    }
}

void process_ack(Packet *ack)
{
    if (status != WAIT_ACK)
    {
        log_info("The current status is not WAIT_ACK\r\n");
        return;
    }
    int tmpID = 0;
    int nodesNum = 0;
    int tmpPktNum = 0;
    int tmpSeq = 0;
    char *buf = ack->pkt_data;
    int offset = 0;
    int i = 0;
    int j = 0;
    struct pkt_elem *pos = NULL;
    struct pkt_elem *pre_pos = NULL;

    memcpy(&nodesNum, buf + offset, sizeof(uint8_t));
    offset += sizeof(uint8_t);

    for (i = 0; i < nodesNum; i++)
    {
        memcpy(&tmpID, buf + offset, sizeof(uint8_t));
        offset += sizeof(uint8_t);
        if (tmpID == my_mac_addr)
        {
            memcpy(&tmpPktNum, buf + offset, sizeof(uint8_t));
            offset += sizeof(uint8_t);
            for (j = 0; j < tmpPktNum; j++)
            {
                memcpy(&tmpSeq, buf + offset, sizeof(int));
                offset += sizeof(int);

                for (int k = 0; k < max_queue_len; k++)
                {
                    if (s_dataPkt_times[k].seqNum == tmpSeq)
                    {
                        s_dataPkt_times[k].seqNum = -1;
                        s_dataPkt_times[k].times = 0;
                        break;
                    }
                }

                if (flag == 1)
                {
                    pos = priority_pkt_queue->next;
                    pre_pos = priority_pkt_queue;
                }
                else
                {
                    pos = sdda_pkt_queue_head->next;
                    pre_pos = sdda_pkt_queue_head;
                }
                pthread_mutex_lock(&qlen_mutex);
                while (pos != NULL)
                {
                    if (tmpSeq == get_mac_pkt_seq(pos->pkt))
                    {
                        pre_pos->next = pos->next;
                        free(pos->pkt);
                        free(pos);
                        pos = pre_pos->next;
                        if (flag == 1)
                            prio_queue_len--;
                        else
                            queue_len--;
                        break;
                    }
                    pos = pos->next;
                    pre_pos = pre_pos->next;
                }
                pthread_mutex_unlock(&qlen_mutex);
            }
            break;
        }
        memcpy(&tmpPktNum, buf + offset, sizeof(uint8_t));
        offset += sizeof(uint8_t);
        offset += tmpPktNum * sizeof(int);
    }

    status = INVALID_STATUS;
    time_t cur_time;
    if (i == nodesNum)
    {
        log_info("Packet-loss-rate on channle is 100% in the current cycle\n");
    }
    else
    {
        log_info("Packet-loss-rate on channle is %f in the current cycle\n", (burst - tmpPktNum) / (float)burst);
        accumulated_recvPktNum += tmpPktNum;
    }
    accumulated_sendPktNum += burst;
    if (accumulated_sendPktNum != 0)
        pktLossRate_channel = (accumulated_sendPktNum - accumulated_recvPktNum) / (float)accumulated_sendPktNum;
    time(&cur_time);
#if 1
    log_info("Accumulated_sendPktNum is %d", accumulated_sendPktNum);
    log_info("Accumulated_lossPktNum is %d", (accumulated_sendPktNum - accumulated_recvPktNum));
    log_info("Packet-loss-rate on channel is %f\n", pktLossRate_channel);
#endif
#if 0
    if(difftime(cur_time, last_time_chn) >= 300)
    {
        log_info("Accumulated_sendPktNum is %d", accumulated_sendPktNum);
        log_info("Accumulated_lossPktNum is %d", (accumulated_sendPktNum-accumulated_recvPktNum));
        log_info("Packet-loss-rate on channel is %f\n", pktLossRate_channel);
        last_time_chn = cur_time;
    }
#endif
}

int get_data_chance_moment(char *buf)
{
    int offset = 0;
    int num = 0;
    int tmpID = 0;
    int tmpWTime = 0;
    int i;

    memcpy(&num, buf + offset, sizeof(uint8_t));
    offset += sizeof(uint8_t);

    for (i = 0; i < num; i++)
    {
        memcpy(&tmpID, buf + offset, sizeof(uint8_t));
        offset += sizeof(uint8_t);
        if (tmpID == my_mac_addr)
        {
            memcpy(&tmpWTime, buf + offset, sizeof(uint16_t));
            break;
        }
        offset += sizeof(uint16_t);
    }
    if (i == num)
    {
        return -1;
    }
    return tmpWTime;
}

void send_data()
{
    int i = 0;
    int j = 0;
    Packet *tmp_pkt = NULL;
    //    log_info("Packet-Number %d\r\n", burst);
    Packet *pkts[burst];
    for (i = 0; i < burst; i++)
    {
        pkts[i] = NULL;
    }
    struct pkt_elem *pos;
    //    log_info("flag = %d\n", flag);
    pthread_mutex_lock(&qlen_mutex);
    if (flag == 1)
    {
        pos = priority_pkt_queue->next;
    }
    else
    {
        pos = sdda_pkt_queue_head->next;
    }
    i = 0;
    while (pos != NULL && i < burst)
    {
        pkts[i] = pos->pkt;
        i++;
        pos = pos->next;
    }
    pthread_mutex_unlock(&qlen_mutex);
    i = 0;
    while (i < burst && pkts[i] != NULL)
    {
        tmp_pkt = (Packet *)malloc(sizeof(Packet));
        memset(tmp_pkt, 0, sizeof(Packet));
        memcpy(tmp_pkt, pkts[i], sizeof(Packet));
        logSend(PKT_DATA,
                tmp_pkt->hdr_mac.src_addr,
                tmp_pkt->hdr_mac.dst_addr, getPktSize(tmp_pkt), "DATA");
        //        log_info("Send DATA packet %d\n",i);
        log_info("Pkt seqNum %d\r\n", get_mac_pkt_seq(tmp_pkt));
        //        log_info("mac_id=%d, net_id=%d, tra_id=%d\n", tmp_pkt->hdr_mac.mac_type, tmp_pkt->hdr_net.net_type, tmp_pkt->hdr_tra.tra_type);
        client_send_down(g_connFd, tmp_pkt, sizeof(Packet), g_moduleId, NULL, 0);
        for (j = 0; j < max_queue_len; j++)
        {
            if (s_dataPkt_times[j].seqNum == get_mac_pkt_seq(tmp_pkt))
            {
                s_dataPkt_times[j].times++;
                break;
            }
        }
        if (j == max_queue_len)
        {
            for (int k = 0; k < max_queue_len; k++)
            {
                if (s_dataPkt_times[k].seqNum == -1)
                {
                    s_dataPkt_times[k].seqNum = get_mac_pkt_seq(tmp_pkt);
                    s_dataPkt_times[k].times++;
                    break;
                }
            }
        }
        free(tmp_pkt);
        i++;
    }
}

void process_txdata_timer(void *arg)
{
    send_data();
    status = WAIT_ACK;
}


void send_rts()
{
    Packet *pkt = NULL;
    pkt = make_rts();
    if (NULL == pkt)
    {
        log_info("Make RTS pkt failed\r\n");
        return;
    }
    /** Send RTS */
    logSend(PKT_CONTROL,
            pkt->hdr_mac.src_addr,
            pkt->hdr_mac.dst_addr, getPktSize(pkt), "RTS");
    if (client_send_down(g_connFd, pkt, sizeof(Packet), g_moduleId, NULL, 0) <= 0)
    {
        log_info("Send rts pkt failed.\r\n");
        return;
    }
    free(pkt);
}

void process_txrts_timer(void *arg)
{
    if (!pkt_queue_empty(priority_pkt_queue))
    {
        for (int i = 0; i < max_queue_len; i++)
        {
            if (s_dataPkt_times[i].times >= 2)
            {
                struct pkt_elem *pos = priority_pkt_queue->next;
                struct pkt_elem *pre_pos = priority_pkt_queue;
                pthread_mutex_lock(&qlen_mutex);
                while (pos != NULL)
                {
                    if (s_dataPkt_times[i].seqNum == get_mac_pkt_seq(pos->pkt))
                    {
                        pre_pos->next = pos->next;
                        free(pos->pkt);
                        free(pos);
                        pos = pre_pos->next;
                        prio_queue_len--;
                        s_dataPkt_times[i].seqNum = -1;
                        s_dataPkt_times[i].times = 0;
                        accumulated_lossPktNum++;
                        break;
                    }
                    pos = pos->next;
                    pre_pos = pre_pos->next;
                }
                pthread_mutex_unlock(&qlen_mutex);
            }
        }
    }

    if (!pkt_queue_empty(sdda_pkt_queue_head))
    {
        for (int i = 0; i < max_queue_len; i++)
        {
            if (s_dataPkt_times[i].times >= 2)
            {
                struct pkt_elem *pos = sdda_pkt_queue_head->next;
                struct pkt_elem *pre_pos = sdda_pkt_queue_head;
                pthread_mutex_lock(&qlen_mutex);
                while (pos != NULL)
                {
                    if (s_dataPkt_times[i].seqNum == get_mac_pkt_seq(pos->pkt))
                    {
                        pre_pos->next = pos->next;
                        free(pos->pkt);
                        free(pos);
                        pos = pre_pos->next;
                        queue_len--;
                        s_dataPkt_times[i].seqNum = -1;
                        s_dataPkt_times[i].times = 0;
                        accumulated_lossPktNum++;
                        break;
                    }
                    pos = pos->next;
                    pre_pos = pre_pos->next;
                }
                pthread_mutex_unlock(&qlen_mutex);
            }
        }
    }

    if (!pkt_queue_empty(priority_pkt_queue))
    {
        flag = 1;
        send_rts();
        status = WAIT_CTS;
    }
    else if (!pkt_queue_empty(sdda_pkt_queue_head))
    {
        flag = 0;
        send_rts();
        status = WAIT_CTS;
    }
    else
    {
        flag = 0;
        status = INVALID_STATUS;
        log_info("Don't have DATA to send, so won't send RTS packet\r\n");
        return;
    }
    time_t current_time;
    if (curPktNum != 0)
        pktLossRate_network = (float)accumulated_lossPktNum / curPktNum;
    time(&current_time);
#if 1
    log_info("Accumulated_lossPktNum is %d", accumulated_lossPktNum);
    log_info("CurPktNum is %d", curPktNum);
    log_info("Packet-loss-rate on network is %f\n", pktLossRate_network);
#endif
#if 0
    if(difftime(current_time, last_time_net) >= 300)
    {
        log_info("Accumulated_lossPktNum is %d", accumulated_lossPktNum);
        log_info("CurPktNum is %d", curPktNum);
        log_info("Packet-loss-rate on network is %f\n", pktLossRate_network);
        last_time_net = current_time;
    }
#endif

    /**
        wcts_timer.timer_status		= SEALINX_TIMER_IDLE;
        wcts_timer.delay_time.tv_sec	= MAX_DURATE_TR;
        wcts_timer.delay_time.tv_usec	= 0;
        wcts_timer.timer_call_back 	= process_wait_cts_timer;
        wcts_timer.arg = NULL;
        if (!sealinx_timer_start(&wcts_timer))
        {
            log_info("start wcts_timer failed\r\n");
            return;
        }
    */
}

//TODO:////////////////////////////////////////////////

void operatequeue_len(int ctl)
{
    pthread_mutex_lock(&qlen_mutex);
    if (ctl)
        queue_len++;
    else
        queue_len--;
    pthread_mutex_unlock(&qlen_mutex);
}



/** Look for the terminal, if exist, return index of array, otherwise return -1 */
int check_terminal_exist(int terminalID)
{
    int i = 0;

    for (i = 0; i < terminal_num; i++)
    {
        if (r_data_id[i].id == terminalID)
            return i;
    }

    return -1;
}

/** Look for free position, return index of array, otherwise return -1 */
int get_free_data_id()
{
    return check_terminal_exist(0);
}

int init_sdda_bs_mac()
{
    int type = 0;
    max_tp = max_tx_range / 1500.0;
    ModuleId moduleIds[NUM_LAYERS];
    moduleIds[LAYER_MAC] = g_moduleId;
    if (!init_logger(gLogFolder, gLogId, gLogFile, TRUE, moduleIds, 1))
    {
        fprintf(stderr, "Unable to init the log module.");
        return FALSE;
    }

    RegistrationResponse serverResponse;

    g_connFd = client_connect(type, LAYER_MAC, moduleIds, &serverResponse, NULL, 0);

    g_coreSharedMemId = serverResponse.coreShareMemId;

    log_info("Key of shared memory by the core: %d", g_coreSharedMemId);

    g_coreSharedData = (CoreSharedData *)shmat(g_coreSharedMemId, NULL, 0);
    if (g_coreSharedData == (CoreSharedData *)-1)
    {
        fprintf(stderr, "Unable to attach the shared memory: %s", strerror(errno));
        return FALSE;
    }

    logger_set_node_id(g_coreSharedData->macAddr, g_coreSharedData->netAddr);
    log_info("Mac address: %d, Net address: %d",
             (int)g_coreSharedData->macAddr, (int)g_coreSharedData->netAddr);
    my_mac_addr = (int)g_coreSharedData->macAddr;

    arpTable = readArpTable(ARP_FILE);



    if(mac_type == 1)
    {
        //bs

        pkt_queue_init(&sdda_cmd_queue_head);
        clear_r_rts_array(r_rts_array);
        clear_r_data_id(r_data_id);

        /** init nodes_delay */
        for (int i = 0; i < MAX_CLIENT_NUM; i++)
        {
            nodes_delay[i].ID = i + 1;
            nodes_delay[i].delay = 0;
        }

        status = INVALID_STATUS;

        sealinx_timer_init(&tr_timer, SEALINX_TIMER_IDLE, TR_TIMER_DURATION, 350000, process_tr_timer, NULL);
        if (!sealinx_timer_start(&tr_timer))
        {
            log_info("Start TR timer failed in init_sdda_bs_mac.\r\n");
            return FALSE;
        }
    }
    else if(mac_type == 2)
    {
        //terminal

        status = INVALID_STATUS;

        for (int i = 0; i < MAX_QUEUE_LEN; i++)
        {
            s_dataPkt_times[i].seqNum = -1;
            s_dataPkt_times[i].times = 0;
        }

        pkt_queue_init(&sdda_pkt_queue_head);
        pkt_queue_init(&priority_pkt_queue);

        time(&last_time_net);
        time(&last_time_chn);
    }


    return TRUE;
}

void set_mac_pkt_type(Packet *pkt, uint16_t mac_type)
{
    struct mac_cmn_subhdr *cmn_subhdr =
        (struct mac_cmn_subhdr *)pkt->hdr_mac.mac_data;
    cmn_subhdr->mac_type = mac_type;
}

uint16_t get_mac_pkt_type(Packet *pkt)
{
    struct mac_cmn_subhdr *cmn_subhdr =
        (struct mac_cmn_subhdr *)pkt->hdr_mac.mac_data;
    return cmn_subhdr->mac_type;
}

void set_mac_pkt_seq(Packet *pkt, int seq)
{
    struct mac_data_subhdr *data_subhdr =
        (struct mac_data_subhdr *)(pkt->hdr_mac.mac_data +
                                   sizeof(struct mac_cmn_subhdr));
    data_subhdr->seq = seq;
}

int get_mac_pkt_seq(Packet *pkt)
{
    struct mac_data_subhdr *data_subhdr =
        (struct mac_data_subhdr *)(pkt->hdr_mac.mac_data +
                                   sizeof(struct mac_cmn_subhdr));
    return data_subhdr->seq;
}

void set_mac_pkt_dataTime(Packet *pkt, uint16_t tlen)
{
    struct mac_ctrl_subhdr *ctrl_subhdr =
        (struct mac_ctrl_subhdr *)(pkt->hdr_mac.mac_data +
                                   sizeof(struct mac_cmn_subhdr) + sizeof(struct mac_wTime_subhdr));
    ctrl_subhdr->dataTxTime = tlen;
}

uint16_t get_mac_pkt_dataTime(Packet *pkt)
{
    struct mac_ctrl_subhdr *ctrl_subhdr =
        (struct mac_ctrl_subhdr *)(pkt->hdr_mac.mac_data +
                                   sizeof(struct mac_cmn_subhdr) + sizeof(struct mac_wTime_subhdr));
    log_info("dataTxTime %d\r\n", ctrl_subhdr->dataTxTime);
    return ctrl_subhdr->dataTxTime;
}

void set_mac_pkt_wTimeTRtoRTS(Packet *pkt, uint16_t tlen)
{
    struct mac_wTime_subhdr *wTime_subhdr =
        (struct mac_wTime_subhdr *)(pkt->hdr_mac.mac_data +
                                    sizeof(struct mac_cmn_subhdr));
    wTime_subhdr->wtime_trToRTS = tlen;
}

uint16_t get_mac_pkt_wTimeTRtoRTS(Packet *pkt)
{
    struct mac_wTime_subhdr *wTime_subhdr =
        (struct mac_wTime_subhdr *)(pkt->hdr_mac.mac_data +
                                    sizeof(struct mac_cmn_subhdr));
    return wTime_subhdr->wtime_trToRTS;
}

int getPktBlockNum(int pktLen, int txmode)
{
    int block_num = 0;
    switch (txmode)
    {
    case 1:
        block_num = (int)ceil(pktLen / 38.0);
        break;
    case 2:
        block_num = (int)ceil(pktLen / 80.0);
        break;
    case 3:
        block_num = (int)ceil(pktLen / 122.0);
        break;
    case 4:
        block_num = (int)ceil(pktLen / 164.0);
        break;
    case 5:
        block_num = (int)ceil(pktLen / 248.0);
        break;
    case 11:
        block_num = (int)ceil(pktLen / 8.0);
        break;
    case 12:
        block_num = (int)ceil(pktLen / 18.0);
        break;
    case 21:
        block_num = (int)ceil(pktLen / 3.0);
        break;
    default:
        logError("The txmode is wrong\n");
        exit(1);
    }
    return block_num;
}

double getRTSDuration()
{
    double rts_duration = 0;
    size_t rtsLen = 0;
    rtsLen = 4 * sizeof(uint8_t) + sizeof(struct mac_cmn_subhdr) + sizeof(struct mac_wTime_subhdr) + sizeof(struct mac_ctrl_subhdr);
    rtsLen += overhead_bytes;
    int block_num;

    block_num = getPktBlockNum(rtsLen, txmode);

    rts_duration = (0.17 + block_guard_time) * block_num + 0.48 + 0.52;
    return rts_duration;
}

void setTRDuration(size_t len)
{
    len += overhead_bytes;
    int block_num;

    block_num = getPktBlockNum(len, txmode);

    tr_duration = (0.17 + block_guard_time) * block_num + 0.48 + 0.52;
}

void setCTSDuration(size_t len)
{
    len += overhead_bytes;
    int block_num;

    block_num = getPktBlockNum(len, txmode);

    cts_duration = (0.17 + block_guard_time) * block_num + 0.48 + 0.52;
}

int set_terminal_rts_moment_toTR(char *buf)
{
    int i = 0;
    int j = 0;
    int minIndex = 0;
    int offset = 0;
    double tmpDelay;
    uint8_t tmpID;
    double tmpWTime = 0;
    uint8_t tmpWTimeFToI = 0;

    if (static_terminal_num > 0)
    {
        /** Sort the delay of all static terminals ascending*/
        for (i = 0; i < static_terminal_num - 1; i++)
        {
            for (j = i + 1; j < static_terminal_num; j++)
            {
                if (nodes_delay[j].delay < nodes_delay[i].delay)
                {
                    tmpID = nodes_delay[j].ID;
                    nodes_delay[j].ID = nodes_delay[i].ID;
                    nodes_delay[i].ID = tmpID;

                    tmpDelay = nodes_delay[j].delay;
                    nodes_delay[j].delay = nodes_delay[i].delay;
                    nodes_delay[i].delay = tmpDelay;
                }
            }
        }

        if (nodes_delay[static_terminal_num - 1].delay > max_tp)
        {
            max_tp = nodes_delay[static_terminal_num - 1].delay;
        }

        for (i = 0; i < terminal_num; i++)
        {
            log_info("Node %d, Propagation delay %f", nodes_delay[i].ID, nodes_delay[i].delay);
        }

        // 开始全部为0，所以下面会留时间给终端发消息来更新
        for (i = 0; i < static_terminal_num; i++)
        {
            if (nodes_delay[i].delay > 0)
            {
                minIndex = i;
                break;
            }
        }

        // 给静态节点预留时间发送rts
        /** Caculate the moment to send RTS on static node */
        if (i == static_terminal_num) // 只有静态节点
        {
            tmpWTime = max_tp - nodes_delay[0].delay;
            if (tmpWTime < 0)
            {
                tmpWTime = 0;
            }
            tmpWTimeFToI = (uint8_t)ceil(tmpWTime);
            memcpy(buf + offset, &nodes_delay[0].ID, sizeof(uint8_t));
            offset += sizeof(uint8_t);
            memcpy(buf + offset, &tmpWTimeFToI, sizeof(uint8_t));
            offset += sizeof(uint8_t);

            for (j = 1; j < static_terminal_num; j++)
            {
                tmpWTime = tmpWTimeFToI + max_tp + getRTSDuration();
                tmpWTimeFToI = (uint8_t)ceil(tmpWTime);
                memcpy(buf + offset, &nodes_delay[j].ID, sizeof(uint8_t));
                offset += sizeof(uint8_t);
                memcpy(buf + offset, &tmpWTimeFToI, sizeof(uint8_t));
                offset += sizeof(uint8_t);
            }
        }
        else
        {
            tmpWTime = max_tp - nodes_delay[minIndex].delay;
            if (tmpWTime < 0)
            {
                tmpWTime = 0;
            }
            tmpWTimeFToI = (uint8_t)ceil(tmpWTime);
            memcpy(buf + offset, &nodes_delay[minIndex].ID, sizeof(uint8_t));
            offset += sizeof(uint8_t);
            memcpy(buf + offset, &tmpWTimeFToI, sizeof(uint8_t));
            offset += sizeof(uint8_t);

            for (i = minIndex + 1; i < static_terminal_num; i++) // TODO: ?
            {
                tmpWTime = 2 * nodes_delay[i - 1].delay + tmpWTimeFToI + guard_time - 2 * nodes_delay[i].delay + getRTSDuration();
                tmpWTimeFToI = (uint8_t)ceil(tmpWTime);
                memcpy(buf + offset, &nodes_delay[i].ID, sizeof(uint8_t));
                offset += sizeof(uint8_t);
                memcpy(buf + offset, &tmpWTimeFToI, sizeof(uint8_t));
                offset += sizeof(uint8_t);
            }

            for (i = 0; i < minIndex; i++)
            {
                tmpWTime = tmpWTimeFToI + max_tp + getRTSDuration();
                tmpWTimeFToI = (uint8_t)ceil(tmpWTime);
                memcpy(buf + offset, &nodes_delay[i].ID, sizeof(uint8_t));
                offset += sizeof(uint8_t);
                memcpy(buf + offset, &tmpWTimeFToI, sizeof(uint8_t));
                offset += sizeof(uint8_t);
            }
        }

        /** Caculate the moment to send RTS on dynamic node */
        for (i = static_terminal_num; i < terminal_num; i++)
        {
            tmpWTime = tmpWTimeFToI + max_tp + getRTSDuration();
            tmpWTimeFToI = (uint8_t)ceil(tmpWTime);
            memcpy(buf + offset, &nodes_delay[i].ID, sizeof(uint8_t));
            offset += sizeof(uint8_t);
            memcpy(buf + offset, &tmpWTimeFToI, sizeof(uint8_t));
            offset += sizeof(uint8_t);
        }
    }
    else
    {
        // 只有动态节点
        /** Caculate the moment to send RTS on dynamic node */
        tmpWTime = tmpWTimeFToI + max_tp;
        tmpWTimeFToI = (uint8_t)ceil(tmpWTime);
        memcpy(buf + offset, &nodes_delay[0].ID, sizeof(uint8_t));
        offset += sizeof(uint8_t);
        memcpy(buf + offset, &tmpWTimeFToI, sizeof(uint8_t));
        offset += sizeof(uint8_t);
        for (i = 1; i < terminal_num; i++)
        {
            tmpWTime = tmpWTimeFToI + max_tp + getRTSDuration();
            tmpWTimeFToI = (uint8_t)ceil(tmpWTime);
            memcpy(buf + offset, &nodes_delay[i].ID, sizeof(uint8_t));
            offset += sizeof(uint8_t);
            memcpy(buf + offset, &tmpWTimeFToI, sizeof(uint8_t));
            offset += sizeof(uint8_t);
        }
    }
    lastRTSWTime = tmpWTimeFToI;
    return offset;
}

int set_terminal_data_moment_toCTS(char *buf)
{
    int i, j;
    uint8_t num = 0;
    int offset = 0;
    uint8_t tmpID;
    int tmpDuration;
    double tmpDelay;
    double tmpWTime;
    uint16_t tmpWTimeFToI;
    for (i = 0; i < terminal_num; i++)
    {
        if (r_rts_array[i].id == 0)
        {
            break;
        }
        num++;
    }
    /** Store the propagation delay and data duration of the terminal to send data */
    nodes_delay_data_duration tmp_nodes_delay[num];

    for (i = 0; i < terminal_num; i++)
    {
        if (r_rts_array[i].id == 0)
        {
            break;
        }

        tmpDelay = (r_rts_array[i].trToRecvRTSDuration - r_rts_array[i].wtime - tr_duration - getRTSDuration()) / 2; // 传播延迟（l/t）
        if (tmpDelay < 0)
        {
            tmpDelay = 0;
        }
        tmp_nodes_delay[i].ID = r_rts_array[i].id;
        tmp_nodes_delay[i].delay = tmpDelay;
        tmp_nodes_delay[i].dataDuration = r_rts_array[i].dataTime;

        for (j = 0; j < terminal_num; j++)
        {
            if (nodes_delay[j].ID == r_rts_array[i].id)
            {
                nodes_delay[j].delay = tmpDelay;
            }
        }
    }

    /** Sort the delay of all terminals to send data ascending*/
    for (i = 0; i < num - 1; i++)
    {
        for (j = i + 1; j < num; j++)
        {
            if (tmp_nodes_delay[j].delay < tmp_nodes_delay[i].delay)
            {
                tmpID = tmp_nodes_delay[j].ID;
                tmp_nodes_delay[j].ID = tmp_nodes_delay[i].ID;
                tmp_nodes_delay[i].ID = tmpID;

                tmpDelay = tmp_nodes_delay[j].delay;
                tmp_nodes_delay[j].delay = tmp_nodes_delay[i].delay;
                tmp_nodes_delay[i].delay = tmpDelay;

                tmpDuration = tmp_nodes_delay[j].dataDuration;
                tmp_nodes_delay[j].dataDuration = tmp_nodes_delay[i].dataDuration;
                tmp_nodes_delay[i].dataDuration = tmpDuration;
            }
        }
    }

    max_tp_data = tmp_nodes_delay[num - 1].delay;
    min_tp_data = tmp_nodes_delay[0].delay;
    num_nodes_data = num;

    memcpy(buf + offset, &num, sizeof(uint8_t));
    offset += sizeof(uint8_t);

    /** caculate the moment to send data on terminals */
    tmpWTime = tmp_nodes_delay[num - 1].delay - tmp_nodes_delay[0].delay;
    tmpWTimeFToI = (uint16_t)ceil(tmpWTime);
    memcpy(buf + offset, &tmp_nodes_delay[0].ID, sizeof(uint8_t));
    offset += sizeof(uint8_t);
    memcpy(buf + offset, &tmpWTimeFToI, sizeof(uint16_t));
    offset += sizeof(uint16_t);
    for (i = 1; i < num; i++)
    {
        tmpWTime = 2 * tmp_nodes_delay[i - 1].delay + tmpWTimeFToI + tmp_nodes_delay[i - 1].dataDuration + guard_time - 2 * tmp_nodes_delay[i].delay;
        tmpWTimeFToI = (uint16_t)ceil(tmpWTime);
        memcpy(buf + offset, &tmp_nodes_delay[i].ID, sizeof(uint8_t));
        offset += sizeof(uint8_t);
        memcpy(buf + offset, &tmpWTimeFToI, sizeof(uint16_t));
        offset += sizeof(uint16_t);
    }

    return offset;
}

void setPhyTxParam(char *phy, int dst, int src, int txMode, ModemType type, int guard_time, int power_level)
{
    ModemInfo *pPhyInfo = (ModemInfo *)phy;
    pPhyInfo->type = Modem_Info_Tx;
    pPhyInfo->tx.phy_param.src = src;
    pPhyInfo->tx.phy_param.dst = dst;
    pPhyInfo->tx.phy_param.mode = txMode;
    pPhyInfo->tx.phy_param.type = type;
    pPhyInfo->tx.phy_param.guard_time = guard_time;
    pPhyInfo->tx.phy_param.power_level = power_level;
}

void make_empty_pkt(Packet *pkt, int myAddr)
{
    if (pkt == NULL)
    {
        logError("Memory allocation for tr_pkt failed");
        exit(0);
    }

    memset(pkt, 0, sizeof(Packet));

    pkt->msg_len = 0;

    pkt->hdr_mac.mac_type = 5;
    pkt->hdr_net.net_type = 4;
    pkt->hdr_tra.tra_type = 3;
    pkt->hdr_tra.service_type = 2;

    pkt->hdr_mac.src_addr = myAddr;
    pkt->hdr_mac.dst_addr = myAddr;
    pkt->hdr_net.src_addr = myAddr;
    pkt->hdr_net.dst_addr = myAddr;

    pkt->hdr_mac.hdr_len = sizeof(pkt->hdr_mac) - sizeof(pkt->hdr_mac.mac_data);
    pkt->hdr_net.hdr_len = sizeof(pkt->hdr_net) - sizeof(pkt->hdr_net.net_data);
    pkt->hdr_tra.hdr_len = sizeof(pkt->hdr_tra) - sizeof(pkt->hdr_tra.tra_data);
}

Packet *make_tr()
{
    Packet *tr_pkt = (Packet *)malloc(sizeof(Packet));
    if (tr_pkt == NULL)
    {
        logError("Memory allocation for tr_pkt failed");
        exit(0);
    }

    make_empty_pkt(tr_pkt, my_mac_addr);
    setPhyTxParam(tr_pkt->phy, -1, -1, txmode, Modem_Type_DATA, -1, -1);

    tr_pkt->hdr_mac.hdr_len = sizeof(tr_pkt->hdr_mac) - sizeof(tr_pkt->hdr_mac.mac_data) + sizeof(struct mac_cmn_subhdr);
    tr_pkt->hdr_mac.dst_addr = MAC_BROADCAST_ADDR;
    set_mac_pkt_type(tr_pkt, SEALINX_P_SDDA_TR);
    tr_pkt->hdr_mac.hdr_len += set_terminal_rts_moment_toTR(tr_pkt->hdr_mac.mac_data + sizeof(struct mac_cmn_subhdr));

    return tr_pkt;
}

int send_tr()
{
    /** Make TR */
    Packet *pkt = NULL;

    pkt = make_tr();
    if (pkt == NULL)
    {
        log_info("Make tr pkt failed\r\n");
        return FALSE;
    }
    setTRDuration(pkt->hdr_mac.hdr_len);
    /** Send TR*/
    logSend(PKT_CONTROL,
            pkt->hdr_mac.src_addr,
            pkt->hdr_mac.dst_addr, getPktSize(pkt), "TR");
    if (client_send_down(g_connFd, pkt, sizeof(Packet), g_moduleId, NULL, 0) <= 0)
    {
        log_info("Send tr pkt failed.\r\n");
        return FALSE;
    }
    /** Get the time of beginning to send TR */
    time(&tr_send_time);
    free(pkt);
    return TRUE;
}

int getPktTxTime(uint8_t pktTxmode, size_t len)
{
    int block_num;
    double pktTxTime;
    len += overhead_bytes;

    block_num = getPktBlockNum(len, pktTxmode);

    pktTxTime = (0.17 + block_guard_time) * block_num + 0.48 + 0.52;
    return (int)ceil(pktTxTime);
}

int cmd_end_sendUp()
{
    /** Make CE */
    Packet *ce_pkt = (Packet *)malloc(sizeof(Packet));
    if (ce_pkt == NULL)
    {
        logError("Memory allocation for ce_pkt failed");
        exit(0);
    }

    make_empty_pkt(ce_pkt, my_mac_addr);

    ce_pkt->hdr_mac.hdr_len = sizeof(ce_pkt->hdr_mac) - sizeof(ce_pkt->hdr_mac.mac_data);

    ProtocolInfo *pi = (ProtocolInfo *)ce_pkt->hdr_net.net_data;
    pi->pktType = 93;
    ce_pkt->hdr_net.hdr_len = sizeof(ce_pkt->hdr_net) - sizeof(ce_pkt->hdr_net.net_data) + sizeof(ProtocolInfo);

    /** Send CE */
    logSend(PKT_CONTROL,
            ce_pkt->hdr_mac.src_addr,
            ce_pkt->hdr_mac.dst_addr, getPktSize(ce_pkt), "CEUP");
    if (client_send_up(g_connFd, ce_pkt, sizeof(Packet), g_moduleId, NULL, 0) <= 0)
    {
        log_info("Send ce pkt failed.\r\n");
        return FALSE;
    }
    free(ce_pkt);
    return TRUE;
}

int per_end_sendUp()
{
    /** Make RE */
    Packet *pe_pkt = (Packet *)malloc(sizeof(Packet));
    if (pe_pkt == NULL)
    {
        logError("Memory allocation for pe_pkt failed");
        exit(0);
    }

    make_empty_pkt(pe_pkt, my_mac_addr);

    ProtocolInfo *pi = (ProtocolInfo *)pe_pkt->hdr_net.net_data;
    pi->pktType = 94;
    pe_pkt->hdr_net.hdr_len = sizeof(pe_pkt->hdr_net) - sizeof(pe_pkt->hdr_net.net_data) + sizeof(ProtocolInfo);

    /** Send RE */
    logSend(PKT_CONTROL,
            pe_pkt->hdr_mac.src_addr,
            pe_pkt->hdr_mac.dst_addr, getPktSize(pe_pkt), "PEUP");
    if (client_send_up(g_connFd, pe_pkt, sizeof(Packet), g_moduleId, NULL, 0) <= 0)
    {
        log_info("Send re pkt failed.\r\n");
        return FALSE;
    }
    free(pe_pkt);
    return TRUE;
}

/** Send comand the second time */
void send_cmd_second_timer_process(void *arg)
{
    uint8_t pktTxmode = txmode;
    int tmpFlag = 0;
    Packet *pkt = (Packet *)arg;
    ProtocolInfo *pi = (ProtocolInfo *)pkt->hdr_net.net_data;
    if (pi->pktType == 88)
        tmpFlag = 1;
    if (pi->pktType == 89)
        tmpFlag = 2;
    int wait_time;
    if (pkt == NULL)
    {
        log_info("The cmd cannot be gotten when it's sent the second time\n");
        return;
    }
    logSend(PKT_DATA,
            pkt->hdr_mac.src_addr,
            pkt->hdr_mac.dst_addr, getPktSize(pkt), "DATA");
    /*    log_info("mac_id=%d, net_id=%d, tra_id=%d\n", pkt->hdr_mac.mac_type, pkt->hdr_net.net_type, pkt->hdr_tra.tra_type); */
    client_send_down(g_connFd, pkt, sizeof(Packet), g_moduleId, NULL, 0);
    if (pkt->bInternal == 0)
    {
        ModemInfo *pPhyInfo;
        pPhyInfo = (ModemInfo *)pkt->phy;
        pktTxmode = pPhyInfo->tx.phy_param.mode;
    }
    wait_time = getPktTxTime(pktTxmode, getPktSize(pkt));
    free(pkt);
    pkt_queue_deque(sdda_cmd_queue_head);
    /** queue_len-- */
    operatequeue_len(FALSE);

    if (tmpFlag == 1)
        cmd_end_sendUp();
    if (tmpFlag == 2)
        per_end_sendUp();

    status = INVALID_STATUS;

    sealinx_timer_init(&tr_timer, SEALINX_TIMER_IDLE, wait_time, 0, process_tr_timer, NULL);

    if (!sealinx_timer_start(&tr_timer))
    {
        log_info("Start TR timer failed\r\n");
    }
}

void measure_range_timer_process(void *arg)
{
    sealinx_timer_init(&tr_timer, SEALINX_TIMER_IDLE, 0, 1000, process_tr_timer, NULL);

    if (!sealinx_timer_start(&tr_timer))
    {
        log_info("Start TR timer failed in measuring range.\r\n");
        return;
    }
}

int send_cmd()
{
    uint8_t pktTxmode = txmode;
    Packet *pkt = NULL;
    pkt = pkt_queue_get_pkt(sdda_cmd_queue_head);
    ProtocolInfo *pi = (ProtocolInfo *)pkt->hdr_net.net_data;
    if (pi->pktType == 97)
    {
        logSend(PKT_DATA,
                pkt->hdr_mac.src_addr,
                pkt->hdr_mac.dst_addr, getPktSize(pkt), "MEASURE_RANGE");
    }

    /** Send command the first time */
    if (client_send_down(g_connFd, pkt, sizeof(Packet), g_moduleId, NULL, 0) <= 0)
    {
        log_info("Send cmd pkt failed.\r\n");
        return FALSE;
    }

    if (pkt->bInternal == 0)
    {
        ModemInfo *pPhyInfo;
        pPhyInfo = (ModemInfo *)pkt->phy;
        pktTxmode = pPhyInfo->tx.phy_param.mode;
    }

    if (pi->pktType == 97)
    {
        sealinx_timer_init(&measure_range_timer, SEALINX_TIMER_IDLE, 13, 0, measure_range_timer_process, NULL);
        if (!sealinx_timer_start(&measure_range_timer))
        {
            log_info("Start measure_range_timer failed.\r\n");
        }
        free(pkt);
        pkt_queue_deque(sdda_cmd_queue_head);
    }
    else
    {
        sealinx_timer_init(&send_cmd_second_timer, SEALINX_TIMER_IDLE, getPktTxTime(pktTxmode, getPktSize(pkt)), 0, send_cmd_second_timer_process, pkt);
        if (!sealinx_timer_start(&send_cmd_second_timer))
        {
            log_info("Start send_cmd_second_timer failed.\r\n");
        }
    }

    return TRUE;
}

int getWrtsDuration()
{
    double wrtsDuration;
    wrtsDuration = tr_duration + lastRTSWTime + 2 * max_tp + getRTSDuration();
    return (int)ceil(wrtsDuration);
}

int getWDataDuration()
{
    double wDataDuration;
    wDataDuration = max_tp_data + min_tp_data + from_rts_get_data_time() + (num_nodes_data - 1) * guard_time + cts_duration;
    return (int)ceil(wDataDuration);
}

int round_end_sendUp()
{
    /** Make RE */
    Packet *re_pkt = (Packet *)malloc(sizeof(Packet));
    if (re_pkt == NULL)
    {
        logError("Memory allocation for re_pkt failed");
        exit(0);
    }

    make_empty_pkt(re_pkt, my_mac_addr);

    ProtocolInfo *pi = (ProtocolInfo *)re_pkt->hdr_net.net_data;
    pi->pktType = 90;
    re_pkt->hdr_net.hdr_len = sizeof(re_pkt->hdr_net) - sizeof(re_pkt->hdr_net.net_data) + sizeof(ProtocolInfo);

    /** Send RE */
    logSend(PKT_CONTROL,
            re_pkt->hdr_mac.src_addr,
            re_pkt->hdr_mac.dst_addr, getPktSize(re_pkt), "REUP");
    if (client_send_up(g_connFd, re_pkt, sizeof(Packet), g_moduleId, NULL, 0) <= 0)
    {
        log_info("Send re pkt failed.\r\n");
        return FALSE;
    }
    free(re_pkt);
    return TRUE;
}

void process_tr_timer(void *arg)
{
    if (!pkt_queue_empty(sdda_cmd_queue_head))
    {
        send_cmd();
    }
    else
    {
        // round_end_sendUp();
        send_tr();
        status = WAITING_RTS;
        clear_r_rts_array(r_rts_array);

        sealinx_timer_init(&wrts_timer, SEALINX_TIMER_IDLE, getWrtsDuration(), 0, process_wait_for_rts_timer, NULL);
        if (!sealinx_timer_start(&wrts_timer))
        {
            log_info("Start wrts_timer failed.\r\n");
        }
    }
}

Packet *make_cts()
{
    int extraLen = 0;
    ModemInfo *pPhyInfo;

    Packet *cts_pkt = (Packet *)malloc(sizeof(Packet));
    if (cts_pkt == NULL)
    {
        logError("Memory allocation for cts_pkt failed");
        exit(0);
    }

    make_empty_pkt(cts_pkt, my_mac_addr);
    setPhyTxParam(cts_pkt->phy, -1, -1, txmode, Modem_Type_DATA, -1, -1);

    cts_pkt->hdr_mac.hdr_len = sizeof(cts_pkt->hdr_mac) - sizeof(cts_pkt->hdr_mac.mac_data) + sizeof(struct mac_cmn_subhdr);
    cts_pkt->hdr_mac.dst_addr = MAC_BROADCAST_ADDR;
    set_mac_pkt_type(cts_pkt, SEALINX_P_SDDA_CTS);
    cts_pkt->hdr_mac.hdr_len += set_terminal_data_moment_toCTS(cts_pkt->hdr_mac.mac_data + sizeof(struct mac_cmn_subhdr));

    return cts_pkt;
}

int send_cts()
{
    /** Make CTS */
    Packet *pkt = NULL;
    pkt = make_cts();
    if (pkt == NULL)
    {
        log_info("Make cts pkt failed\r\n");
        return FALSE;
    }
    setCTSDuration(pkt->hdr_mac.hdr_len);

    /** Send cts */
    logSend(PKT_CONTROL,
            pkt->hdr_mac.src_addr,
            pkt->hdr_mac.dst_addr, getPktSize(pkt), "CTS");
    if (client_send_down(g_connFd, pkt, sizeof(Packet), g_moduleId, NULL, 0) <= 0)
    {
        log_info("Send cts pkt failed.\r\n");
        return FALSE;
    }
    free(pkt);
    return TRUE;
}

int from_rts_get_data_time()
{
    int total = 0;
    int i = 0;
    /** get total time of r_rts_array */
    for (i = 0; i < terminal_num; i++)
    {
        if (r_rts_array[i].id != 0)
        {
            total += r_rts_array[i].dataTime;
        }
    }

    return total;
}

void process_wait_for_rts_timer(void *arg)
{
    if (from_rts_get_data_time() == 0)
    {
        status = INVALID_STATUS;
        clear_r_rts_array(r_rts_array);

        sealinx_timer_init(&tr_timer, SEALINX_TIMER_IDLE, 0, 1000, process_tr_timer, NULL);
        if (!sealinx_timer_start(&tr_timer))
        {
            log_info("Start TR timer failed.\r\n");
        }
    }
    else
    {
        total_pktLen = 0;
        send_cts();
        status = RECEIVING_DATA;

        sealinx_timer_init(&wdata_timer, SEALINX_TIMER_IDLE, getWDataDuration(), 0, process_wait_for_data_timer, NULL);
        clear_r_rts_array(r_rts_array);
        if (!sealinx_timer_start(&wdata_timer))
        {
            log_info("Start wdata timer failed.\r\n");
        }
    }
}

int fill_ack_info(char *buf)
{
    int i = 0;
    int offset = 0;
    uint8_t nodesNum = 0;

    for (i = 0; i < terminal_num; i++)
    {
        if (r_data_id[i].id == 0)
        {
            break;
        }
        nodesNum++;
    }
    memcpy(buf + offset, &nodesNum, sizeof(uint8_t));
    offset += sizeof(uint8_t);

    for (i = 0; i < terminal_num; i++)
    {
        if (r_data_id[i].id != 0)
        {
            memcpy(buf + offset, &r_data_id[i].id, sizeof(uint8_t));
            offset += sizeof(uint8_t);
            memcpy(buf + offset, &r_data_id[i].num, sizeof(uint8_t));
            offset += sizeof(uint8_t);
            memcpy(buf + offset, r_data_id[i].rcv_id, r_data_id[i].num * sizeof(int));
            offset += r_data_id[i].num * sizeof(int);
        }
    }

    return offset;
}

Packet *make_ack()
{
    ModemInfo *pPhyInfo;

    Packet *ack_pkt = (Packet *)malloc(sizeof(Packet));
    if (ack_pkt == NULL)
    {
        logError("Memory allocation for ack_pkt failed");
        exit(0);
    }

    make_empty_pkt(ack_pkt, my_mac_addr);
    setPhyTxParam(ack_pkt->phy, -1, 0, txmode, Modem_Type_DATA, -1, -1);

    ack_pkt->hdr_mac.hdr_len = sizeof(ack_pkt->hdr_mac) - sizeof(ack_pkt->hdr_mac.mac_data) + sizeof(struct mac_cmn_subhdr);
    ack_pkt->hdr_mac.dst_addr = MAC_BROADCAST_ADDR;
    set_mac_pkt_type(ack_pkt, SEALINX_P_SDDA_ACK);
    ack_pkt->msg_len = fill_ack_info(ack_pkt->pkt_data);

    return ack_pkt;
}

int send_ack()
{
    int ack_txTime = 0;
    Packet *pkt = NULL;

    pkt = make_ack();
    if (NULL == pkt)
    {
        log_info("Make ACK pkt failed\r\n");
        return FALSE;
    }
    logSend(PKT_CONTROL,
            pkt->hdr_mac.src_addr,
            pkt->hdr_mac.dst_addr, getPktSize(pkt), "ACK");
    if (client_send_down(g_connFd, pkt, sizeof(Packet), g_moduleId, NULL, 0) <= 0)
    {
        log_info("Send ACK pkt failed.\r\n");
        return FALSE;
    }
    ack_txTime = getPktTxTime(txmode, getPktSize(pkt));
    free(pkt);
    return ack_txTime;
}

int check_recv_data_exist()
{
    int i = 0;

    for (i = 0; i < terminal_num; i++)
    {
        if (r_data_id[i].id != 0)
            return TRUE;
    }

    return FALSE;
}

void process_wait_for_data_timer(void *arg)
{
    int delay = 0;
    time_t pktRx_endTime;
    double round_time;
    double dataPkt_rate;
    double allPkt_rate;
    time(&pktRx_endTime);
    round_time = difftime(pktRx_endTime, tr_send_time);
    if (round_time != 0)
    {
        dataPkt_rate = total_pktLen * 8 / round_time;
        allPkt_rate = (total_pktLen + 14 + 10 * num_nodes_data + 7 + 3 * num_nodes_data) * 8 / round_time;
        log_info("DataPkt_rate on MAC %f", dataPkt_rate);
        log_info("AllPkt_rate on MAC %f\n", allPkt_rate);
    }
    /** Send ACK */
    int ack_time = 0;
    if (check_recv_data_exist() == TRUE)
    {
        ack_time = send_ack();
    }
    if (ack_time > 0)
    {
        delay = ack_time;
    }
    else
    {
        delay = TR_TIMER_DURATION;
    }
    clear_r_data_id(r_data_id);
    status = INVALID_STATUS;

    sealinx_timer_init(&tr_timer, SEALINX_TIMER_IDLE, delay, 0, process_tr_timer, NULL);
    if (!sealinx_timer_start(&tr_timer))
    {
        log_info("Start TR timer failed.\r\n");
    }
}

int main(int argc, char **argv)
{
    log_info("000-22--111111-");
    atexit(clean_up);
    signal(SIGINT, signal_handler);

    if (!parse_arguments(argc, argv))
    {
        exit(EXIT_FAILURE);
    }

    if (!init_sdda_bs_mac())
        exit(EXIT_FAILURE);

    logInfo("Starting SDDA_BS_MAC\r\n");

    sdda_bs_mac_process();
    return EXIT_SUCCESS;
}

void signal_handler(int sig)
{
    int type = 0;
    log_info("Received signal (%d)", sig);

    if (g_connFd > -1)
    {
        client_close(type, g_connFd, NULL, 0);
        g_connFd = -1;
    }
}

void clean_up(void)
{
    int type = 0;
    log_info("Cleaning up ...");

    if (g_connFd > -1)
    {
        client_close(type, g_connFd, NULL, 0);
    }

    int rc = shmdt(g_coreSharedData);
    if (rc == -1)
    {
        log_error("Unable to detach shared data: %s", strerror(errno));
    }

    logInfo("Stopping SDDA");
    close_logger();
}

int parse_arguments(int argc, char **argv)
{
    int i = 0;
    int code_readcfg = -1;
    while (i < argc)
    {
        char *t = argv[i];
        if (strcmp(t, "-i") == 0)
        {
            i++;
            if (i < argc)
            {
                int moduleId = strtol(argv[i], NULL, 10);
                if (moduleId > MAX_MODULE_ID || moduleId < MIN_MODULE_ID)
                {
                    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
                    return FALSE;
                }
                g_moduleId = moduleId;
            }
        }
        else if (strcmp(t, "-c") == 0)
        {
            i++;
            if (i < argc)
            {
                code_readcfg = load_cfgfile(argv[i]);
            }
        }
        else if (strcmp(t, "-f") == 0)
        {
            i++;
            if (i < argc)
            {
                gLogFile = atoi(argv[i]);
            }
        }
        else if (strcmp(t, "-v") == 0)
        {
            log_info("build time: %s %s", __DATE__, __TIME__);
            log_info("SEALINX_VERSION: %s", SEALINX_VERSION);
            exit(0);
        }
        i++;
    }
    return g_moduleId <= MAX_MODULE_ID && g_moduleId >= MIN_MODULE_ID && (!code_readcfg);
}

int load_cfgfile(const char *configFile)
{
    char *token;
    char local_buff[sizeof(struct pdu_buff)];

    /** get the parameters of sdda */
    FILE *sdda_cfg = fopen(configFile, "r");
    if (!sdda_cfg)
    {
        logError("Fail to find the configuration file of SDDA_BS\r\n");
        exit(EXIT_FAILURE);
    }
    memset(local_buff, 0, sizeof(local_buff));
    while (fgets(local_buff, sizeof(local_buff), sdda_cfg))
    {
        if (NULL == (token = strtok(local_buff, " :")))
        {
            logError("Wrong configuration file format!\r\n");
            exit(1);
        }
        if (*token == '#')
            continue;

        mac_type = atoi(token);

        if (NULL == (token = strtok(NULL, " :")))
        {
            logError("Wrong configuration file format!\r\n");
            exit(1);
        }
        max_tx_range = atof(token);

        if (NULL == (token = strtok(NULL, " :")))
        {
            logError("Wrong configuration file format!\r\n");
            exit(1);
        }
        guard_time = atof(token);

        if (NULL == (token = strtok(NULL, " :")))
        {
            logError("Wrong configuration file format!\r\n");
            exit(1);
        }
        block_guard_time = atof(token);

        if (NULL == (token = strtok(NULL, " :")))
        {
            logError("Wrong configuration file format!\r\n");
            exit(1);
        }
        terminal_num = atoi(token);

        if (NULL == (token = strtok(NULL, " :")))
        {
            logError("Wrong configuration file format!\r\n");
            exit(1);
        }
        static_terminal_num = atoi(token);

        if (NULL == (token = strtok(NULL, " :")))
        {
            logError("Wrong configuration file format!\r\n");
            exit(1);
        }
        txmode = atoi(token);

        if (NULL == (token = strtok(NULL, " :")))
        {
            logError("Wrong configration file format!");
            exit(1);
        }
        max_upload_dataNum = atoi(token);

        if (NULL == (token = strtok(NULL, " :")))
        {
            logError("Wrong configration file format!");
            exit(1);
        }
        max_queue_len = atoi(token);
        break;
    }
    log_info("Finish reading the configuration file\r\n");
    fclose(sdda_cfg);
    return 0;
}

int sdda_bs_mac_process()
{
    int recv_num = 0;
    PduBuff *pbuf;
    char recv_buf[IMSG_MAX_DATA_LENGTH];

    InternalMessageHeader dataHeader;

    while (1)
    {
        memset(recv_buf, 0, sizeof(recv_buf));

        recv_num = client_read(g_connFd, recv_buf, IMSG_MAX_DATA_LENGTH, &dataHeader, NULL, 0);

        if (recv_num == -1)
        {
            logError("Connection error\r\n");
            exit(1);
        }
        else if (recv_num == -2)
        {
            log_warning("Data was not successfully received\r\n");
        }
        else if (recv_num == 0)
        {
            logInfo("Connection closed\r\n");
            break;
        }

        pbuf = (PduBuff *)recv_buf;

        if (from_upper_layer(dataHeader))
        {
            bs_mac_tx_process(pbuf);
        }
        else if (from_lower_layer(dataHeader))
        {
            bs_mac_rx_process(pbuf);
        }
        else
        {
            logError("Packet state error\n");
            continue;
        }
    }

    return 0;
}

void bs_mac_tx_process(Packet *pkt)
{
    if(mac_type == 1)
    {
        logInfo("Get DATA Packet from Upper Layer\r\n");
        if (pkt->hdr_net.dst_addr == NET_BROADCAST_ADDR)
            pkt->hdr_mac.dst_addr = MAC_BROADCAST_ADDR;
        else
            pkt->hdr_mac.dst_addr = getMac(arpTable, pkt->hdr_net.next_hop);

        pkt->hdr_mac.src_addr = my_mac_addr;
        pkt->hdr_mac.mac_type = g_moduleId;
        pkt->hdr_mac.hdr_len = sizeof(pkt->hdr_mac) - sizeof(pkt->hdr_mac.mac_data) + sizeof(struct mac_cmn_subhdr) + sizeof(struct mac_data_subhdr);
        set_mac_pkt_type(pkt, SEALINX_P_SDDA_DATA);
        set_mac_pkt_seq(pkt, cmd_seqnum++);

        if (queue_len >= MAX_QUEUE_LEN)
        {
            logDrop(PKT_DATA,
                    pkt->hdr_mac.src_addr,
                    pkt->hdr_mac.dst_addr,
                    getPktSize(pkt), "Queue Overflow\r\n");
            return;
        }
        else
        {
            pkt_queue_insert_pkt(pkt, sdda_cmd_queue_head);
            /** queue_len++ */
            operatequeue_len(TRUE);
        }
    }
    else if(mac_type == 2)
    {
        logInfo("Get DATA Packet from Upper Layer\r\n");
        if (pkt->hdr_net.dst_addr == NET_BROADCAST_ADDR)
            pkt->hdr_mac.dst_addr = MAC_BROADCAST_ADDR;
        else
            pkt->hdr_mac.dst_addr = getMac(arpTable, pkt->hdr_net.next_hop);

        pkt->hdr_mac.src_addr = my_mac_addr;
        pkt->hdr_mac.mac_type = g_moduleId;
        pkt->hdr_mac.hdr_len = sizeof(pkt->hdr_mac) - sizeof(pkt->hdr_mac.mac_data) + sizeof(struct mac_cmn_subhdr) + sizeof(struct mac_data_subhdr);
        set_mac_pkt_type(pkt, SEALINX_P_SDDA_DATA);
        set_mac_pkt_seq(pkt, pkt_seqnum++);

        ProtocolInfo *pi = (ProtocolInfo *)pkt->hdr_net.net_data;
        if (pi->pktType == 80 || pi->pktType == 96)
        {
            if (queue_len >= max_queue_len)
            {
                log_info("Queue Full");
                while (!pkt_queue_empty(sdda_pkt_queue_head))
                {
                    pthread_mutex_lock(&qlen_mutex);
                    struct pkt_elem *tmp = sdda_pkt_queue_head->next;
                    for (int i = 0; i < MAX_QUEUE_LEN; i++)
                    {
                        if (s_dataPkt_times[i].seqNum == get_mac_pkt_seq(tmp->pkt))
                        {
                            s_dataPkt_times[i].seqNum = -1;
                            s_dataPkt_times[i].times = 0;
                            break;
                        }
                    }
                    pthread_mutex_unlock(&qlen_mutex);
                    pkt_queue_deque(sdda_pkt_queue_head);
                    operatequeue_len(FALSE);
                }
                log_info("Clear the queue");
            }
            pkt_queue_insert_pkt(pkt, sdda_pkt_queue_head);
            /** queue_len++ */
            operatequeue_len(TRUE);
        }
        else
        {
            if (prio_queue_len >= max_queue_len)
            {
                log_info("Queue Full");
                while (!pkt_queue_empty(priority_pkt_queue))
                {
                    pthread_mutex_lock(&qlen_mutex);
                    struct pkt_elem *tmp = priority_pkt_queue->next;
                    for (int i = 0; i < MAX_QUEUE_LEN; i++)
                    {
                        if (s_dataPkt_times[i].seqNum == get_mac_pkt_seq(tmp->pkt))
                        {
                            s_dataPkt_times[i].seqNum = -1;
                            s_dataPkt_times[i].times = 0;
                            break;
                        }
                    }
                    pthread_mutex_unlock(&qlen_mutex);
                    pkt_queue_deque(priority_pkt_queue);
                    operate_prio_queue_len(FALSE);
                }
                log_info("Clear the prio_queue");
            }
            pkt_queue_insert_pkt(pkt, priority_pkt_queue);
            /** queue_len++ */
            operate_prio_queue_len(TRUE);
        }
    }

}

void process_mac_data(Packet *pkt)
{
    if(mac_type == 1)
    {
        int id_array = -1;

        if (pkt->hdr_mac.dst_addr != my_mac_addr)
        {
            log_info("This packet is not given to me.\r\n");
            return;
        }

        ProtocolInfo *pi = (ProtocolInfo *)pkt->hdr_net.net_data;
        if (pi->pktType == 97)
        {
            sealinx_timer_cancel(&measure_range_timer);
            client_send_up(g_connFd, pkt, sizeof(Packet), g_moduleId, NULL, 0);

            sealinx_timer_init(&tr_timer, SEALINX_TIMER_IDLE, 0, 1000, process_tr_timer, NULL);

            if (!sealinx_timer_start(&tr_timer))
            {
                log_info("Start TR timer failed in measuring range.\r\n");
                return;
            }
            return;
        }

        if (status != RECEIVING_DATA)
        {
            log_info("Received error pkt ,in process_mac_data.\r\n");
            return;
        }
        id_array = check_terminal_exist(pkt->hdr_mac.src_addr);
        if (id_array >= 0)
        {
            r_data_id[id_array].num++;
            r_data_id[id_array].rcv_id[r_data_id[id_array].num - 1] = get_mac_pkt_seq(pkt);
        }
        else
        {
            id_array = get_free_data_id();
            if (id_array < 0)
            {
                log_info("Don't have free r_data_id for this terminal.\r\n");
                return;
            }
            r_data_id[id_array].id = pkt->hdr_mac.src_addr;
            r_data_id[id_array].num++;
            r_data_id[id_array].rcv_id[r_data_id[id_array].num - 1] = get_mac_pkt_seq(pkt);
        }
        total_pktLen += getPktSize(pkt);
        client_send_up(g_connFd, pkt, sizeof(Packet), g_moduleId, NULL, 0);
    }
    else if(mac_type ==  2)
    {
    if ((pkt->hdr_mac.dst_addr == my_mac_addr) || (pkt->hdr_mac.dst_addr == MAC_BROADCAST_ADDR))
        {
            if (get_mac_pkt_seq(pkt) == 0)
            {
                seqCount++;
                cur_seq = -1;
                if (seqCount == 1)
                {
                    client_send_up(g_connFd, pkt, sizeof(Packet), g_moduleId, NULL, 0);
                    return;
                }
                else if (seqCount == 2)
                {
                    log_info("The DATA packet has been received\r\n");
                    seqCount = 0;
                    return;
                }
            }
            if (cur_seq != get_mac_pkt_seq(pkt))
            {
                client_send_up(g_connFd, pkt, sizeof(Packet), g_moduleId, NULL, 0);
                cur_seq = get_mac_pkt_seq(pkt);
            }
            else
            {
                log_info("The DATA packet has been received\r\n");
                return;
            }
        }
        else
        {
            log_info("The packet is not given to me\r\n");
            return;
        }
    }

}

void process_mac_rts(Packet *pkt)
{
    if(mac_type != 1)
    {
        //只有bs需要收rts
        return;
    }

    int i = 0;
    time_t rts_recv_time;

    time(&rts_recv_time);

    if (pkt->hdr_mac.dst_addr != my_mac_addr)
    {
        log_info("This packet is not given to me.\r\n");
        return;
    }

    if (status != WAITING_RTS)
    {
        log_info("Received error RTS pkt.\r\n");
        return;
    }
    if (r_rts_array[terminal_num - 1].id != 0)
    {
        log_info("Too RTS pkt from terminal.\r\n");
        return;
    }
    for (i = 0; i < terminal_num; i++)
    {
        if (r_rts_array[i].id == 0)
        {
            r_rts_array[i].id = pkt->hdr_mac.src_addr;
            r_rts_array[i].wtime = get_mac_pkt_wTimeTRtoRTS(pkt);                       // TERMINAL:Time(send rts time) - Time(recv tr timr)
            r_rts_array[i].dataTime = get_mac_pkt_dataTime(pkt);                        // 发送数据所需时间
            r_rts_array[i].trToRecvRTSDuration = difftime(rts_recv_time, tr_send_time); // BS:Time(recv rts time) - time(send tr time)
            //            log_info("Node %d, WTimeToSendRTS %d, dataTxTime %d, SendTRToRecvRTSDuration %f\n", r_rts_array[i].id, r_rts_array[i].wtime, r_rts_array[i].dataTime, r_rts_array[i].trToRecvRTSDuration);
            //            log_info("TR_duration %f, RTS_duration %f\r\n", tr_duration, getRTSDuration());
            return;
        }
    }

    log_info("No space for storing RTS packet.\r\n");
}


void process_tr(Packet *tr)
{
    int send_rts_moment;
    send_rts_moment = get_rts_chance_moment(tr->hdr_mac.mac_data + sizeof(struct mac_cmn_subhdr));
    if (send_rts_moment < 0)
    {
        log_info("Don't find the moment to send rts, the node ID is out of range\r\n");
        status = INVALID_STATUS;
        return;
    }

    status = WAIT_RTS_CHANCE;

    sealinx_timer_init(&txrts_timer, SEALINX_TIMER_IDLE, send_rts_moment, 0, process_txrts_timer, NULL);

    log_info("Send RTS packet after %ds\r\n", txrts_timer.delay_time.tv_sec);
    if (!sealinx_timer_start(&txrts_timer))
    {
        log_info("Start txrts_timer failed\r\n");
        return;
    }
}


void bs_mac_rx_process(Packet *pkt)
{

    switch (get_mac_pkt_type(pkt))
    {
        ///////////////////////////////////////////////////////////////////////////////
        //common
        case SEALINX_P_SDDA_DATA:
            logReceive(PKT_DATA,
                    pkt->hdr_mac.src_addr,
                    pkt->hdr_mac.dst_addr, getPktSize(pkt), "DATA");
            log_info("Pkt seqNum %d\n", get_mac_pkt_seq(pkt));
            process_mac_data(pkt);
            break;
        ///////////////////////////////////////////////////////////////////////////////
        //bs
        case SEALINX_P_SDDA_RTS:
            logReceive(PKT_CONTROL,
                    pkt->hdr_mac.src_addr,
                    pkt->hdr_mac.dst_addr, getPktSize(pkt), "RTS");
            process_mac_rts(pkt);
            break;

        ///////////////////////////////////////////////////////////////////////////////
        //terminal
        case SEALINX_P_SDDA_TR:
            time(&tr_recv_time);
            logReceive(PKT_CONTROL,
                pkt->hdr_mac.src_addr,
                pkt->hdr_mac.dst_addr, getPktSize(pkt), "TR");
            process_tr(pkt);
            break;

        case SEALINX_P_SDDA_CTS:
            logReceive(PKT_CONTROL,
                pkt->hdr_mac.src_addr,
                pkt->hdr_mac.dst_addr, getPktSize(pkt), "CTS");
            process_cts(pkt);
            break;

        case SEALINX_P_SDDA_ACK:
            logReceive(PKT_CONTROL,
                pkt->hdr_mac.src_addr,
                pkt->hdr_mac.dst_addr, getPktSize(pkt), "ACK");
            process_ack(pkt);
            break;

        default:
            log_info("Received error pkt, type=%d.\r\n", get_mac_pkt_type(pkt));
            break;
        }
}
