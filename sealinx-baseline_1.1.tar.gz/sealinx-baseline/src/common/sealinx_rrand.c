/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author james
 */

#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>

#include "sealinx_rrand.h"

#define RANDMAX 10000

int poisson(double lambda)
{
	/* Generating real random number */
	//srand((unsigned)time(NULL));
	double U, T;
	int rand_num = 0;
	/** 
	 * Generate a random number from 0 to (RANDMAX - 1)
	 * Make it 1 to RANDMAX to Prevent ZERO 
	 */
	rand_num = rrandom() % (RANDMAX - 1) + 1.0;
	U = (double)rand_num / (double)RANDMAX;
	T = -1.0 * log(U) / lambda;
	return T;
}

/**
 * Integer interface of random number generator
 * The output is between integer number
 * @low and @high 
 */
int random_int(int low, int high)
{
	return (rrandom() % (RANDMAX - 1)) * (high - low) / RANDMAX + low;
}

/**
 * Real random number generator 
 */
int rrandom()
{
	struct timeval now;
	gettimeofday(&now, NULL);
	srand((unsigned)((now.tv_sec % 100) * 100000 + now.tv_usec));
	return rand();
}
