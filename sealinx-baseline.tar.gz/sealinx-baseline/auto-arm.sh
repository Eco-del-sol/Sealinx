#!/bin/bash
echo "autoreconfig ..."
autoreconf -i --force --verbose

echo "Building ARM version"
./configure --host=arm-linux-gnueabi PKG_CONFIG_PATH=/opt/ARM/lib/pkgconfig
    
make clean
make
make install
 
