/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * Utility function for OFDM modem working in command mode.
 *
 * @author son
 */

#include <sealinx.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sealinx_serial.h>
#include <sealinx_utils.h>
#include <sealinx_common.h>
#include <math.h>
#include <pthread.h>

#include "ofdm_base.h"
#include "ofdm_cmd_utils.h"

#define ONLINE_MODE 1
#define COMMAND_MODE 2
#define MODEM_TIMEOUT 10
#define NAME_LENGTH 256
#define OFDM_BUFFER_SIZE_SMALL 200

/**
 * Template for issuing an OFDM command.
 *
 * @param modem Descriptor of the modem.
 * @return depends on the command.
 */
int ofdm_cmd_template(Modem * modem)
{
	ofdm_lock(modem);
	/* TODO: issue the command */
	/* TODO: read response */
	ofdm_release(modem);
}

/**
 * Sends a PDU -- locked version.
 *
 * @param modem Descriptor of the modem.
 * @param pbuf The PDU to send
 * @retval CEXEC_SUCCESS if success
 * @retval CEXEC_RECOVERABLE if encountering recoverable error
 * @retval CEXEC_SYS_ERROR if encoutering unrecoverable error
 */
int ofdm_send_pdu_locked(Modem * modem, PduBuff * pbuf)
{
	ofdm_lock(modem);
	int retVal = ofdm_send_pdu(modem, pbuf);
	ofdm_release(modem);
	return retVal;
}

/**
 * Switches the modem to its normal operation mode (modem will be locked exclusively).
 *
 * @param modem Descriptor of the modem
 * @return TRUE if success; FALSE, otherwise.
 */
int ofdm_to_operation_mode_locked(Modem * modem)
{
	/* TODO: the commented following code gave me linking error. look at it later */
	ofdm_lock(modem);
	int retval = ofdm_to_operation_mode(modem);
	ofdm_release(modem);

	return retval;

/*    ofdm_lock(modem);
    modem->initialized = FALSE;
    if (ofdm_to_cmd(modem)) {
        log_info("Modem switched to command mode");
        if (ofdm_switch_tx_complete(modem, TRUE)) {
            log_info("Complete transmission notification on");
            modem->initialized = TRUE;
        }
    }
    ofdm_release(modem);
    return modem->initialized;*/
}
