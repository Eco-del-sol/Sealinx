#ifndef _DELIMIT_H_
#define _DELIMIT_H_

#include "List.h"

typedef struct DELIMITER {
	ListHead node;
	int n_bytes;
	char bytes[0];
} Delimiter;

/* Delimiters list is sorted by the delimter length */
#define Delimit_minDelimiterLen(dlmts) ({ \
	Delimiter *first = list_first_entry_or_null(&(dlmts)->node, Delimiter, node); \
	(first) ? first->n_bytes : 0; \
})

#define Delimit_maxDelimiterLen(dlmts) ({ \
	Delimiter *last = list_last_entry_or_null(&(dlmts)->node, Delimiter, node); \
	(last) ? last->n_bytes : 0; \
})

static inline void Delimit_init(Delimiter * dlmts)
{
	list_init(&dlmts->node);
	dlmts->n_bytes = 0;
}

Delimiter *Delimit_addDelimiter(Delimiter * dlmts, const char *buf, int len);

void Delimit_deleteAll(Delimiter * dlmts);

int Delimit_getNDelimiters(Delimiter * dlmts);

int Delimit_searchFirst(Delimiter * dlmts, const char *buf, int len,
			Delimiter ** first);

#endif
