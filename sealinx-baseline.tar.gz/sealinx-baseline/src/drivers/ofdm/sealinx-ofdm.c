/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * Benthos modem driver.
 *
 * @author jun, james, son
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <err.h>
#include <errno.h>
#include <signal.h>
#include <pthread.h>
#include <termios.h>
#include <sys/time.h>
#include <sys/shm.h>
#include <time.h>
#include <math.h>

#include <sealinx.h>
#include <sealinx_utils.h>
#include <sealinx_serial.h>

#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>

#include "config.h"
#include "ofdm_utils.h"
#include "sealinx-ofdm.h"

// File descriptor of the serial port
int g_serialFd = -1;

/** Log identity for this module. */
char *g_logId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char *g_logFolder = DEFAULT_LOG_FOLDER;

/** File descriptor of the connection to the core. */
int g_connFd;

/** Shared data by the core module. */
CoreSharedData *g_coreSharedData;

/** ID of the shared memory by the core module. */
int g_coreSharedMemId;

/** Name of the config file. */
char *g_cfgFileName = DEFAULT_CFG_FILE_NAME;

/** Verbosity level. */
int g_verbose = 0;

/** The thread reading the serial line. */
pthread_t g_serialThread;

/** The thread reading the core. */
pthread_t g_coreThread;

/** The acoustic sending rate of the OFDM modem (bps). */
int g_ofdmAcousticRate;
/** The maximum transmission unit (bytes)/ */
int g_ofdmMtu;
// the quota to control the sending speed
//int g_ofdmQuota;
/** the OFDM inter frame guard time (ms). */
int g_ofdmIfgt;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 1;

#define FILE_BUFSIZE (1024)

/**
 * Read configuration file for OFDM
 *
 * @param serialFd File descriptor of the serial port connecting to the modem.
 * @param confFileName Name of the config file.
 * @return TRUE if the operation succeeds; FALSE, otherwise.
 */
int read_config(char *confFileName)
{
	char local_buff[FILE_BUFSIZE];
	char *token;
	g_ofdmMtu = 0, g_ofdmAcousticRate = 0, g_ofdmIfgt = 0;

	/* Open up modem configuration file */
	FILE *ofdm_cfg = fopen(confFileName, "r");
	if (!ofdm_cfg) {
		logInfo("Could not open config file: %s", strerror(errno));
		return FALSE;
	}
	memset(local_buff, 0, sizeof(local_buff));
	logInfo("Reading config file...");
	/* Reading the config file */
	while (fgets(local_buff, sizeof(local_buff), ofdm_cfg)) {
		token = strtok(local_buff, " :");
		if (*token == '#')
			continue;
		if (strstr(token, "OFDM_ACOUSTIC_RATE")) {
			token = strtok(NULL, " :");
			g_ofdmAcousticRate = atoi(token);
			logInfo("G_OFDMACOUSTICRATE: %d bps",
				g_ofdmAcousticRate);
			if (g_ofdmAcousticRate <= 0) {
				logError("OFDM_ACOUSTIC_RATE invalid value");
				fclose(ofdm_cfg);
				return FALSE;
			}
			continue;
		} else if (strstr(token, "OFDM_MTU")) {
			token = strtok(NULL, " :");
			g_ofdmMtu = atoi(token);
			logInfo("OFDM_MTU: %d.", g_ofdmMtu);
			if (g_ofdmMtu <= 0) {
				logError("OFDM_MTU invalid value");
				fclose(ofdm_cfg);
				return FALSE;
			}
			continue;
		} else if (strstr(token, "OFDM_IFGT")) {
			token = strtok(NULL, " :");
			g_ofdmIfgt = atoi(token);
			logInfo("OFDM_IFGT: %d.", g_ofdmIfgt);
			if (g_ofdmIfgt <= 0) {
				logError("OFDM_IFGT invalid value");
				fclose(ofdm_cfg);
				return FALSE;
			}
			continue;
		} else {
			continue;
		}
	}
	if (g_ofdmMtu * g_ofdmAcousticRate * g_ofdmIfgt == 0) {
		logError("Missing required parameter(s)!");
		fclose(ofdm_cfg);
		return FALSE;
	}
	logInfo("OFDM Modem initialized!");
	fclose(ofdm_cfg);
	return TRUE;
}

void clean_up(void)
{
	int type = 0;
	logInfo("Cleanup resources.");
	logInfo("Stopping OFDM Modem Driver");
	logInfo("Closing serial port and the connection to the core...");

	if (g_serialFd > -1) {
		log_info("Close modem serial port");
		serial_close(g_serialFd);
	}
	if (g_connFd > -1) {
		log_info("close connection to the core module");
		client_close(type, g_connFd, NULL, 0);
	}

	if (g_coreSharedData) {
		if (shmdt(g_coreSharedData) == -1)
			log_error("Unable to detach shared data: %s",
				  strerror(errno));
	}
	close_logger();
}

void signal_handler(int sig)
{
	int type = 0;
	log_info("Received signal (%d)", sig);

	if (g_connFd > -1) {
		client_close(type, g_connFd, NULL, 0);
		g_connFd = -1;
	}

	if (g_serialFd > -1)
		close(g_serialFd);
}

/**
 * Handles data originated from the modem.
 *
 * @retval TRUE if the operation succeeds.
 * @retval FALSE if the operation fails.
 */
int handle_external_data(void)
{
	int moreData = TRUE;
	int nBytesRead;
	PduBuff pbuf;

	while (moreData) {
		nBytesRead = modem_recv(g_serialFd, &pbuf, &moreData);
		if (nBytesRead < 0) {
			log_error("Failed to receive from modem");
			return FALSE;
		}
		if (nBytesRead != 0) {
			logReceiveFromSerial(nBytesRead, "");
			client_send_up(g_connFd, &pbuf, sizeof(PduBuff),
				       OFDM_DRIVER_ID, NULL, 0);
		}
	}
	return TRUE;
}

/**
 * Handles data originated from inside the protocol stack.
 *
 * @return Size of data put to the media if the operation succeeds;
 * -1 otherwise.
 */
int handle_internal_data(void)
{
	char buffer[IMSG_MAX_DATA_LENGTH];
	InternalMessageHeader dataHeader;
	int nBytesRead = client_read(g_connFd, buffer, IMSG_MAX_DATA_LENGTH,
				     &dataHeader, NULL, 0);
	if (nBytesRead == -1) {
		log_error("Error reading from core: %s", strerror(errno));
		return -1;
	}

	PduBuff *pbuf = (PduBuff *) buffer;

	logReceiveFromStack(nBytesRead, "");

	int retVal = -1;
	if (from_upper_layer(dataHeader)) {
		retVal = modem_send2(g_serialFd, pbuf);
		if (retVal < 0) {
			logError("Failed to send to modem");
			return -1;
		}
	} else {
		log_error("Invalid packet direction");
		return -1;
	}
	return retVal;
}

/**
 * Main function of the thread handling data from serial port.
 *
 * @param data UNUSED.
 * @return UNUSED.
 */
void *serial_thread(void *data)
{
	while (1) {
		if (!handle_external_data())
			break;
	}
	return NULL;
}

/**
 * Main function of the thread handling data from upper layers.
 *
 * @param data UNUSED.
 * @return UNUSED.
 */
void *core_thread(void *data)
{
	pthread_cond_t ifgtCond = PTHREAD_COND_INITIALIZER;
	pthread_mutex_t ifgtMutex = PTHREAD_MUTEX_INITIALIZER;

	struct timespec endTransTime;
	struct timeval now;
	long transDelayMs;	// in ms

	while (TRUE) {
		int dataLen = handle_internal_data();
		if (dataLen == -1)
			break;

		pthread_mutex_lock(&ifgtMutex);
		gettimeofday(&now, NULL);
		if (debug_mode == VERBOSE)
			logInfo("start waiting at %d seconds %d milliseconds",
				now.tv_sec, now.tv_usec / 1000);
		/* calculating transmission delay:
		 * block size: 80 bytes
		 * block duration: 220 milliseconds
		 * preample duration: 620 milliseconds
		 * other delay: 100 milliseconds */
		transDelayMs = ceil((double)dataLen / 80 * 220) + 620 + 100;	// in milliseconds
		long endTimeUsec =
		    now.tv_usec + (transDelayMs + g_ofdmIfgt) * 1000;

		endTransTime.tv_sec = now.tv_sec + endTimeUsec / 1000000;
		endTransTime.tv_nsec = endTimeUsec % 1000000 * 1000;

		pthread_cond_timedwait(&ifgtCond, &ifgtMutex, &endTransTime);
		pthread_mutex_unlock(&ifgtMutex);
		gettimeofday(&now, NULL);

		if (debug_mode == VERBOSE) {
			logInfo("stop waiting at %d seconds %d milliseconds",
				now.tv_sec, now.tv_usec / 1000);
			logInfo("inter frame guard time: %d milliseconds",
				g_ofdmIfgt);
			logInfo("transmission delay: %d milliseconds",
				transDelayMs);
		}
		if (debug_mode != FALSE)
			logInfo("Waited %d milliseconds",
				transDelayMs + g_ofdmIfgt);
	}
	return NULL;
}

/**
 * Parse command line arguments.
 *
 * @param argc Number of arguments
 * @param argv The arguments
 * @return TRUE if the argument can be parse; FALSE, otherwise.
 */
int parse_arguments(int argc, char **argv)
{
	int i = 0;
	while (i < argc) {
		char *t = argv[i];
		if (strcmp(t, "-c") == 0) {
			i++;
			if (i < argc)
				g_cfgFileName = argv[i];
		} else if (strcmp(t, "-g") == 0) {
			g_verbose = TRUE;
		} else if (strcmp(t, "-g2") == 0) {
			g_verbose = VERBOSE;
		} else if (strcmp(t, "-f") == 0) {
			i++;
			if (i < argc)
				gLogFile = atoi(argv[i]);
		}
		i++;
	}
	return TRUE;
}

/**
 * Initializes modem.
 *
 * @retval TRUE if the operation succeeds.
 * @retval FALSE if the operation fails.
 */
int init_modem(void)
{
	/* Initialize the modem */
	if (!read_config(g_cfgFileName)) {
		log_error("Fail to initialize modem");
		return FALSE;
	}

	/* Open up the serial connection to the modem */
	g_serialFd = serial_open();
	if (g_serialFd <= 0) {
		log_error("Fail to open serial port: %s", strerror(errno));
		return FALSE;
	}

	if (tcflush(g_serialFd, TCIOFLUSH) == 0) {
		logInfo("input and output buffers flushed");
	} else {
		logError("input and output buffers flush failed");
		return FALSE;
	}
	return TRUE;
}

/**
 * Initialize the program.
 *
 * @retval TRUE if the operation succeeds.
 * @retval FALSE if the operation fails.
 */
int init(void)
{
	int type = 0;
	if (!init_logger(g_logFolder, g_logId, gLogFile, TRUE, NULL, 0)) {
		fprintf(stderr, "Fail to init the log module.");
		return FALSE;
	}

	RegistrationResponse serverResponse;

	g_connFd =
	    client_connect(type, LAYER_PHYSICAL, NULL, &serverResponse, NULL,
			   0);

	if (g_connFd == -1)
		return FALSE;

	g_coreSharedMemId = serverResponse.coreShareMemId;

	log_info("Key of core shared memory: %d", g_coreSharedMemId);

	g_coreSharedData = (CoreSharedData *) shmat(g_coreSharedMemId, NULL, 0);
	if (g_coreSharedData == (CoreSharedData *) - 1) {
		log_error("Unable to attach the shared memory: %s",
			  strerror(errno));
		return FALSE;
	}

	logger_set_node_id(g_coreSharedData->macAddr,
			   g_coreSharedData->netAddr);
	log_info("Mac address: %d, net address: %d",
		 (int)g_coreSharedData->macAddr,
		 (int)g_coreSharedData->netAddr);

	debug_mode = g_verbose;

	if (!init_modem())
		return FALSE;

	return TRUE;
}

/**
 * Main program.
 *
 * @param argc Number of arguments.
 * @param argv The arguments.
 * @retval EXIT_SUCCESS If the program exits normally.
 * @retval EXIT_FAILURE If an error occurs.
 */
int main(int argc, char **argv)
{
	atexit(clean_up);
	signal(SIGINT, signal_handler);

	if (!parse_arguments(argc, argv))
		return EXIT_FAILURE;

	if (!init())
		return EXIT_FAILURE;

	pthread_create(&g_serialThread, NULL, serial_thread, NULL);
	pthread_create(&g_coreThread, NULL, core_thread, NULL);

	pthread_join(g_serialThread, NULL);
	pthread_join(g_coreThread, NULL);

	return 0;
}
