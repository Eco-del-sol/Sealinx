#ifndef _COM_H
#define _COM_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <err.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>
#include <sys/shm.h>

#include <sealinx.h>
#include "sealinx_pktq.h"
#include "sealinx_timer.h"
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>

#define MAX_CLIENT_NUM 10
#define MAX_RECV_DATA_NUM 100


typedef struct __recv_data_id{
    /** Terminal ID */
    uint8_t id;
    /** The number of DATA packets received */
    uint8_t num;
    /** The sequence number of DATA packet */
    int rcv_id[MAX_RECV_DATA_NUM];
}recv_data_id;


typedef struct __recv_rts{
    /** Terminal ID to send data */
    uint8_t id;
    /** The duration from receiving TR to Sending RTS */
    uint8_t wtime;
    /** The duration of data */
    uint16_t dataTime;
    /** The duration from BS sending TR to receiving RTS */
    double trToRecvRTSDuration;
}recv_rts;

typedef struct __nodes_delay_data_duration{
    /** Terminal ID */
    uint8_t ID;
    /** The propagation delay from the termiinal to BS */
    double delay;
    /** The data tx time of the terminal to send data */
    int dataDuration;
}nodes_delay_data_duration;



typedef struct __bs_nodes_delay{
    /** Terminal ID */
    uint8_t ID;
    /** The propagation delay from the termiinal to BS */
    double delay;
}bs_nodes_delay;


struct mac_cmn_subhdr {
    /** The type of MAC_packet */
    uint16_t mac_type;
};

struct mac_data_subhdr {
    /** The sequence number of DATA packet */
    int seq;
};

struct mac_wTime_subhdr {
    /** The duration from receiving TR to Sending RTS */
    uint16_t wtime_trToRTS;
};

struct mac_sMoment_subhdr {
    /** The sending time stamp of RTS */
    time_t sTimeStamp;
};

struct mac_ctrl_subhdr {
    /** The duration of DATA to be sent */
	uint16_t dataTxTime;
};

typedef struct {
    /** Packet type. */
	uint8_t pktType;
} __attribute__ ((__packed__)) ProtocolInfo;

#endif