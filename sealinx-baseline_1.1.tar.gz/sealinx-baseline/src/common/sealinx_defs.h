/**
 * Common definitions for the Sealinx framework.
 *
 * @file sealinx_defs.h
 * @copyright Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT
 * LLC.  All rights reserved. Proprietary property of AquaSeNT LLC.
 * @author son,xiaoyan
 *
 */

#ifndef __SEALINX_DEFS_H__
#define __SEALINX_DEFS_H__

#include <sealinx_shmem.h>

#ifndef TRUE
#define TRUE 1
#define FALSE (!TRUE)
#endif

/**
 * Handle of a Sealinx packet.
 * @ingroup GenericPacket
 */
typedef int SealinxPacket;

/**
 * Sealinx packet length.
 */
typedef unsigned int PacketLength;

/** 
 * @defgroup Data_MacHeader MAC header
 * @ingroup DataPacket
 *
 * Definitions and functions that manipulate the MAC header of a data
 * packet.
 * @{
 */

/**
 * @name Mac Address Definitions
 * @{
 */
/** MAC address. */
typedef uint8_t MacAddress;

/** Broadcast MAC address. */
#define BROADCAST_MAC_ADDR 99
/** @} */

/**
 * Sets the ID of the MAC layer. This operation is only valid when the
 * packet is typed #SP_TYPE_DATA.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] id The ID to set.
 * @result TRUE if success; FALSE, otherwise.
 */
int sp_set_mac_type(SealinxPacket packet, ModuleId id);

/**
 * Sets the length of the MAC layer header. This operation is only
 * valid when the packet is typed TYPE_DATA and the length of extra
 * data is no more than the allowed size.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] xtraLen Length of extra data.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_mac_extra_len(SealinxPacket packet, PacketLength xtraLen);

/**
 * Sets destination MAC address of a packet. This function is valid
 * only if the packet type is #SP_TYPE_DATA.
 *
 * @param[in] packet The packet.
 * @param[in] macAddr The MAC address.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_mac_dst_addr(SealinxPacket packet, MacAddress macAddr);

/**
 * Sets source MAC address of a packet. This function is valid
 * only if the packet type is #SP_TYPE_DATA.
 *
 * @param[in] packet The packet.
 * @param[in] macAddr The MAC address.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_mac_src_addr(SealinxPacket packet, MacAddress macAddr);

/**
 * Gets destination MAC address of a packet. This function is valid
 * only if the packet type is #SP_TYPE_DATA.
 *
 * @param[in] packet The packet.
 * @return The destination MAC address if success; -1, otherwise.
 */
int sp_get_mac_dst_addr(SealinxPacket packet);

/**
 * Gets source MAC address of a packet. This function is valid
 * only if the packet type is #SP_TYPE_DATA.
 *
 * @param[in] packet The packet.
 * @return The source MAC address.
 */
int sp_get_mac_src_addr(SealinxPacket packet);

/**
 * Calculates packet size from the MAC layer up to application layer,
 * including all headers and payload size. This operation is valid
 * only when the packet type is #SP_TYPE_DATA.
 *
 * @param packet The packet.
 * @return The size if success; -1, otherwise.
 */
int sp_get_mac_size(SealinxPacket packet);
/** @} */

/** Maximum payload length. */
#define MAX_DATA_LENGTH 4096

/**
 * @defgroup SealinxConnection Sealinx Connection
 *
 * Definitions and functions to manipulate a Sealinx connection. In
 * order to send or receive packets from the core module, a connection
 * need to be opened with #open_mac_connection, #open_net_connection,
 * #open_tra_connection or #open_app_connection, depending on which
 * networking layer the caller is. Data is sent to the core with
 * #sealinx_send and received with #sealinx_recv. Finally, the
 * connection has to be freed to return resources to the OS.
 *
 * @note Maintaining a persistent connection is more efficient. It is
 * not recommended that you open a connection just to read some data
 * and close immediately.
 *
 * @{
 */
/** Handle of a Sealinx connection. */
typedef int SealinxConnection;

/**
 * Opens a Sealinx connection at the *PHY layer*.
 *
 * @param[out] conn Handle of the new connection.
 * @return Non negative if success; error code (negative), otherwise.
 */
int open_phy_connection(SealinxConnection * conn);

/**
 * Opens a Sealinx connection at the *MAC layer*.
 *
 * @param[in] macId ID of the MAC layer.
 * @param[out] conn Handle of the new connection.
 * @return Non negative if success; error code (negative), otherwise.
 */
int open_mac_connection(ModuleId macId, SealinxConnection * conn);

/**
 * Opens a Sealinx connection at the *network layer*.
 *
 * @param[in] netId ID of the network layer.
 * @param[in] macId ID of the MAC layer.
 * @param[out] conn Handle of the new connection.
 * @return Non negative if success; error code (negative), otherwise.
 */
int open_net_connection(ModuleId netId, ModuleId macId,
			SealinxConnection * conn);

/**
 * Opens a Sealinx connection at the *transport layer*.
 *
 * @param[in] traId ID of the transport layer.
 * @param[in] netId ID of the network layer.
 * @param[in] macId ID of the MAC layer.
 * @param[out] conn Handle of the new connection.
 * @return Non negative if success; error code (negative), otherwise.
 */
int open_tra_connection(ModuleId traId, ModuleId netId, ModuleId macId,
			SealinxConnection * conn);

/**
 * Opens a Sealinx connection at the *application layer*.
 *
 * @param[in] appId ID of the application layer.
 * @param[in] traId ID of the transport layer.
 * @param[in] netId ID of the network layer.
 * @param[in] macId ID of the MAC layer.
 * @param[out] conn The new connection.
 * @return Non negative if success; error code (negative), otherwise.
 */
int open_app_connection(ModuleId appId, ModuleId traId, ModuleId netId,
			ModuleId macId, SealinxConnection * conn);

/**
 * Free a Sealinx connection.
 *
 * @param[in] conn Handle of the connection to be freed.
 */
void free_connection(SealinxConnection conn);

/**
 * Gets the MAC address of a Sealinx connection.
 * @param[in] conn Handle of the connection.
 * @return The local MAC address.
 */
MacAddress sp_get_local_mac_addr(SealinxConnection conn);

/**
 * Gets the network address of a Sealinx connection
 * @param[in] conn Handle of the connection.
 * @return the local network address.
 */
MacAddress sp_get_local_net_addr(SealinxConnection conn);

/**
 * Sends data to a Sealinx connection
 *
 * @param[in] conn The Sealinx connection.
 * @param[in] packet The packet to send. The packet is initialized
 * outside this funtion.
 * @return Return code of this operation.
 */
int sealinx_send(SealinxConnection conn, SealinxPacket packet);

/**
 * Read data from a Sealinx connection.
 *
 * @param[in] conn The Sealinx connection.
 * @param[in,out] packet The packet that hold the reading. The packet
 * must be allocated before being passed into this function.
 * @return Return code of the read operation function. Success is
 * indicated by a positive result; otherwise, non positive.
 */
int sealinx_recv(SealinxConnection conn, SealinxPacket packet);
/** @} */

typedef struct {
	int connFd;
	LayerId layerId;
	ModuleId moduleId;
	int coreSharedMemId;
	CoreSharedData *coreSharedData;
} SealinxConnectionStruct;

/**
 * @defgroup SealinxPacket Sealinx Packet
 * Group of packet-related definitions and functions
 *
 */

/**
 * @defgroup GenericPacket Generic Packet
 * @ingroup SealinxPacket
 *
 * @{
 */

/**
 * Allocates a new packet.
 *
 * @return Handle of the new packet.
 * @retval 0 if the operation fails.
 */
SealinxPacket sp_new();

/**
 * Frees an allocated packet
 *
 * @param[in] packet Handle of the packet.
 */
void sp_free(SealinxPacket packet);

/** @} */

/**
 * @defgroup Metadata Metadata
 * @ingroup GenericPacket
 *
 * This is a collection of definitions and function that manipulate a
 * packet's metadata. A Sealinx packet internally is not barely
 * packets transferred between network nodes. It carries other
 * information, which is captured in the metadata:
 * - \ref PacketTypes "Packet types": most packets exchanged between local Sealinx
 * modules carry data. However, inorder to facilicate cross layer
 * design, more types of packets are needed.
 * - \ref PacketDirections "Packet directions": this information is needed to route packets
 * between local Sealinx modules. It is unrelated to network layer
 * routing.
 *
 * @{
 */

/**
 * @anchor PacketTypes
 * @name Packet Types
 * @{
 * @ingroup Metadata
 */
/** Type of a Sealinx packet. */
typedef uint8_t PacketType;

/** Value of type ::PacketType indicating a *data packet*. */
#define SP_TYPE_DATA 0x01
/** @} */

/**
 * Gets packet type.
 *
 * @param[in] packet Handle of the packet.
 * @return TRUE if success; FALSE, otherwise.
 */
PacketType sp_get_type(SealinxPacket packet);

/**
 * Sets packet type.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] type Type of the packet.
 */
void sp_set_type(SealinxPacket packet, PacketType type);

/**
 * @anchor PacketDirections
 * @name Packet Directions
 * @{
 * @ingroup Metadata
 */

/** Direction of a Sealinx packet. */
typedef int PacketDirection;

/** Value of ::PacketDirection indicating a packet destined to the *upper layer*. */
#define SP_DIRECTION_UP 1

/** Value of ::PacketDirection indicating a packet destined to the *lower layer*. */
#define SP_DIRECTION_DOWN -1
/** @} */

/**
 * Sets direction of the packet. This information is useful for sealinx_send.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] dir Direction of the packet.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_dir(SealinxPacket packet, PacketDirection dir);

/**
 * Gets packet direction.
 *
 * @param[in] packet Handle of the packet.
 * @return The direction of the packet
 */
PacketDirection sp_get_dir(SealinxPacket packet);

/**
 * Check whether a packet is originated from an upper layer.
 * @param[in] packet Handle of the packet.
 * @return TRUE if the packet is from an upper layer; FALSE, otherwise.
 */
int sp_from_upper(SealinxPacket packet);

/**
 * Check whether a packet is originated from a lower layer.
 * @param[in] packet Handle of the packet.
 * @return TRUE if the packet is from a lower layer; FALSE, otherwise.
 */
int sp_from_lower(SealinxPacket packet);
	  /** @} *//* end Metadata group */

/**
 * @defgroup DataPacket Data Packet
 * @ingroup SealinxPacket
 */

/**
 * @defgroup Data_NetworkHeader Network header
 * @ingroup DataPacket
 *
 * Definitions and functions that manipulate the network header of a
 * data packet.
 *
 * @{
 */
/**
 * @name Network Address Definitions
 * @{
 */
/** Network address. */
typedef uint8_t NetAddress;

/** Broadcast network address. */
#define BROADCAST_NET_ADDR 99
/** @} */

/**
 * Sets extra length of the network layer header. This operation is
 * only valid when the packet is typed TYPE_DATA and the length of
 * extra data is no more than the allowed size.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] xtraLen Length of extra data.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_net_extra_len(SealinxPacket packet, PacketLength xtraLen);

/**
 * Gets destination network address of a packet. This function is
 * valid only if the packet type is #SP_TYPE_DATA.
 *
 * @param[in] packet The packet.
 * @return The destination network address if success; -1 if failure.
 */
int sp_get_net_dst_addr(SealinxPacket packet);

/**
 * Gets source network address of a packet. This function is
 * valid only if the packet type is #SP_TYPE_DATA.
 *
 * @param[in] packet The packet.
 * @return The source network address if success; -1, otherwise.
 */
int sp_get_net_src_addr(SealinxPacket packet);

/**
 * Sets destination network address of a packet. This function is
 * valid only if the packet type is #SP_TYPE_DATA.
 *
 * @param[in] packet The packet.
 * @param[out] netAddr The returned network address.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_net_dst_addr(SealinxPacket packet, NetAddress netAddr);

/**
 * Gets source network address of a packet. This function is
 * valid only if the packet type is #SP_TYPE_DATA.
 *
 * @param[in] packet The packet.
 * @param[out] netAddr The returned network address.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_net_src_addr(SealinxPacket packet, NetAddress netAddr);

/**
 * Set next hop network address of a packet. This function is valid
 * only if the packet type is #SP_TYPE_DATA.
 *
 * @param[in] packet The packet.
 * @param[out] netAddr The returned network address.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_net_next_hop(SealinxPacket packet, NetAddress netAddr);

/**
 * Set next hop network address of a packet. This function is valid
 * only if the packet type is #SP_TYPE_DATA.
 *
 * @param[in] packet The packet.
 * @return The next hop address if success; -1, otherwise.
 */
int sp_get_net_next_hop(SealinxPacket packet);

/**
 * Calculates packet size from the networ layer up to application,
 * including all headers and payload size. This operation is valid
 * only when the packet type is #SP_TYPE_DATA.
 *
 * @param packet The packet.
 * @return The size if success; -1, otherwise.
 */
int sp_get_net_size(SealinxPacket packet);

/**
 * Sets the ID of the network layer. This operation is only valid when
 * the packet is typed #SP_TYPE_DATA.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] id The ID to set.
 * @result TRUE if success; FALSE, otherwise.
 */
int sp_set_net_type(SealinxPacket packet, ModuleId id);
/** @} */

/**
 * @defgroup Data_TransHeader Tranport header
 * @ingroup DataPacket
 *
 * Definitions and functions that manipulate the transport header of a
 * data packet.
 *
 * @{
 */
/**
 * Sets the ID of the transport layer. This operation is only valid when
 * the packet is typed IMSG_TYPE_DATA.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] id The ID to set.
 * @result TRUE if success; FALSE, otherwise.
 */
int sp_set_tra_type(SealinxPacket packet, ModuleId id);

/**
 * Sets extra length of the transport layer header. This operation is
 * only valid when the packet is typed TYPE_DATA and the length of
 * extra data is no more than the allowed size.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] xtraLen Length of extra data.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_tra_extra_len(SealinxPacket packet, PacketLength xtraLen);

/**
 * Calculates packet size from the transport layer up to application,
 * including all headers and payload size. This operation is valid
 * only when the packet type is #SP_TYPE_DATA.
 *
 * @param packet The packet.
 * @return The size if success; -1, otherwise.
 */
int sp_get_tra_size(SealinxPacket packet);

/**
 * Sets the service type of the transport layer. This operation is
 * only valid when the packet is typed #SP_TYPE_DATA.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] id The ID to set.
 * @result TRUE if success; FALSE, otherwise.
 */
int sp_set_tra_service_type(SealinxPacket packet, ModuleId id);

/** @} */

/**
 * @defgroup Data_AppHeader Application payload
 * @ingroup DataPacket
 *
 * Definitions and functions to manipulate the application payload of
 * a data packet.
 *
 * @{
 */

/**
 * Sets the length of the payload.
 *
 * @param[in] packet The packet.
 * @param[in] len The new payload length.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_payload_length(SealinxPacket packet, PacketLength len);

/**
 * Gets the length of the payload.
 *
 * @param[in] packet The packet.
 * @return The payload length if success; -1, otherwise.
 */
int sp_get_payload_length(SealinxPacket packet);

/**
 * Sets the packet's payload.
 *
 * @param[in] packet The packet.
 * @param[in] payload Pointer to the payload.
 * @param[in] payloadLen Size of the payload.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_payload(SealinxPacket packet, void *payload,
		   PacketLength payloadLen);
/** @} */
#endif /* __SEALINX_DEFS_H__ */
