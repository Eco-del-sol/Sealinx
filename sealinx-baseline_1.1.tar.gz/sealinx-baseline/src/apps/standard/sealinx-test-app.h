/**
 * Sealinx app test about packet lose & data rate.
 *
 * @Author	Jifeng Zhu
 * @Date	2019-07-23
 * @Version	0.1
 */

#ifndef __SEALINX_TEST_APP_H__
#define	__SEALINX_TEST_APP_H__

/** Default log identity for this module. */
#define DEFAULT_LOG_ID "APP_TEST"

/** Default path to the folder consisting log files.*/
#define DEFAULT_LOG_FOLDER "logs/"

/**Default config file name for dynamic routing. */
#define DEFAULT_CFG_FILE_NAME "config_test_app.cfg"

typedef struct{
	uint8_t sendNum;
	uint8_t pktNum;
	//int sendTime;
	long long sendTime;
	uint16_t data_len;
	char data[4096];
} __attribute__ ((__packed__)) PayloadData;

#endif				/* __SEALINX_TEST_APP_H__ */
