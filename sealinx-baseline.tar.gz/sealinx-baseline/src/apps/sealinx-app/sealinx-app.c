#include "sealinx-app.h"
#include "sealinx-app-func.h"

app_module_config_t g_app_module_cfg = {0};

void clean_up(void)
{
    int32_t type = 0;
    log_info("Cleaning up ...");

    if (g_app_module_cfg.connect_fd > -1)
    {
        client_close(type, g_app_module_cfg.connect_fd, NULL, 0);
    }

    if (g_app_module_cfg.core_shared_data)
    {
        int32_t rc = shmdt(g_app_module_cfg.core_shared_data);
        if (rc == -1)
        {
            log_error("Unable to detach shared data: %s", strerror(errno));
        }
    }

    close_logger();
}

/**
 * Signal handler.
 *
 * @param sig Signal ID.
 */
void signal_handler(int32_t sig)
{
    int32_t type = 0;
    log_info("Received signal (%d)", sig);

    g_app_module_cfg.is_running = FALSE;

    if (g_app_module_cfg.connect_fd > -1)
    {
        client_close(type, g_app_module_cfg.connect_fd, NULL, 0);
        g_app_module_cfg.connect_fd = -1; 
    }
}
static gboolean load_config(const int8_t *file_name)    
{
    gboolean result = FALSE;
    GKeyFile *key_file = g_key_file_new();

    gboolean can_open = g_key_file_load_from_file(key_file, file_name, G_KEY_FILE_NONE, NULL);

    if (can_open)
    {
        result = TRUE;
        g_app_module_cfg.module_id = 
        	g_key_file_get_integer(key_file, PROTOCOL_PARAMS_GROUP, APP_MODULE_ID, NULL);
        g_app_module_cfg.tra_module_id = 
        	g_key_file_get_integer(key_file, PROTOCOL_PARAMS_GROUP, TRA_MODULE_ID, NULL);
        g_app_module_cfg.net_module_id = 
        	g_key_file_get_integer(key_file, PROTOCOL_PARAMS_GROUP, NET_MODULE_ID, NULL);
        g_app_module_cfg.mac_module_id = 
        	g_key_file_get_integer(key_file, PROTOCOL_PARAMS_GROUP, MAC_MODULE_ID, NULL);
        g_app_module_cfg.tx_mode =
            g_key_file_get_integer(key_file, PROTOCOL_PARAMS_GROUP, GATEWAY_TXMODE_KEY, NULL);
        g_app_module_cfg.tx_power =
            g_key_file_get_integer(key_file, PROTOCOL_PARAMS_GROUP, TX_POWER_LEVEL_KEY, NULL);
        g_app_module_cfg.judge_searial_socket =
            g_key_file_get_integer(key_file, PROTOCOL_PARAMS_GROUP, SEARIAL_OR_SOCKET, NULL);
        g_app_module_cfg.baud =
            g_key_file_get_integer(key_file, PROTOCOL_PARAMS_GROUP, BAUD_KEY, NULL);
        memcpy(g_app_module_cfg.port,
            g_key_file_get_string(key_file, PROTOCOL_PARAMS_GROUP, PORT_KEY, NULL), 24);
        g_app_module_cfg.log_file =
            g_key_file_get_integer(key_file, PROTOCOL_PARAMS_GROUP, LOG_FILE_KEY, NULL);
        g_app_module_cfg.delay_time =
            g_key_file_get_integer(key_file, PROTOCOL_PARAMS_GROUP, DELAY_TIME_KEY, NULL);
        g_app_module_cfg.socket_file =
            g_key_file_get_string(key_file, PROTOCOL_PARAMS_GROUP, SOCKET_FILE_KEY, NULL);
            
    }
    g_key_file_free(key_file);
    return result;
}

static void log_config(void)
{
    logInfo(">> Begin parameters");
    logInfo("g_app_module_cfg.module_id    	= %d", g_app_module_cfg.module_id);
    logInfo("g_app_module_cfg.tx_mode      	= %d", g_app_module_cfg.tx_mode);
    logInfo("g_app_module_cfg.tx_power     	= %d", g_app_module_cfg.tx_power);
    logInfo("g_app_module_cfg.baud      	= %d", g_app_module_cfg.baud);
    logInfo("g_app_module_cfg.port      	= %s", g_app_module_cfg.port);
    logInfo("g_app_module_cfg.log_file      = %d", g_app_module_cfg.log_file);
    logInfo("g_app_module_cfg.delay_time	= %d", g_app_module_cfg.delay_time);
    logInfo(">> End parameters");
}


/**
 * Parse command line arguments.
 *
 * @param argc Number of arguments
 * @param argv The arguments
 * @return TRUE if the argument can be parse; FALSE, otherwise.
 */
 
int parse_arguments(int argc, char **argv)
{	
    int c;
    while ((c = getopt (argc, argv, "f:v")) != -1) {
        switch (c) 
        {
            case 'f': 
				if (!load_config(optarg))
				{
					fprintf(stderr, "Error while loading g_config file (%s).\n", optarg);
					exit(EXIT_FAILURE);
				}
            case 'v':
                print_ver();
                exit(0);
            case '?':
                return FALSE;		
		}	
    }	
    return (optind == argc);
}
#if 0
int32_t parse_arguments(int32_t argc, int8_t **argv)
{
    int i;

    if (1 == argc)
    {
        print_usage(argv[0]);
        exit(0);
    }
    for (i = 0; i < argc; i++)
    {
        if (strcmp(argv[i], "--cfg") == 0)
        {
            i++;
            if (!load_config(argv[i]))
            {
                fprintf(stderr, "Error while loading g_config file (%s).\n", argv[i]);
                exit(EXIT_FAILURE);
            }
        }
        else
        if (strcmp(argv[i], "--help")==0)
        {
            print_usage(argv[0]);
            exit(0);
        }        
    }
	log_info("===========APP MODULE PARESE_ARGUMENTS END===========/r/n"); 
    return 1;
}
#endif
/**
 * Print the usage of the program.
 */
static void print_usage(const int8_t *progName)
{
    printf("USAGE: %s -f  config_name.cfg",progName);
}

void init_app_module_config_default()
{
    strcpy(g_app_module_cfg.port, "/dev/ttyS1");
    g_app_module_cfg.baud = 115200;
    g_app_module_cfg.module_id = 5;
    g_app_module_cfg.fifo_buffer = NULL;
    g_app_module_cfg.is_running = TRUE;
    g_app_module_cfg.log_file = 1;
    strcpy(g_app_module_cfg.log_id, DEFAULT_LOG_ID);
	strcpy(g_app_module_cfg.log_folder, DEFAULT_LOG_FOLDER);
}

int32_t init_udp_socket(void)
{
    int8_t *token;
    int8_t temp_buf[20] = {0};
    int8_t udp_addr_port[4][18] = {0};
    FILE *socket_addr = fopen(g_app_module_cfg.socket_file, "r");
    if(socket_addr == NULL)
    {
        LOG_DISPLAY("OPEN SOCKET FILE FAIL");
    }
    int32_t count = 0;
    for(int32_t i = 0;i< 8;i++)
    {
        memset(temp_buf, 0, sizeof(temp_buf));
        fgets(temp_buf, sizeof(temp_buf), socket_addr);
        token = strtok(temp_buf, " ");
        if (*token == '#')
            continue;
        if(token == NULL)
        {
            log_info("SOCKET PARAMETER IS ERRON,[%d]",i);
            exit(1);
        }
        memcpy(udp_addr_port[count++],token,strlen(token));
    }
    fclose(socket_addr);

    g_app_module_cfg.client_addr_len = sizeof(g_app_module_cfg.client_addr);
    // 创建 socket
    g_app_module_cfg.fd_socket = socket(AF_INET, SOCK_DGRAM, 0);
    LOG_DISPLAY("g_app_module_cfg.fd_socket ===> %d",g_app_module_cfg.fd_socket);
    if (g_app_module_cfg.fd_socket < 0) {
        perror("socket creation failed");
        return 0;
    }
    // 设置服务器地址
    memset(&g_app_module_cfg.server_addr, 0, sizeof(g_app_module_cfg.server_addr));
    g_app_module_cfg.server_addr.sin_family = AF_INET;
    g_app_module_cfg.server_addr.sin_addr.s_addr = inet_addr((const int8_t *)udp_addr_port[0]);
    g_app_module_cfg.server_addr.sin_port = htons(atoi(udp_addr_port[1]));

    memset(&g_app_module_cfg.client_addr, 0, sizeof(g_app_module_cfg.client_addr));
    g_app_module_cfg.client_addr.sin_family = AF_INET;
    g_app_module_cfg.client_addr.sin_addr.s_addr = inet_addr((const int8_t *)udp_addr_port[2]);
    g_app_module_cfg.client_addr.sin_port = htons(atoi(udp_addr_port[3]));

    LOG_DISPLAY("UDP server is IP %s...",udp_addr_port[0]);
    LOG_DISPLAY("UDP server is running on port %d...",atoi(udp_addr_port[1]));

    LOG_DISPLAY("UDP client is IP %s...",udp_addr_port[2]);
    LOG_DISPLAY("UDP client is running on port %d...",atoi(udp_addr_port[3]));

    // 绑定 socket
    LOG_DISPLAY("g_app_module_cfg.fd_socket ===> %d",g_app_module_cfg.fd_socket);
    if (bind(g_app_module_cfg.fd_socket, (const struct sockaddr *)&g_app_module_cfg.server_addr, sizeof(g_app_module_cfg.server_addr)) < 0) {
        perror("bind failed");
        return 0;
    }
    return 1;
}

static int32_t init_gateway()
{
    int32_t type = 0;
    ModuleId moduleIds[NUM_LAYERS] = {0};
    moduleIds[LAYER_MAC] = g_app_module_cfg.mac_module_id;
    moduleIds[LAYER_NETWORK] = g_app_module_cfg.net_module_id;
    moduleIds[LAYER_TRANSPORT] = g_app_module_cfg.tra_module_id;
    moduleIds[LAYER_APPLICATION] = g_app_module_cfg.module_id;
    RegistrationResponse serverResponse;
    g_app_module_cfg.is_running = TRUE;

    if (!init_logger(g_app_module_cfg.log_folder, g_app_module_cfg.log_id, g_app_module_cfg.log_file, TRUE, moduleIds, 4))
    {
        fprintf(stderr, "Unable to init the log module.");
        return FALSE;
    }

    g_app_module_cfg.core_shared_data = (CoreSharedData *) - 1;
    g_app_module_cfg.connect_fd = client_connect(type, LAYER_APPLICATION, moduleIds, &serverResponse, NULL, 0);
    
    if (g_app_module_cfg.connect_fd == -1)
    {
        return -1;
    }
		
    g_app_module_cfg.core_shared_mem_id = serverResponse.coreShareMemId;
    log_info("Key of shared memory by the core: %d", g_app_module_cfg.core_shared_mem_id);
    g_app_module_cfg.core_shared_data = (CoreSharedData *)shmat(g_app_module_cfg.core_shared_mem_id, NULL, 0);
    
    if (g_app_module_cfg.core_shared_data == (CoreSharedData *)-1)
    {
        fprintf(stderr, "Unable to attach the shared memory: %s", strerror(errno));
        return FALSE;
    }

    logger_set_node_id(g_app_module_cfg.core_shared_data->macAddr, g_app_module_cfg.core_shared_data->netAddr);
    log_info("Mac address: %d, net address: %d",
             (int32_t)g_app_module_cfg.core_shared_data->macAddr, (int32_t)g_app_module_cfg.core_shared_data->netAddr);

    g_app_module_cfg.fifo_buffer = (uint8_t *)malloc(MAX_MFIFO_LEN);
    if(g_app_module_cfg.fifo_buffer == NULL)
    {
        free(g_app_module_cfg.fifo_buffer);
        log_info("g_app_module_cfg.fifo_buffer init error");
    }
    pthread_mutex_init(&g_app_module_cfg.f_lock, NULL);
    g_app_module_cfg.mfifo_buf = mfifo_init(g_app_module_cfg.fifo_buffer, MAX_MFIFO_LEN, &g_app_module_cfg.f_lock);
    return TRUE;
}




/**
 * Main program.
 *
 * @param argc Number of parameters.
 * @param argv Array of parameters.
 */
int32_t main(int32_t argc, int8_t **argv)
{
	print_ver;
    atexit(clean_up);
    signal(SIGINT, signal_handler);

    init_app_module_config_default();

    if (!parse_arguments(argc, argv))
    {
        print_usage(argv[0]);
        return EXIT_FAILURE;
    }
    log_config(); 
    
    if (!init_gateway())
    {
        return EXIT_FAILURE;
    }

    int8_t *init_msg = "Modem Initialization successful\r\n";
    int32_t init_msg_len = strlen(init_msg);
    log_info("init_msg_len: %d", init_msg_len);

    if(g_app_module_cfg.judge_searial_socket)
    {
        if(!init_udp_socket())
        {
            LOG_DISPLAY("UDP INIT FAIL");
            return FALSE;
        }
    }
    else
    {
        if ((g_app_module_cfg.fd_serial = Serial_open(g_app_module_cfg.port, g_app_module_cfg.baud, 8, 'n', 1)) < 0)
        {
            log_error("Open serial %s error", g_app_module_cfg.port);
            return -1;
        }
        Serial_write(g_app_module_cfg.fd_serial, init_msg, init_msg_len);
    }

    pthread_t recv_from_serial_thread_id;
    pthread_t send_thread_id;
    pthread_t recv_from_down_thread_id;

    pthread_create(&recv_from_serial_thread_id, NULL, process_recv_from_serial, NULL);
    pthread_create(&send_thread_id, NULL, process_send, NULL);
    pthread_create(&recv_from_down_thread_id, NULL, process_recv_from_down, NULL);

    pthread_join(recv_from_serial_thread_id, NULL);
    pthread_join(send_thread_id, NULL);
    pthread_join(recv_from_down_thread_id, NULL);

    close(g_app_module_cfg.fd_socket);
}


