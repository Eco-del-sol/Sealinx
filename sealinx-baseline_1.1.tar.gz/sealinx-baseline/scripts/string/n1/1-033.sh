#!/bin/sh

BIN=./bin

$BIN/sealinx-core -f 1 &
sleep 3
sleep 2
$BIN/sealinx-tdma -i 2 -f 1 -b 4 -c 1 -a 6 &
sleep 2
$BIN/sealinx-sroute -i 3 -m 2 -f 1 -c config_net.cfg &
sleep 2
$BIN/sealinx-tra-tln -i 4 -n 3 -m 2 -f 1 -c config-tra-tln.cfg &
sleep 2
$BIN/sealinx-test-app -i 5 -f 1 -m 2 -n 3 -t 4 -c config_test_app.cfg -d 4 -l 6 -b 5 &
