#include "bs.h"
void clear_r_data_id(recv_data_id *r_data_id)
{
    int i = 0;

    for (i = 0; i < MAX_CLIENT_NUM; i++)
    {
        memset(&r_data_id[i], 0, sizeof(recv_data_id));
    }
}

void clear_r_rts_array(recv_rts *r_rts_array)
{
    int i = 0;
    for (i = 0; i < MAX_CLIENT_NUM; i++)
    {
        memset(&r_rts_array[i], 0, sizeof(recv_rts));
    }
}


