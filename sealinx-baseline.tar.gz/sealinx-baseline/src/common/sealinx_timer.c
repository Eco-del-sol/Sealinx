/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author yibo
 */

#include <pthread.h>
#include <sys/select.h>
#include <stdio.h>
#include <unistd.h>
#include "sealinx_log.h"

#include "sealinx_timer.h"


int sealinx_timer_init(sealinx_timer_t * sealinx_timer,enum sealinx_timer_status status,int tv_sec,int tv_usec,void (*timer_call_back) (void *),void *arg) 
{
    sealinx_timer->delay_time.tv_sec = tv_sec;
    sealinx_timer->delay_time.tv_usec = tv_usec;
    sealinx_timer->arg = arg;
    sealinx_timer->timer_status = status;
    sealinx_timer->timer_call_back = timer_call_back;

   return 0;

}

void *sealinx_timer_delay(void *arg)
{
	sealinx_timer_t *sealinx_timer = (sealinx_timer_t *) arg;
	struct timeval delay_time = sealinx_timer->delay_time;

	pthread_detach(pthread_self());
	select(0, 0, 0, 0, &delay_time);

	/*call back after delay */
	sealinx_timer->timer_status = SEALINX_TIMER_IDLE;
	sealinx_timer->timer_call_back(sealinx_timer->arg);
	return NULL;
}

/**
 * after delay_time, timer_call_back will be called
 */
int sealinx_timer_start(sealinx_timer_t * sealinx_timer)
{

	int status_code;
	if (sealinx_timer->timer_status != SEALINX_TIMER_IDLE) {
		logError("Cannot start a pending timer");
		status_code = SEALINX_TIMER_ERROR;
	} else {
		sealinx_timer->timer_status = SEALINX_TIMER_PENDING;

		if (pthread_create(&sealinx_timer->tid,
				   NULL,
				   sealinx_timer_delay,
				   (void *)sealinx_timer)) {

			status_code = SEALINX_TIMER_ERROR;
		} else {
			status_code = SEALINX_TIMER_OK;
		}
	}

	return status_code;
}

enum sealinx_timer_status get_sealinx_timer_status(sealinx_timer_t *
						   sealinx_timer)
{
	return sealinx_timer->timer_status;
}

void sealinx_timer_cancel(sealinx_timer_t * sealinx_timer)
{
	struct timeval delay_time;
	delay_time.tv_sec = 0;
	delay_time.tv_usec = 1000;
	if (sealinx_timer->timer_status == SEALINX_TIMER_PENDING) {
		pthread_cancel(sealinx_timer->tid);
		sealinx_timer->timer_status = SEALINX_TIMER_IDLE;
	}
}

void timeval_add(struct timeval *result, struct timeval *t1, struct timeval *t2)
{
	result->tv_sec = t1->tv_sec + t2->tv_sec;
	result->tv_usec = t1->tv_usec + t2->tv_usec;
	result->tv_sec += result->tv_usec / MillionMicroSecond;
	result->tv_usec = result->tv_usec % MillionMicroSecond;
}

/*minuend */
void timeval_subtract(struct timeval *result,
		      struct timeval *minuend, struct timeval *subtrahend)
{
	result->tv_sec = minuend->tv_sec - subtrahend->tv_sec;
	if (minuend->tv_usec < subtrahend->tv_usec) {
		minuend->tv_usec += MillionMicroSecond;
		minuend->tv_sec -= 1;
	}
	result->tv_usec = minuend->tv_usec - subtrahend->tv_usec;
	result->tv_sec = minuend->tv_sec - subtrahend->tv_sec;
}

struct timeval *timeval_add_long(struct timeval *t1, unsigned long t2)
{
	t1->tv_usec += t2;
	t1->tv_sec += t1->tv_usec / MillionMicroSecond;
	t1->tv_usec = t1->tv_usec % MillionMicroSecond;
	return t1;
}
