#ifndef _BS_H
#define _BS_H

#include "com.h"

int max_tx_range;

double guard_time;

double block_guard_time;

uint8_t txmode;

int terminal_num;

int static_terminal_num;

int mac_type;

struct pkt_elem *sdda_cmd_queue_head;



bs_nodes_delay nodes_delay[MAX_CLIENT_NUM];

recv_rts r_rts_array[MAX_CLIENT_NUM];

recv_data_id r_data_id[MAX_CLIENT_NUM];

void clear_r_data_id(recv_data_id *r_data_id);

void clear_r_rts_array(recv_rts *r_rts_array);



#endif