/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * Common definitions in SeaLinx.
 *
 * @author son.
 */

#ifndef __SEALINX_COMMON_H__
#define __SEALINX_COMMON_H__

#ifndef FALSE
#define FALSE 0
#endif /* FALSE */

#ifndef TRUE
#define TRUE (!FALSE)
#endif /* TRUE */

#endif /* __SEALINX_COMMON_H__ */
