/**
 * Adaptive Modulation and coding
 */
#include "stdlib.h"
#include <sealinx.h>
#include "amc.h"
#include "../ang/List.h"

struct amc_state {
	ListHead list;
	uint8_t src;
	uint8_t dst;
	struct amc_metric metric;
	struct amc_mode mode;
};

/* self mac address */
// static uint8_t self;
/*
 * Store the amc states in a linked list
 * Caution: list_head type is used as the list head instead of amc_state
 */
static ListHead states;

#define find_state(src, dst) ({ \
	struct amc_state *st = NULL; \
	list_for_each_entry(st, &states, list) { \
		if ((src) == st->src && (dst) == st->dst) \
			break; \
	} \
	(&(st->list) == &states) ? NULL : st; \
})

static void metric_mode_mapping(struct amc_metric *metric,
				struct amc_mode *mode);

int amc_init()
{
	//todo: initial the amc state list head
	list_init(&states);
	return 0;
}

int amc_feed_metric(uint8_t src, uint8_t dst, struct amc_metric *metric)
{
	struct amc_state *st;
	/* check if the metric is for me; boardcast is not allowed */
	// if (dst != self)
	//      return AMC_E_NOTFORME;
	st = find_state(src, dst);

	// todo: find the src key in the state list.
	// if not found, create one and add it to the list tail
	// Might return memory error when failing to create one

	//todo: update the metric of the found state

	if (st == NULL) {
		st = (struct amc_state *)malloc(sizeof(struct amc_state));
		if (st == NULL) {
			// log_info("failed to create a new list in amc.c");
			return -1;
		}
		list_add_tail(&st->list, &states);
	}
	st->src = src;
	st->dst = dst;
	st->metric.esnr = metric->esnr;
	return 0;
}

/*
 * @return NULL if metric is not found for the (src, dst) combination
 */
struct amc_metric *amc_get_metric(uint8_t src, uint8_t dst)
{
	// amc_metric *metric;
	struct amc_state *st;

	st = find_state(src, dst);
	if (st == NULL)
		return NULL;
	return &st->metric;
}

struct amc_mode *amc_get_mode(uint8_t src, uint8_t dst)
{
	//todo: find the src key in the state list.
	// if not found, return NULL
	struct amc_state *st;
	st = find_state(src, dst);
	if (st == NULL)
		return NULL;

	metric_mode_mapping(&st->metric, &st->mode);
	return &st->mode;

	//invoking metric_mode_mapping on the state found

	//return amc_mode of state
}

/*
 * metric to mode mapping
 */
static void metric_mode_mapping(struct amc_metric *metric,
				struct amc_mode *mode)
{
	static const int map[] = { 0, 4, 6, 8, 11 };
	uint8_t m;

	for (m = 1; m < sizeof(map); m++) {
		if (metric->esnr < map[m])
			break;
	}
	mode->txmode = m;
}
