#ifndef MODEM_H
#define MODEM_H

#ifdef __cplusplus
extern "C" {
#endif

#include <pthread.h>

#define MAX_DATA_LENGTH 5120

typedef struct Modem_Phy_Params {
    int dst;         // destnation modem Id
    int src;         // source modem Id
    int mode;        // communication mode in {1,2,3,4,5}
    int type;        // data type, 0: data message; 1: acoustic wave
    int guard_time;  // protection the acoustic wave between data blocks
    int power_level; // from 0 to 100
} Modem_Phy_Params;

typedef struct Socket_Pkt {
    Modem_Phy_Params phy;
    int payload_size;
    char payload[MAX_DATA_LENGTH];
} Socket_Pkt;

typedef void (*rxCallback)(Modem_Phy_Params phy, int len, char *payload);
typedef void (*Hook)(void);

typedef struct Modem_Ops {
    rxCallback rxcb;
    Hook rx_start_hook;
    Hook rx_stop_hook;
} Modem_Ops;

int modem_init(Modem_Ops *ops);
int modem_start();
// int modem_status(int regId,int field,int *data);
int modem_run();
int modem_stop();
int modem_close();

int modem_send(Modem_Phy_Params *phy, int len, const void *data);

#ifdef __cplusplus
}
#endif
#endif
