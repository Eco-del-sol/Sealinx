#include <errno.h>
#include <sys/select.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <sealinx.h>
#include <sealinx_common.h>
#include <sealinx_utils.h>

#include "ofdm_base.h"

/* Set the output file name */
#define OUTPUT_FILE "./logs/sealinx-ofdm.out"

const char *HEX_MAP = "0123456789ABCDEF";

int write_to_file(const char *input, int input_size)
{
	FILE *fp = fopen(OUTPUT_FILE, "a");
	if (fp == NULL) {
		log_error("failed to open the output file: %s",
			  strerror(errno));
		return -1;
	}
	if (fwrite(input, input_size, 1, fp) < 0) {
		log_error("failed to write to the output file: %s",
			  strerror(errno));
		fclose(fp);
		return -1;
	}
	fclose(fp);
	return 0;
}

void fill_signature(PhysicalDataPacket * pdp)
{
	pdp->signature[0] = 0x55;
	pdp->signature[1] = 0x55;
}

int verify_signature(PhysicalDataPacket * pdp)
{
	//writeLog("0x%2x 0x%2x", (int) pdp->signature[0], (int) pdp->signature[1]);
	if (pdp->signature[0] == 0x55 && pdp->signature[1] == 0x55)
		return 1;

	log_error("Invalid signature (0x%2x 0x%2x )", (int)pdp->signature[0],
		  (int)pdp->signature[1]);
	return 0;
}

/**
 * Lock the modem.
 *
 * @param modem Descriptor of the modem.
 */
int ofdm_lock(Modem * modem)
{
	pthread_mutex_lock(&modem->lock);
#ifdef DEBUG
	log_info("Lock modem");
#endif
}

/**
 * Unlock the modem.
 *
 * @param modem Descriptor of the modem.
 */
int ofdm_release(Modem * modem)
{
#ifdef DEBUG
	log_info("Release modem");
#endif
	pthread_mutex_unlock(&modem->lock);
}

/**
 * Prepares the raw data stream of a PDU to send.
 *
 * @param pdu The PDU.
 * @param sendBuffer The raw data stream buffer.
 * @return Length of the raw data stream.
 */
int serialize_pdu(PduBuff * pdu, char *sendBuffer)
{
	PhysicalDataPacket *pdp = (PhysicalDataPacket *) sendBuffer;
	char *bp = (char *)pdp->data;
	int total_num = sizeof(PhysicalDataPacket), i;

	fill_signature(pdp);

	// Start copying frame length
	memcpy(bp, &(pdu->msg_len), sizeof(pdu->msg_len));
	bp += sizeof(pdu->msg_len);
	total_num += sizeof(pdu->msg_len);
	// Start copying mac header
	memcpy(bp, &(pdu->hdr_mac), pdu->hdr_mac.hdr_len);
	bp += pdu->hdr_mac.hdr_len;
	total_num += pdu->hdr_mac.hdr_len;
	// Start copying network header
	*bp++ = ':';		/* Use ':' to seperate headers */
	total_num++;
	memcpy(bp, &(pdu->hdr_net), pdu->hdr_net.hdr_len);
	bp += pdu->hdr_net.hdr_len;
	total_num += pdu->hdr_net.hdr_len;
	// Start copying transport header
	*bp++ = ':';		/* Use ':' to seperate headers */
	total_num++;
	memcpy(bp, &(pdu->hdr_tra), pdu->hdr_tra.hdr_len);
	bp += pdu->hdr_tra.hdr_len;
	total_num += pdu->hdr_tra.hdr_len;
	// Start copying data payload
	*bp++ = ':';		/* Use ':' to seperate headers and payload */
	total_num++;
	memcpy(bp, &(pdu->pkt_data), pdu->msg_len);
	bp += pdu->msg_len;
	total_num += pdu->msg_len;
	*bp++ = ':';		/* Use ':' to mark the end of payload */
	total_num++;

	pdp->length = total_num - sizeof(PhysicalDataPacket);
	pdp->crc = sl_crc32((char *)pdp->data, pdp->length);

	for (i = total_num - 1; i >= 0; i--) {
		int c = sendBuffer[i];
		sendBuffer[i * 2 + 1] = HEX_MAP[c & 15];
		sendBuffer[i * 2] = HEX_MAP[(c >> 4) & 15];
	}
	return 2 * total_num;
}

/**
 * Deserializes raw data into a PDU.
 *
 * @param bp The raw data.
 * @param pdu The PDU.
 */
void deserialize_raw_data(char *bp, struct pdu_buff *pdu)
{
	struct type_mac_hdr m_hdr;
	struct type_net_hdr n_hdr;
	struct type_tra_hdr t_hdr;
	unsigned short int header_len = 0;
	unsigned short int recv_frame_len = 0;
	// Then get the DATA length of the frame
	memcpy(&recv_frame_len, bp, sizeof(pdu->msg_len));
	/* recv_frame_len is the size of DATA */

	bp += sizeof(pdu->msg_len);

	// Then copy the hearders into the pdu
	// Starting from MAC header
	memset(&m_hdr, 0, sizeof(struct type_mac_hdr));
	memcpy(&header_len, bp, sizeof(m_hdr.hdr_len));
	memcpy(&m_hdr, bp, header_len);
	memcpy(&(pdu->hdr_mac), &m_hdr, sizeof(struct type_mac_hdr));
	bp += header_len;
	bp++;			/* Jump over the ':' between MAC and NET headers */
	// Processing the NET header
	if (*bp != ':') {
		/* Meaning there is a NET header */
		memset(&n_hdr, 0, sizeof(struct type_net_hdr));
		memcpy(&header_len, bp, sizeof(n_hdr.hdr_len));
		memcpy(&n_hdr, bp, header_len);
		memcpy(&(pdu->hdr_net), &n_hdr, sizeof(struct type_net_hdr));
		bp += header_len;
	}
	bp++;			/* Jump over the ':' between NET and TRA headers */
	// Processing the TRA header
	if (*bp != ':') {
		/* Meaning there is a TRA header */
		memset(&t_hdr, 0, sizeof(struct type_tra_hdr));
		memcpy(&header_len, bp, sizeof(t_hdr.hdr_len));
		memcpy(&t_hdr, bp, header_len);
		memcpy(&(pdu->hdr_tra), &t_hdr, sizeof(struct type_tra_hdr));
		bp += header_len;
	}
	bp++;			/* Jump over the ':' between TRA header and APP payload */
	// Copy the payload into the pdu
	if (*bp != ':')		/* Meaning there is a APP payload */
		memcpy(&(pdu->pkt_data), bp, recv_frame_len);

	bp++;			/* Jump over the ':' after the APP payload */
	// Set the payload length
	pdu->msg_len = recv_frame_len;
	//pdu->pkt_type = PACKET_INCOMING;
//	pdu->pkt_state = PKT_STATE_PHY;
}

/**
 * Converts a hexadecimal digit to a byte value.
 *
 * @param a The hexadecimal digit.
 * @return The byte value if valid; -1, otherwise.
 */
int hex_to_dec(char a)
{
	if ('0' <= a && '9' >= a)
		return a - '0';
	else if ('a' <= a && 'f' >= a)
		return a - 'a' + 10;
	else if ('A' <= a && 'F' >= a)
		return a - 'A' + 10;

	return -1;
}

/**
 * Interprets a command response (not including $MMRXD.)
 *
 * @param data The byte stream containing command responses.
 * @param len Size of the byte stream
 *
 * @retval 0 More data is needed to interpret.
 * @retval -1 Length of unrecognized response.
 * @retval >0 Length of recognized response.
 */
int interpret_cmd_resp(char *data, int len)
{
	int n = 0, crlfFound;
	if (len < 3)		/* a response must have '$', '\r', '\n' */
		return 0;

	while (n < len && data[n] != '\n')
		n++;

	crlfFound = n < len && data[n] == '\n';

	if (crlfFound) {
		n++;
		if (n > 6 && memcmp(data, "$MMOKY", 6) == 0)
			return n;
		if (n > 7
		    && (memcmp(data, "$MMERR,", 7) == 0
			|| memcmp(data, "$MMTDN,", 7) == 0))
			return n;
	} else {
		if (memcmp(data, "$MMOKY", max(n, 6)) == 0
		    || memcmp(data, "$MMERR,", max(n, 7)) == 0
		    || memcmp(data, "$MMTDN,", max(n, 7)) == 0)
			return 0;
	}
	return -n;
}

/**
 * Interprets the data part following $MMRXD.
 *
 * @param src The octet stream.
 * @param len Size of the octet stream.
 * @param dst The destination byte stream.
 *
 * @retval Length of the octet data that is interpreted.
 */
int interpret_hex_data(char *src, int len, char *dst)
{
	int i, k = 0, n = len % 2 ? len - 1 : len;
	for (i = 0; i < n - 1; i += 2) {
		int a = hex_to_dec(src[i]), b = hex_to_dec(src[i + 1]);
		if (a == -1 || b == -1)
			break;

		dst[k++] = (a << 4) | b;
	}
	return k * 2;
}

/**
 * Resets parameter of an ofdm modem.
 *
 * @param modem Descriptor of the modem.
 */
void ofdm_reset(Modem * modem)
{
	modem->appDataLen = 0;
	modem->nypRecvBuffer = modem->recvBuffer;
	modem->nypRecvBufLen = 0;
	modem->cmdRespLen = 0;
	modem->readState = READ_STATE_RESP;
	modem->initialized = FALSE;
}

/**
 * Checks whether there are pending responses in the buffer.
 *
 * @param modem Descriptor of the modem.
 * @return TRUE if there are pending responses; FALSE, otherwise.
 */
int resp_in_buffer(Modem * modem)
{
	return modem->cmdRespLen > 0;
}

/**
 * Initialize the OFDM modem.
 *
 * @param fd File descriptor of the serial port connecting to the modem.
 * @param appUnitSize Size of application block.
 * @param phyUnitSize Size of physical blocks
 *
 * @return Descriptor of the modem if successfully initialized; NULL, otherwise.
 */
Modem *ofdm_init(int fd, int appUnitSize, int phyUnitSize,
		 DeliverPduCallBack dpc)
{
	Modem *modem = (Modem *) malloc(sizeof(Modem));

	modem->appData = (char *)malloc(appUnitSize);
	/* The sending buffer contains the physical data packet (in
	   hexadecimal form) and the command preamble + CRLF. */
	modem->sendBufSize = 2 * phyUnitSize + CMD_OVERHEAD_LENGTH;
	modem->sendBuffer = malloc(modem->sendBufSize);

	/* The receiving buffer contains the physical data packet (in
	   hexadecimal form) and the command response. */
	modem->recvBufSize = 2 * phyUnitSize + CMD_OVERHEAD_LENGTH;
	modem->recvBuffer = malloc(modem->recvBufSize);
	modem->fd = fd;
	modem->deliver_pdu_callback = dpc;
	pthread_mutex_init(&modem->lock, NULL);
	ofdm_reset(modem);
	return modem;
}

/**
 * Release the modem.
 *
 * @param modem Descriptor of the modem.
 */
void ofdm_free(Modem * modem)
{
	if (!modem)
		return;

	pthread_mutex_destroy(&modem->lock);
	free(modem->appData);
	free(modem->recvBuffer);
	free(modem);
}

int ofdm_write_wait(Modem * modem, long int sec, long int usec)
{
	fd_set set;
	struct timeval timeout;

	FD_ZERO(&set);
	FD_SET(modem->fd, &set);

	timeout.tv_sec = sec;
	timeout.tv_usec = usec;
	return select(FD_SETSIZE, NULL, &set, NULL, &timeout);
}

int ofdm_read_wait(Modem * modem, long int sec, long int usec)
{
	fd_set set;
	struct timeval timeout;

	FD_ZERO(&set);
	FD_SET(modem->fd, &set);

	timeout.tv_sec = sec;
	timeout.tv_usec = usec;
	return select(FD_SETSIZE, &set, NULL, NULL, &timeout);
}

/**
 * Checks whether data is ready in the serial line.
 *
 * @param modem Descriptor of the modem.
 * @param waitInterval The interval that the input is probed (in microseconds).
 * @return 0 if timeout, 1 if input available, -1 if error.
 */
int ofdm_data_ready(Modem * modem, unsigned int waitInterval)
{
	fd_set set;
	struct timeval timeout;

	/* Initialize the file descriptor set. */
	FD_ZERO(&set);
	FD_SET(modem->fd, &set);

	/* Initialize the timeout data structure. */
	timeout.tv_sec = waitInterval / 1000000;
	timeout.tv_usec = waitInterval % 1000000;

	/* select returns 0 if timeout, 1 if input available, -1 if error. */
	return select(FD_SETSIZE, &set, NULL, NULL, &timeout);
}

void handle_mmrxd(Modem * modem)
{
	int i, nCommas = 0;

	/* for new format */
	for (i = 7; i < modem->nypRecvBufLen && nCommas < 2; i++) {
		if (modem->nypRecvBuffer[i] == ',')
			nCommas++;
	}

	if (nCommas == 2) {
//        log_info("MMRXD header complete, state changed: response -> data, data @ %d", i);
		MOVE_BUFFER_POINTER(modem->nypRecvBuffer, modem->nypRecvBufLen,
				    i);
		modem->readState = READ_STATE_DATA;
	} else {
//        log_info("MMRXD header incomplete, state unchanged");
	}
}

/**
 * Processes the modem raw data stream as data.
 *
 * @param modem Descriptor of the modem.
 * @return TRUE if there are something that can be interpreted in the sream; FALSE, otherwise.
 */
int process_stream_as_data(Modem * modem)
{
	int k;
	if (hex_to_dec(*modem->nypRecvBuffer) != -1
	    && hex_to_dec(*(modem->nypRecvBuffer + 1)) != -1) {
		k = interpret_hex_data(modem->nypRecvBuffer,
				       modem->nypRecvBufLen,
				       modem->appData + modem->appDataLen);
		modem->appDataLen += k / 2;
		MOVE_BUFFER_POINTER(modem->nypRecvBuffer, modem->nypRecvBufLen,
				    k);
	} else if (*modem->nypRecvBuffer == '\r'
		   && *(modem->nypRecvBuffer + 1) == '\n') {
		modem->readState = READ_STATE_RESP;
		MOVE_BUFFER_POINTER(modem->nypRecvBuffer, modem->nypRecvBufLen,
				    2);
//        log_info("modem->nypRecvBufLen = %d", modem->nypRecvBufLen);
	} else {
		for (k = 0;
		     k < modem->nypRecvBufLen && modem->nypRecvBuffer[k] != '$';
		     k++) ;
		MOVE_BUFFER_POINTER(modem->nypRecvBuffer, modem->nypRecvBufLen,
				    k);
		modem->readState = READ_STATE_RESP;
//        log_info("skip %d invalid input bytes", k);
	}
	return modem->nypRecvBufLen > 1;
}

/**
 * Processes the modem raw data stream as response.
 *
 * @param modem Descriptor of the modem.
 * @return TRUE if there are something left in the stream that can be interpreted; FALSE, otherwise.
 */
int process_stream_as_resp(Modem * modem)
{
	int k, moreData = TRUE;
	for (k = 0; k < modem->nypRecvBufLen && modem->nypRecvBuffer[k] != '$';
	     k++) ;
	MOVE_BUFFER_POINTER(modem->nypRecvBuffer, modem->nypRecvBufLen, k);
	if (modem->nypRecvBufLen >= 7
	    && memcmp(modem->nypRecvBuffer, "$MMRXD,", 7) == 0) {
		handle_mmrxd(modem);
	} else {
		k = interpret_cmd_resp(modem->nypRecvBuffer,
				       modem->nypRecvBufLen);
		if (k > 0) {
			memcpy(modem->cmdResponse + modem->cmdRespLen,
			       modem->nypRecvBuffer, k);
			modem->cmdRespLen += k + 1;
			modem->cmdResponse[modem->cmdRespLen - 1] = '\0';
			MOVE_BUFFER_POINTER(modem->nypRecvBuffer,
					    modem->nypRecvBufLen, k);
		} else if (k < 0) {
			log_error("Invalid response");
			log_data(modem->nypRecvBuffer, -k);
			MOVE_BUFFER_POINTER(modem->nypRecvBuffer,
					    modem->nypRecvBufLen, -k);
			log_info("skip %d invalid input bytes", -k);
			/*modem->readState = READ_STATE_INIT; */
		} else {
			moreData = FALSE;
		}
	}
	return moreData;
}

/**
 * Feed data from modem.
 *
 * @param modem Modem descriptor.
 * @return TRUE if the serial port is still readable; FALSE, otherwise.
 */
int ofdm_fetch_data(Modem * modem)
{
	int running, nread;
	int tt;
	PduBuff pbuf;

	COMPACT_BUFFER(modem->recvBuffer, modem->nypRecvBuffer,
		       modem->nypRecvBufLen);

	nread = read(modem->fd, modem->recvBuffer + modem->nypRecvBufLen,
		     modem->recvBufSize - modem->nypRecvBufLen);

	log_info("get data from serial:");
	for (tt = 0; tt < nread; tt++)
		log_info("%c", modem->recvBuffer[modem->nypRecvBufLen + tt]);
	//
	if (nread == -1) {
		log_error("Error while reading data from serial port: %s",
			  strerror(errno));
		return FALSE;
	} else if (nread == 0) {
		return TRUE;
	}
#ifdef DEBUG
	//write(1, modem->recvBuffer + modem->nypRecvBufLen, nread);
	log_data(modem->recvBuffer + modem->nypRecvBufLen, nread);
	log_info("%s: nread = %d", __PRETTY_FUNCTION__, nread);
#endif

	modem->nypRecvBufLen += nread;

	running = modem->nypRecvBufLen > 1;
	while (running) {
		switch (modem->readState) {
		case READ_STATE_DATA:
			running = process_stream_as_data(modem);
			break;
		case READ_STATE_RESP:
			running = process_stream_as_resp(modem);
			break;
		case READ_STATE_INIT:
			log_error("Possibly modem is reset or in data mode");
			// TODO: remove the following line in production version
			//write(modem->fd, "$HHCRW,R_LPDIS,1\r\n", 18);
			break;
		}
	}
	while (ofdm_data_in_buffer(modem, &pbuf))
		modem->deliver_pdu_callback(&pbuf);

	return TRUE;
}

/**
 * Checks if there is an application data packet in the modem buffer. If so,
 * this function fills a PDU with the data.
 *
 * @param modem Descriptor of the modem.
 * @param pbuf The PDU that will contain the data.
 *
 * @retval TRUE if there is a complete incoming data packet in modem buffer.
 * @retval FALSE otherwise.
 */
int ofdm_data_in_buffer(Modem * modem, PduBuff * pbuf)
{
	// accumulated data
	int retval = FALSE;

//    log_info("%s: modem = %p, modem->appDataLen = %d",
//             __PRETTY_FUNCTION__, modem, modem->appDataLen);

	if (modem->appDataLen < sizeof(PhysicalDataPacket)) {
		/* Size of not-yet-processed data is less than the size of header
		   added by physical layer. */
		return FALSE;
	}
	PhysicalDataPacket *pdp = (PhysicalDataPacket *) modem->appData;
	if (!verify_signature(pdp)) {
		/* Something wrong with the packet. Discard it! */
		modem->appDataLen = 0;
		return FALSE;
	}
//    log_info("%s: pdp->length = %d, modem->appDataLen = %d",
//             __PRETTY_FUNCTION__, pdp->length, modem->appDataLen);
	if (pdp->length + sizeof(PhysicalDataPacket) <= modem->appDataLen) {
#ifdef DEBUG
		log_data(modem->appData,
			 pdp->length + sizeof(PhysicalDataPacket));
#endif
		if (pdp->crc == sl_crc32((char *)pdp->data, pdp->length)) {
			log_info("CRC32 check passed");
			deserialize_raw_data((char *)pdp->data, pbuf);
			int pktlen = pdp->length + sizeof(PhysicalDataPacket);
			memmove(modem->appData, modem->appData + pktlen,
				modem->appDataLen - pktlen);
			modem->appDataLen -= pktlen;
			retval = TRUE;
		} else {
			log_info("CRC32 check failed");
			int nskip;
			for (nskip = 2; nskip < modem->appDataLen - 1; nskip++) {
				if (modem->appData[nskip] == 0x55
				    && modem->appData[nskip + 1] == 0x55)
					break;
			}
			if (nskip == modem->appDataLen - 1
			    && modem->appData[nskip] != 0x55)
				nskip++;
			memmove(modem->appData, modem->appData + nskip,
				modem->appDataLen - nskip);
			modem->appDataLen -= nskip;
		}
	}
	return retval;
}

/**
 * Removes a command response from the command response list.
 *
 * @param modem Descriptor of the modem.
 */
int ofdm_remove_cmd_resp(Modem * modem)
{
	if (modem->cmdRespLen == 0)
		return -1;

	int lengthRemoved = strlen(modem->cmdResponse) + 1;
	/* actual length of cmd response trailing NULL character */

	memmove(modem->cmdResponse, modem->cmdResponse + lengthRemoved,
		modem->cmdRespLen - lengthRemoved);
	modem->cmdRespLen -= lengthRemoved;
	return 0;
}
