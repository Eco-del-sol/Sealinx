/* put synopsis for mac protocols here */
/**
\page overview_page
\section overview_mac_sec MAC Protocols

\subsection sealinx-mac
<tt>sealinx-mac</tt> is a dummy MAC layer. The syntax of <tt>sealinx-mac</tt> is

\code
sealinx-mac -i <protocol ID> -p <core port>
\endcode
where
 - <tt>\<protocol ID\></tt> is the identifier of the protocol, which will be
   filled in the type field in the MAC header.
 - <tt>\<core port\></tt> is the port that the core is listening on.

With this syntax, multiple MAC layers can be connected to one, given
that their identifiers are different.

\subsection sealinx-uwaloha
<tt>sealinx-aloha</tt> implements the ALOHA protocol. The syntax of
<tt>sealinx-uwaloha</tt> is

\code
sealinx-uwaloha -i <protocol ID> -p <core port> -c <aloha config file> -t <arp table file>
\endcode

where 
 - <tt>\<protocol ID\></tt> and <tt>\<core port\></tt> are the same as with sealinx-mac
 - <tt>\<aloha config file\></tt> is the configuration file of aloha.
 - <tt>\<arp table file\></tt> is the file specifying the ARP table.

A sample aloha config file follows

\code
UWALOHA_SOCK_TIMEOUT : 10
UWALOHA_ACK_TIMEOUT : 25
UWALOHA_RETX_MAX  : 3
UWALOHA_BROADCAST_ADD : 99
\endcode

In this file:
 - <tt>UWALOHA_SOCK_TIMEOUT</tt> is the timeout length on reading the core socket.
 - <tt>UWALOHA_ACK_TIMEOUT</tt> is the ACK time out.
 - <tt>UWALOHA_RETX_MAX</tt>  is the maximum number of retransmissions.
 - <tt>UWALOHA_BROADCAST_ADD</tt> is the broadcast address. This is deprecated and will be removed in future releases.

An ARP table file consists of address mappings, each of which is a separate line formatted as follows
\code
<mac address> : <net address>
\endcode

 */
