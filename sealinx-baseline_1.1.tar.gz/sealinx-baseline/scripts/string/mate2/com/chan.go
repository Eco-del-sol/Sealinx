package com

// SimChannel ...
var SimChannel = make(chan Wave, 10)
