#ifndef __OFDM_BASE_H__
#define __OFDM_BASE_H__

#include <pthread.h>

/**
 * Size of OFDM physical packet size.
 */
#define OFDM_PHY_PACKET_SIZE 500

/**
 * Guard against extra data which may be added to a packet before
 * it is sent out.
 */
#define OFDM_EXTRA_GUARD 100

/**
 * Length of command/response preamble.
 */
#define CMD_OVERHEAD_LENGTH 100

/**
 * Length of the buffer containing command responses.
 */
#define CMD_RESP_BUF_LEN (10 * CMD_OVERHEAD_LENGTH)

#define COMPACT_BUFFER(orig, current, currentLen) { \
        memmove((orig), (current), (currentLen));   \
        current = orig;                             \
}

#define MOVE_BUFFER_POINTER(ptr, len, offset) { \
        (ptr) += (offset);                      \
        (len) -= (offset);                      \
}

typedef struct {
	uint8_t signature[2];
	uint16_t length;
	uint32_t crc;
	uint8_t data[0];
} __attribute__ ((__packed__)) PhysicalDataPacket;

typedef enum {
	READ_STATE_RESP,	// reading response
	READ_STATE_DATA,	// reading data
	READ_STATE_INIT		// initialization
} ReadState;

typedef void (*DeliverPduCallBack) (PduBuff *);

/**
 * Descriptor of a modem.
 */
typedef struct {
    /** Buffer to assemble application data. */
	char *appData;
    /** Capacity of appData. */
	int appDataLen;
    /** Command responses. */
	char cmdResponse[CMD_RESP_BUF_LEN];
    /** Length of command responses. */
	int cmdRespLen;
    /** File descriptor of the modem port. */
	int fd;
    /** State of reading modem port. */
	ReadState readState;
    /** Sending buffer. */
	char *sendBuffer;
    /** Capacity of sendBuffer. */
	int sendBufSize;

    /** Receiving buffer. */
	char *recvBuffer;
    /** Capacity of recvBuffer. */
	int recvBufSize;
    /** Not-yet-processed receiving buffer. */
	char *nypRecvBuffer;
    /** Current size of data in nypRecvBuffer. */
	int nypRecvBufLen;
    /** Mutex for reading the modem. */
	pthread_mutex_t lock;

	DeliverPduCallBack deliver_pdu_callback;

	int initialized;
} Modem;

#ifdef	__cplusplus
extern "C" {
#endif

/**
 * Initialize the OFDM modem.
 *
 * @param fd File descriptor of the serial port connecting to the modem.
 * @param appUnitSize Size of application block.
 * @param phyUnitSize Size of physical blocks
 * @param dpc Callback function for delivering a PDU.
 *
 * @return Descriptor of the modem if successfully initialized; NULL, otherwise.
 */
	Modem *ofdm_init(int fd, int appUnitSize, int phyUnitSize,
			 DeliverPduCallBack dpc);

/**
 * Release the modem.
 *
 * @param modem Descriptor of the modem.
 */
	void ofdm_free(Modem * modem);

/**
 * Lock the modem.
 *
 * @param modem Descriptor of the modem.
 */
	int ofdm_lock(Modem * modem);

/**
 * Unlock the modem.
 *
 * @param modem Descriptor of the modem.
 */
	int ofdm_release(Modem * modem);

/**
 * Checks if there is a data packet in the modem buffer. If so, this function
 * fills a PDU with the data.
 *
 * @param modem Descriptor of the modem.
 * @param pbuf The PDU that will contain the data.
 *
 * @retval TRUE if there is a complete incoming data packet in modem buffer.
 * @retval FALSE otherwise.
 */
	int ofdm_data_in_buffer(Modem * modem, PduBuff * pbuf);

/**
 * Checks whether data is ready in the serial line.
 *
 * @param modem Descriptor of the modem.
 * @param waitInterval The interval that the input is probed (in microseconds).
 * @return 0 if timeout, 1 if input available, -1 if error.
 */
	int ofdm_data_ready(Modem * modem, unsigned int waitInterval);

/**
 * Feed data from modem.
 *
 * @param modem Modem descriptor.
 */
	int ofdm_fetch_data(Modem * modem);

/**
 * Checks whether there are pending responses in the buffer.
 *
 * @param modem Descriptor of the modem.
 * @return TRUE if there are pending responses; FALSE, otherwise.
 */
	int resp_in_buffer(Modem * modem);

	int ofdm_read_wait(Modem * modem, long int sec, long int usec);
	int serialize_pdu(PduBuff * pdu, char *sendBuffer);
	int ofdm_remove_cmd_resp(Modem * modem);
	int ofdm_write_wait(Modem * modem, long int sec, long int usec);

#ifdef	__cplusplus
}
#endif
#endif				/* __OFDM_BASE_H__ */
