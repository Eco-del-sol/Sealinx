#include <stdlib.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/shm.h>
#include <sealinx_pdu.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>
#include <sealinx_defs.h>

/**
 * Send data to the upper layer.
 *
 * @param[in] sealinxHandle Handle of the connection.
 * @param[in] data Data to send.
 * @param[in] dataLength The length of the data.
 */
int send_up(SealinxConnection sealinxHandle, void *data, int dataLength)
{
	SealinxConnectionStruct *slac =
	    (SealinxConnectionStruct *) sealinxHandle;
	return client_send_up(slac->connFd, data, dataLength, slac->moduleId,
			      NULL, 0);
}

/**
 * Send data to the lower layer.
 *
 * @param[in] sealinxHandle Handle of the connection.
 * @param[in] data Data to send.
 * @param[in] dataLength The length of the data.
 */
int send_down(SealinxConnection sealinxHandle, void *data, int dataLength)
{
	SealinxConnectionStruct *slac =
	    (SealinxConnectionStruct *) sealinxHandle;

	return client_send_down(slac->connFd, data, dataLength, slac->moduleId,
				NULL, 0);
}

/**
 * Allocates a new packet.
 *
 * @return A handle of the new packet.
 * @retval 0 if the operation fails.
 */
SealinxPacket sp_new()
{
	SealinxPacketStruct *res =
	    (SealinxPacketStruct *) malloc(sizeof(SealinxPacketStruct));
	return (int)res;
}

/**
 * Free an allocated packet
 *
 * @param[in] packet Handle of the packet.
 */
void sp_free(SealinxPacket packet)
{
	free((void *)packet);
}

/**
 * Sets the ID of the MAC layer. This operation is only valid when the
 * packet is typed IMSG_TYPE_DATA.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] id The ID to set.
 * @result TRUE if success; FALSE, otherwise.
 */
int sp_set_mac_type(SealinxPacket packet, ModuleId id)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != IMSG_TYPE_DATA)
		return FALSE;

	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	pbuf->hdr_mac.mac_type = id;
	return TRUE;
}

/**
 * Set the length of the MAC layer header. This operation is only
 * valid when the packet is typed TYPE_DATA and the length of extra
 * data is no more than the allowed size.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] xtraLen Length of extra data.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_mac_extra_len(SealinxPacket packet, PacketLength xtraLen)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != IMSG_TYPE_DATA)
		return FALSE;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	if (xtraLen > sizeof(pbuf->hdr_mac.mac_data))
		return FALSE;
	pbuf->hdr_mac.hdr_len = sizeof(struct type_mac_hdr) -
	    sizeof(pbuf->hdr_mac.mac_data) + xtraLen;
	return TRUE;
}

/**
 * Sets direction of the packet. This information is useful for sealinx_send.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] dir Direction of the packet.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_dir(SealinxPacket packet, PacketDirection dir)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	pkt->header.direction = dir;
	return TRUE;
}

/**
 * Gets packet direction.
 *
 * @param[in] packet Handle of the packet.
 * @return TRUE if success; FALSE, otherwise.
 */
PacketDirection sp_get_dir(SealinxPacket packet)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	return pkt->header.direction;
}

/**
 * Judge if the packet is from upper layer.
 *
 * @param[in] packet Handle of the packet.
 * @return 1 if true; 0, otherwise.
 */
int sp_from_upper(SealinxPacket packet)
{
	return sp_get_dir(packet) == SP_DIRECTION_DOWN;
}

/**
 * Judge if the packet is from lower layer.
 *
 * @param[in] packet Handle of the packet.
 * @return 1 if true; 0, otherwise.
 */
int sp_from_lower(SealinxPacket packet)
{
	return sp_get_dir(packet) == SP_DIRECTION_UP;
}

/**
 * Gets packet type.
 *
 * @param[in] packet Handle of the packet.
 * @return the packet type.
 */
PacketType sp_get_type(SealinxPacket packet)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	return pkt->header.type;
}

/**
 * Sets packet type.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] type Type of the packet.
 */
void sp_set_type(SealinxPacket packet, PacketType type)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	pkt->header.type = type;
}

/**
 * Sets the length of the payload.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] len The new payload length.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_payload_length(SealinxPacket packet, PacketLength len)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != SP_TYPE_DATA)
		return FALSE;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	//if (xtraLen > sizeof(pbuf->hdr_mac.mac_data)) return FALSE;
	// TODO check length here
	pbuf->msg_len = len;
	pkt->header.dataLength = PDU_SIZE(len);
	return TRUE;
}

/**
 * Gets the length of the payload.
 *
 * @param[in] packet The packet.
 * @return The payload length if success; -1, otherwise.
 */
int sp_get_payload_length(SealinxPacket packet)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != SP_TYPE_DATA)
		return -1;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	return pbuf->msg_len;
}

/**
 * Sets the packet's payload.
 *
 * @param[in] packet The packet.
 * @param[in] payload Pointer to the payload.
 * @param[in] payloadLen Size of the payload.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_payload(SealinxPacket packet, void *payload, PacketLength payloadLen)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != SP_TYPE_DATA)
		return FALSE;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	//if (xtraLen > sizeof(pbuf->hdr_mac.mac_data)) return FALSE;
	// TODO check length here
	pbuf->msg_len = payloadLen;
	pkt->header.dataLength = PDU_SIZE(payloadLen);
	memcpy(pbuf->pkt_data, payload, payloadLen);
	return TRUE;
}

/**
 * Sets destination MAC address of a packet. This function is valid
 * only if the packet type is SP_TYPE_DATA.
 *
 * @param[in] packet The packet.
 * @param[in] macAddr The MAC address.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_mac_dst_addr(SealinxPacket packet, MacAddress macAddr)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != SP_TYPE_DATA)
		return FALSE;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	pbuf->hdr_mac.dst_addr = macAddr;
	return TRUE;
}

/**
 * Sets source MAC address of a packet. This function is valid
 * only if the packet type is SP_TYPE_DATA.
 *
 * @param[in] packet The packet.
 * @param[in] macAddr The MAC address.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_mac_src_addr(SealinxPacket packet, MacAddress macAddr)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != SP_TYPE_DATA)
		return FALSE;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	pbuf->hdr_mac.src_addr = macAddr;
	return TRUE;
}

/**
 * Gets destination MAC address of a packet. This function is valid
 * only if the packet type is SP_TYPE_DATA.
 *
 * @param[in] packet The packet.
 * @return The destination MAC address if success; -1, otherwise.
 */
int sp_get_mac_dst_addr(SealinxPacket packet)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != SP_TYPE_DATA)
		return -1;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	return pbuf->hdr_mac.dst_addr;
}

/**
 * Gets source MAC address of a packet. This function is valid
 * only if the packet type is SP_TYPE_DATA.
 *
 * @param[in] packet The packet.
 * @return The source MAC address if success; -1, otherwise.
 */
int sp_get_mac_src_addr(SealinxPacket packet)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != SP_TYPE_DATA)
		return -1;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	return pbuf->hdr_mac.src_addr;
}

/**
 * Sends data to a Sealinx connection
 *
 * @param[in] conn The Sealinx connection.
 * @param[in] packet The packet to send. The packet is initialized
 * outside this funtion.
 * @return Return code of this operation.
 */
int sealinx_send(SealinxConnection conn, SealinxPacket packet)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	SealinxConnectionStruct *sconn = (SealinxConnectionStruct *) conn;
	pkt->header.moduleId = sconn->moduleId;
	return send_to_core(sconn->connFd, pkt->buffer, &pkt->header, NULL, 0);
}

/**
 * Read data from a Sealinx connection.
 *
 * @param[in] conn The Sealinx connection.
 * @param[in,out] packet The packet that hold the reading. The packet
 * must be allocated before being passed into this function.
 * @return Return code of the read operation function. Success is
 * indicated by a positive result; otherwise, non positive.
 */
int sealinx_recv(SealinxConnection conn, SealinxPacket packet)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	SealinxConnectionStruct *sconn = (SealinxConnectionStruct *) conn;
	int nBytesRead =
	    client_read(sconn->connFd, pkt->buffer, IMSG_MAX_DATA_LENGTH,
			&pkt->header, NULL, 0);
	return nBytesRead;
}

/**
 * Opens a Sealinx connection for the PHY layer.
 *
 * @return Non negative if success; error code (negative), otherwise.
 */
int open_phy_connection(SealinxConnection * conn)
{
	int type;
	*conn = 0;
	SealinxConnectionStruct *scs =
	    (SealinxConnectionStruct *)malloc(sizeof(SealinxConnectionStruct));
	
	RegistrationResponse serverResponse;

	scs->moduleId = 22;
	scs->coreSharedData = (CoreSharedData *) - 1;
	scs->connFd =
	    client_connect(type, LAYER_PHYSICAL, NULL, &serverResponse, NULL, 0);
	
	if (scs->connFd == -1)
		return -1;

	scs->coreSharedMemId = serverResponse.coreShareMemId;
	scs->coreSharedData = (CoreSharedData *) shmat(scs->coreSharedMemId, NULL, 0);
	if (scs->coreSharedData == (CoreSharedData *) - 1)
		return -2;

	*conn = (SealinxConnection) scs;
	return 0;
}

/**
 * Calculates packet size from the MAC layer up to application layer,
 * including all headers and payload size. This operation is valid
 * only when the packet type is SP_TYPE_DATA.
 *
 * @param packet The packet.
 * @return The size if success; -1, otherwise.
 */
int sp_get_mac_size(SealinxPacket packet)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != SP_TYPE_DATA)
		return -1;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	return pbuf->msg_len + pbuf->hdr_net.hdr_len +
	    pbuf->hdr_tra.hdr_len + pbuf->hdr_mac.hdr_len;
}

/**
 * Opens a Sealinx connection for the MAC layer.
 *
 * @return Non negative if success; error code (negative), otherwise.
 */
//int open_mac_connection(ModuleId macId, CoreId coreId, SealinxConnection *conn) {
int open_mac_connection(ModuleId macId, SealinxConnection * conn)
{
	int type;
	*conn = 0;
	SealinxConnectionStruct *scs =
	    (SealinxConnectionStruct *) malloc(sizeof(SealinxConnectionStruct));
	ModuleId moduleIds[NUM_LAYERS] = { macId };
	RegistrationResponse serverResponse;

	scs->moduleId = macId;
	scs->coreSharedData = (CoreSharedData *) - 1;
	scs->connFd =
	    client_connect(type, LAYER_MAC, moduleIds, &serverResponse, NULL,
			   0);
	if (scs->connFd == -1)
		return -1;

	scs->coreSharedMemId = serverResponse.coreShareMemId;
	scs->coreSharedData =
	    (CoreSharedData *) shmat(scs->coreSharedMemId, NULL, 0);
	if (scs->coreSharedData == (CoreSharedData *) - 1)
		return -2;

	*conn = (SealinxConnection) scs;
	return 0;
}

/**
 * Opens a Sealinx connection for the network layer.
 *
 * @return Non negative if success; error code (negative), otherwise.
 */
//int open_net_connection(ModuleId netId, ModuleId macId, CoreId coreId, SealinxConnection *conn) {
int open_net_connection(ModuleId netId, ModuleId macId,
			SealinxConnection * conn)
{
	int type = 0;
	*conn = 0;
	SealinxConnectionStruct *scs =
	    (SealinxConnectionStruct *) malloc(sizeof(SealinxConnectionStruct));
	ModuleId moduleIds[NUM_LAYERS] = { macId, netId };
	RegistrationResponse serverResponse;

	scs->moduleId = macId;
	scs->coreSharedData = (CoreSharedData *) - 1;
	scs->connFd =
	    client_connect(type, LAYER_NETWORK, moduleIds, &serverResponse,
			   NULL, 0);

	if (scs->connFd == -1)
		return -1;

	scs->coreSharedMemId = serverResponse.coreShareMemId;
	scs->coreSharedData =
	    (CoreSharedData *) shmat(scs->coreSharedMemId, NULL, 0);
	if (scs->coreSharedData == (CoreSharedData *) - 1)
		return -2;

	*conn = (SealinxConnection) scs;
	return 0;
}

/**
 * Free the sealinx connection.
 * @param conn The sealinx connection.
 */
void free_connection(SealinxConnection conn)
{
	int type = 0;
	SealinxConnectionStruct *scs = (SealinxConnectionStruct *) conn;

	if (scs->coreSharedData != (CoreSharedData *) - 1)
		shmdt(scs->coreSharedData);

	if (scs->connFd > -1)
		client_close(type, scs->connFd, NULL, 0);
}

/**
 * Get local MAC address.
 * @param  conn The sealinx connection.
 * @return MAC address.
 */
MacAddress sp_get_local_mac_addr(SealinxConnection conn)
{
	SealinxConnectionStruct *scs = (SealinxConnectionStruct *) conn;
	return scs->coreSharedData->macAddr;
}

/**
 * Get local Net address.
 * @param  conn The sealinx connection.
 * @return Net address.
 */
MacAddress sp_get_local_net_addr(SealinxConnection conn)
{
	SealinxConnectionStruct *scs = (SealinxConnectionStruct *) conn;
	return scs->coreSharedData->netAddr;
}

/**
 * Sets extra length of the network layer header. This operation is
 * only valid when the packet is typed TYPE_DATA and the length of
 * extra data is no more than the allowed size.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] xtraLen Length of extra data.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_net_extra_len(SealinxPacket packet, PacketLength xtraLen)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != IMSG_TYPE_DATA)
		return FALSE;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	if (xtraLen > sizeof(pbuf->hdr_net.net_data))
		return FALSE;
	pbuf->hdr_net.hdr_len = sizeof(struct type_net_hdr) -
	    sizeof(pbuf->hdr_net.net_data) + xtraLen;
	return TRUE;
}

/**
 * Gets destination network address of a packet. This function is
 * valid only if the packet type is SP_TYPE_DATA.
 *
 * @param[in] packet The packet.
 * @return The destination network address if success; -1 if failure.
 */
int sp_get_net_dst_addr(SealinxPacket packet)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != SP_TYPE_DATA)
		return -1;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	return pbuf->hdr_net.dst_addr;
}

/**
 * Gets source network address of a packet. This function is
 * valid only if the packet type is SP_TYPE_DATA.
 *
 * @param[in] packet The packet.
 * @return The source network address if success; -1, otherwise.
 */
int sp_get_net_src_addr(SealinxPacket packet)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != SP_TYPE_DATA)
		return -1;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	return pbuf->hdr_net.src_addr;
}

/**
 * Sets destination network address of a packet. This function is
 * valid only if the packet type is SP_TYPE_DATA.
 *
 * @param packet The packet.
 * @param netAddr The destination network address to set.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_net_dst_addr(SealinxPacket packet, NetAddress netAddr)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != SP_TYPE_DATA)
		return FALSE;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	pbuf->hdr_net.dst_addr = netAddr;
	return TRUE;
}

/**
 * Sets source network address of a packet. This function is
 * valid only if the packet type is SP_TYPE_DATA.
 *
 * @param packet The packet.
 * @param netAddr The source network address to set.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_net_src_addr(SealinxPacket packet, NetAddress netAddr)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != SP_TYPE_DATA)
		return FALSE;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	pbuf->hdr_net.src_addr = netAddr;
	return TRUE;
}

/**
 * Set next hop network address of a packet. This function is valid
 * only if the packet type is SP_TYPE_DATA.
 *
 * @param packet The packet.
 * @param netAddr The next hop network address to set.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_net_next_hop(SealinxPacket packet, NetAddress netAddr)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != SP_TYPE_DATA)
		return FALSE;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	pbuf->hdr_net.next_hop = netAddr;
	return TRUE;
}

/**
 * Get next hop network address of a packet. This function is valid
 * only if the packet type is SP_TYPE_DATA.
 *
 * @param[in] packet The packet.
 * @return The next hop network address if success; -1, otherwise.
 */
int sp_get_net_next_hop(SealinxPacket packet)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != SP_TYPE_DATA)
		return -1;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	return pbuf->hdr_net.next_hop;
}

/**
 * Calculates packet size from the network layer up to application,
 * including all headers and payload size. This operation is valid
 * only when the packet type is SP_TYPE_DATA.
 *
 * @param packet The packet.
 * @return The size if success; -1, otherwise.
 */
int sp_get_net_size(SealinxPacket packet)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != SP_TYPE_DATA)
		return -1;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	return pbuf->msg_len + pbuf->hdr_net.hdr_len + pbuf->hdr_tra.hdr_len;
}

/**
 * Sets the ID of the network layer. This operation is only valid when
 * the packet is typed IMSG_TYPE_DATA.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] id The ID to set.
 * @result TRUE if success; FALSE, otherwise.
 */
int sp_set_net_type(SealinxPacket packet, ModuleId id)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != IMSG_TYPE_DATA)
		return FALSE;

	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	pbuf->hdr_net.net_type = id;
	return TRUE;
}

/**
 * Opens a Sealinx connection for the transport layer.
 *
 * @param[in] traId ID of the transport layer.
 * @param[in] netId ID of the network layer.
 * @param[in] macId ID of the MAC layer.
 * @param[in] coreId ID of the core module.
 * @param[out] conn The new connection.
 * @return Non negative if success; error code (negative), otherwise.
 */
//int open_tra_connection(ModuleId traId, ModuleId netId, ModuleId macId, CoreId coreId, SealinxConnection *conn) {
int open_tra_connection(ModuleId traId, ModuleId netId, ModuleId macId,
			SealinxConnection * conn)
{
	int type = 0;
	*conn = 0;
	SealinxConnectionStruct *scs =
	    (SealinxConnectionStruct *) malloc(sizeof(SealinxConnectionStruct));
	ModuleId moduleIds[NUM_LAYERS] = { macId, netId, traId };
	RegistrationResponse serverResponse;

	scs->moduleId = macId;
	scs->coreSharedData = (CoreSharedData *) - 1;
	scs->connFd =
	    client_connect(type, LAYER_TRANSPORT, moduleIds, &serverResponse,
			   NULL, 0);

	if (scs->connFd == -1)
		return -1;

	scs->coreSharedMemId = serverResponse.coreShareMemId;
	scs->coreSharedData =
	    (CoreSharedData *) shmat(scs->coreSharedMemId, NULL, 0);
	if (scs->coreSharedData == (CoreSharedData *) - 1)
		return -2;

	*conn = (SealinxConnection) scs;
	return 0;
}

/**
 * Sets the ID of the transport layer. This operation is only valid when
 * the packet is typed IMSG_TYPE_DATA.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] id The ID to set.
 * @result TRUE if success; FALSE, otherwise.
 */
int sp_set_tra_type(SealinxPacket packet, ModuleId id)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != IMSG_TYPE_DATA)
		return FALSE;

	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	pbuf->hdr_tra.tra_type = id;
	return TRUE;
}

/**
 * Sets extra length of the transport layer header. This operation is
 * only valid when the packet is typed TYPE_DATA and the length of
 * extra data is no more than the allowed size.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] xtraLen Length of extra data.
 * @return TRUE if success; FALSE, otherwise.
 */
int sp_set_tra_extra_len(SealinxPacket packet, PacketLength xtraLen)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != IMSG_TYPE_DATA)
		return FALSE;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	if (xtraLen > sizeof(pbuf->hdr_tra.tra_data))
		return FALSE;
	pbuf->hdr_tra.hdr_len = sizeof(struct type_tra_hdr) -
	    sizeof(pbuf->hdr_tra.tra_data) + xtraLen;
	return TRUE;
}

/**
 * Calculates packet size from the transport layer up to application,
 * including all headers and payload size. This operation is valid
 * only when the packet type is SP_TYPE_DATA.
 *
 * @param packet The packet.
 * @return The size if success; -1, otherwise.
 */
int sp_get_tra_size(SealinxPacket packet)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != SP_TYPE_DATA)
		return -1;
	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	return pbuf->msg_len + pbuf->hdr_tra.hdr_len;
}

/**
 * Sets the service type of the transport layer. This operation is
 * only valid when the packet is typed IMSG_TYPE_DATA.
 *
 * @param[in] packet Handle of the packet.
 * @param[in] id The ID to set.
 * @result TRUE if success; FALSE, otherwise.
 */
int sp_set_tra_service_type(SealinxPacket packet, ModuleId id)
{
	SealinxPacketStruct *pkt = (SealinxPacketStruct *) packet;
	if (pkt->header.type != IMSG_TYPE_DATA)
		return FALSE;

	PduBuff *pbuf = (PduBuff *) pkt->buffer;
	pbuf->hdr_tra.service_type = id;
	return TRUE;
}

/**
 * Opens a Sealinx connection for the application layer.
 *
 * @param[in] appId ID of the application layer.
 * @param[in] traId ID of the transport layer.
 * @param[in] netId ID of the network layer.
 * @param[in] macId ID of the MAC layer.
 * @param[in] coreId ID of the core module.
 * @param[out] conn The new connection.
 * @return Non negative if success; error code (negative), otherwise.
 */
//int open_app_connection(ModuleId appId, ModuleId traId, ModuleId netId, ModuleId macId, CoreId coreId, SealinxConnection *conn) {
int open_app_connection(ModuleId appId, ModuleId traId, ModuleId netId,
			ModuleId macId, SealinxConnection * conn)
{
	int type = 0;
	*conn = 0;
	SealinxConnectionStruct *scs =
	    (SealinxConnectionStruct *) malloc(sizeof(SealinxConnectionStruct));
	ModuleId moduleIds[NUM_LAYERS] = { macId, netId, traId, appId };
	RegistrationResponse serverResponse;

	scs->moduleId = macId;
	scs->coreSharedData = (CoreSharedData *) - 1;
	scs->connFd =
	    client_connect(type, LAYER_APPLICATION, moduleIds, &serverResponse,
			   NULL, 0);
	if (scs->connFd == -1)
		return -1;

	scs->coreSharedMemId = serverResponse.coreShareMemId;
	scs->coreSharedData =
	    (CoreSharedData *) shmat(scs->coreSharedMemId, NULL, 0);
	if (scs->coreSharedData == (CoreSharedData *) - 1)
		return -2;

	*conn = (SealinxConnection) scs;
	return 0;
}
