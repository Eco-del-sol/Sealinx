ps axo user:20,pid,cmd | grep "sealinx*" | grep `eval whoami` | \
	grep -v grep | grep -v "gedit"| grep -v "sealinx-core" | awk '{print $2}' | \
	while read i; do kill -9 $i; done

ps axo user:20,pid,cmd | grep "sealinx-core" | grep `eval whoami` | \
	grep -v grep | awk '{print $2}' | \
	while read i; do kill $i; done
