/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * OFDM modem in command mode.
 *
 * @author
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <err.h>
#include <errno.h>
#include <signal.h>
#include <pthread.h>
#include <termios.h>
#include <sys/time.h>
#include <sys/shm.h>
#include <time.h>
#include <math.h>
#include <sealinx.h>
#include <sealinx_utils.h>
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>
#include "config.h"
#include "sealinx-ang.h"

/** Log identity for this module. */
char *g_logId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char *g_logFolder = DEFAULT_LOG_FOLDER;

/** File descriptor of the connection to the core. */
int g_connFd;

/** Shared data by the core module. */
CoreSharedData *g_coreSharedData;

/** ID of the shared memory by the core module. */
int g_coreSharedMemId;

/** Name of the config file. */
char *g_cfgFileName = DEFAULT_CFG_FILE_NAME;

/** Verbosity level. */
int g_verbose = 0;

/** Modem Node */
int g_node = 0;

/** The thread reading the modem. */
pthread_t g_modemThread;

/** The thread reading the core. */
pthread_t g_coreThread;

/** The acoustic sending rate of the OFDM modem (bps). */
int g_ofdmAcousticRate;
/** The maximum transmission unit (bytes)/ */
int g_ofdmMtu;
/** the OFDM inter frame guard time (ms). */
int g_ofdmIfgt;

int g_running;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 1;

extern struct mdm_phy_ops *gMdmDrvOps;

#define FILE_BUFSIZE (1024)

/**
 * Read configuration file for OFDM
 *
 * @param serialFd File descriptor of the serial port connecting to the modem.
 * @param confFileName Name of the config file.
 * @return TRUE if the operation succeeds; FALSE, otherwise.
 */
int read_config(char *confFileName)
{
	char local_buff[FILE_BUFSIZE];
	char *token;
	g_ofdmMtu = 0, g_ofdmAcousticRate = 0, g_ofdmIfgt = 0;

	/* Open up modem configuration file */
	FILE *ofdm_cfg = fopen(confFileName, "r");
	if (!ofdm_cfg) {
		log_info("Could not open config file: %s", strerror(errno));
		return FALSE;
	}
	memset(local_buff, 0, sizeof(local_buff));
	log_info("Reading config file...");
	/* Reading the config file */
	while (fgets(local_buff, sizeof(local_buff), ofdm_cfg)) {
		token = strtok(local_buff, " :");
		if (*token == '#')
			continue;
		if (strstr(token, "OFDM_ACOUSTIC_RATE")) {
			token = strtok(NULL, " :");
			g_ofdmAcousticRate = atoi(token);
			log_info("G_OFDMACOUSTICRATE: %d bps",
				 g_ofdmAcousticRate);
			if (g_ofdmAcousticRate <= 0) {
				log_error("OFDM_ACOUSTIC_RATE invalid value");
				fclose(ofdm_cfg);
				return FALSE;
			}
			continue;
		} else if (strstr(token, "OFDM_MTU")) {
			token = strtok(NULL, " :");
			g_ofdmMtu = atoi(token);
			log_info("OFDM_MTU: %d.", g_ofdmMtu);
			if (g_ofdmMtu <= 0) {
				log_error("OFDM_MTU invalid value");
				fclose(ofdm_cfg);
				return FALSE;
			}
			continue;
		} else if (strstr(token, "OFDM_IFGT")) {
			token = strtok(NULL, " :");
			g_ofdmIfgt = atoi(token);
			log_info("OFDM_IFGT: %d.", g_ofdmIfgt);
			if (g_ofdmIfgt <= 0) {
				log_error("OFDM_IFGT invalid value");
				fclose(ofdm_cfg);
				return FALSE;
			}
			continue;
		} else {
			continue;
		}
	}
	if (g_ofdmMtu * g_ofdmAcousticRate * g_ofdmIfgt == 0) {
		log_error("Missing required parameter(s)!");
		fclose(ofdm_cfg);
		return FALSE;
	}
	fclose(ofdm_cfg);
	return TRUE;
}

void fill_signature(PhysicalDataPacket * pdp)
{
	pdp->signature[0] = 0x55;
	pdp->signature[1] = 0x55;
}

void clean_up(void)
{
	log_info("Cleanup resources.");
	log_info("Stopping OFDM Modem Driver");

	if (g_coreSharedData) {
		if (shmdt(g_coreSharedData) == -1)
			log_error("Unable to detach shared data: %s",
				  strerror(errno));
	}

	close_logger();
	gMdmDrvOps->close();
}

void signal_handler(int sig)
{
	int type = 0;
	log_info("Received signal (%d)", sig);
	log_info("Prepare to shut down driver");

	g_running = FALSE;

	if (g_connFd > -1) {
		log_info("Close connection to core");
		client_close(type, g_connFd, NULL, 0);
	} else {
		log_info("no connection to core");	//tbd
	}
}

/**
 * Delivers a PDU to the upper layer.
 *
 * @param pbuf The PDU to be delivered.
 */
void deliver_pdu1(PduBuff * pbuf)
{
	if (!gMdmDrvOps->isInitialized()) {
		log_info
		    ("Drop packet from %d (modem driver has not been fully initialized)",
		     (int)pbuf->hdr_mac.src_addr);
	} else {
		log_info("Deliver data to upper layer");
		//client_send_up(g_connFd, pbuf, PDU_SIZE(pbuf->msg_len), OFDM_DRIVER_ID, NULL, 0);
		client_send_up(g_connFd, pbuf, sizeof(PduBuff), OFDM_DRIVER_ID,
			       NULL, 0);
	}
}

/**
 * Prepares the raw data stream of a PDU to send.
 *
 * @param pdu The PDU.
 * @param sendBuffer The raw data stream buffer.
 * @return Length of the raw data stream.
 */
int serialize_pdu(PduBuff * pdu, char *sendBuffer)
{
	PhysicalDataPacket *pdp = (PhysicalDataPacket *) sendBuffer;
	char *bp = (char *)pdp->data;
	int total_num = sizeof(PhysicalDataPacket), i;

	fill_signature(pdp);

	// Start copying frame length
	memcpy(bp, &(pdu->msg_len), sizeof(pdu->msg_len));
	bp += sizeof(pdu->msg_len);
	total_num += sizeof(pdu->msg_len);
	// Start copying mac header
	memcpy(bp, &(pdu->hdr_mac), pdu->hdr_mac.hdr_len);
	bp += pdu->hdr_mac.hdr_len;
	total_num += pdu->hdr_mac.hdr_len;
	// Start copying network header
	*bp++ = ':';		/* Use ':' to seperate headers */
	total_num++;
	memcpy(bp, &(pdu->hdr_net), pdu->hdr_net.hdr_len);
	bp += pdu->hdr_net.hdr_len;
	total_num += pdu->hdr_net.hdr_len;
	// Start copying transport header
	*bp++ = ':';		/* Use ':' to seperate headers */
	total_num++;
	memcpy(bp, &(pdu->hdr_tra), pdu->hdr_tra.hdr_len);
	bp += pdu->hdr_tra.hdr_len;
	total_num += pdu->hdr_tra.hdr_len;
	// Start copying data payload
	*bp++ = ':';		/* Use ':' to seperate headers and payload */
	total_num++;
	memcpy(bp, &(pdu->pkt_data), pdu->msg_len);
	bp += pdu->msg_len;
	total_num += pdu->msg_len;
	*bp++ = ':';		/* Use ':' to mark the end of payload */
	total_num++;

	pdp->length = total_num - sizeof(PhysicalDataPacket);
	pdp->crc = sl_crc32((char *)pdp->data, pdp->length);

	return total_num;
}

/**
 * Deserializes raw data into a PDU.
 *
 * @param bp The raw data.
 * @param pdu The PDU.
 */
void deserialize_raw_data(char *bp, struct pdu_buff *pdu)
{
	struct type_mac_hdr m_hdr;
	struct type_net_hdr n_hdr;
	struct type_tra_hdr t_hdr;
	unsigned short int header_len = 0;
	unsigned short int recv_frame_len = 0;
	// Then get the DATA length of the frame
	memcpy(&recv_frame_len, bp, sizeof(pdu->msg_len));
	/* recv_frame_len is the size of DATA */

	bp += sizeof(pdu->msg_len);

	// Then copy the hearders into the pdu
	// Starting from MAC header
	memset(&m_hdr, 0, sizeof(struct type_mac_hdr));
	memcpy(&header_len, bp, sizeof(m_hdr.hdr_len));
	memcpy(&m_hdr, bp, header_len);
	memcpy(&(pdu->hdr_mac), &m_hdr, sizeof(struct type_mac_hdr));
	bp += header_len;
	bp++;			/* Jump over the ':' between MAC and NET headers */
	// Processing the NET header
	if (*bp != ':') {
		/* Meaning there is a NET header */
		memset(&n_hdr, 0, sizeof(struct type_net_hdr));
		memcpy(&header_len, bp, sizeof(n_hdr.hdr_len));
		memcpy(&n_hdr, bp, header_len);
		memcpy(&(pdu->hdr_net), &n_hdr, sizeof(struct type_net_hdr));
		bp += header_len;
	}
	bp++;			/* Jump over the ':' between NET and TRA headers */
	// Processing the TRA header
	if (*bp != ':') {
		/* Meaning there is a TRA header */
		memset(&t_hdr, 0, sizeof(struct type_tra_hdr));
		memcpy(&header_len, bp, sizeof(t_hdr.hdr_len));
		memcpy(&t_hdr, bp, header_len);
		memcpy(&(pdu->hdr_tra), &t_hdr, sizeof(struct type_tra_hdr));
		bp += header_len;
	}
	bp++;			/* Jump over the ':' between TRA header and APP payload */
	// Copy the payload into the pdu
	if (*bp != ':') {
		/* Meaning there is a APP payload */
		memcpy(&(pdu->pkt_data), bp, recv_frame_len);
	}
	bp++;			/* Jump over the ':' after the APP payload */
	// Set the payload length
	pdu->msg_len = recv_frame_len;
	//pdu->pkt_type = PACKET_INCOMING;
//	pdu->pkt_state = PKT_STATE_PHY;
}

/**
 * Main function of the thread handling data from modem.
 *
 * @param data UNUSED.
 * @return UNUSED.
 */
void *modem_thread(void *data)
{
	PduBuff pdu;
	int err;
	while (g_running) {
		while (err = gMdmDrvOps->get(&pdu))
			usleep(50000);

		deliver_pdu1(&pdu);
	}
	return NULL;
}

/**
 * Main function of the thread handling data from upper layers.
 *
 * @param data UNUSED.
 * @return UNUSED.
 */
void *core_thread(void *data)
{
	char buffer[IMSG_MAX_DATA_LENGTH * 2];
	int len;
	InternalMessageHeader dataHeader;
	while (g_running) {
		int nBytesRead = client_read(g_connFd, buffer,
					     IMSG_MAX_DATA_LENGTH, &dataHeader,
					     NULL, 0);
		if (nBytesRead == -1) {
			log_error("Error reading from core: %s",
				  strerror(errno));
			break;
		}
		logReceiveFromStack(nBytesRead, "");
		if (nBytesRead == 0) {
			log_info("Core connection closed");
			break;
		}
		PduBuff *pbuf = (PduBuff *) buffer;
		if (from_upper_layer(dataHeader)) {
			while (!gMdmDrvOps->isInitialized() && g_running)
				usleep(10000);
			gMdmDrvOps->put(pbuf);

			// todo: handle error in the following way
		} else {
			log_error("Invalid packet direction");
		}
	}
	log_info("Enter core thread");
	return NULL;
}

/**
 * Parse command line arguments.
 *
 * @param argc Number of arguments
 * @param argv The arguments
 * @return TRUE if the argument can be parse; FALSE, otherwise.
 */
int parse_arguments(int argc, char **argv)
{
	int i = 0;
	while (i < argc) {
		char *t = argv[i];
		if (strcmp(t, "-c") == 0) {
			i++;
			if (i < argc)
				g_cfgFileName = argv[i];
		} else if (strcmp(t, "-g") == 0) {
			g_verbose = TRUE;
		} else if (strcmp(t, "-g2") == 0) {
			g_verbose = 2;
		} else if (strcmp(t, "-f") == 0) {
			i++;
			if (i < argc)
				gLogFile = atoi(argv[i]);
		} else if (strcmp(t, "-n") == 0) {
			i++;
			if (i < argc)
				g_node = atoi(argv[i]);
		}
		i++;
	}
	return TRUE;
}

/**
 * Initializes modem.
 *
 * @retval TRUE if the operation succeeds.
 * @retval FALSE if the operation fails.
 */
int init_modem(void)
{
	/* Initialize the modem */
	if (!read_config(g_cfgFileName)) {
		log_error("Fail to initialize modem");
		return FALSE;
	}
	if (gMdmDrvOps->init())
		return FALSE;

	gMdmDrvOps->report(&g_node);
	return TRUE;
}

/**
 * Initialize the program.
 *
 * @retval TRUE if the operation succeeds.
 * @retval FALSE if the operation fails.
 */
int init(void)
{
	int type = 0;
	g_running = TRUE;

	if (!init_logger(g_logFolder, g_logId, gLogFile, TRUE, NULL, 0)) {
		fprintf(stderr, "Fail to init the log module.");
		return FALSE;
	}

	RegistrationResponse serverResponse;

	g_connFd =
	    client_connect(type, LAYER_PHYSICAL, NULL, &serverResponse, NULL,
			   0);

	if (g_connFd == -1)
		return FALSE;

	g_coreSharedMemId = serverResponse.coreShareMemId;

	log_info("Key of core shared memory: %d", g_coreSharedMemId);

	g_coreSharedData = (CoreSharedData *) shmat(g_coreSharedMemId, NULL, 0);
	if (g_coreSharedData == (CoreSharedData *) - 1) {
		log_error("Unable to attach the shared memory: %s",
			  strerror(errno));
		return FALSE;
	}

	logger_set_node_id(g_coreSharedData->macAddr,
			   g_coreSharedData->netAddr);
	log_info("Mac address: %d, net address: %d",
		 (int)g_coreSharedData->macAddr,
		 (int)g_coreSharedData->netAddr);

	if (init_modem() != TRUE) {
		log_error("test init mode failed");
		return FALSE;
	} else {
		log_info("Modem init succeeds");
	}
	return TRUE;
}

/**
 * Main program.
 *
 * @param argc Number of arguments.
 * @param argv The arguments.
 * @retval EXIT_SUCCESS If the program exits normally.
 * @retval EXIT_FAILURE If an error occurs.
 */
int main(int argc, char **argv)
{
	atexit(clean_up);
	signal(SIGINT, signal_handler);

	if (parse_arguments(argc, argv) != TRUE)
		return EXIT_FAILURE;

	if (init() != TRUE)
		return EXIT_FAILURE;

	log_info("init finished and succeeded");
	pthread_create(&g_modemThread, NULL, modem_thread, NULL);
	pthread_create(&g_coreThread, NULL, core_thread, NULL);

	gMdmDrvOps->run();
	pthread_join(g_modemThread, NULL);
	pthread_join(g_coreThread, NULL);

	return 0;
}
