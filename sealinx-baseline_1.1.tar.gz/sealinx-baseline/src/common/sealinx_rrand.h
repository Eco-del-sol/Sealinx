/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author james
 */

#ifndef __SEALINX_RRAND_H__
#define __SEALINX_RRAND_H__

#ifdef	__cplusplus
extern "C" {
#endif

    /**
     *
     **/
	int poisson(double lambda);

	/* Integer interface of random number generator
	 * The output is between integer number
	 * @low and @high */
	int random_int(int low, int high);

	/* Real random number generator */
	int rrandom(void);

#ifdef	__cplusplus
}
#endif
#endif
