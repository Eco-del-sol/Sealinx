/*
* CopyRight Reserved: 智慧海洋
* Filename:	StreamDelimit.c
* Description:	  接收数据处理头文件
* Date:		2017.07.07
* Author:	Lxt
*/
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "StreamDelimit.h"
#include "Circularbuffer.h"
static int findInRange(CircularBuffer * cbuf, int start, int end,
		       Delimiter * dlmts, Delimiter ** dlmt_found)
{
	int maxDLen;
	int start2, end2;
	char *junction;
	int pos_found;
	//间隔符最大长度
	maxDLen = Delimit_maxDelimiterLen(dlmts);
	if (end < start) {	/* find in xxx___xxx */
		start2 = CircularBuffer_getPhyLen(cbuf) - maxDLen + 1;
		if (start2 < start)
			start2 = start;
		end2 = maxDLen - 1;
		//------------更改--------------------
		if (end2 > end)
			end2 = end;
		junction =
		    malloc(CircularBuffer_getPhyLen(cbuf) - start2 + end2);
		if (!junction)
			return -2;
		memcpy(junction, &cbuf->buf[start2],
		       CircularBuffer_getPhyLen(cbuf) - start2);
		memcpy(&junction[CircularBuffer_getPhyLen(cbuf) - start2],
		       cbuf->buf, end2);

		/* search in the ___xxx */
		pos_found = Delimit_searchFirst(dlmts, &cbuf->buf[start],
						CircularBuffer_getPhyLen(cbuf) -
						start, dlmt_found);
		if (pos_found >= 0)
			return start + pos_found;
		/* search in the junction */
		pos_found = Delimit_searchFirst(dlmts, junction,
						CircularBuffer_getPhyLen(cbuf) -
						start2 + end2, dlmt_found);
		if (pos_found >= 0)
			return (pos_found + start2 >=
				CircularBuffer_getPhyLen(cbuf)) ? pos_found +
			    start2 -
			    CircularBuffer_getPhyLen(cbuf) : pos_found + start2;
		/* search in the xxx___ */
		pos_found =
		    Delimit_searchFirst(dlmts, cbuf->buf, end, dlmt_found);
		return pos_found;
	} else {
		//printf("end-start:%d\n",end - start);
		pos_found = Delimit_searchFirst(dlmts, &cbuf->buf[start],
						end - start, dlmt_found);
		//printf("*********pos_found:%d\n",pos_found);
		if (pos_found >= 0)
			pos_found = start + pos_found;
		return pos_found;
	}
}

static int resultEnlist(DelimitedData * list, VarArray * va, int hasHeader,
			int hasTrailer)
{
	DelimitedData *dd;
	if (VarArray_getLen(va) == 0)
		return -1;
	dd = malloc(sizeof(*dd) + VarArray_getLen(va));
	if (!dd)
		return -2;

	dd->hasHeader = hasHeader;
	dd->hasTrailer = hasTrailer;

	//printf("VarArray: length %d\n", VarArray_getLen(va));
	dd->len = VarArray_read(va, dd->buf, VarArray_getLen(va), 0);
	list_add_tail(&dd->node, &list->node);

	return 0;
}

//创建并初始化StreamDelimit结构体
StreamDelimit *StreamDelimit_create(int bufSize)
{
	StreamDelimit *sd;

	sd = malloc(sizeof(*sd));
	if (!sd)
		return NULL;
	//初始化循环缓冲区
	sd->cirBuf = CircularBuffer_create(bufSize);
	//printf("xxxxxxxxxxxxxxxx\n");
	if (!sd->cirBuf)
		goto free_sd;
	//初始化间隔符链表头结点
	Delimit_init(&sd->delimiters);
	//初始化数据包链表头结点
	DelimitedData_init(&sd->results);
	//初始化中间缓冲区链表头结点
	sd->dataBuf.va = VarArray_create();
	if (!sd->dataBuf.va)
		goto free_sd;
	sd->dataBuf.hasHeader = 0;
	sd->dataBuf.hasTrailer = 0;
	return sd;

free_cirBuf:
	CircularBuffer_delete(sd->cirBuf);
free_sd:
	free(sd);
	return NULL;
}

void DelimitedData_deleteAll(DelimitedData * dlmtd)
{
	DelimitedData *iter, *iter_n;

	list_for_each_entry_safe(iter, iter_n, &dlmtd->node, node)
	    free(iter);
}

void StreamDelimit_delete(StreamDelimit * sd)
{
	CircularBuffer_delete(sd->cirBuf);
	Delimit_deleteAll(&sd->delimiters);
	DelimitedData_deleteAll(&sd->results);
	VarArray_delete(sd->dataBuf.va);
}

int StreamDelimit_addDelimiters(StreamDelimit * sd, const char *header,
				int headerLen, const char *trailer,
				int trailerLen)
{
	Delimiter *dlmt;
	dlmt = Delimit_addDelimiter(&sd->delimiters, header, headerLen);
	if (!dlmt)
		return -1;
	sd->header = dlmt;
	dlmt = Delimit_addDelimiter(&sd->delimiters, trailer, trailerLen);
	if (!dlmt)
		return -1;
	sd->trailer = dlmt;
	return 0;
}

int StreamDelimit_input(StreamDelimit * sd, char *buf, int len)
{
	CircularBuffer_append(sd->cirBuf, buf, len);
	return 0;
}

DelimitedData *StreamDelimit_output(StreamDelimit * sd)
{
	DelimitedData *dd;

	if (StremDelimit_output_isEmpty(sd))
		return NULL;
	//dd = list_first_entry_or_null(&sd->results.node, typeof(sd->results), node);
	dd = list_first_entry(&sd->results.node, typeof(sd->results), node);
	list_del(sd->results.node.next);
	return dd;
}

int StreamDelimit_delimit(StreamDelimit * sd)
{
	int tail, newHead, i;
	int pos_found;
	Delimiter *dlmt_found;
	VarArray *iter2;
	//循环缓冲区无数据
	if (!CircularBuffer_getLen(sd->cirBuf))
		return -1;
	tail = sd->cirBuf->tail;
	//在循环缓冲区中查找是否存在间隔符
	pos_found = findInRange(sd->cirBuf, sd->cirBuf->head, tail,
				&sd->delimiters, &dlmt_found);
	if (pos_found < 0) {	/* Neither header nor trailer found */
		if (CircularBuffer_getLen(sd->cirBuf) >=
		    Delimit_maxDelimiterLen(&sd->delimiters)) {
			/* leave a section for future search */
			newHead =
			    CircularBuffer_decreasePointer(sd->cirBuf, tail,
							   Delimit_maxDelimiterLen
							   (&sd->delimiters) -
							   1);
			if (newHead >= sd->cirBuf->head) {
				VarArray_append(sd->dataBuf.va,
						&sd->cirBuf->buf[sd->cirBuf->
								 head],
						newHead - sd->cirBuf->head);
			} else {
				VarArray_append(sd->dataBuf.va,
						&sd->cirBuf->buf[sd->cirBuf->
								 head],
						CircularBuffer_getPhyLen(sd->
									 cirBuf)
						- sd->cirBuf->head);
				VarArray_append(sd->dataBuf.va,
						&sd->cirBuf->buf[0], newHead);
			}
		} else {
			return -2;
		}
	} else {
		//找到间隔符
		newHead =
		    CircularBuffer_increasePointer(sd->cirBuf, pos_found,
						   dlmt_found->n_bytes);
		//如果找到了结束符
		if (dlmt_found == sd->trailer) {	/* trailer found */
			sd->dataBuf.hasTrailer = 1;
			if (newHead >= sd->cirBuf->head) {
				VarArray_append(sd->dataBuf.va,
						&sd->cirBuf->buf[sd->cirBuf->
								 head],
						newHead - sd->cirBuf->head);
			} else {
				VarArray_append(sd->dataBuf.va,
						&sd->cirBuf->buf[sd->cirBuf->
								 head],
						CircularBuffer_getPhyLen(sd->
									 cirBuf)
						- sd->cirBuf->head);
				VarArray_append(sd->dataBuf.va,
						&sd->cirBuf->buf[0], newHead);
			}
			resultEnlist(&sd->results, sd->dataBuf.va,
				     sd->dataBuf.hasHeader,
				     sd->dataBuf.hasTrailer);
			/* create a new va buffer */
			VarArray_delete(sd->dataBuf.va);
			sd->dataBuf.va = VarArray_create();
			sd->dataBuf.hasHeader = 0;
			sd->dataBuf.hasTrailer = 0;
		} else {
			//如果找到的是起始符
			//先存储起始符前的数据
			if (pos_found >= sd->cirBuf->head) {
				VarArray_append(sd->dataBuf.va,
						&sd->cirBuf->buf[sd->cirBuf->
								 head],
						pos_found - sd->cirBuf->head);
			} else {
				VarArray_append(sd->dataBuf.va,
						&sd->cirBuf->buf[sd->cirBuf->
								 head],
						CircularBuffer_getPhyLen(sd->
									 cirBuf)
						- sd->cirBuf->head);
				VarArray_append(sd->dataBuf.va,
						&sd->cirBuf->buf[0], pos_found);
			}
			resultEnlist(&sd->results, sd->dataBuf.va,
				     sd->dataBuf.hasHeader,
				     sd->dataBuf.hasTrailer);
			/* create a new va buffer */
			VarArray_delete(sd->dataBuf.va);
			sd->dataBuf.va = VarArray_create();
			sd->dataBuf.hasHeader = 1;
			sd->dataBuf.hasTrailer = 0;
			//再存储起始符
			if (newHead >= pos_found) {
				VarArray_append(sd->dataBuf.va,
						&sd->cirBuf->buf[pos_found],
						newHead - pos_found);
			} else {
				VarArray_append(sd->dataBuf.va,
						&sd->cirBuf->buf[pos_found],
						CircularBuffer_getPhyLen(sd->
									 cirBuf)
						- pos_found);
				VarArray_append(sd->dataBuf.va,
						&sd->cirBuf->buf[0], newHead);
			}
			sd->cirBuf->head = newHead;
			return 0;
		}
	}
	sd->cirBuf->head = newHead;
	return 0;
}
