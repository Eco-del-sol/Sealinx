================================================================================
文件夹名：sealinx/src/drivers/ipc
应用程序名：sealinx-drivers-ipc
应用程序作用：向上与Sealinx core层相连，向下与Modem DSP相连，提供网络协议栈
              物理层的功能
编译环境：Linux + arm-linux-gnueabi-gcc + Automake
运行环境：智慧海洋TI OMAPL138 Modem平台
编译库依赖：libAngelfish/*.h *.so
            libIpc/*.h *.so
            libCmem/*.h *.so
运行库依赖：libAngelfish/libAngelfish.so
            libIpc/*.so
            libCmem/*.so
            其中，libIpc和libCmem是TI官方提供的DSP与ARM双核通讯的库文件
            libAngelfish是智慧海洋提供的控制Modem数据收发与参数修改的库文件
版本：V1.0
时间：2019年5月9日
联系方式：jing_zhang@smartoceantech.com
================================================================================

运行依赖：
    1、Sealinx core层已经运行
    2、运行目录下有config_driver_ipc.cfg配置文件
        该文件中的示例内容为下
        EMULATION_NODE_A :1
        EMULATION_NODE_B :3
        EMULATION_RATE :100
        MODEM_MODE :1
        MODEM_GUARD_TIME :150
        以上内容含义为：id为1的Modem和id为3的Modem通讯成功率为100%
            （用于模拟两个Modem之间信道不稳定的情况）
            本Modem默认的发送模式为1，默认的发送保护间隔时间为150ms

使用方式示例：
    root@omapl138-lcdk:~#    sealinx-core -f 0 &
    root@omapl138-lcdk:~#    sealinx-drivers-ipc -f 0 -g &
    其中，-f 0代表程序不将运行日志存储到文件系统中；
          -g 代表允许程序在Console终端显示普通级别的运行信息；
          -g2 代表允许程序在Console终端显示调试级别的运行信息

额外提示：
    Modem关机时勿直接拔电；
    建议先关闭当前正在运行Sealinx程序，然后将系统缓存中的数据同步到SD卡中的
    文件系统中，再执行关机命令，最后再拔电源（防止文件系统在写入期间异常断电
    导致文件系统损坏）
    命令如下：
    root@omapl138-lcdk:~#    ./stop.sh
    root@omapl138-lcdk:~#    sync
    root@omapl138-lcdk:~#    poweroff
    然后拔电
================================================================================

源码介绍
ipc_main.c：
    调用modem_init初始化Modem，注册数据接收回调函数，注册数据发送完成回调函数
        (相关的头文件modem.h)
    调用init_logger存储运行日志
    调用client_connect与Sealinx core层连接
    调用modem_start开启并运行一个Modem接收线程，用于监听DSP发来的数据
    创建并运行ipcThread_core接收线程，用于监听core层发来的数据
    运行期间可以调用modem_status设置与获取Modem的设备ID、版本号、开启波形存储、
        开启接收调试信息、开启发送调试信息、发送功率、数据接收保护间隔、
        数据发送保护间隔、配置保存、手动触发波形接收、恢复默认配置
        (相关的头文件mregs.h)
    运行期间可以调用modem_status从Modem发送水声数据出去，调用modem_range与
        另一个Modem进行测距
    
ipc_common.c：
    将Sealinx core与Modem之间的数据在格式上相互转化（因为Modem发送时要保证
        数据尽可能的精简）
    如果打开调试开关，在Console中输出每次收发的具体数据

../../common/sealinx/modem_info.h：
    操作Modem时各种参数的定义

libAngelfish/include/modem.h：
    Modem的操作接口
================================================================================
