package nodes

import (
	"log"
	// "math"
	"strconv"
	"time"

	"github.com/BurntSushi/toml"
	"mate2/geometry/plane"
)

// max speed for nodes
const (
	knot    = 0.514 // m/s
	MaxKnot = 10 * knot
)

type moveSpeed struct {
	Speed float64
}

type node struct {
	plane.Point
	Move moveSpeed // `toml:"move"`
	Path plane.Path
}

// NodeList logged all initialized nodes
var NodeList map[int32]*node

type tomlConfig struct {
	Nodes map[string]*node
}

// initialized all nodes from configure file
func init() {
	NodeList = make(map[int32]*node)
	var config tomlConfig
	if _, err := toml.DecodeFile("config.toml", &config); err != nil {
		log.Printf("\033[34mNODE: %v\033[0m", err)
		return
	}
	for s, n := range config.Nodes {
		i, err := strconv.Atoi(s)
		if err != nil {
			panic(err)
		}
		NodeList[int32(i)] = n
		go automove(n, int32(i))
	}
}

func automove(n *node, i int32) {
	ts := time.Millisecond * 20
	speed := n.Move.Speed
	if speed == 0 {
		return
	}
	for {
		for _, dst := range n.Path {
			n.Point.MoveTo(&dst, speed*knot, ts)
			log.Printf("\033[1;36mNODE: Node%d arrived at (%.1f, %.1f)\033[0m",
				i, NodeList[i].X, NodeList[i].Y)
		}
		if len(n.Path) == 1 {
			break
		}
	}
}
