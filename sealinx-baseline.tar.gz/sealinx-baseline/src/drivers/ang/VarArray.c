#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "VarArray.h"

#define offsetToOffsetInSection(va, os)	\
	(offsetFromStart(va, os) % VAR_ARRAY_SECTION_LEN)
//得到总的缓冲区数据字节长度
static int getAllocatedLen(VarArray * va)
{
	VarArray *section;
	int n_section = 0;

	list_for_each_entry(section, &va->node, node)
	    n_section++;

	return n_section * VAR_ARRAY_SECTION_LEN;
}

//偏移
static int offsetFromStart(VarArray * va, int offset)
{
	//offset 小于0时,从临时缓冲区尾部偏移
	if (offset < 0) {
		int len = VarArray_getLen(va);
		return len + offset + 1;
	} else {
		return offset;
	}
}

//缓冲区链表中插入结点
static VarArray *insertNewSection(VarArray * va)
{
	VarArray *new;
	/* create the first entry */
	new = malloc(sizeof(*new) + VAR_ARRAY_SECTION_LEN);
	if (!new)
		return NULL;
	//-------------更改----------------
	//list_add(&new->node, &va->node);
	list_add_tail(&new->node, &va->node);
	new->pos = 0;

	va->pos += VAR_ARRAY_SECTION_LEN;

	return new;
}

//找到相应链表的那块
static VarArray *positiveOffsetToSection(VarArray * va, int positive_offset)
{
	int section_n;
	int count_from_end;
	VarArray *ret;

	if (positive_offset >= VarArray_getLen(va))	/* positive_offset out of array range */
		return NULL;

	section_n = positive_offset / VAR_ARRAY_SECTION_LEN;

	list_for_each_entry(ret, &va->node, node) {
		if (section_n == 0)
			break;
		section_n--;
	}

	return ret;
}

//创建缓冲区链表头结点
VarArray *VarArray_create()
{
	VarArray *head;

	/* create a header which has no data */
	head = malloc(sizeof(*head));
	if (!head)
		return NULL;

	list_init(&head->node);
	head->pos = 0;

	return head;
}

//删除缓冲区链表
void VarArray_delete(VarArray * va)
{
	VarArray *iter, *iter_n;

	list_for_each_entry_safe(iter, iter_n, &va->node, node)
	    free(iter);
}

//实际缓冲区数据长度
int VarArray_getLen(VarArray * va)
{
	int len = 0;
	VarArray *iter;

	list_for_each_entry(iter, &va->node, node)
	    len += iter->pos;

	return len;
}

int VarArray_write(VarArray * va, const char *buf, int len, int offset)
{
	//static int writetime=0;
	VarArray *section;
	int osInSec, secLen, wlen;

	if (len == 0)
		return 0;
	wlen = 0;

	//判断从临时缓冲区哪个位置插入
	offset = offsetFromStart(va, offset);	//此时offset=整个临时缓冲区数据长度
	/* finding the  in which the offset falls in */
	//找到在哪块插入
	section = positiveOffsetToSection(va, offset);
	if (!section) {		/* not found */
		if (offset == VarArray_getLen(va)) {
			if (offset == getAllocatedLen(va)) {	//在块的尾部
				section = insertNewSection(va);
				if (!section)
					return wlen;
			} else {
				section =
				    list_last_entry(&va->node, typeof(*va),
						    node);
			}
		} else {
			return wlen;
		}
	}
	osInSec = offsetToOffsetInSection(va, offset);	//指向将要被填数据的空间
	//块中剩余空间
	secLen = VAR_ARRAY_SECTION_LEN - osInSec;	/* partial length in the first section */

	while (1) {
		//块中剩余空间足够
		if (secLen > (len - wlen)) {
			secLen = len - wlen;
		}
		memcpy(&section->data[osInSec], &buf[wlen], secLen);
		section->pos = osInSec + secLen;
		wlen += secLen;
		if (wlen == len)
			break;
		section = list_next_entry(section, node);
		//新建一个块
		if (section == va) {	/* reaches the last section */
			section = insertNewSection(va);
			if (!section)
				break;
		}
		secLen = VAR_ARRAY_SECTION_LEN;
		osInSec = 0;
	}
	return wlen;
}

int VarArray_read(VarArray * va, char *buf, int len, int offset)
{
	VarArray *section;
	int osInSec, secLen, rlen;

	if (len == 0)
		return 0;

	rlen = 0;
	//
	offset = offsetFromStart(va, offset);
	/* finding the  in which the offset falls in */
	section = positiveOffsetToSection(va, offset);
	if (!section)		/* not found */
		return 0;

	osInSec = offsetToOffsetInSection(va, offset);
	//块中要读的数据
	secLen = section->pos - osInSec;	/* partial length in the first section */
	while (1) {
		if (secLen > len - rlen)
			secLen = len - rlen;

		memcpy(&buf[rlen], &section->data[osInSec], secLen);

		rlen += secLen;
		if (rlen == len)
			break;
		section = list_next_entry(section, node);
		if (section == va)	/* reaches the last section */
			break;

		secLen = section->pos;
		osInSec = 0;
	}
	return rlen;
}
