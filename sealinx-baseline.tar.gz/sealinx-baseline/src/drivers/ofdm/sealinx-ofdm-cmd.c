/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * OFDM modem in command mode.
 *
 * @author son
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <err.h>
#include <errno.h>
#include <signal.h>
#include <pthread.h>
#include <termios.h>
#include <sys/time.h>
#include <sys/shm.h>
#include <time.h>
#include <math.h>

#include <sealinx.h>
#include <sealinx_utils.h>
#include <sealinx_serial.h>

#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>

#include "config.h"
#include "ofdm_cmd_utils.h"
#include "ofdm_base.h"
#include "sealinx-ofdm-cmd.h"

// Shared memory for connectivity
//SharedData connectivity; //leave it here

/** Indicator of whether the connectivity control module is loaded. */
//int g_connCtlLoaded;

/** File descriptor of the serial port. */
int g_serialFd = -1;

/** Log identity for this module. */
char *g_logId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char *g_logFolder = DEFAULT_LOG_FOLDER;

/** File descriptor of the connection to the core. */
int g_connFd;

/** Shared data by the core module. */
CoreSharedData *g_coreSharedData;

/** ID of the shared memory by the core module. */
int g_coreSharedMemId;

/** Name of the connectivity file. */
//char *g_connFileName = DEFAULT_CONN_FILE_NAME;

/** Name of the config file. */
char *g_cfgFileName = DEFAULT_CFG_FILE_NAME;

/** Verbosity level. */
int g_verbose = 0;

/** The thread reading the serial line. */
pthread_t g_serialThread;

/** The thread reading the core. */
pthread_t g_coreThread;

/** The acoustic sending rate of the OFDM modem (bps). */
int g_ofdmAcousticRate;
/** The maximum transmission unit (bytes)/ */
int g_ofdmMtu;
// the quota to control the sending speed
//int g_ofdmQuota;
/** the OFDM inter frame guard time (ms). */
int g_ofdmIfgt;

int g_running;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 1;

Modem *g_modem;

#define FILE_BUFSIZE (1024)

/**
 * Read configuration file for OFDM
 *
 * @param serialFd File descriptor of the serial port connecting to the modem.
 * @param confFileName Name of the config file.
 * @return TRUE if the operation succeeds; FALSE, otherwise.
 */
int read_config(char *confFileName)
{
	char local_buff[FILE_BUFSIZE];
	char *token;
	g_ofdmMtu = 0, g_ofdmAcousticRate = 0, g_ofdmIfgt = 0;

	/* Open up modem configuration file */
	FILE *ofdm_cfg = fopen(confFileName, "r");
	if (!ofdm_cfg) {
		log_info("Could not open config file: %s", strerror(errno));
		return FALSE;
	}
	memset(local_buff, 0, sizeof(local_buff));
	log_info("Reading config file...");
	/* Reading the config file */
	while (fgets(local_buff, sizeof(local_buff), ofdm_cfg)) {
		token = strtok(local_buff, " :");
		if (*token == '#')
			continue;
		if (strstr(token, "OFDM_ACOUSTIC_RATE")) {
			token = strtok(NULL, " :");
			g_ofdmAcousticRate = atoi(token);
			log_info("G_OFDMACOUSTICRATE: %d bps",
				 g_ofdmAcousticRate);
			if (g_ofdmAcousticRate <= 0) {
				log_error("OFDM_ACOUSTIC_RATE invalid value");
				fclose(ofdm_cfg);
				return FALSE;
			}
			continue;
		} else if (strstr(token, "OFDM_MTU")) {
			token = strtok(NULL, " :");
			g_ofdmMtu = atoi(token);
			log_info("OFDM_MTU: %d.", g_ofdmMtu);
			if (g_ofdmMtu <= 0) {
				log_error("OFDM_MTU invalid value");
				fclose(ofdm_cfg);
				return FALSE;
			}
			continue;
		} else if (strstr(token, "OFDM_IFGT")) {
			token = strtok(NULL, " :");
			g_ofdmIfgt = atoi(token);
			log_info("OFDM_IFGT: %d.", g_ofdmIfgt);
			if (g_ofdmIfgt <= 0) {
				log_error("OFDM_IFGT invalid value");
				fclose(ofdm_cfg);
				return FALSE;
			}
			continue;
		} else
			continue;
	}
	if (g_ofdmMtu * g_ofdmAcousticRate * g_ofdmIfgt == 0) {
		log_error("Missing required parameter(s)!");
		fclose(ofdm_cfg);
		return FALSE;
	}
	fclose(ofdm_cfg);
	return TRUE;
}

void clean_up(void)
{
	log_info("Cleanup resources.");
	log_info("Stopping OFDM Modem Driver");

	if (g_coreSharedData) {
		if (shmdt(g_coreSharedData) == -1) {
			log_error("Unable to detach shared data: %s",
				  strerror(errno));
		}
	}

	close_logger();

	ofdm_free(g_modem);
}

void signal_handler(int sig)
{
	int type = 0;
	if (sig != SIGINT) {
		return;
	}

	log_info("Prepare to shut down driver");

	g_running = FALSE;

	if (g_connFd > -1) {
		log_info("Close connection to core");
		client_close(type, g_connFd, NULL, 0);
	}

	if (g_serialFd > -1) {
		log_info("Close modem serial port");
		serial_close(g_serialFd);
	}
}

/**
 * Handles data originated from inside the protocol stack.
 *
 * @return Size of data from the channel if the operation succeeds;
 * -1 otherwise.
 */
int handle_internal_data(void)
{
	char buffer[IMSG_MAX_DATA_LENGTH];
	InternalMessageHeader dataHeader;
	int nBytesRead = client_read(g_connFd, buffer, IMSG_MAX_DATA_LENGTH,
				     &dataHeader, NULL, 0);
	if (nBytesRead == -1) {
		log_error("Error reading from core: %s", strerror(errno));
		return -1;
	}

	logReceiveFromStack(nBytesRead, "");

	if (nBytesRead == 0) {
		return 0;
	}

	PduBuff *pbuf = (PduBuff *) buffer;

	int retVal = -1;
	if (from_upper_layer(dataHeader)) {
#ifdef DEBUG
		log_info("Send data to media");
#endif
		while (!g_modem->initialized && g_running) ;

		retVal = ofdm_send_pdu_locked(g_modem, pbuf);

		if (retVal < 0) {
			log_error("Failed to send to modem");
		}
	} else {
		log_error("Invalid packet direction");
	}

	return retVal;
}

/**
 * Delivers a PDU to the upper layer.
 *
 * @param pbuf The PDU to be delivered.
 */
void deliver_pdu1(PduBuff * pbuf)
{
	if (!g_modem->initialized) {
		log_info
		    ("Drop packet from %d (modem driver has not been fully initialized)",
		     (int)pbuf->hdr_mac.src_addr);
	} else {
		log_info("Deliver data to upper layer");
		client_send_up(g_connFd, pbuf, PDU_SIZE(pbuf->msg_len),
			       OFDM_DRIVER_ID, NULL, 0);
	}
}

/**
 * Main function of the thread handling data from serial port.
 *
 * @param data UNUSED.
 * @return UNUSED.
 */
void *serial_thread(void *data)
{
	PduBuff pdu;
	while (g_running) {
		int retval = ofdm_read_wait(g_modem, 1, 0);

		if (retval == 0)
			continue;
		if (retval == -1)
			break;

		ofdm_lock(g_modem);
		int rv = ofdm_read_wait(g_modem, 0, 0);

//      log_info("%s: rv = %d", __PRETTY_FUNCTION__, rv);

		if (rv < 0) {
			g_running = FALSE;
		}

		if (rv > 0 && !ofdm_fetch_data(g_modem)) {
			g_running = FALSE;
		}

		ofdm_release(g_modem);
	}

	return NULL;
}

/**
 * Main function of the thread handling data from upper layers.
 *
 * @param data UNUSED.
 * @return UNUSED.
 */
void *core_thread(void *data)
{
	char buffer[IMSG_MAX_DATA_LENGTH];
	InternalMessageHeader dataHeader;
	while (g_running) {
		/*int dataLen = handle_internal_data();
		   if (dataLen == -1) {
		   break;
		   }

		   if (dataLen == 0) {
		   break;
		   } */

		int nBytesRead =
		    client_read(g_connFd, buffer, IMSG_MAX_DATA_LENGTH,
				&dataHeader, NULL, 0);
		if (nBytesRead == -1) {
			log_error("Error reading from core: %s",
				  strerror(errno));
			break;
		}

		logReceiveFromStack(nBytesRead, "");

		if (nBytesRead == 0) {
			log_info("Core connection closed");
			break;
		}

		PduBuff *pbuf = (PduBuff *) buffer;

		int rv = -1;
		if (from_upper_layer(dataHeader)) {
			while (!g_modem->initialized && g_running) ;

			rv = ofdm_send_pdu_locked(g_modem, pbuf);

			if (rv == CEXEC_SYS_ERROR) {
				log_error("Failed to send to modem");
				break;
			} else if (rv == CEXEC_SUCCESS) {
#ifdef DEBUG
				log_info("Data sent to modem successfully");
#endif
			} else if (rv == CEXEC_RECOVERABLE) {
#ifdef DEBUG
				log_warning("Encounter recoverable error");
#endif
			}
		} else {
			log_error("Invalid packet direction");
		}
	}
	return NULL;
}

/**
 * Parse command line arguments.
 *
 * @param argc Number of arguments
 * @param argv The arguments
 * @return TRUE if the argument can be parse; FALSE, otherwise.
 */
int parse_arguments(int argc, char **argv)
{
	int i = 0;
	while (i < argc) {
		char *t = argv[i];
		if (strcmp(t, "-c") == 0) {
			i++;
			if (i < argc) {
				g_cfgFileName = argv[i];
			}
		} else if (strcmp(t, "-g") == 0) {
			g_verbose = TRUE;
		} else if (strcmp(t, "-g2") == 0) {
			g_verbose = VERBOSE;
		} else if (strcmp(t, "-f") == 0) {
			i++;
			if (i < argc) {
				gLogFile = atoi(argv[i]);
			}
		}
		i++;
	}
	return TRUE;
}

/**
 * Initializes modem.
 *
 * @retval TRUE if the operation succeeds.
 * @retval FALSE if the operation fails.
 */
int init_modem(void)
{
	/* Initialize the modem */
	if (!read_config(g_cfgFileName)) {
		log_error("Fail to initialize modem");
		return FALSE;
	}

	/* Open up the serial connection to the modem */
	g_serialFd = serial_open();
	if (g_serialFd <= 0) {
		log_error("Fail to open serial port: %s", strerror(errno));
		return FALSE;
	}

	if (tcflush(g_serialFd, TCIOFLUSH) == 0) {
		log_info("input and output buffers flushed");
	} else {
		log_error("input and output buffers flush failed");
		return FALSE;
	}

	g_modem =
	    ofdm_init(g_serialFd,
		      sizeof(PduBuff) + sizeof(PhysicalDataPacket) +
		      OFDM_EXTRA_GUARD, OFDM_PHY_PACKET_SIZE, deliver_pdu1);

	return ofdm_to_operation_mode_locked(g_modem);
}

/**
 * Initialize the program.
 *
 * @retval TRUE if the operation succeeds.
 * @retval FALSE if the operation fails.
 */
int init(void)
{
	int type = 0;
	g_running = TRUE;

	if (!init_logger(g_logFolder, g_logId, gLogFile, TRUE, NULL, 0)) {
		fprintf(stderr, "Fail to init the log module.");
		return FALSE;
	}

	RegistrationResponse serverResponse;

	g_connFd =
	    client_connect(type, LAYER_PHYSICAL, NULL, &serverResponse, NULL,
			   0);

	if (g_connFd == -1) {
		return FALSE;
	}
	g_coreSharedMemId = serverResponse.coreShareMemId;

	log_info("Key of core shared memory: %d", g_coreSharedMemId);

	g_coreSharedData = (CoreSharedData *) shmat(g_coreSharedMemId, NULL, 0);
	if (g_coreSharedData == (CoreSharedData *) - 1) {
		log_error("Unable to attach the shared memory: %s",
			  strerror(errno));
		return FALSE;
	}

	logger_set_node_id(g_coreSharedData->macAddr,
			   g_coreSharedData->netAddr);
	log_info("Mac address: %d, net address: %d",
		 (int)g_coreSharedData->macAddr,
		 (int)g_coreSharedData->netAddr);

	if (!init_modem()) {
		return FALSE;
	} else {
		log_info("Modem init succeeds");
	}

	return TRUE;
}

/**
 * Main program.
 *
 * @param argc Number of arguments.
 * @param argv The arguments.
 * @retval EXIT_SUCCESS If the program exits normally.
 * @retval EXIT_FAILURE If an error occurs.
 */
int main(int argc, char **argv)
{
	atexit(clean_up);
	signal(SIGINT, signal_handler);

	if (!parse_arguments(argc, argv)) {
		return EXIT_FAILURE;
	}

	if (!init()) {
		return EXIT_FAILURE;
	}

	pthread_create(&g_serialThread, NULL, serial_thread, NULL);
	pthread_create(&g_coreThread, NULL, core_thread, NULL);

	pthread_join(g_serialThread, NULL);
	pthread_join(g_coreThread, NULL);

	return 0;
}
