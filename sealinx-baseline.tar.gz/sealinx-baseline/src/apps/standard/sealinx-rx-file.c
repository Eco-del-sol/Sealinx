/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author haining
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/un.h>
#include <unistd.h>
#include <signal.h>
#include <sys/time.h>
#include <err.h>
#include <errno.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/time.h>
#include <fcntl.h>

#include <sealinx.h>
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>

#define MAX_BUF_SIZE 4096

#define TCP_HEADER_LENGTH (2 * sizeof(short int) + sizeof(sealinxTcpHeader))
#define FLAG_INIT_CONNECTION 4
#define FLAG_FREE_CONNECTION 8
#define FLAG_ENABLE_CLIENT 16

/**
 * Default log identity for this module.
 */
#define DEFAULT_LOG_ID "RX_FILE"

/**
 * Default path to the folder consisting log files.
 */
#define DEFAULT_LOG_FOLDER "logs/"

/** Log identity for this module. */
char * gLogId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char * gLogFolder = DEFAULT_LOG_FOLDER;

/** File descriptor of the connection to the core. */
int g_connFd;

/** ID of the current module. */
ModuleId g_moduleId;

/** ID of the MAC module. */
ModuleId g_macId;

/** ID of the network module. */
ModuleId g_netId;

/** ID of the transport module. */
ModuleId g_transId;

/**
 * Shared data by the core module.
 */
CoreSharedData *g_coreSharedData;

int g_coreSharedMemId;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 1;

char g_terminator[32]="###@@@$$$%%%";

// Port number type
typedef short int PortNumber;

/*sealinx_tcp_header structure*/
typedef struct {
    PortNumber l_port;
    PortNumber r_port;
    u_char flag;
    u_char window;
    u_short seq_num;
    u_short ack_num;
    u_short rcv_bmp;
    //char md2[16];
} __attribute__((__packed__)) sealinxTcpHeader;

typedef struct {
    int fileSize;
    short fileNameLength;
    char fileName[100];
} __attribute__((__packed__)) FileInfo;


/**
 * Parse command line arguments.
 *
 * @param argc Number of arguments
 * @param argv The arguments
 * @return TRUE if the argument can be parse; FALSE, otherwise.
 */
int parse_arguments(int argc, char ** argv) {
    int i = 0;
    while (i < argc) {
	char * t = argv[i];
	if (strcmp(t, "-i") == 0) {
	    i ++;
	    if (i < argc)  {
		int moduleId = strtol(argv[i], NULL, 10);
		if (moduleId > MAX_MODULE_ID || moduleId < MIN_MODULE_ID) {
		    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
		    return FALSE;
		}
		g_moduleId = moduleId;
	    }
	} else if (strcmp(t, "-m") == 0) {
	    i ++;
	    if (i < argc)  {
		int macId = strtol(argv[i], NULL, 10);
		if (macId > MAX_MODULE_ID || macId < MIN_MODULE_ID) {
		    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
		    return FALSE;
		}
		g_macId = macId;
	    }
	} else if (strcmp(t, "-n") == 0) {
	    i ++;
	    if (i < argc)  {
		int netId = strtol(argv[i], NULL, 10);
		if (netId > MAX_MODULE_ID || netId < MIN_MODULE_ID) {
		    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
		    return FALSE;
		}
		g_netId = netId;
	    }
	} else if (strcmp(t, "-t") == 0) {
	    i ++;
	    if (i < argc)  {
		int transId = strtol(argv[i], NULL, 10);
		if (transId > MAX_MODULE_ID || transId < MIN_MODULE_ID) {
		    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
		    return FALSE;
		}
		g_transId = transId;
	    }
	} else if (strcmp(t, "-f") == 0) {
	    i ++;
	    if (i < argc) {
		gLogFile = atoi(argv[i]);
	    }
	}
	i++;
    }
    return g_moduleId >= MIN_MODULE_ID && g_moduleId <= MAX_MODULE_ID && 
        g_macId >= MIN_MODULE_ID && g_macId <= MAX_MODULE_ID && 
        g_netId >= MIN_MODULE_ID && g_netId <= MAX_MODULE_ID && 
        g_transId >= MIN_MODULE_ID && g_transId <= MAX_MODULE_ID;
}

/**
 * Print the usage of the program.
 */
void print_usage(const char *progName) {
    printf("USAGE: %s "
           "-i <module id> -m <mac protocol id> -n <network protocol id> "
	   "-t <transport protocol id> "
	   "[-f <log file outoput flag>]\n", 
           progName);
}

/**
 * Calculate the actual size of data that is transmitted/received by this layer.
 * This size includes the size of headers of upper layers and the length of 
 * payload.
 *
 * @param pbuf The received/transmitted data.
 * @return The actual size.
 */
int calc_actual_size(PduBuff *pbuf) {
    return pbuf->msg_len + pbuf->hdr_tra.hdr_len;
}

/**
 * Initialize the program.
 */
int init(void) {
    int type = 0;
    ModuleId moduleIds[NUM_LAYERS];
    moduleIds[LAYER_MAC] = g_macId;
    moduleIds[LAYER_NETWORK] = g_netId;
    moduleIds[LAYER_TRANSPORT] = g_transId;
    moduleIds[LAYER_APPLICATION] = g_moduleId;

    if (!init_logger(gLogFolder, gLogId, gLogFile, TRUE, moduleIds, 4)) {
        fprintf(stderr, "Unable to init the log module.");
        return FALSE;
    }

    RegistrationResponse serverResponse;

    g_connFd = client_connect(type, LAYER_APPLICATION, moduleIds, &serverResponse, NULL, 0);
				 
    g_coreSharedMemId = serverResponse.coreShareMemId;
    
    log_info("Key of shared memory by the core: %d", g_coreSharedMemId);
    
    g_coreSharedData = (CoreSharedData *) shmat(g_coreSharedMemId, NULL, 0);
    if (g_coreSharedData == (CoreSharedData *) -1) {
        fprintf(stderr, "Unable to attach the shared memory: %s", 
                strerror(errno));
        return FALSE;
    }

    logger_set_node_id(g_coreSharedData->macAddr, g_coreSharedData->netAddr);
    log_info("Mac address: %d, net address: %d", 
             (int) g_coreSharedData->macAddr, (int) g_coreSharedData->netAddr);
    return TRUE;
}


/**
 * Signal handler.
 *
 * @param sig Signal ID.
 */
void signal_handler(int sig) {
    int type = 0;
    log_info("Received signal (%d)", sig);

    if (g_connFd > -1) {
	client_close(type, g_connFd, NULL, 0);
        g_connFd = -1;
    }
}

/**
 * Clean up allocated resources.
 */
void clean_up(void) {
    int type = 0;
    log_info("Cleaning up ...");
    
    if (g_connFd > -1) {
	client_close(type, g_connFd, NULL, 0);
    }

    if (g_coreSharedData) {
	int rc = shmdt(g_coreSharedData);
	if (rc == -1) {
	    log_error("Unable to detach shared data: %s", strerror(errno));
	}
    }

    close_logger();
}

void freeConnection() {
    PduBuff pbuf;
    pbuf.hdr_tra.hdr_len = TCP_HEADER_LENGTH;
    pbuf.hdr_tra.service_type = g_moduleId;
    sealinxTcpHeader *initAckHeader = (sealinxTcpHeader *) pbuf.hdr_tra.tra_data;
    initAckHeader->flag = FLAG_FREE_CONNECTION;
    client_send_down(g_connFd, &pbuf, sizeof(PduBuff), g_moduleId, NULL, 0);
}

void *rcv_file_func(void *param) {
    int rcvFD = -1;
    char g_rcv_buf[MAX_BUF_SIZE];
    FileInfo fInfo;
    int recv_num = 0;
    InternalMessageHeader dataHeader;
    PduBuff pbuf;

	while(1){
		logInfo("Waiting for a new file info or completion signal");
		do {
			recv_num = client_read(g_connFd, &pbuf, IMSG_MAX_DATA_LENGTH, &dataHeader, NULL, 0);
		} while (recv_num == 0);
		
		logInfo("A new file info or completion signal recived");
		if (recv_num < 0) {
			logError("read from connection error");
			return NULL;
		}
		
		if(strncmp(pbuf.pkt_data,g_terminator,strlen(g_terminator))==0){
			logInfo("All files received successfully");
			break;
		}

		memset(&fInfo,0,sizeof(fInfo));
		memcpy(&fInfo,pbuf.pkt_data,sizeof(fInfo));
		
		fInfo.fileName[fInfo.fileNameLength] = 0;
		rcvFD = open(fInfo.fileName, O_CREAT | O_RDWR, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
		if (rcvFD == -1) {
			logError("failed to create %s: %s", fInfo.fileName, strerror(errno));
			return NULL;
		} else {
			logInfo("created file %s successfully", fInfo.fileName);
		}
		
		int recvLen = 0;
		while (recvLen < fInfo.fileSize) {
			logInfo("File %s: recvLen = %d; fInfo.fileSize = %d", fInfo.fileName,recvLen, fInfo.fileSize);

		 if(client_read(g_connFd, &pbuf, IMSG_MAX_DATA_LENGTH, &dataHeader, NULL, 0) <0) {
				logError("read from connection error");
				return NULL;
			}

		 recv_num=pbuf.msg_len;
		 memcpy(g_rcv_buf,pbuf.pkt_data,recv_num);

			if (recv_num == 0) {
				continue;
			}
			
			recvLen += recv_num;
			
			logReceive(PKT_DATA, pbuf.hdr_mac.src_addr, pbuf.hdr_mac.dst_addr, recv_num, "one segment received");
			if ((write(rcvFD, g_rcv_buf, recv_num)) != recv_num) {
				logError("write to file error");
				return NULL;
			}
		}
		
		//freeConnection();	
		close(rcvFD);
		logInfo("file %s received successfully",fInfo.fileName);
    }
    //freeConnection();	
    return NULL;
}

void cleanUp(void) {
    close(g_connFd);
    freeANLog();
}

int main(int argc, char** argv) {
    atexit(clean_up);
    signal(SIGINT, signal_handler);

    if (!parse_arguments(argc, argv)) {
	    print_usage(argv[0]);
	    return EXIT_FAILURE;
    }

    if (!init()) {
        return EXIT_FAILURE;
    }

    /* For signal handling */
    int sig;
    sigset_t termSig;
    sigemptyset(&termSig);
    sigaddset(&termSig, SIGINT);
    sigaddset(&termSig, SIGTERM);
    pthread_sigmask(SIG_BLOCK, &termSig, NULL);

    pthread_t thread_rcv_file;
    if ((pthread_create(&thread_rcv_file, NULL, rcv_file_func, NULL)) != 0) {
        logError("create rcv_file thread failed");
        return EXIT_FAILURE;
    }

    /* Wait for a termmination signal */
    if ((sigwait(&termSig, &sig)) != 0) {
        logError("sigwait failed");
    } else {
        logInfo("Termination signal received, exiting...");
    }
    pthread_cancel(thread_rcv_file);

    pthread_sigmask(SIG_UNBLOCK, &termSig, NULL);
    pthread_join(thread_rcv_file, NULL);

    return EXIT_SUCCESS;
}
