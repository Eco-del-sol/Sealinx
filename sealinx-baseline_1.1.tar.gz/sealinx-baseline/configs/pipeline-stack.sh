#!/bin/bash
#/usr/bin/lad_omapl138 -g -l /home/root/end_user/lad.txt
/home/root/modem-scripts/fs_log.sh
/home/root/modem-scripts/loadDsp.sh
sleep 7

sealinx-core -f 1 &
sleep 1
sealinx-drivers-ipc -g 2 -f 1 & 
sleep 2
sealinx-pipeline-extensions -i 2 -f 1 -strict-rtt -ca config_pmac_link_relay.cfg &
sleep 2
sealinx-pmac-route -i 3 -f 1 -m 2 -c config_net.cfg &
sleep 2
sealinx-pmac-tra -i 4 -f 1 -m 2 -n 3 &
sleep 2
sealinx-pmac-link-relay -i 5 -m 2 -n 3 -t 4 -c config_pmac_link_relay.cfg -p /dev/ttyS1 -b 115200 & 
