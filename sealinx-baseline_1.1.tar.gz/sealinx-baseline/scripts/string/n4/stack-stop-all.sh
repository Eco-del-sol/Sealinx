ps axo user:20,pid,cmd | grep "sealinx*" | \
	grep -v grep | grep -v "gedit"|  awk '{print $2}' | \
	while read i; do kill -9 $i; done

