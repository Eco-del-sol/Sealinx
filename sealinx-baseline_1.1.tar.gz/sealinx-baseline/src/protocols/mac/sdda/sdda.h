/**
 * SDDA_BS_MAC
 * date: 2019-2-28
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <err.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>
#include <sys/shm.h>

#include <sealinx.h>
#include "sealinx_pktq.h"
#include "sealinx_timer.h"
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>

#include "com.h"

#define DEFAULT_LOG_ID "SDDA_BS"

#define DEFAULT_LOG_FOLDER "logs/"

// #define MAX_CLIENT_NUM 10

#define TR_TIMER_DURATION  1

// #define MAX_RECV_DATA_NUM 100

typedef enum __status_bs
{
    INVALID_STATUS = 0,
    WAITING_RTS    = 1,
    RECEIVING_DATA = 2
}status_bs;




// typedef struct __bs_nodes_delay{
//     /** Terminal ID */
//     uint8_t ID;
//     /** The propagation delay from the termiinal to BS */
//     double delay;
// }bs_nodes_delay;

// typedef struct __nodes_delay_data_duration{
//     /** Terminal ID */
//     uint8_t ID;
//     /** The propagation delay from the termiinal to BS */
//     double delay;
//     /** The data tx time of the terminal to send data */
//     int dataDuration;
// }nodes_delay_data_duration;

// struct mac_cmn_subhdr {
//     /** The type of MAC_packet */
//     uint16_t mac_type;
// };

// struct mac_data_subhdr {
//     /** The sequence number of DATA packet */
//     int seq;
// };

// struct mac_wTime_subhdr {
//     /** The duration from receiving TR to Sending RTS */
//     uint16_t wtime_trToRTS;
// };

// struct mac_sMoment_subhdr {
//     /** The sending time stamp of RTS */
//     time_t sTimeStamp;
// };

// struct mac_ctrl_subhdr {
//     /** The duration of DATA to be sent */
// 	uint16_t dataTxTime;
// };

// typedef struct {
//     /** Packet type. */
// 	uint8_t pktType;
// } __attribute__ ((__packed__)) ProtocolInfo;

void operatequeue_len(int ctl);

void clear_r_rts_array();

void clear_r_data_id();

int check_terminal_exist(int terminalID);

int get_free_data_id();

int getPktTxTime(uint8_t pktTxmode, size_t len);

int cmd_end_sendUp();

int per_end_sendUp();

void send_cmd_second_timer_process(void *arg);

void measure_range_timer_process(void *arg);

int send_cmd();

void set_mac_pkt_type(Packet * pkt, uint16_t mac_type);

uint16_t get_mac_pkt_type(Packet * pkt);

void set_mac_pkt_seq(Packet * pkt, int seq);

int get_mac_pkt_seq(Packet * pkt);

void set_mac_pkt_dataTime(Packet * pkt, uint16_t tlen);

uint16_t get_mac_pkt_dataTime(Packet * pkt);

void set_mac_pkt_wTimeTRtoRTS(Packet * pkt, uint16_t tlen);

uint16_t get_mac_pkt_wTimeTRtoRTS(Packet * pkt);

void set_mac_pkt_sTimeStamp(Packet * pkt, time_t sts);

time_t get_mac_pkt_sTimeStamp(Packet * pkt);

double getRTSDuration();

int set_terminal_rts_moment_toTR(char* buf);

Packet* make_tr();

void setTRDuration(size_t len);

int send_tr();

int getWrtsDuration();

int round_end_sendUp();

void process_tr_timer(void *arg);

int set_terminal_data_moment_toCTS(char* buf);

Packet* make_cts();

void setCTSDuration(size_t len);

int send_cts();

int from_rts_get_data_time();

int getWDataDuration();

void process_wait_for_rts_timer(void *arg);

int fill_ack_info(char *buf);

Packet* make_ack();

int send_ack();

int check_recv_data_exist();

void process_wait_for_data_timer(void *arg);

void signal_handler(int sig);

void clean_up(void);

void process_mac_data(Packet *pkt);

void process_mac_rts(Packet *pkt);

void bs_mac_rx_process(Packet *pkt);

void bs_mac_tx_process(Packet *pkt);

int parse_arguments(int argc, char ** argv) ;

int load_cfgfile(const char* configFile);

int init_sdda_bs_mac();

int sdda_bs_mac_process();
