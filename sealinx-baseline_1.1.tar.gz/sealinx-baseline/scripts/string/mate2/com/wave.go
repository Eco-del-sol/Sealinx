package com

import (
	// "time"

	"mate2/geometry/plane"
)

// Wave propagation under water
type Wave struct {
	ID         uint32
	ModemID    int32
	BirthPoint plane.Point
	DeathLine  int32 // max propagation range for modem's wave
	Packet
}
