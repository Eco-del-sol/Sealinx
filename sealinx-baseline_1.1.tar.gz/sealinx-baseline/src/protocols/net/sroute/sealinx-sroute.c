/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * Static routing.
 *
 * @author james, son
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/un.h>
#include <unistd.h>
#include <err.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>
#include <sys/shm.h>

#include <sealinx.h>
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>
#include <modem_info.h>

/** Default log identity for this module. */
#define DEFAULT_LOG_ID "SROUTE"

/** Default path to the folder consisting log files. */
#define DEFAULT_LOG_FOLDER "logs/"

/** Default name of the routing table file. */
#define DEFAULT_ROUTE_TABLE_FILE_NAME "config_net.cfg"

/** Log identity for this module. */
char *gLogId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char *gLogFolder = DEFAULT_LOG_FOLDER;

/** File descriptor of the connection to the core. */
int g_connFd;

/** ID of the current module. */
ModuleId g_moduleId;

/** ID of the MAC module */
ModuleId g_macId;

/** Shared data by the core module. */
CoreSharedData *g_coreSharedData;

/** Key of the shared memory by the core. */
int g_coreSharedMemId;

/** Name of the routing table file. */
char *g_routeTableFileName;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 1;

/**
 * Calculate the actual size of data that is transmitted/received by this layer.
 * This size includes the size of headers of upper layers and the length of
 * payload.
 *
 * @param pbuf The received/transmitted data.
 * @return The actual size.
 */
int calc_actual_size(PduBuff * pbuf)
{
	return pbuf->msg_len + pbuf->hdr_net.hdr_len + pbuf->hdr_tra.hdr_len;
}

/**
 * Parse command line arguments.
 *
 * @param argc Number of arguments
 * @param argv The arguments
 * @return TRUE if the argument can be parse; FALSE, otherwise.
 */
int parse_arguments(int argc, char **argv)
{
	int c;
    int moduleId;
    int macId;
	
	while ((c = getopt (argc, argv, "i:m:c:f:v")) != -1) {
        switch (c) {
        case 'i':
        	moduleId = atoi(optarg);
            if (moduleId > MAX_MODULE_ID || moduleId < MIN_MODULE_ID) {
                fprintf(stderr, "Invalid module ID (%s)\n", optarg);
                return FALSE;
            }
            g_moduleId = moduleId;
            break;
            
        case 'm':
        	macId = atoi(optarg);
            if (macId > MAX_MODULE_ID || macId < MIN_MODULE_ID) {
                fprintf(stderr, "Invalid module ID (%s)\n", optarg);
                return FALSE;
            }
            g_macId = macId;
            break;
        
        case 'c':
        	g_routeTableFileName = optarg;
            break;
        
        case 'f':
        	gLogFile = atoi(optarg);
            break;
            
		case 'v':
			log_info("build time: %s %s", __DATE__, __TIME__);
			log_info("SEALINX_VERSION: %s", SEALINX_VERSION);
			exit(0);
		
		case '?':
			return FALSE;
		}
	}
	
	return g_moduleId >= MIN_MODULE_ID && g_moduleId <= MAX_MODULE_ID &&
	       g_macId >= MIN_MODULE_ID && g_macId <= MAX_MODULE_ID;
}

/**
 * Print the usage of the program.
 */
void print_usage(const char *progName)
{
	printf("USAGE: %s "
	       "-i <module id> -m <mac id> [-c <routing table file name>] [-f <log file outoput flag>]\n",
	       progName);
}

/**
 * Initialize the program.
 */
int init_sroute(void)
{
	int type = 0;
	ModuleId moduleIds[NUM_LAYERS];
	moduleIds[LAYER_MAC] = g_macId;
	moduleIds[LAYER_NETWORK] = g_moduleId;
	
	if (!init_logger(gLogFolder, gLogId, gLogFile, TRUE, moduleIds, 2)) {
		fprintf(stderr, "Unable to init the log module.");
		return FALSE;
	}
	
	RegistrationResponse serverResponse;
	g_connFd = client_connect(type, LAYER_NETWORK, moduleIds, &serverResponse, NULL, 0);
	g_coreSharedMemId = serverResponse.coreShareMemId;
	log_info("Key of shared memory by the core: %d", g_coreSharedMemId);
	g_coreSharedData = (CoreSharedData *) shmat(g_coreSharedMemId, NULL, 0);
	
	if (g_coreSharedData == (CoreSharedData *) - 1) {
		fprintf(stderr, "Unable to attach the shared memory: %s", strerror(errno));
		return FALSE;
	}
	
	logger_set_node_id(g_coreSharedData->macAddr, g_coreSharedData->netAddr);
	log_info("Mac address: %d, net address: %d",
		    (int)g_coreSharedData->macAddr,
		    (int)g_coreSharedData->netAddr);
	
	return TRUE;
}

/**
 * Signal handler.
 * @param sig Signal ID.
 */
void signal_handler(int sig)
{
	int type = 0;
	log_info("Received signal (%d)", sig);

	if (g_connFd > -1) {
		client_close(type, g_connFd, NULL, 0);
		g_connFd = -1;
	}
}

/**
 * Clean up allocated resources.
 */
void clean_up(void)
{
	int type = 0;
	log_info("Cleaning up ...");
	if (g_connFd > -1) {
		client_close(type, g_connFd, NULL, 0);
	}
	int rc = shmdt(g_coreSharedData);
	if (rc == -1) {
		log_error("Unable to detach shared data: %s", strerror(errno));
	}
	close_logger();
}

/**
 * Finds the next hop to a destination from a node.
 *
 * @param local_id Local node's network address.
 * @param dst_id Destination node's network address.
 * @return Network address of the next hop if found.
 * @retval -1 if errors occur.
 */
int get_next_hop(unsigned short int local_id, unsigned short int dst_id)
{
	int id1, id2, id3, next_id;
	int flag_found = 0;
	char *token;
	char local_buff[1000];
	FILE *network_cfg = fopen(g_routeTableFileName, "r");

	if (!network_cfg) {
		logError("No routing table found: %s", strerror(errno));
		return -1;
	}
	memset(local_buff, 0, sizeof(local_buff));
	while (fgets(local_buff, sizeof(local_buff), network_cfg)) {
		token = strtok(local_buff, " :");
		if (*token == '#')
			continue;
		if (token == NULL)
			continue;
		id1 = atoi(token);
		token = strtok(NULL, " :");
		if (token == NULL)
			continue;
		id2 = atoi(token);
		token = strtok(NULL, " :");
		if (token == NULL)
			continue;
		id3 = atoi(token);
		if (id1 == local_id && id3 == dst_id) {
			if (id2 >= 0 && id2 < 65536) {
				next_id = id2;
				flag_found = 1;
				break;
			}
		}
	}
	fclose(network_cfg);
	if (flag_found == 1) {
		logInfo("Next Hop for DEST NODE %d: Node %hu", dst_id, next_id);
		return next_id;
	} else {
		logInfo("Next Hop cannot be found!");
		return -1;
	}
}

/**
 * Process outgoing data.
 *
 * @param pbuf The data.
 */
void process_outgoing_data(PduBuff * pbuf)
{
	int nextHop = get_next_hop(g_coreSharedData->netAddr, pbuf->hdr_net.dst_addr);
	if (nextHop < 0) {
		log_drop(PKT_DATA, 
		         pbuf->hdr_net.src_addr,
			     pbuf->hdr_net.dst_addr, 
			     calc_actual_size(pbuf),
			     "No route found");
		return;
	}
	
	pbuf->hdr_net.net_type = g_moduleId;
	pbuf->hdr_net.next_hop = nextHop;
	pbuf->hdr_net.hdr_len = sizeof(struct type_net_hdr)-sizeof(pbuf->hdr_net.net_data);
	log_send(PKT_DATA, 
	         pbuf->hdr_net.src_addr,
		     pbuf->hdr_net.dst_addr, 
		     calc_actual_size(pbuf), 
		     "DATA");

	client_send_down(g_connFd, pbuf, sizeof(PduBuff), g_moduleId, NULL, 0);
	return;
}

/**
 * Processes incoming TXDONE pkt.
 *
 * @param pbuf The data.
 */
void processIncomingTxDonePkt (PduBuff *pdu)
{
    client_send_up(g_connFd, pdu, sizeof(PduBuff), g_moduleId, NULL, 0);
    return;
}

/**
 * Processes incoming data pkt.
 *
 * @param pbuf The data.
 */
void processIncomingDataPkt(PduBuff * pbuf)
{
	if ((pbuf->hdr_net.dst_addr == g_coreSharedData->netAddr) ||
		(pbuf->hdr_net.dst_addr == NET_BROADCAST_ADDR)) {
		log_receive(PKT_DATA, 
		            pbuf->hdr_net.src_addr,
			        pbuf->hdr_net.dst_addr, 
			        calc_actual_size(pbuf),
			        "DATA");
			        
		client_send_up(g_connFd, pbuf, sizeof(PduBuff), g_moduleId, NULL, 0);
		return;
	}
	
	if (pbuf->hdr_net.next_hop == g_coreSharedData->netAddr) {
	    log_forward(PKT_DATA, 
		            pbuf->hdr_net.src_addr, 
		            pbuf->hdr_net.next_hop,
			        pbuf->hdr_net.dst_addr, 
			        calc_actual_size(pbuf), 
			        "FORWARD_DATA");
	    
		int nextHop = get_next_hop(g_coreSharedData->netAddr, pbuf->hdr_net.dst_addr);
		if (nextHop < 0) {
			log_drop(PKT_DATA, 
			         pbuf->hdr_mac.src_addr,
				     pbuf->hdr_mac.dst_addr, 
				     calc_actual_size(pbuf),
				     "Next hop not found");
			return;
		}
		
		pbuf->hdr_net.next_hop = nextHop;
		pbuf->hdr_net.net_type = g_moduleId;
		pbuf->hdr_net.hdr_len = sizeof(struct type_net_hdr) - sizeof(pbuf->hdr_net.net_data);
			        
        ModemInfo *rxInfo = (ModemInfo *)pbuf->phy;
        ModemInfo *txInfo = (ModemInfo *)malloc(sizeof(ModemInfo));
        memset(txInfo, 0, sizeof(ModemInfo));
        txInfo->type = Modem_Info_Tx;
        memcpy(&txInfo->tx.phy_param, &rxInfo->rx.phy_param, sizeof(Modem_Phy_Params));
        memset(pbuf->phy, 0, sizeof(ModemInfo));
        memcpy(pbuf->phy, txInfo, sizeof(ModemInfo));

		client_send_down(g_connFd, pbuf, sizeof(PduBuff), g_moduleId, NULL, 0);
		
		free(txInfo);
		return;
	} else {
		/* Not for me, no need to forward it */
		log_drop(PKT_DATA, 
		         pbuf->hdr_net.src_addr,
			     pbuf->hdr_net.dst_addr, 
			     calc_actual_size(pbuf),
			     "Packet is not for me");
	    return;
	}
}

/**
 * Processes incoming data.
 *
 * @param pbuf The data.
 */
void process_incoming_data(PduBuff * pbuf)
{
    ModemInfo *pPhyInfo= (ModemInfo *)pbuf->phy;
    
    switch (pPhyInfo->type) {
    case Modem_Info_Tx_Done:
        log_info("Modem_Info_Tx_Done");
        processIncomingTxDonePkt(pbuf);
        break;
    
    case Modem_Info_Rx:
    log_info("Modem_Info_Rx");
        processIncomingDataPkt(pbuf);
        break;
        
    default:
        logError("ERROR RECEIVE PACKET TYPE");
        exit(1);
    }
    
    return;
}

/**
 * Main program.
 *
 * @param argc Number of parameters.
 * @param argv Array of parameters.
 */
int main(int argc, char **argv)
{
	atexit(clean_up);
	signal(SIGINT, signal_handler);
	
	char buffer[IMSG_MAX_DATA_LENGTH];
	InternalMessageHeader dataHeader;
	
	if (!parse_arguments(argc, argv)) {
		print_usage(argv[0]);
		return EXIT_FAILURE;
	}
	
	if (!init_sroute()) {
		return EXIT_FAILURE;
	}
	
	while (TRUE) {
		int nBytesRead =
		    client_read(g_connFd, buffer, IMSG_MAX_DATA_LENGTH, &dataHeader, NULL, 0);
		if (nBytesRead == -1) {
			log_error("System error occurred");
			break;
		}
		if (nBytesRead == -2) {
			log_warning("Data was not successfully received");
		}
		if (nBytesRead == 0) {
			logInfo("Connection closed by the core module");
			break;
		}
		
		PduBuff *pbuf = (PduBuff *) buffer;
		
		if (from_upper_layer(dataHeader)) {
			process_outgoing_data(pbuf);
		} else if (from_lower_layer(dataHeader)) {
			process_incoming_data(pbuf);
		} else {
			log_error("Packet state error");
			continue;
		}
	}
	return EXIT_SUCCESS;
}
