/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author yibo
 */

#ifndef __SEALINX_TIMERQ_H__
#define __SEALINX_TIMERQ_H__

#include "sealinx_timer.h"
#include "sealinx_pktq.h"

/*pass this structure to timer_list variable*/
struct timer_q_elem {
	sealinx_timer_t start_timer;
	Packet pkt;
	struct timer_q_elem *next;
};

#ifdef	__cplusplus
extern "C" {
#endif
	/*
	 * initialize the timer queue. head is a point without any assigned space.
	 * q_clear_timer points to the a timer_list
	 */
	void timer_queue_init(struct timer_q_elem **head);
	/*free all elements in the timer queue */
	void timer_queue_free(struct timer_q_elem **head);
	/*delete the specified element */
	void timer_queue_delete(struct timer_q_elem *head,
				struct timer_q_elem *elem);
	/*insert delay_timer into the queue */
	void timer_queue_insert(struct timer_q_elem *head,
				struct timer_q_elem *delay_timer);

	struct timer_q_elem *timer_queue_findtimerbypkt(struct timer_q_elem
							*head, Packet * pkt,
							int (*id_compare)
							(Packet *, Packet *));
#ifdef	__cplusplus
}
#endif
#endif
