/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author yibo
 */  
    
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <sys/time.h>
    
#include "sealinx_time.h"
    
#define TIMESTR_BUFSIZE 100 
    
/* Return the current time to the array pointed by @time_string
 * The size of the array is specified in @max_size
 * Time is accurate in seconds 
 */ 
int get_timestring_sec(char *time_string, int max_size)
{
	
	time_t now;
	
	struct tm *tp;
	
	//char local_string[TIMESTR_BUFSIZE];
	now = time((time_t *) NULL);
	
	tp = localtime(&now);
	
	//memset(local_string, 0, sizeof (local_string));
	//strftime(local_string, sizeof(local_string), "%Y %m %d %H:%M:%S", tp);
	return strftime(time_string, max_size, "%d%H%M%S", tp);
	
	    /*if (strlen(local_string) > max_size) {
	       printf("\nget_timestring_sec: output buffer too small, need %d bytes in total\n", strlen(local_string));
	       strcpy(time_string, "9999");
	       } else
	       strcpy(time_string, local_string); */ 
}


 
void get_fulltimestring_sec(char *time_string, int max_size)
{
	
	time_t now;
	
	struct tm *tp;
	
	char local_string[TIMESTR_BUFSIZE];
	
	now = time((time_t *) NULL);
	
	tp = localtime(&now);
	
	memset(local_string, 0, sizeof(local_string));
	
	strftime(local_string, sizeof(local_string), "%Y %m %d %H:%M:%S", tp);
	
	if (strlen(local_string) > max_size) {
		
		printf("\nget_timestring_sec: output buffer too small, need %d bytes in total\n",
		     				(int)strlen(local_string));
		
		strcpy(time_string, "9999");
	
	} else
		
		strcpy(time_string, local_string);

}


