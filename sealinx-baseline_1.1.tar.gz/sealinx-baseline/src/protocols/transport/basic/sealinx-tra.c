/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * Sample code for the transport protocol.
 *
 * @author son
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <err.h>
#include <signal.h>
#include <sys/socket.h>
#include <errno.h>
#include <sealinx.h>
#include <sys/shm.h>

#include <sealinx.h>
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>

/** Default log identity for this module. */
#define DEFAULT_LOG_ID "DUMMY_TRA"

/** Default path to the folder consisting log files. */
#define DEFAULT_LOG_FOLDER "logs/"

/** Log identity for this module. */
char *gLogId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char *gLogFolder = DEFAULT_LOG_FOLDER;

/** ID of the current module. */
ModuleId g_moduleId;

/** ID of the MAC module. */
ModuleId g_macId;

/** ID of the network module. */
ModuleId g_netId;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 1;

/** Shared data by the core module. */
CoreSharedData *g_coreSharedData;

/** ID of the shared memory by the core module. */
int g_coreSharedMemId;

/** File descriptor of the connection to the core. */
int g_connFd;


/**
 * Clean up allocated resources.
 */
void clean_up(void)
{
	int type = 0;
    log_info("Cleaning up ...");

    if (g_connFd > -1) {
        client_close(type, g_connFd, NULL, 0);
    }

    if (g_coreSharedData) {
        int rc = shmdt(g_coreSharedData);
        if (rc == -1) {
            log_error("Unable to detach shared data: %s", strerror(errno));
        }
    }

    close_logger();
}

/**
 * Signal handler.
 *
 * @param sig Signal ID.
 */
void signal_handler(int sig)
{
	int type = 0;
    log_info("Received signal (%d)", sig);

    if (g_connFd > -1) {
        client_close(type, g_connFd, NULL, 0);
        g_connFd = -1;
    }
}

/**
 * Parse command line arguments.
 *
 * @param argc Number of arguments
 * @param argv The arguments
 * @return TRUE if the argument can be parse; FALSE, otherwise.
 */
int parse_arguments(int argc, char **argv)
{
#if 0
	int i = 0;
	while (i < argc) {
		char *t = argv[i];
		if (strcmp(t, "-i") == 0) {
			i++;
			if (i < argc) {
				int moduleId = strtol(argv[i], NULL, 10);
				if (moduleId > MAX_MODULE_ID || moduleId < MIN_MODULE_ID) {
					fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
					return FALSE;
				}
				g_moduleId = moduleId;
			}
		} else if (strcmp(t, "-m") == 0) {
			i++;
			if (i < argc) {
				int macId = strtol(argv[i], NULL, 10);
				if (macId > MAX_MODULE_ID || macId < MIN_MODULE_ID) {
					fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
					return FALSE;
				}
				g_macId = macId;
			}
		} else if (strcmp(t, "-n") == 0) {
			i++;
			if (i < argc) {
				int netId = strtol(argv[i], NULL, 10);
				if (netId > MAX_MODULE_ID || netId < MIN_MODULE_ID) {
					fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
					return FALSE;
				}
				g_netId = netId;
			}
		} else if (strcmp(t, "-f") == 0) {
			i++;
			if (i < argc)
				gLogFile = atoi(argv[i]);
		}
		i++;
	}
#else
    int c;
    int moduleId;
    int macId;
    int netId;

	while ((c = getopt (argc, argv, "i:m:n:f:v")) != -1) {
        switch (c) {
        case 'i':
        	moduleId = atoi(optarg);
            if (moduleId > MAX_MODULE_ID || moduleId < MIN_MODULE_ID) {
                fprintf(stderr, "Invalid module ID (%s)\n", optarg);
                return FALSE;
            }
            g_moduleId = moduleId;
            break;

        case 'm':
        	macId = atoi(optarg);
            if (macId > MAX_MODULE_ID || macId < MIN_MODULE_ID) {
                fprintf(stderr, "Invalid module ID (%s)\n", optarg);
                return FALSE;
            }
            g_macId = macId;
            break;

        case 'n':
        	netId = atoi(optarg);
            if (netId > MAX_MODULE_ID || netId < MIN_MODULE_ID) {
                fprintf(stderr, "Invalid module ID (%s)\n", optarg);
                return FALSE;
            }
            g_netId = netId;
            break;

        case 'f':
        	gLogFile = atoi(optarg);
            break;

		case 'v':
			log_info("build time: %s %s", __DATE__, __TIME__);
			log_info("SEALINX_VERSION: %s", SEALINX_VERSION);
			exit(0);

		case '?':
			return FALSE;
		}
	}
#endif

	return g_moduleId >= MIN_MODULE_ID && g_moduleId <= MAX_MODULE_ID &&
	       g_macId >= MIN_MODULE_ID && g_macId <= MAX_MODULE_ID &&
	       g_netId >= MIN_MODULE_ID && g_netId <= MAX_MODULE_ID;
}

/**
 * Print the usage of the program.
 */
void print_usage(const char *progName)
{
	printf("USAGE: %s "
	       "-i <module id> -m <mac protocol id> -n <net protocol id> [-f <log file outoput flag>]\n",
	       progName);
}

/**
 * Initialize the program.
 */
int init_tra(void)
{
	int type = 0;
	ModuleId moduleIds[NUM_LAYERS];
	moduleIds[LAYER_TRANSPORT] = g_moduleId;
	moduleIds[LAYER_NETWORK] = g_netId;
	moduleIds[LAYER_MAC] = g_macId;

	if (!init_log(gLogFolder, gLogId, gLogFile, TRUE, g_moduleId)) {
		fprintf(stderr, "Unable to init the log module.");
		return FALSE;
	}

	RegistrationResponse serverResponse;
	g_connFd = client_connect(type, LAYER_TRANSPORT, moduleIds, &serverResponse, NULL, 0);
	g_coreSharedMemId = serverResponse.coreShareMemId;
	log_info("Key of shared memory by the core: %d", g_coreSharedMemId);

	g_coreSharedData = (CoreSharedData *)shmat(g_coreSharedMemId, NULL, 0);
	if (g_coreSharedData == (CoreSharedData *) - 1) {
		fprintf(stderr, "Unable to attach the shared memory: %s", strerror(errno));
		return FALSE;
	}

	logger_set_node_id(g_coreSharedData->macAddr, g_coreSharedData->netAddr);
	log_info("Mac address: %d, Net address: %d",
	        (int)g_coreSharedData->macAddr, (int)g_coreSharedData->netAddr);
	return TRUE;
}

/**
 * Main program.
 *
 * @param argc Number of parameters.
 * @param argv Array of parameters.
 */
int main(int argc, char **argv)
{
	atexit(clean_up);
	signal(SIGINT, signal_handler);

	if (!parse_arguments(argc, argv)) {
		print_usage(argv[0]);
		return EXIT_FAILURE;
	}
	if (!init_tra())
		return EXIT_FAILURE;

	char recv_buf[IMSG_MAX_DATA_LENGTH];
    InternalMessageHeader dataHeader;
    PduBuff *pbuf = (PduBuff *) recv_buf;

	while (TRUE) {
		memset(recv_buf, 0, sizeof (recv_buf));

        int retCode = client_read(g_connFd, recv_buf, IMSG_MAX_DATA_LENGTH, &dataHeader, NULL, 0);
		if (retCode <= 0) {
			// TODO check retCode here
			break;
		}

		if (from_upper_layer(dataHeader)) {
			log_info("Get data from APP layer");
			pbuf->hdr_tra.hdr_len = sizeof(pbuf->hdr_tra)-sizeof(pbuf->hdr_tra.tra_data);
			pbuf->hdr_tra.tra_type = g_moduleId;
			log_send(PKT_DATA,
				     pbuf->hdr_net.src_addr,
				     pbuf->hdr_net.dst_addr,
				     pbuf->msg_len+pbuf->hdr_tra.hdr_len,
				     "DATA");
			client_send_down(g_connFd, pbuf, sizeof(PduBuff), g_moduleId, NULL, 0);
		} else if (from_lower_layer(dataHeader)) {
			log_info("Get data from NET layer");
			log_receive(PKT_DATA,
	                   pbuf->hdr_net.src_addr,
	                   pbuf->hdr_net.dst_addr,
	                   pbuf->msg_len+pbuf->hdr_tra.hdr_len,
	                   "DATA");
			client_send_up(g_connFd, pbuf, sizeof(PduBuff), g_moduleId, NULL, 0);
		} else {
			log_error("Packet state error");
			continue;
		}
	}
	return EXIT_SUCCESS;
}
