/*!
 * @file    modem_info.h
 * @brief   Information struct of modem.
 */

#ifndef __MODEM_INFO__H
#define __MODEM_INFO__H

#ifdef __cplusplus
extern "C" {
#endif

#include "../drivers/ipc/libAngelfish/include/modem.h"

/*==== phy_range ====*/
typedef struct {
    /* Copied form struct Rngio_Packet of Rngio.h */
    int error;      /* 0 if succeeded otherwise failed */
    int remoteId;   /* ID of another modem */
    float deltaT;   /* Not used now, timestamp difference between two modems */
    float distance; /* Distance between two modems */
} ModemRange;

/*==== phy_param ====*/
typedef enum {
    /* Copied form definition of mregs.h */
    MODEM_MID =     0,  /* This register stores a modem ID which basically it's MAC address */
    MODEM_BIV =     3,  /* Boot image version */
    MODEM_RXFLG =   30, /* Receiving flags */
    MODEM_TXFLG =   31, /* Transmittng flags */
    MODEM_TXPWR =   50, /* Transmitting power */
    MODEM_RXGAIN =  51, /* Receiving gain */
    MODEM_GUARDT =  52, /* Guard time between OFDM blocks */
    MODEM_FXN =     73, /* Functionalities */
} ModemConfigId;

typedef enum {
    /* Copied form definition of mregs.h */
    MODEM_Field_NONE = 0 /* Default field */
} ModemXxxField; /* MODEM_MID, MODEM_BIV, MODEM_TXPWR, MODEM_RXGAIN, MODEM_GUARDT */

typedef enum {
    /* Copied form definition of mregs.h */
    /* When this field is set to TRUE, modem receivs all incomming acoustic
     * packets without regarding the destination modem IDs of the packets. When
     * FALSE, modem receives only the acoustic packets with the destination ID
     * same as its own ID.
     */
    MODEM_Field_RXFLG_RALL = 1,
    /* This field assigns the trigger channel in a mutiple receiving channel
     * modem. The triggering channel is always on for acoustic packet detection.
     */
    MODEM_Field_RXFLG_RCHL = 2,
    MODEM_Field_RXFLG_ISNR = 3, /* 0 or 1, close or open debug information of ISNR */
    MODEM_Field_RXFLG_ZONE = 4, /* 0 or 1, close or open debug information of ZONE */
    MODEM_Field_RXFLG_RAW  = 5, /* 0 or 1, don't or save raw wave file */
    MODEM_Field_RXFLG_DBG  = 6, /* 0 or 1, close or open debug information */
    MODEM_Field_RXFLG_TCHL = 7  /* Not used now */
} ModemRxflgField; /* MODEM_RXFLG */

typedef enum {
    MODEM_Field_TXFLG_DONE = 1,
    MODEM_Field_TXFLG_DBG  = 2
} ModemTxflagField; /* MODEM_TXFLG */

typedef enum {
    MODEM_Field_FXN_MANUALRX = 1,
    MODEM_Field_FXN_CFGSAVE  = 2,
    MODEM_Field_FXN_FACSET   = 3
} ModemFxnField; /* MODEM_FXN */

typedef union {
    enum {
        MODEM_CONFIG_OFF = 0,
        MODEM_CONFIG_ON = 1
    } modem_config_value_bool;

    int modem_config_value_int;
} ModemConfigValue;

typedef struct {
    /* Copied form struct Mrio_Packet of Mrio.h */
    int err;    /* error flag of option */
    int regId;  /* register id, limited by enum ModemParamId, defined in mreg.h of modem */
    int field;  /* register field, limited by enum ModemParamField, defined in mreg.h of modem */
    int value;  /* 0 is off, 1 is on, int value otherwise, limited by ModemParamValue */
} ModemCfg;

/*==== phy_send_finish ====*/
typedef struct {
    int err;    /* the successful flag at send, 0 if successful, error ID otherwise */
    int sn;     /* serial number with tx times, self-increased by sending modem */
} ModemTxDone;

/*==== phy_send ====*/
typedef enum {
    /* Copied form enum Acomm_Mode of acomm.h */
	/* Regular modes */
	Modem_Mode_RS		= 0,    /* Range and preamble */
	Modem_Mode_R1		= 1,
	Modem_Mode_R2		= 2,
	Modem_Mode_R3		= 3,
	Modem_Mode_R4		= 4,
	Modem_Mode_R5		= 5,
	/* AUV modes */
	Modem_Mode_AS		= 10,
	Modem_Mode_A1		= 11,
	Modem_Mode_A2		= 12,
    /* Mfsk modes */
    Modem_Mode_FS       = 20,
    Modem_Mode_F1       = 21
} ModemMode;

typedef enum {
    /* Copied form enum Acomm_Type of acomm.h */
	Modem_Type_DATA 	= 0,	/* Packet ata */
	Modem_Type_NWK 		= 1,	/* Don't care, network */
	Modem_Type_WAVE 	= 64, 	/* Don't care, wave play */
	Modem_Type_RANGE 	= 65,	/* Don't care, ranging */
	Modem_Type_LOC 		= 66,	/* Don't care, localization */
    Modem_Type_REMOTE	= 67, 	/* Don't care, remote control */
} ModemType;

typedef enum {
    /* Copied form enum Acomm_GuardTime of acomm.h */
	Modem_GuardTime_50 = 50,
	Modem_GuardTime_100 = 100,
	Modem_GuardTime_150 = 150
} ModemGuardTime;

typedef struct {
    Modem_Phy_Params phy_param; /* the receiving parameters */
} ModemTx;

/*==== phy_recv ====*/
typedef struct {
    /* Copied form struct Acio_Rx of Acio.h */
    int err;    /* the successful flag at receive, 0 if successful, error ID otherwise */
    Modem_Phy_Params phy_param; /* the receiving parameters */
    unsigned int sn;            /* not used now, serial number with tx times */
	float effsnr;               /* receiving effective signal noise ratio */
} ModemRx;

/*==== phy ====*/
typedef enum {
    /* Copied form enum UioChannel of Uio.h */
    Modem_Info_Tx = 0,      /* Send packet to another modem */
    Modem_Info_Tx_Done,     /* Notice, the packet has been sent out */
    Modem_Info_Rx,          /* Received a packet from modem */
    Modem_Config_Set,       /* Set a configuration of modem */
    Modem_Config_Get,       /* Get a configuration value of modem */
    Modem_Range             /* Get distance between the modem with another modem */
} ModemInfoType;

typedef struct {
    ModemInfoType type;
    union {
        ModemTx tx;         /* Valid if type is Modem_Info_Tx */
        ModemTxDone txDone; /* Valid if type is Modem_Info_Tx_Done */
        ModemRx rx;         /* Valid if type is Modem_Info_Rx */
        ModemCfg cfg;       /* Valid if type is Modem_Config_Set or Get */
        ModemRange range;   /* Valid if type is Modem_Range */
    };
} ModemInfo; /* Called by struct PduBuff's phy of sealinx_pdu.h */

#ifdef __cplusplus
}
#endif

#endif /* __MODEM_INFO__H */
