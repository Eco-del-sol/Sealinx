/**
\page overview_page
\section overview_app_sec Application

In the application layer, we include a Poisson traffic generator: <tt>sealinx-tx-poi</tt>. In the sender, the syntax is
\code
sealinx-tx-poi -i <app ID> -p <core port> -m <MAC protocol ID> -n <net protocol ID> - t <transport protocol id> -l <packet length> -r <traffic rate> -d <destination node>
\endcode
where
 - <tt>\<app ID\></tt> is the identifier of the application, which will be filled in the service type field. 
 - <tt>\<core port\></tt> is the port that the core is listening on.
 - <tt>\<mac protocol ID\></tt> is the identifier of the underlying MAC protocol.
 - <tt>\<net protocol ID\></tt> is the identifier of the underlying network protocol. Note that the network protocol must be registered with the MAC protocol.
 - <tt>\<transport protocol ID\></tt> is the identifier of the underlying network protocol. Note that the network protocol must be registered with the network protocol.
 - <tt>\<packet length\></tt> is the size of the packet that is sent.
 - <tt>\<traffic rate\></tt> is the rate of sending, in packets per second.
 - <tt>\<destination node\></tt> is the network address of the destination.
Note that multiple upper layer protocol can be registered with a lower layer one.

 */
