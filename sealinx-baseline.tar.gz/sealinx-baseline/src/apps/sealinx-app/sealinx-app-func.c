#include "sealinx-app-func.h"
#include "sealinx-app.h"
//#include "./common/sealinx_protocols_common.h"
#include "sealinx_protocols_common.h"


extern app_module_config_t g_app_module_cfg;

int8_t * time_display_locate(void)
{
	time_t current_time;
    struct tm *local_time;
    //time_display_locate
	int8_t time_string[128];
    // 获取当前系统时间
    current_time = time(NULL);
    // 将时间转换为本地时间
    local_time = localtime(&current_time);
    // 格式化时间字符串
    memset(time_string, 0, sizeof(time_string));
    strftime(time_string, sizeof(time_string), "%Y-%m-%d %H:%M:%S", local_time);
    // 打印时间
    return time_string;
}

static int32_t str2hex(const int8_t *src, int8_t *dst, int32_t len)
{
    int32_t i;
    uint8_t c;
    for (i = 0; i < len; i++)
    {
        c = (uint8_t)src[i];
        *dst++ = HEX(c >> 4);
        *dst++ = HEX(c & 0xF);
    }
    return 0;
}

static int32_t hex2dec(int8_t a)
{
    if ('0' <= a && '9' >= a)
        return a - '0';
    else if ('a' <= a && 'f' >= a)
        return a - 'a' + 10;
    else if ('A' <= a && 'F' >= a)
        return a - 'A' + 10;
    return -1;
}

static int32_t interpret_hex_data(const int8_t *src, int8_t *dst, int32_t len)
{
    int32_t i, k = 0;
    int32_t n = len % 2 ? len - 1 : len;
    for (i = 0; i < n - 1; i += 2)
    {
        int32_t a = hex2dec(src[i]), b = hex2dec(src[i + 1]);
        if (a == -1 || b == -1)
            break;
        dst[k++] = (a << 4) | b;
    }
    return k * 2;
}
int32_t judge_send_mode(uint8_t mode)
{
    int32_t ntr;
    switch (mode)
    {
        case 1 ... 5:
        case 11:
        case 12:
        case 21:
            ntr = TRUE;
            break;
        
        default:
            ntr = FALSE;
            break;
    }
    return ntr;
}


static int32_t serial_data_to_pkt(int8_t *payload, int32_t len)
{

    uint32_t temp = 0;
    //定义一个1024*13字节大小的数据
    int8_t buff[IMSG_MAX_DATA_LENGTH] = {0};
    //将数组强转成pdu类型
    PduBuff *pkt = (PduBuff *)buff;
    pkt->pkt_type = SEALINX_BTYPE_DATA_TRANSPARENCY;
	pkt->hdr_net.hdr_len = sizeof(pkt->hdr_net) - sizeof(pkt->hdr_net.net_data) + sizeof(net_data_struct);

	transparency_send_data *trans_data = (transparency_send_data *)payload;

    pkt->hdr_net.dst_addr = trans_data->dest_id;
    pkt->hdr_net.src_addr = g_app_module_cfg.core_shared_data->netAddr;
    LOG_DISPLAY("pkt->hdr_net.dst_addr ===>(%d)", pkt->hdr_net.dst_addr);	
    
    //填充TraInfo类型结构体
    TraInfo *ti = (TraInfo *)pkt->hdr_tra.tra_data;
    ti->appUnpack = 0;
    ti->traUnpack = 0;
    pkt->hdr_tra.service_type = g_app_module_cfg.module_id;
    pkt->hdr_tra.hdr_len = sizeof(pkt->hdr_tra) - sizeof(pkt->hdr_tra.tra_data) + sizeof(TraInfo);
    LOG_DISPLAY("TRA_LEN ==>%d",pkt->hdr_tra.hdr_len);

    
    //填充ModemInfo类型结构体
    ModemInfo *pPhyInfo = (ModemInfo *)pkt->phy;
    pPhyInfo->type = Modem_Info_Tx;
	pPhyInfo->tx.phy_param.dst  = 0;
	pPhyInfo->tx.phy_param.src  = 0;
	pPhyInfo->tx.phy_param.guard_time  = -1;
	pPhyInfo->tx.phy_param.power_level = -1;
	
    //判断模式是否正确
    if(!judge_send_mode(trans_data->send_mode))
    {
        LOG_DISPLAY("sendmode is erro,can't send");
        return FALSE;
    }
    if(trans_data->retrans_flag != 0 && trans_data->retrans_flag != 1)
    {
        LOG_DISPLAY("sendagain flag is erro,can't send");
        return FALSE;
    }
    if(trans_data->auto_flag != 0 && trans_data->auto_flag != 1)
    {
        LOG_DISPLAY("monitor flag is erro,can't send");
        return FALSE;
    }
    
    pPhyInfo->tx.phy_param.mode = trans_data->send_mode;
    
	net_data_struct* net_data = (net_data_struct*)pkt->hdr_net.net_data;
	net_data->retrans_flag = trans_data->retrans_flag;
	net_data->auto_manual_flag = trans_data->auto_flag;
	net_data->time_stamp = trans_data->timestamp;
    
    pkt->msg_len = len-sizeof(uint8_t) * 4 - sizeof(uint32_t);
    LOG_DISPLAY("net_data.retrans_flag==>%d", net_data->retrans_flag);
    LOG_DISPLAY("net_data.auto_manual_flag==>%d", net_data->auto_manual_flag);
    LOG_DISPLAY("net_data.time_stamp==>%d", net_data->time_stamp);
    LOG_DISPLAY("pkt->msg_len==>%d", pkt->msg_len);
    
    // 将数据拷贝到pkt->data中
    memcpy(pkt->pkt_data, trans_data->data, pkt->msg_len);
    pkt->bInternal = 0;
    
    log_send(PKT_DATA,
             pkt->hdr_net.src_addr,
             pkt->hdr_net.dst_addr,
             pkt->msg_len,
             "SEND_AUV_DATA");
    client_send_down(g_app_module_cfg.connect_fd, pkt, sizeof(PduBuff), g_app_module_cfg.module_id, NULL, 0);
    return TRUE;
}

int32_t serial_data_parse(int8_t *payload, int32_t len)
{
	//如果总字节数小于或者等于18，表明该指令或者数据不完整；字节数不是偶数则表明格式不是16进制
	if(len <= 18 || len % 2 != 0)
	{
		LOG_DISPLAY("Data length is too short or is not even");
		return FALSE;
	}
	int8_t payload_buf[PDU_DATA_LEN];
    memset(payload_buf, 0, sizeof(payload_buf));
    interpret_hex_data(payload, payload_buf, len);
    printf("******************serial_data in******************************\n");
    for (int32_t i = 0; i < len / 2; i++)
    {
        printf("(0x%x) ", payload_buf[i]);
    }
    printf("******************serial_data end******************************\n");

    busi_data_head *head_info = (busi_data_head *)payload_buf;
    LOG_DISPLAY("head_info->opt ===>(%d)", head_info->opt);
    switch (head_info->opt)
    {
	    case SEALINX_BTYPE_DATA_TRANSPARENCY:
	        if(!serial_data_to_pkt(head_info->data, head_info->dataLen - 9))
	        {
	            log_error(" Business type 1 nalysis erro");
	            return FALSE;
	        }
	        break;

		default:
	        log_error("ERROR BUSINESS DATA TYPE");
	        return FALSE;

    }


}


int32_t serial_data_get(int8_t *input, int32_t inputLen)
{
    static int8_t buf[MAX_BUFF_LEN];
    static int32_t count = 0;
    int32_t rtn = 0;
    int32_t i = 0;
    for (i = 0; i < inputLen; i++)
    {
        if ('$' == input[i] || '@' == input[i])
        {
                memset(buf, 0x00, sizeof(buf));
                count = 0;
                buf[count] = input[i];
                count++;
                continue;
        }
        else if(MAX_BUFF_LEN < count){
            log_error("auv Data length is too long,can't to analysis");
            break;
        }
        else if ('#' == buf[count])
        {
            rtn = serial_data_parse(buf + 1, count - 1);
            count = 0;
            continue;
        }

        buf[count] = input[i];
        count++;
    }
    return rtn;
}
void send_app_data_out(int8_t *send_buff)
{
    int32_t rtn;
    if(g_app_module_cfg.judge_searial_socket)
    {
        sendto(g_app_module_cfg.fd_socket, send_buff, strlen(send_buff), 0, (struct sockaddr *)&g_app_module_cfg.client_addr, g_app_module_cfg.client_addr_len);
    }
    else
    {
        rtn = Serial_write(g_app_module_cfg.fd_serial, send_buff, strlen(send_buff));
    }
    if (rtn > 0) 
    {
        log_info("Serial Write Success");
    }
}

void incoming_data_trans_out(PduBuff *pdu)
{
	//todo by business type
}

void incoming_pkt_parse(PduBuff *pdu)
{
    switch (pdu->pkt_type)
    {
		case SEALINX_BTYPE_DATA_TRANSPARENCY:
		    log_info("GATEWAY RECEIVE DATA_TX_FROM_AUV id: %d", pdu->pkt_type);
		    incoming_data_trans_out(pdu);
		    break;
		default:
	        log_info("Gateway do not receive this type of message: %d", pdu->pkt_type);
	        //process_unrecognizable_data_from_down(pdu);
	        break;
    }
    return;
}


void *process_recv_from_serial(void *param)
{
    int32_t len = 0;
    static int8_t serial_read_buf[MAX_SER_LEN];
    static int8_t network_buf[MAX_SER_LEN];
    while (g_app_module_cfg.is_running)
    {
        
        if(g_app_module_cfg.judge_searial_socket)
        {
        	memset(network_buf, 0, sizeof(network_buf)); 
            if((len = recvfrom(g_app_module_cfg.fd_socket, network_buf, MAX_SER_LEN, 0, (struct sockaddr *)&g_app_module_cfg.client_addr, &g_app_module_cfg.client_addr_len))<= 0)
            {
                usleep(100000);
            }
            else
            {
                mfifo_put(g_app_module_cfg.mfifo_buf, network_buf, len);
                int8_t client_ip[INET_ADDRSTRLEN];
                printf("data from %s:%d\n",  inet_ntop(AF_INET, &g_app_module_cfg.client_addr.sin_addr, client_ip, sizeof(client_ip)), ntohs(g_app_module_cfg.client_addr.sin_port));
            }
        }
        else
        {
        	memset(serial_read_buf, 0, sizeof(serial_read_buf)); 
            if ((len = Serial_read(g_app_module_cfg.fd_serial, serial_read_buf, MAX_SER_LEN, 100)) <= 0)
            {
                usleep(100000); // 100ms
            }
            else
            {
                mfifo_put(g_app_module_cfg.mfifo_buf, serial_read_buf, len);
            }
        }        
    }
    return NULL;
}


void *process_recv_from_down(void *param)
{
    int8_t buffer[IMSG_MAX_DATA_LENGTH];
    InternalMessageHeader dataHeader;
    PduBuff *pbuf = (PduBuff *)buffer;
    int32_t nBytesRead;

    log_info("Enter TLN-CBS process_recv_from_down");
    while (g_app_module_cfg.is_running)
    {
        nBytesRead = client_read(g_app_module_cfg.connect_fd, buffer, IMSG_MAX_DATA_LENGTH, &dataHeader, NULL, 0);

        if (nBytesRead == -1)
        {
            log_error("System error occurred");
            break;
        }
        else if (nBytesRead == -2)
        {
            log_warning("Data was not successfully received");
            continue;
        }
        else if (nBytesRead == 0)
        {
            logInfo("Connection closed by the core module");
            break;
        }
        
        if (from_lower_layer(dataHeader))
        {
            incoming_pkt_parse(pbuf);
        }
        else if (from_upper_layer(dataHeader))
        {
            log_warning("There is no layer higher than this one");
        }
        else
        {
            log_error("Packet state error");
            continue;
        }
    }
    return NULL;
}

void *process_send(void *param)
{
    static int8_t buf[MAX_SOCKET_LEN];
    int32_t i, len, cmd_len;
    while (g_app_module_cfg.is_running)
    {
        if ((len = mfifo_len(g_app_module_cfg.mfifo_buf)) > 0)
        {
            memset(buf, 0, sizeof(buf));
            mfifo_get(g_app_module_cfg.mfifo_buf, buf, len);
            serial_data_get(buf, len);
        }
        else
        {
            usleep(100000);
        }
    }
    return NULL;
}
