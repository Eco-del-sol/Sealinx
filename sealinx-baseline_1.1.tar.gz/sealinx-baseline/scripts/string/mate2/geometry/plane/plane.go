package plane

import (
	// "log"
	"math"
	"time"
)

// Point represents a point on the plane geometry
type Point struct{ X, Y float64 }

// Distance is used to calculate the distance between to points
func (p *Point) Distance(q *Point) float64 {
	return math.Hypot(q.X-p.X, q.Y-p.Y)
}

// Equal retuwns true if two points in same place
func (p *Point) Equal(q *Point) bool {
	return p.X == q.X && p.Y == q.Y
}

// Move node
func (p *Point) Move(x, y float64) {
	p.X += x
	p.Y += y
}

// MoveTo moves one point to another
// q: the dst position
// speed: move speed (m/s)
// tstep: time step (microsecond)
func (p *Point) MoveTo(q *Point, speed float64, timeStep time.Duration) {
	srcPoint := *p
	d := p.Distance(q)
	x := q.X - p.X
	y := q.Y - p.Y
	deltaD := speed * timeStep.Seconds()
	deltaX := x * deltaD / d
	deltaY := y * deltaD / d

	for p.Distance(&srcPoint) < d {
		p.Move(deltaX, deltaY)
		time.Sleep(timeStep)
	}
}
