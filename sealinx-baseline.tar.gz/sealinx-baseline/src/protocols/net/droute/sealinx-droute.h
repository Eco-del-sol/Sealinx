/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author son
 */

#ifndef __SEALINX_DROUTE_H__
#define	__SEALINX_DROUTE_H__

#include <stdint.h>

/**
 * Default log identity for this module.
 */
#define DEFAULT_LOG_ID "DROUTE"

/**
 * Default path to the folder consisting log files.
 */
#define DEFAULT_LOG_FOLDER "logs/"



/*get route tabel command macro, add by yuansong 2018-5-2*/
#define GET_DROUTE_TABLE_REQ 0x01

#define GET_DROUTE_TABLE_IND 0x02
//////////////////////////////////////////////////////




/**
 * Print function names for debug output
 */
#define __FUNC_E__ (printf("%s() -- enter \n", __PRETTY_FUNCTION__));
#define __FUNC_L__ (printf("%s() -- leave \n", __PRETTY_FUNCTION__));

/*
 * Network layer broadcast address.
 */
#define NET_BROADCAST_ADDR 99

#define NET_PKT_DATA 90
#define NET_PKT_HELLO 99

#define NO_END_TIME (0xFFFFFFFFFFFFFFFFull)

#define PROTOCOL_PARAMS_GROUP "Protocol Parameters"
#define STABLE_HELLO_PERIOD_KEY "StableHelloPeriod"
#define UNSTABLE_HELLO_PERIOD_KEY "UnstableHelloPeriod"
#define ENTRY_TIMEOUT_KEY "EntryTimeout"
#define NUM_ROUTING_ENTRIES_KEY "NumRoutingEntries"
#define MIN_UPDATE_WAIT_KEY "MinimumUpdateWait"
#define MAX_UPDATE_WAIT_KEY "MaximumUpdateWait"

#define DR_LOG_NAME "sealinx-droute.log"
#define DR_NAM_NAME "sealinx-droute.nam"

#define MAX_HOP_COUNT 100000

/** Default config file name for dynamic routing. */
#define DEFAULT_CFG_FILE_NAME "config_dr.cfg"

/**
 * Operational parameter for the dynamic routing module.
 */
typedef struct {
    /**
     * Period of hello message when the routing table is stable.
     */
	uint32_t stableHelloPeriod;

    /**
     * Period of hello message when the routing table is unstable.
     */
	uint32_t unstableHelloPeriod;

    /**
     * Maximum number of routing entries.
     */
	uint16_t numRoutingEntries;

    /** 
     * The time interval after which, an entry is invalidated.
     */
	uint32_t entryTimeout;

    /**
     * Minimum time that a node needs to wait before it broadcasts
     * changes to its routing table.
     */
	uint32_t minUpdateWait;

    /** 
     * Maximum time that a node needs to wait before it broadcasts 
     * changes to its routing table.
     */
	uint32_t maxUpdateWait;
} DRConfig;

/**
 * Structure of a routing entry
 */
typedef struct {
    /**
     * Destination of the route.
     */
	uint8_t dest;

    /**
     * Number of hop to the above destination from the current node.
     */
	uint8_t numHops;

    /**
     * List of nodes on the route.
     */
	uint8_t *nodes;
} __attribute__ ((__packed__)) RoutingEntry;

typedef struct {
	//uint8_t count;
	uint32_t crc;
	//RoutingEntry entries[0];
	uint16_t vectorLen;	// length of the routing vector.
	uint8_t routingVectors[0];
	// routingVectors[0]: hop count
	// routingVectors[1] -> routingVectors[routingVectors[0]]: intermediate node
	// routingVectors[1 + routingVectors[1]] : dest
	// ... and so on.
} __attribute__ ((__packed__)) HelloPayload;

typedef struct {
	uint8_t from;
	//        uint8_t count;
	//        RoutingEntry entries[0];
	uint16_t vectorLen;	// length of the routing vector.
	uint8_t rtVector[0];
	// routingVectors[0]: hop count
	// routingVectors[1] -> routingVectors[routingVectors[0]]: intermediate node
	// routingVectors[1 + routingVectors[1]] : dest
} __attribute__ ((__packed__)) RoutingTable;

typedef struct {
    /** Packet type. */
	uint8_t pktType;
} __attribute__ ((__packed__)) ProtocolInfo;

typedef struct {
	//int dest;
	//int nextHop;
	//int hopCount;
	int numHops;
	uint8_t dest;
	uint8_t nextHop;
	uint8_t *relays;
	uint8_t tag;
	//guint timerId;
	//gboolean active;
} LocalRoutingEntry;

typedef struct {
	int neighbor;
	int count;
} ReceivedHelloRecord;

typedef struct {
	int neighbor;
	guint timerId;
	//uint64_t endTime;
	int numRecvHellos;
} NeighborTimeout;

#ifdef	__cplusplus
extern "C" {
#endif
	RoutingTable *allocRT(int maxNumEntries);
	//void allocLocalRT(void);
	//void initLocalRT(void);
	int main(int argc, char **argv);
	gboolean data_ready(GIOChannel * source, GIOCondition condition,
			    gpointer data);
	void signal_handler(int sig);
	void clean_up(void);
	gboolean load_config(const char *fileName);
	void initVariables();
	void dealloc_resources();
	//void *netSend(void * data);
	void *helloHandler(void *data);
	void initTimers();
	gboolean sendFirstHello(gpointer data);
	gboolean sendHello(gpointer data);
	int prepareSentRoutingTable(void *dest);
	void processOutgoingPacket(PduBuff * pbuf);
	void processIncomingPacket(PduBuff * pbuf);
	void processIncomingDataPacket(PduBuff * pbuf);
	void processHelloPacket(PduBuff * pbuf);
	gboolean processRemoteRoutingTable(RoutingTable * rt);
	gboolean alive_neighbor_timeout(gpointer data);
	void dispatchMessage(PduBuff * pbuf);
	int findNextHop(int dest);
	uint64_t nowMs(void);
	uint64_t timevalToMs(struct timeval *t);
	void printRoutingTable(void);
	int calcActualSize(PduBuff * buf);

	void log_config(void);

	gint neighborTimeoutCmp(gconstpointer a, gconstpointer b,
				gpointer userData);

#ifdef	__cplusplus
}
#endif
#endif				/* __SEALINX_DROUTE_H__ */
