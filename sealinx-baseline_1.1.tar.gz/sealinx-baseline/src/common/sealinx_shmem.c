/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author james, son
 */

#if defined(__linux__)
#include <linux/limits.h>
#elif defined(__APPLE__)
#include <limits.h>
#endif
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <stdio.h>
#include <memory.h>
#include <errno.h>
#include <stdlib.h>

#include "sealinx_shmem.h"
#include "sealinx_log.h"

/**
 * Generate IPC key for a module based on its full path and the id of the IPC method.
 * 
 * @param ipcId the id of the IPC method.
 * @return The IPC key if successful. Otherwise, generate_ipc_key() shall return (key_t)-1 and set errno to indicate the error.
 */
key_t generate_ipc_key(int ipcId)
{
	char *fullpath = (char *)malloc(PATH_MAX);
	int length = readlink("/proc/self/exe", fullpath, PATH_MAX);
	fullpath[length] = '\0';
	key_t retKey = ftok(fullpath, ipcId);
	if (retKey == (key_t) - 1) {
		fprintf(stderr, "%s: %s (%s) (%d)\n", __PRETTY_FUNCTION__,
			strerror(errno), fullpath, length);
	}
	free(fullpath);
	return retKey;
}

/**
 * Generate IPC key for a module based on its full path and the id of the IPC method.
 * 
 * @param ipcId the id of the IPC method.
 * @return The IPC key if successful. Otherwise, generate_ipc_key() shall return (key_t)-1 and set errno to indicate the error.
 */
key_t generate_key(int ipcId)
{
	char *fullpath = (char *)malloc(PATH_MAX);
	int length = readlink("/proc/self/exe", fullpath, PATH_MAX);

	int i;
	for (i = length; i >= 0; --i) {
		if (fullpath[i] == '/') {
			fullpath[i + 1] = '\0';
			break;
		}
	}
	key_t retKey = ftok(fullpath, ipcId);
	if (retKey == (key_t) - 1) {
		fprintf(stderr, "%s: %s (%s) (%d)\n", __PRETTY_FUNCTION__,
			strerror(errno), fullpath, length);
	}
	free(fullpath);

	return retKey;
}

#define NUM_SEMAPHORES 1

//----------------------------------------------------------
//Declare functinos of moduls
//---------------------------------------------------------
int initServerSemphore(int semid);
int getKeys(char *semPath, char *shmPath, int key, key_t * semKey,
	    key_t * shmKey);
int _initServerSharedData(key_t semkey, key_t shmkey, int sizeSharedMem,
			  SharedData * sd);
int _initClientSharedData(key_t semkey, key_t shmkey, int sizeSharedMem,
			  SharedData * sd);
int touch(char *filename);

/**
 *get key by some paramers
 *
 *@param semPath path of semphore
 *@param shmPath path of share memory
 *@param key of init value
 *@param semKey key of semphore
 *@param shmKey key of share memory
 */
int getKeys(char *semPath, char *shmPath, int key,
	    key_t * semKey, key_t * shmKey)
{
	*semKey = ftok(semPath, key);
	if (*semKey == -1) {
		logError("%s ftok() for sem failed: %d", __PRETTY_FUNCTION__,
			 strerror(errno));
		return 0;
	}
	*shmKey = ftok(shmPath, key);
	if (*shmKey == -1) {
		logError("%s ftok() for shm failed: %d", __PRETTY_FUNCTION__,
			 strerror(errno));
		return 0;
	}

	return 1;
}

/**
 *init server semphore
 *
 *@param semid id of semphore
 *@return 1 on success, otherwise 0
 */
int initServerSemphore(int semid)
{
	short sarray[NUM_SEMAPHORES];

	sarray[0] = 1;

	int rc = semctl(semid, 1, SETALL, sarray);
	if (rc == -1) {
		logError("%s semctl() failed %s", __PRETTY_FUNCTION__,
			 strerror(errno));
		return 0;
	}
	return 1;
}

/**
 *init server share data
 *
 *@param semKey key of share memory semphore
 *@param shmKey key of share memory
 *@param sizeShareMem size of share memory
 *@param sd pointer of share data
 *@return 1 on success, otherwise 0.
 */
int _initServerSharedData(key_t semkey, key_t shmkey,
			  int sizeSharedMem, SharedData * sd)
{
	/* Create a semaphore set using the IPC key.  The number of      */
	/* semaphores in the set is two.  If a semaphore set already     */
	/* exists for the key, return an error. The specified permissions */
	/* give everyone read/write access to the semaphore set.         */

	sd->semid = semget(semkey, NUM_SEMAPHORES, 0666 | IPC_CREAT | IPC_EXCL);
	if (sd->semid == -1) {
		logError("%s semget() failed: %s", __PRETTY_FUNCTION__,
			 strerror(errno));
		return 0;
	}

	/* Create a shared memory segment using the IPC key.  The        */
	/* size of the segment is a constant.  The specified permissions */
	/* give everyone read/write access to the shared memory segment. */
	/* If a shared memory segment already exists for this key,       */
	/* return an error.                                              */
	sd->shmid = shmget(shmkey, sizeSharedMem, 0666 | IPC_CREAT | IPC_EXCL);
	if (sd->shmid == -1) {
		logError("%s shmget() failed %s", __PRETTY_FUNCTION__,
			 strerror(errno));
		return 0;
	}

	/* Attach the shared memory segment to the server process.       */
	sd->data = (void *)shmat(sd->shmid, NULL, 0);
	if (sd->data == NULL) {
		logError("%s shmat() failed: %s", __PRETTY_FUNCTION__,
			 strerror(errno));
		return 0;
	}

	return 1;
}

/**
 *init client share data
 *
 *@param semKeyPath of path of share memory semphore
 *@param shmKeyPath of path of share memory
 *@param key of share memory
 *@param sizeShareMem size of share memory
 *@param sd pointer of share data
 *@return 1 on success, otherwise 0.
 */
int initClientSharedData(char *semKeyPath, char *shmKeyPath,
			 int key, int sizeSharedData, SharedData * sd)
{
	key_t semKeys, shmKeys;
	if (!getKeys(semKeyPath, shmKeyPath, key, &semKeys, &shmKeys)) {
		return 0;
	}

	return _initClientSharedData(semKeys, shmKeys, sizeSharedData, sd);
}

/**
 *assistance function for inition client share data
 *
 *@param semkey of key of share memory semphore
 *@param shmkey of key of share memory
 *@param sizeShareMem size of share memory
 *@param sd pointer of share data
 *@return 1 on success, otherwise 0.
 */
int _initClientSharedData(key_t semkey, key_t shmkey, int sizeSharedMem,
			  SharedData * sd)
{
	/* Create a semaphore set using the IPC key.  The number of      */
	/* semaphores in the set is two.  If a semaphore set already     */
	/* exists for the key, return an error. The specified permissions */
	/* give everyone read/write access to the semaphore set.         */

	sd->semid = semget(semkey, NUM_SEMAPHORES, 0666);
	if (sd->semid == -1) {
		logError("%s semget() failed: %s", __PRETTY_FUNCTION__,
			 strerror(errno));
		return 0;
	}

	/* Create a shared memory segment using the IPC key.  The        */
	/* size of the segment is a constant.  The specified permissions */
	/* give everyone read/write access to the shared memory segment. */
	/* If a shared memory segment already exists for this key,       */
	/* return an error.                                              */
	sd->shmid = shmget(shmkey, sizeSharedMem, 0666);
	if (sd->shmid == -1) {
		logError("%s shmget() failed %s", __PRETTY_FUNCTION__,
			 strerror(errno));
		return 0;
	}

	/* Attach the shared memory segment to the server process.       */
	sd->data = (void *)shmat(sd->shmid, NULL, 0);
	if (sd->data == NULL) {
		logError("%s shmat() failed: %s", __PRETTY_FUNCTION__,
			 strerror(errno));
		return 0;
	}

	return 1;
}

/**
 *open file of share var
 *
 *@param filename of will open file
 *@return 1 on success, otherwise 0
 */
int touch(char *filename)
{
	int fd = open(filename, O_CREAT,
		      S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
	if (fd == -1 && errno != EEXIST) {
		return 0;
	}
	if (fd > -1) {
		close(fd);
	}
	return 1;
}

/**
 *Init servere share data
 *
 *@param semKeyPath path of share semphore key
 *@param shmKeyPath path of share memory
 *@param key of share memory var
 *@param sizeSharedData size of share data
 *@param sd of share pointer
 */
int initServerSharedData(char *semKeyPath, char *shmKeyPath, int key,
			 int sizeSharedData, SharedData * sd)
{
	sd->shmKeyPath = NULL;
	sd->semKeyPath = NULL;
	if (!touch(semKeyPath)) {
		log_error("Create semaphore key file: %s", strerror(errno));
		return 0;
	}
	if (!touch(shmKeyPath)) {
		logError("Create shared memory key file: %s", strerror(errno));
		return 0;
	}

	log_info("semKeyPath = %s, shmKeyPath = %s", semKeyPath, shmKeyPath);

	key_t semKeys, shmKeys;
	if (!getKeys(semKeyPath, shmKeyPath, key, &semKeys, &shmKeys)) {
		return 0;
	}

	if (!_initServerSharedData(semKeys, shmKeys, sizeSharedData, sd)) {
		return 0;
	}

	if (!initServerSemphore(sd->semid)) {
		return 0;
	}

	sd->shmKeyPath = strdup(shmKeyPath);
	sd->semKeyPath = strdup(semKeyPath);

	return 1;
}

/**
 *Server release share date
 *
 *@param sd share data pointer
 *@retrun 1 on success, otherwise 0. 
 */
int releaseServerSharedData(SharedData * sd)
{
	int result = 1;
	struct shmid_ds shmid_struct;
	int rc;
	/* Clean up the environment by removing the semid structure,     */
	/* detaching the shared memory segment, and then performing      */
	/* the delete on the shared memory segment ID.                   */

	unlink(sd->semKeyPath);
	unlink(sd->shmKeyPath);
	free(sd->semKeyPath);
	free(sd->shmKeyPath);

	rc = semctl(sd->semid, 1, IPC_RMID);
	if (rc == -1) {
		log_error("Remove semid: %s", strerror(errno));
		result = 0;
	}
	rc = shmdt(sd->data);
	if (rc == -1) {
		log_error("Detach data: %s", strerror(errno));
		result = 0;
	}
	rc = shmctl(sd->shmid, IPC_RMID, &shmid_struct);
	if (rc == -1) {
		log_error("Remove shmid: %s", strerror(errno));
		result = 0;
	}
	return result;
}

/**
 *Client release share data
 *
 *@param sd share data pointer
 *@retrun 1 on success, otherwise 0. 
 */
int releaseClientSharedData(SharedData * sd)
{
	int rc, result = 1;
	/* Detach the shared memory segment from the current process.    */
	unlink(sd->semKeyPath);
	unlink(sd->shmKeyPath);
	free(sd->semKeyPath);
	free(sd->shmKeyPath);

	rc = shmdt(sd->data);
	if (rc == -1) {
		logError("Detach data: %s", strerror(errno));
		result = 0;
	}
	//free(sd);
	return result;
}

/**
 * Wait on a binary semaphore.  Block until the semaphore value is positive, then decrement it by 1.
 *
 *@param sd share data pointer
 *@return key value of share data
 */
int binSemaphoreWait(SharedData * sd)
{
	struct sembuf operations[1];
	/* Use the first (and only) semaphore.  */
	operations[0].sem_num = 0;
	/* Decrement by 1. */
	operations[0].sem_op = -1;
	/* Permit undoing. */
	operations[0].sem_flg = SEM_UNDO;
	return semop(sd->semid, operations, 1);
}

/**
 *Post to a binary semaphore: increment its value by 1. This returns immediately.
 *
 *@param sd share data pointer
 *@return key value of share data
 */
int binSemaphorePost(SharedData * sd)
{
	struct sembuf operations[1];
	/* Use the first (and only) semaphore.  */
	operations[0].sem_num = 0;
	/* Increment by 1. */
	operations[0].sem_op = 1;
	/* Permit undoing. */
	operations[0].sem_flg = SEM_UNDO;
	return semop(sd->semid, operations, 1);
}
