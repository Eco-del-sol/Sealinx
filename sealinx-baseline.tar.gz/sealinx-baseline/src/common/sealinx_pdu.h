/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author james, son
 */

#ifndef __SEALINX_PDU_H__
#define __SEALINX_PDU_H__

#include <stdint.h>

/****************************
 ** MAC header definitions.
 ****************************/

/** Broadcast address at the MAC layer. */
#define MAC_BROADCAST_ADDR 99

/** Maximum length of MAC header. */
#define MAX_HEADER_SIZE_MAC 100

/** Minimum length of MAC header. */
#define MIN_LENGTH_MAC_HEADER (4 * sizeof(uint8_t))

/** Length of MAC header with extra data included. */
#define MAC_HEADER_LENGTH(extraDataLen) \
    (MIN_LENGTH_MAC_HEADER + (extraDataLen))

/**
 * Header of the MAC layer.
 * When changed, update MIN_LENGTH_MAC_HEADER accordingly.
 */
typedef struct type_mac_hdr {
    /** Actual length of the whole header. */
	uint8_t hdr_len;
    /** MAC protocol ID. */
	uint8_t mac_type;
    /** Source MAC address. */
	uint8_t src_addr;
    /** Destination MAC address. */
	uint8_t dst_addr;
    /** Extra data to the MAC header. */
	char mac_data[MAX_HEADER_SIZE_MAC - MIN_LENGTH_MAC_HEADER];
} __attribute__ ((__packed__)) MacHeader;

/******************************
 ** Network header definitions.
 ******************************/

/** Broadcast address at the network layer. */
#define NET_BROADCAST_ADDR 99

/** Maximum length of network header. */
#define MAX_HEADER_SIZE_NET 100	/* increased for VBF    */

/** Minimum length of network header. */
#define MIN_LENGTH_NET_HEADER (5 * (sizeof(uint8_t)))

/** Length of NET header with extra data included. */
#define NET_HEADER_LENGTH(extraDataLen) \
    (MIN_LENGTH_NET_HEADER + (extraDataLen))

/**
 * Network header.
 * When changed, update MIN_LENGTH_NET_HEADER accordingly.
 */
typedef struct type_net_hdr {
    /** Length of the whole header */
	uint8_t hdr_len;
    /** Network protocol ID. */
	uint8_t net_type;
    /** Source network address. */
	uint8_t src_addr;
    /** Destination network address. */
	uint8_t dst_addr;
    /** Next hop of the packet. */
	uint8_t next_hop;
    /** Extra data to the network header */
	char net_data[MAX_HEADER_SIZE_NET - MIN_LENGTH_NET_HEADER];
} __attribute__ ((__packed__)) NetHeader;

/********************************
 ** Transport header definitions.
 ********************************/

/** Maximum length of transport header. */
#define MAX_HEADER_SIZE_TRA 20	/* same as TCP  */

/** Minimum length of transport header. */
#define MIN_LENGTH_TRANS_HEADER (3 * sizeof(uint8_t))

/** Length of MAC header with extra data included. */
#define TRANS_HEADER_LENGTH(extraDataLen) \
    (MIN_LENGTH_TRANS_HEADER + (extraDataLen))

/**
 * Header of transport layer.
 * When changed, update MIN_LENGTH_TRANS_HEADER accordingly.
 */
typedef struct type_tra_hdr {
    /** Actual length of the whole header. */
	uint8_t hdr_len;
    /** ID of transport layer protocols. */
	uint8_t tra_type;
    /** Types of transport layer services. */
	uint8_t service_type;
    /** Extra data to the transport layer. */
	char tra_data[MAX_HEADER_SIZE_TRA - MIN_LENGTH_TRANS_HEADER];
} __attribute__ ((__packed__)) TransportHeader;

//#define MAX_DATA_PAYLOAD_SIZE (4096)
#define MAX_DATA_PAYLOAD_SIZE (1024*12)
#define MAX_PHY_SIZE (512)
typedef struct pdu_buff {
	uint16_t msg_len;	/* Length of pkt_data */
	uint8_t	pkt_type;  /**Universal type**/
	MacHeader hdr_mac;
	NetHeader hdr_net;
	TransportHeader hdr_tra;
	char pkt_data[MAX_DATA_PAYLOAD_SIZE];

    /* The following fields will not be sent over the network
       Only useful for protocol stack handling */
    int bInternal;  /*1: internal*/
    int fromModule; /* (layer_id << 16 ) | module_id */
    int toModule;
	char phy[MAX_PHY_SIZE];  /* ModemInfo struct defined in modem_info.h */

	/* 总共的块数 */
    uint8_t blockNum;
    uint8_t txMode;
} PduBuff;

#define PDU_HEADER_SIZE (sizeof(uint16_t) + \
                         sizeof(MacHeader) + \
                         sizeof(NetHeader) + \
                         sizeof(TransportHeader) + \
                         2 * sizeof(int))

#define PDU_SIZE(dataSize) (PDU_HEADER_SIZE + (dataSize))

#ifdef	__cplusplus
extern "C" {
#endif

#ifdef	__cplusplus
}
#endif
#endif				/* __SEALINX_PDU_H__ */
