#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "Delimit.h"

/* Check if there is a delimiter from the list that matches the given buffer */
static Delimiter *checkMatch(Delimiter * dlmts, const char *buf, int len)
{
	Delimiter *iter;
	if (len <= 0)
		return NULL;
	list_for_each_entry(iter, &dlmts->node, node) {
		if (iter->n_bytes > len)
			continue;
		if (!memcmp(iter->bytes, buf, iter->n_bytes))
			break;
	}
	return (iter == dlmts) ? NULL : iter;
}

int Delimit_getNDelimiters(Delimiter * dlmts)
{
	ListHead *iter;
	int count = 0;
	list_for_each(iter, &dlmts->node)
	    count++;

	return count;
}

/*******************************************************
 * @description Adding new delimiter to the list of delimiters
 * 		which is sorted by delimiter length.
 * 		向链表中增加间隔符，间隔符从小到大排列
 * @param[in]   dlmts	list of delimiters (链表头节点)
 * @param[in]   buf	content of delimiter to be added (将要添加的间隔符)
 * @param[in]   len	length of content of delimiter to be added (将要添加的间隔符长度)
 * @param[out]  NULL
 * @return      pointer to added delimiter if succeeded, NULL if failed
 *****************************************************/
Delimiter *Delimit_addDelimiter(Delimiter * dlmts, const char *buf, int len)
{
	Delimiter *iter, *new;

	new = malloc(sizeof(*new) + len);
	if (!new)
		return NULL;
	memcpy(new->bytes, buf, len);
	new->n_bytes = len;

	list_for_each_entry(iter, &dlmts->node, node) {
		if (iter->n_bytes > new->n_bytes)
			break;
	}
	list_add_tail(&new->node, &iter->node);

	return new;
}

void Delimit_deleteAll(Delimiter * dlmts)
{
	Delimiter *iter, *iter_n;

	list_for_each_entry_safe(iter, iter_n, &dlmts->node, node)
	    free(iter);
}

int Delimit_searchFirst(Delimiter * dlmts, const char *buf, int len,
			Delimiter ** first)
{
	int i;
	for (i = 0; i < len - Delimit_minDelimiterLen(dlmts) + 1; i++) {
		*first = checkMatch(dlmts, &buf[i], len - i);
		if (*first)
			return i;
	}
	*first = NULL;
	return -1;
}
