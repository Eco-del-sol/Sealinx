/**
 * Copyright 2008-2019, by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @file    ipc_common.c
 * @brief   Parse sealinx pdu and modem ipc packet data.
 *
 * @author  XiongWen created on May/10/2018
 *          Modified by ZhangJing on May/15/2019
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <err.h>
#include <errno.h>
#include <signal.h>
#include <pthread.h>
#include <termios.h>
#include <sys/time.h>
#include <sys/shm.h>
#include <time.h>
#include <math.h>
#include <ctype.h>
#include <sealinx.h>
#include <sealinx_utils.h>
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>

#include "ipc_common.h"

/**
 * Debug print controlled by '-g' option
 */
void ipcCommon_printPdu(PduBuff *pdu, PrintType type)
{
    int i = 0;
    int len;
    ModemInfo *pPhyInfo;

    if (!pdu)
        return;

    pPhyInfo = (ModemInfo *)pdu->phy;

    if (type == FromCore)
        log_info("--------========>>>>Pdu(from core) info>>>>=======--------");
    else
        log_info("========--------<<<<pdu(from modem) info<<<<--------========");

    if ((pPhyInfo->type == Modem_Info_Tx) || (pPhyInfo->type == Modem_Info_Rx)) {
        /* Pdu length info */
        log_info("Msg_len   : %d", pdu->msg_len);
        /* Mac info */
        log_info("MacHeader : hdr_len %d, mac_type %d, src_addr %d, dst_addr %d, mac_data(%d):",
                pdu->hdr_mac.hdr_len, pdu->hdr_mac.mac_type, pdu->hdr_mac.src_addr,
                pdu->hdr_mac.dst_addr, pdu->hdr_mac.hdr_len - 4);
        len = pdu->hdr_mac.hdr_len - 4;
        if (len > 20)
            len = 20;
        if (len > 0) {
            printf("[");
            for (i=0; i<len; i++) {
                if (isprint(pdu->hdr_mac.mac_data[i]))
                    printf("%c", pdu->hdr_mac.mac_data[i]);
                else
                    printf("/%02x", pdu->hdr_mac.mac_data[i]);
            }
            printf("]\n");
        }

        /* Network info */
        log_info("NetHeader : hdr_len %d, net_type %d, src_addr %d, dst_addr %d, next_hop %d, net_data(%d):",
                pdu->hdr_net.hdr_len, pdu->hdr_net.net_type, pdu->hdr_net.src_addr,
                pdu->hdr_net.dst_addr, pdu->hdr_net.next_hop, pdu->hdr_net.hdr_len - 5);
        len = pdu->hdr_net.hdr_len - 5;
        if (len > 0) {
            printf("[");
            for (i=0; i<len; i++) {
                if (isprint(pdu->hdr_net.net_data[i]))
                    printf("%c", pdu->hdr_net.net_data[i]);
                else
                    printf("/%02x", pdu->hdr_net.net_data[i]);
            }
            printf("]\n");
        }

        /* Transport info */
        log_info("hdr_tra   : hdr_len %d, tra_type %d, service_type %d, tra_data(%d):",
                pdu->hdr_tra.hdr_len, pdu->hdr_tra.tra_type,
                pdu->hdr_tra.service_type, pdu->hdr_tra.hdr_len - 3);
        len = pdu->hdr_tra.hdr_len - 3;
        if (len > 0) {
            printf("[");
            for (i=0; i<len; i++) {
                if (isprint(pdu->hdr_tra.tra_data[i]))
                    printf("%c", pdu->hdr_tra.tra_data[i]);
                else
                    printf("/%02x", pdu->hdr_tra.tra_data[i]);
            }
            printf("]\n");
        }

        /* Pdu data info */
        log_info("pkt_data(%d):", pdu->msg_len);
        len = pdu->msg_len;
        if (len > 20)
            len = 20;
        if (len > 0) {
            printf("[");
            for (i=0; i<len; i++) {
                if (isprint(pdu->pkt_data[i]))
                    printf("%c", pdu->pkt_data[i]);
                else
                    printf("/%02x", pdu->pkt_data[i]);
            }
            printf("...]\n");
        }
    }

    /* Modem parameter */
    log_info("pkt_type %d", pPhyInfo->type);
    if (pPhyInfo->type == Modem_Info_Tx) {
        log_info("dst:%d, src:%d, mode:%d, type:%d, gtime:%d, power:%d",
                pPhyInfo->tx.phy_param.dst, pPhyInfo->tx.phy_param.src,
                pPhyInfo->tx.phy_param.mode, pPhyInfo->tx.phy_param.type,
                pPhyInfo->tx.phy_param.guard_time, pPhyInfo->tx.phy_param.power_level);
    } else if (pPhyInfo->type == Modem_Info_Rx) {
        log_info("mode:%d, esnr:%f, err:%d, sn:%d",
                pPhyInfo->rx.phy_param.mode, pPhyInfo->rx.effsnr,
                pPhyInfo->rx.err, pPhyInfo->rx.sn);
        log_info("src:%d, dst:%d, type:%d, gtime:%d, power:%d",
                pPhyInfo->rx.phy_param.src, pPhyInfo->rx.phy_param.dst,
                pPhyInfo->rx.phy_param.type, pPhyInfo->rx.phy_param.guard_time,
                pPhyInfo->rx.phy_param.power_level);
    } else if ((pPhyInfo->type == Modem_Config_Set) || (pPhyInfo->type == Modem_Config_Get)) {
        log_info("reg %s id:%d, field:%d, value:%d, err:%d",
                (pPhyInfo->type == Modem_Config_Set)?"write":"read",
                pPhyInfo->cfg.regId, pPhyInfo->cfg.field,
                pPhyInfo->cfg.value, pPhyInfo->cfg.err);
    } else if (pPhyInfo->type == Modem_Info_Tx_Done) {
        log_info("txdone sn:%d, err:%d", pPhyInfo->txDone.sn,
                pPhyInfo->txDone.err);
    }

    if (type == FromCore)
        log_info(">>>>print pdu end>>>>\n");
    else
        log_info("<<<<print pdu from modem end<<<<\n");

    return;
}

/**
 * Debug print controlled by '-g' option
 */
void ipcCommon_printAcio(char *acio, Modem_Phy_Params *phy, PrintType type)
{
    int i, len;
    uint16_t recv_frame_len = 0;
    PduBuff *pdu;
    pdu = (PduBuff *)acio;
    if (!acio)
        return;
    /* msg_len(uint16) + MacHeader + '|' + NetHeader + '|' + TransHeader + '|' +
       packetData */

    /* Frame length */
    if (type == FromModem)
        log_info("========--------<<<<Phy(from modem) info<<<<--------========");
    else
        log_info("--------========>>>>Modem data(from pdu of core) info>>>>=======--------");

    memcpy(&recv_frame_len, acio, sizeof(recv_frame_len));
    log_info("msg_len   : %d", recv_frame_len);
    acio += sizeof(uint16_t);

    /* Mac Header */
    if (*acio != '|') {
        MacHeader *pHdrMac = (MacHeader *)acio;
        log_info("MacHeader : hdr_len %d, mac_type %d, src_addr %d, dst_addr %d, mac_data(%d):",
                pHdrMac->hdr_len, pHdrMac->mac_type, pHdrMac->src_addr,
                pHdrMac->dst_addr, pHdrMac->hdr_len - 4);
        len = pHdrMac->hdr_len - 4;
        if (len > 0) {
            printf("[");
            for (i=0; i<len; i++) {
                if (isprint(pHdrMac->mac_data[i]))
                    printf("%c", pHdrMac->mac_data[i]);
                else
                    printf("/%02x", pHdrMac->mac_data[i]);
            }
            printf("]\n");
        }
        acio += pHdrMac->hdr_len;
    }
    acio++;  /* Jump over the '|' between MAC and NET headers */

    /* Net Header */
    if (*acio != '|') {
        NetHeader *pHdrNet = (NetHeader *)acio;
        log_info("NetHeader : hdr_len %d, net_type %d, src_addr %d, dst_addr %d, next_hop %d, net_data(%d):",
                pHdrNet->hdr_len, pHdrNet->net_type, pHdrNet->src_addr,
                pHdrNet->dst_addr, pHdrNet->next_hop, pHdrNet->hdr_len - 5);
        len = pHdrNet->hdr_len - 5;
        if (len > 0) {
            printf("[");
            for (i=0; i<len; i++) {
                if (isprint(pHdrNet->net_data[i]))
                    printf("%c", pHdrNet->net_data[i]);
                else
                    printf("/%02x", pHdrNet->net_data[i]);
            }
            printf("]\n");
        }
        acio += pHdrNet->hdr_len;
    }
    acio++;  /* Jump over the '|' between NET and TRA headers */

    /* Tra header */
    if (*acio != '|') {
        TransportHeader *pHdrTra = (TransportHeader *)acio;
        log_info("hdr_tra   : hdr_len %d, tra_type %d, service_type %d, tra_data(%d):",
                pHdrTra->hdr_len, pHdrTra->tra_type,
                pHdrTra->service_type, pHdrTra->hdr_len - 3);
        len = pHdrTra->hdr_len - 3;
        if (len > 0) {
            printf("[");
            for (i=0; i<len; i++) {
                if (isprint(pHdrTra->tra_data[i]))
                    printf("%c", pHdrTra->tra_data[i]);
                else
                    printf("/%02x", pHdrTra->tra_data[i]);
            }
            printf("]\n");
        }
        acio += pHdrTra->hdr_len;
    }
    acio++;  /* Jump over the '|' between TRA header and APP payload */

    /* Pkt data */
    log_info("pkt_data(%d):", recv_frame_len);
    if (recv_frame_len > 20)
        recv_frame_len = 20;
    if (0 < recv_frame_len) {
        printf("[");
        int i = 0;
        for (i=0; i<recv_frame_len; i++) {
            if (isprint(acio[i]))
                printf("%c", acio[i]);
            else
                printf("/%02x", acio[i]);
        }
        printf("...]\n");
    }

    /* Modem parameter */
    log_info("dst:%d, src:%d, mode:%d, type:%d, gtime:%d, power:%d",
            phy->dst, phy->src, phy->mode, phy->type, phy->guard_time, phy->power_level);

    if (type == FromModem)
        log_info("<<<<print modem data end<<<<\n");
    else
        log_info(">>>>print modem data from pdu end>>>>\n");

    return;
}

/**
 * Copy sealinx pdu data to modem acio
 */
int ipcCommon_pduToAcio(PduBuff *pdu, char *acio, int *len, Modem_Phy_Params *phy)
{
    int acioLen = 0;
    ModemInfo *pPhyInfo;

    if ((!acio) || (!pdu))
        return -1;

    /* payload_len + mac_data + '|' + net_data + '|' + tra_data + '|' + payload */

    /* Frame length, length of payload */
    //todo:adding length check
    memcpy(acio, &(pdu->msg_len), sizeof(pdu->msg_len));
    acio += sizeof(pdu->msg_len);
    acioLen += sizeof(pdu->msg_len);

    /* Mac header */
    memcpy(acio, &(pdu->hdr_mac), pdu->hdr_mac.hdr_len);
    acio += pdu->hdr_mac.hdr_len;
    acioLen += pdu->hdr_mac.hdr_len;

    /* Net header */
    *acio++ = '|';   /* Use '|'(0x7C > hdr_len) to seperate headers */
    acioLen++;
    memcpy(acio, &(pdu->hdr_net), pdu->hdr_net.hdr_len);
    acio += pdu->hdr_net.hdr_len;
    acioLen += pdu->hdr_net.hdr_len;

    /* Tra header */
    *acio++ = '|';    /* Use '|' to seperate headers */
    acioLen++;
    memcpy(acio, &(pdu->hdr_tra), pdu->hdr_tra.hdr_len);
    acio += pdu->hdr_tra.hdr_len;
    acioLen += pdu->hdr_tra.hdr_len;

    /* Payload */
    *acio++ = '|';    /* Use '|' to seperate headers and payload */
    acioLen++;
    memcpy(acio, &(pdu->pkt_data), pdu->msg_len);
    acio += pdu->msg_len;
    acioLen += pdu->msg_len;

    *len = acioLen;

    /* Modem parameter */
    pPhyInfo = (ModemInfo *)pdu->phy;
    pPhyInfo->type = Modem_Info_Tx;
    memcpy(phy, &pPhyInfo->tx.phy_param, sizeof(Modem_Phy_Params));

    return 0;
}

/**
 * Copy data from acio of modem to pdu of sealinx
 */
int ipcCommon_acioToPdu(char *acio, int len, Modem_Phy_Params *phy, float effsnr, PduBuff *pdu)
{
    uint16_t msg_len = 0;
    uint8_t header_len = 0;
    ModemInfo *pPhyInfo;

    /* Notes: the pkt_state of Pdubuff not used in physical layer. */
    /* payload_len + mac_data + '|' + net_data + '|' + tra_data + '|' + payload */

    if ((!acio) || (!pdu))
        return -1;

    memset(pdu, 0x00, sizeof(PduBuff));
    /* Frame length */
    memcpy(&msg_len, acio, sizeof(pdu->msg_len));
    acio += sizeof(pdu->msg_len);
    pdu->msg_len = msg_len;
    if (pdu->msg_len > MAX_DATA_PAYLOAD_SIZE)
        return -1;

    /* MAC header */
    if (*acio != '|') { /* If MAC header is not NULL */
        memcpy(&header_len, acio, sizeof(pdu->hdr_mac.hdr_len));
        if (header_len > MAX_HEADER_SIZE_MAC)
            return -1;
        memcpy(&(pdu->hdr_mac), acio, header_len);
        acio += header_len;
    }
    if (*acio != '|')
        return -1;
    acio++;   /* Jump over the '|' between MAC and NET headers */

    /* NET header */
    if (*acio != '|') { /* If NET header is not NULL */
        memcpy(&header_len, acio, sizeof(pdu->hdr_net.hdr_len));
        if (header_len > MAX_HEADER_SIZE_NET)
            return -1;
        memcpy(&(pdu->hdr_net), acio, header_len);
        acio += header_len;
    }
    if (*acio != '|')
        return -1;
    acio++;  /* Jump over the '|' between NET and TRA headers */

    /* TRA header */
    if (*acio != '|') { /* If TRA header is not NULL */
        memcpy(&header_len, acio, sizeof(pdu->hdr_tra.hdr_len));
        if (header_len > MAX_HEADER_SIZE_TRA)
            return -1;
        memcpy(&(pdu->hdr_tra), acio, header_len);
        acio += header_len;
    }
    if (*acio != '|')
        return -1;
    acio++;   /* Jump over the '|' between TRA header and APP payload */

    /* Frame data */
    if (pdu->msg_len !=
            (len - sizeof(pdu->msg_len) - pdu->hdr_mac.hdr_len -
            pdu->hdr_net.hdr_len - pdu->hdr_tra.hdr_len - 3))
        return -1;
    memcpy(&(pdu->pkt_data), acio, msg_len);

    /* Modem parameter */
    if (phy) {
        pPhyInfo = (ModemInfo *)pdu->phy;
        pPhyInfo->type = Modem_Info_Rx;
        pPhyInfo->rx.err = 0;
        pPhyInfo->rx.effsnr = effsnr;
        log_info("222222222PHY_eff_snr: %.3f", pPhyInfo->rx.effsnr);
        pPhyInfo->rx.sn = 0;
        memcpy(&pPhyInfo->rx.phy_param, phy, sizeof(Modem_Phy_Params));
    }

    return 0;
}
