#ifndef _AMC_H_
#define _AMC_H_
/**
 * Adaptive Modulation and coding
 */
#include "sealinx_system.h"

struct amc_metric {
	uint8_t esnr;
};

struct amc_mode {
	uint8_t txmode;
};

int amc_init();

void amc_set_self_mac_addr(uint8_t self);

int amc_feed_metric(uint8_t src, uint8_t dst, struct amc_metric *metric);
struct amc_metric *amc_get_metric(uint8_t src, uint8_t dst);

struct amc_mode *amc_get_mode(uint8_t src, uint8_t dst);

#endif
