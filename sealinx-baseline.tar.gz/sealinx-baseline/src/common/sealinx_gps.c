/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author james
 */

#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <errno.h>
#include <math.h>
#include <unistd.h>

#include "sealinx_log.h"

/**
 * Need the support of GPSD, i.e. GPSD has to be working correctly
 * To use, just include this file and call read_gps
 */

#include "sealinx_gps.h"

#define BUF_SIZE (1024*2)

///int errno;

/**
 * Obtain the latest GPS information, i.e. location, speed and time
 * Save into a buffer @buf which is @len bytes in length
 * Return -1 on errors
 *
 * GPS info format:
 * GPSD,P=41.716037 -72.201972,V=0.060,D=2010-06-18T04:34:04.00Z
 * P means location
 * V means ground speed (in knots)
 * D is the date
 * T is the time (Greenwich time)
 *
 * NOTE if a information is not available at this time '?' will be
 * returned, e.g. the following message would be possible:
 * GPSD,P=?,V=?,D=?
 */
int read_gps(char *buf, int len)
{
	char cmd[] = "pvd\n";
	char recv_buf[BUF_SIZE];
	struct sockaddr_in addr;
	struct hostent *hp;
	int fd;
	int recv_num = 0;
	/** go find out about the desired host machine */
	if ((hp = gethostbyname(HOST)) == 0) {
		logError("%s gethostbyname: %s", __PRETTY_FUNCTION__,
			 strerror(errno));
		return -1;
	}
	/** fill in the socket structure with host information */
	memset(&addr, 0, sizeof(addr));
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = ((struct in_addr *)(hp->h_addr))->s_addr;
	addr.sin_port = htons(PORT);
	/** grab an Internet domain socket */
	if ((fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		logError("%s socket: %s", __PRETTY_FUNCTION__, strerror(errno));
		return -1;
	}
	/** connect to PORT on HOST */
	if (connect(fd, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
		logError("%s connect: %s", __PRETTY_FUNCTION__,
			 strerror(errno));
		close(fd);
		return -1;
	}
	/** send a message to the server PORT on machine HOST */
	if (send(fd, cmd, strlen(cmd), 0) < 0) {
		logError("%s send: %s", __PRETTY_FUNCTION__, strerror(errno));
		close(fd);
		return -1;
	}
	/** wait for a message to come back from the server */
	memset(recv_buf, 0, sizeof(recv_buf));
	if ((recv_num = recv(fd, recv_buf, sizeof(recv_buf), 0)) < 0) {
		logError("%s recv: %s", __PRETTY_FUNCTION__, strerror(errno));
		close(fd);
		return -1;
	}
	/** check if the buffer is long enough */
	if (recv_num > len) {
		logError("%s buffer too small!", __PRETTY_FUNCTION__);
		close(fd);
		return -1;
	}
	/** copy the GPS info into the buffer */
	strcpy(buf, recv_buf);
	close(fd);
	return 0;
}

/**
 * Parse the GPS message received and store the
 * information into GPS_MSG structure
 * GPS message format:
 * $GPRMC,220516,A,5133.82,N,00042.24,W,173.8,231.8,130694,004.2,W
 */
int gps_parser(char *buf, int len, GPS_MSG * gps_msg)
{
	// TODO: to be done
	return 0;
}

/**
 * Set system clock
 * Note that this requires admin privilege
 * Return 0 on success or -1 otherwise
 */
int set_system_time(GPS_MSG * gps_msg)
{
	// TODO: to be done
	return 0;
}

/**
 *  Write received GPS message to a file
 * Return 0 on success or -1 otherwise
 */
int gps_write_cfg(GPS_MSG * gps_msg)
{
	// TODO: to be done
	return 0;
}

/**
 * Assume GPS receiver is connected to a serial port
 * we can read from it to get GPS information,
 * set system clock according to these information,
 * and save the GPS info to a file
 */
void gps_reader(void *param)
{
	// TODO: to be done
}

/**get the location information of this node in latitude and longitude*/
void getGPS_Location(Global_Location * gl, char *gps_info)
{
	char token;
	sscanf(gps_info, "GPSD, P=%c", &token);
	if (token != '?')
		sscanf(gps_info, "GPSD,P=%lf %lf,", &gl->lat, &gl->lon);
	/**printf("%f, %f\n", gl->lat, gl->lon); */
}

/**return the distance between these two points in meter*/
double getDistance(Global_Location * r1, Global_Location * r2)
{
	double lat1_rad, lon1_rad, lat2_rad, lon2_rad, delta_lat, delta_lon;

	double a, c, dist;
	lat1_rad = r1->lat * PI / 180;
	lon1_rad = r1->lon * PI / 180;
	lat2_rad = r2->lat * PI / 180;
	lon2_rad = r2->lon * PI / 180;
	delta_lat = lat1_rad - lat2_rad;
	delta_lon = lon1_rad - lon2_rad;

	a = sin(delta_lat / 2) * sin(delta_lat / 2)
	    +
	    cos(lat1_rad) * cos(lat2_rad) * sin(delta_lon / 2) * sin(delta_lon /
								     2);
	c = 2 * atan2(sqrt(a), sqrt(1 - a));
	dist = 6371004 * c;
	return dist;		/** in meters */
}
