#!/bin/sh

BIN=./bin

$BIN/sealinx-core -f 1 &
sleep 3
$BIN/sealinx-drivers -f 1 & 
sleep 2
$BIN/sealinx-bcmac -i 2 -f 1 -c config_bcmac.cfg &
sleep 2
$BIN/sealinx-sroute -i 3 -m 2 -f 1 -c config_net.cfg &
sleep 2
$BIN/sealinx-tra-tln -i 4 -n 3 -m 2 -f 1 -c config-tra-tln.cfg &
sleep 2
$BIN/sealinx-tx-poi-tln -i 5 -f 1 -m 2 -n 3 -t 4 -x 1 &
