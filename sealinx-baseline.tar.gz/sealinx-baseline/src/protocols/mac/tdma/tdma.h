#ifndef _TDMA_H
#define _TDMA_H

#include <stdio.h>
#include <sys/time.h>
#include <stdlib.h>
#include <sealinx.h>
#include <sealinx_timer.h>



typedef struct 
{
    struct timeval  txSlotLen;
    uint32_t txSlotTotal;
    uint32_t txSlotNum;
}tdmaParam;
typedef struct tdmaArg
{

    tdmaParam tdma;
    void *atTxSlotCallbackFunParam;
    void(*atTxSlotCallbackFun)(void);
}tdmaArg;


/**
 * @brief test use
 * 
 * @param arg 
 */
void printCurrentTime(void *arg);



/**
 * @brief 
 * 
 * @param txSlotLen 单个时隙的长度
 * @param txSlotTotal 一个周期的时隙数量（节点数量）
 * @param txSlotNum 发送数据的时隙
 * @param txSlotFun 发送数据的时隙调用的函数
 * @param txSlotFunParam 发送数据的时隙调用的函数的参数
 * @return int 
 */
int tdmaParamInit(uint32_t txSlotLen, uint32_t txSlotTotal, uint32_t txSlotNum, void (*txSlotFun)(void *), void *txSlotFunParam);


// /**
//  * @brief 根据传进来的参数开始tdma
//  * 
//  * @param Arg 经过tdmaParamInit赋值后的结构体
//  * @return int 
//  */
// int tdmaStart(tdmaArg *Arg);


/**
 * @brief strat tdma
 * 
 * @return int 
 */
int TDMA_BASELINE();


#endif /* _TDMA_H */
