/**
 * Copyright 2008-2019, by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @file    ipc_main.c
 * @brief   Transform between sealinx pdu and modem ipc.
 *
 * @author  XiongWen created on May/10/2018
 *          Modified by ZhangJing on May/15/2019
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <err.h>
#include <errno.h>
#include <signal.h>
#include <pthread.h>
#include <termios.h>
#include <sys/time.h>
#include <sys/shm.h>
#include <time.h>
#include <math.h>
#include <glib.h>
#include <ctype.h>
#include <sealinx.h>
#include <sealinx_utils.h>
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>

#include "ipc_common.h"
#include "ipc_main.h"
#include "modem.h"
#include "fifo.h"

//#define IPC_UNITTEST            /* Used in driver ipc unit test */

#define CONFIG_DEBUG_LEVEL 3    /* Must defined in using lib of modem! */
int G_DEBUG_LEVEL = CONFIG_DEBUG_LEVEL;

#define FILE_BUFSIZE (1024)     /* Reading configuration file */
#define IPC_DRIVER_ID 22        /* Sealinx modem id */
/** Verbosity level. */
#ifndef VERBOSE
#define VERBOSE (2)		/* For extended debug mode */
#endif
int g_verbose = 0;      /* Flag of debug print, 0, !0 or 2 */

/** Shared data by the core module. */
CoreSharedData *g_coreSharedData = NULL;

int g_myMid = -1;       /* Modem id: 1~255 */
int g_running = 0;      /* Flag of initialized */
int g_ipcInitFlag = 0;  /* Flag of ipc initialized */
int g_fifo = 0;         /* Fifo ptr of pdu header sent with modem */

/** File descriptor of the connection to the core. */
int g_connFd = -1;

char *g_logFolder = "logs/";
char *g_logId = "DRIVER_IPC";
int g_logFile = 1;  /* Flag of log save */

/** ID of the shared memory by the core module. */
int g_coreSharedMemId = 0;

/** Name of the config file. */
char *g_cfgFileName = "./config_driver_ipc.cfg";

/**
 * Communication succcessfull rate emulation.
 */
static int gs_emulation_a_id = 1;
static int gs_emulation_b_id = 2;
static int gs_emulation_rate = 100;
static int gs_modem_mode = 1;
static int gs_modem_guard_time = 150;
static PduHeader gs_lastPduFromCore;

/**
 * The mock success rate of modem transmission.
 */
static int success_rate(int src, int dst)
{
    GRand *randGen;
    int rate;

    if (src == -1 || dst == -1 ||
        gs_emulation_a_id == -1 || gs_emulation_b_id == -1)
        return -1;

    if ((src != gs_emulation_a_id && src != gs_emulation_b_id) ||
        (dst != gs_emulation_a_id && dst != gs_emulation_b_id))
        return -1;

    randGen = g_rand_new();
    rate = g_rand_int_range(randGen, 0, 100);
    log_info("rate %d, myMid %d, a_id %d, b_id %d, emulation_rate %d",
        rate, g_myMid, gs_emulation_a_id, gs_emulation_b_id, gs_emulation_rate);

    return rate & (rate < gs_emulation_rate);
}

/**
 * Print packet information received by modem.
 */
static int ipc_printModemPacket(char *payload, int len, Modem_Phy_Params *phy,
                                 int err, char *dbg)
{
    time_t timep;
    struct tm *p;
    char buf[4096];
    char temp[IpcMain_LogInfor_Len];
    int dbgLen = 0;
    int i = 0;
    int j = 0;

    memset(buf, 0x00, sizeof(buf));
    time(&timep);
    p = localtime(&timep);

    if ((3072 -1) <= strlen(dbg)){ /* 3072 is copied from Acio_RX_DBG_LEN of Acio.h */
        log_info("dbg_str len is too long");
        return -3;
    }

    dbgLen = sprintf(buf, "%d-%d-%d %d:%d:%d dbg len is %d, infor:\n%s\n",
            (1900 + p->tm_year), (1 + p->tm_mon), p->tm_mday,
            p->tm_hour, p->tm_min, p->tm_sec, strlen(dbg), dbg);

    dbgLen += strlen(dbg);
    memset(temp, 0x00, sizeof(temp));
    for (i=0; i<dbgLen; i++){
        temp[j] = buf[i];
        j++;
        if (j == (IpcMain_LogInfor_Len - 1)) {
            temp[j] = 0;
            j = 0;
            log_info("%s", temp);
            memset(temp, 0x00, sizeof(temp));
        }
    }

    if (0 < strlen(temp))
        log_info("%s", temp);

    return 0;
}

/**
 * Modem acio data to sealinx pdu
 */
int acioToPdu(char *acio, int len, Modem_Phy_Params *phy, float effsnr, PduBuff *pdu)
{
    int ret = 0;

    ret = ipcCommon_acioToPdu(acio, len, phy, effsnr, pdu);

    if (VERBOSE == g_verbose) {
        if (phy)
            ipcCommon_printAcio(acio, phy, FromModem);
        ipcCommon_printPdu(pdu, FromModem);
    }
    if (ret < 0) {
        log_error("Packet format from modem error!");
    }

    return ret;
}

/**
 * Send packet to up layer of sealinx
 */
static void deliver_pdu(PduBuff *buf)
{
    int ret;

#ifndef IPC_UNITTEST
    if (g_connFd != -1) {
        ret = client_send_up(g_connFd, buf, sizeof(PduBuff),
                    IPC_DRIVER_ID, NULL, 0);
        if (ret < 0)
            log_error("Deliver pdu to croe error!");
    }
#endif
}

#ifdef IPC_UNITTEST
void fill_pdu(PduBuff *pdu, char opt, int param1, int param2, int param3)
{
    ModemInfo *pPhyInfo = (ModemInfo *)pdu->phy;

    memset(pdu, 0, sizeof(PduBuff));
	pdu->msg_len = 0;	/* Payload size */
	pdu->hdr_mac.hdr_len = 4 + 5;
	pdu->hdr_mac.mac_type = 1;
	pdu->hdr_mac.src_addr = 2;
	pdu->hdr_mac.dst_addr = 3;
	memset(pdu->hdr_mac.mac_data, 'A', 5);

	pdu->hdr_net.hdr_len = 5 + 5;
	pdu->hdr_net.net_type = 4;
	pdu->hdr_net.src_addr = 3;
	pdu->hdr_net.dst_addr = 2;
	pdu->hdr_net.next_hop = 1;
	memset(pdu->hdr_net.net_data, 'B', 5);

	pdu->hdr_tra.hdr_len = 3 + 5;
	pdu->hdr_tra.tra_type = 1;
	pdu->hdr_tra.service_type = 2;
	memset(pdu->hdr_tra.tra_data, 'C', 5);

    if (opt == 'a') { /* send modem data */
        pdu->msg_len = param1;
        memset(pdu->pkt_data, 'U', pdu->msg_len);
        pPhyInfo->type = Modem_Info_Tx;
        pPhyInfo->tx.phy_param.dst = param3;
        pPhyInfo->tx.phy_param.guard_time = Modem_GuardTime_150;
        pPhyInfo->tx.phy_param.mode = param2;
        pPhyInfo->tx.phy_param.power_level = 100;
        pPhyInfo->tx.phy_param.src = 1; /* don't care */
        pPhyInfo->tx.phy_param.type = Modem_Type_DATA;
    } else if (opt == 'b') { /* write modem register */
        pPhyInfo->type = Modem_Config_Set;
        pPhyInfo->cfg.regId = param1;
        pPhyInfo->cfg.field = param2;
        pPhyInfo->cfg.value = param3;
        pPhyInfo->cfg.err = 0;
    } else if (opt == 'c') { /* read modem register */
        pPhyInfo->type = Modem_Config_Get;
        pPhyInfo->cfg.regId = param1;
        pPhyInfo->cfg.field = param2;
        pPhyInfo->cfg.value = 0;
        pPhyInfo->cfg.err = 0;
    } else if (opt == 'd') { /* distance measurement */
        pPhyInfo->type = Modem_Range;
        pPhyInfo->range.remoteId = 2;
    } else
        printf("pdu opt error!\n");
}
#endif /* IPC_UNITTEST */

/**
 * Get packet from up layer of sealinx
 */
static char buffer[IMSG_MAX_DATA_LENGTH];
static char acio_data[4096];
static PduBuff pduBuf;
static PduHeader pduHeader;
int ipc_readFromCore(void)
{
    InternalMessageHeader dataHeader;
    int sentError = 0;
    int nBytesRead;
    int len = 0, sn = -1, err, read_reg_value;

#ifndef IPC_UNITTEST
    /* get packet */
    nBytesRead = client_read(g_connFd, buffer, IMSG_MAX_DATA_LENGTH, &dataHeader, NULL, 0);

    if (-1 == nBytesRead) {
        log_error("Error reading from core: %s", strerror(errno));
        return -1;
    }

    if (0 == nBytesRead) {
        log_info("Core connection closed");
        return -1;
    }

    if (!from_upper_layer(dataHeader)) {
        log_error("Get data frorm core error!");
        return -1;
    }

    log_info("Core connection get data %d", nBytesRead);

    PduBuff *pbuf = (PduBuff *)buffer;
    ModemInfo *pPhyInfo = (ModemInfo *)pbuf->phy;
#else /* IPC_UNITTEST */
    PduBuff *pbuf = &pduBuf;
    ModemInfo *pPhyInfo = (ModemInfo *)pbuf->phy;
    printf("=====================Driver ipc unit test===========================\n");
    printf("==== Please input option number \t\t\t\t====\n");
    printf(">>>> [a]: Send data to modem, param is len, mode, dst and times ====\n");
    printf("     e.g. a 100 1 1 16\t\t\t\t\t\t====\n");
    printf(">>>> [b]: Write modem register, param is id, filed, value and 0 ====\n");
    printf("     e.g. b 31 1 1 0\t\t\t\t\t\t====\n");
    printf(">>>> [c]: Read modem register, param is id, filed, 0 and 0\t====\n");
    printf("     e.g. c 30 5 0 0\t\t\t\t\t\t====\n");
    printf(">>>> [d]: Distance measurement, param is dstId, 0, 0, and 0 \t====\n");
    printf("     e.g. d 2 0 0 0\t\t\t\t\t\t====\n");
    printf("====================================================================\n\n\n\n\n");
    char opt;
    int param1, param2, param3, param4;
    //todo: adding %s and parse input string
    scanf("%c%d%d%d%d", &opt, &param1, &param2, &param3, &param4);
    printf(">>>>> The input is %c, %d, %d, %d ====\n", opt, param1, param2, param3);
    if (opt < 'a' || opt > 'd' || param1 < 0 || param2 < 0 || param3 < 0)
        return 0;
RESEND:
    fill_pdu(pbuf, opt, param1, param2, param3);
#endif /* IPC_UNITTEST */

    Modem_Phy_Params phy = {0};
    if (Modem_Info_Tx == pPhyInfo->type) {
        /* send data */
        ipcCommon_pduToAcio(pbuf, acio_data, &len, &phy);
        if (VERBOSE == g_verbose) {
            ipcCommon_printPdu(pbuf, FromCore);
            ipcCommon_printAcio(acio_data, &phy, FromCore);
        }

        int err = modem_send(acio_data, len, &phy, &sn);
        memcpy(&pduHeader, pbuf, sizeof(PduHeader) - sizeof(int));
        if (err)
            log_error("Modem send error: %d", err);
        else {
            log_info("Modem send, times: %d", sn);
            pduHeader.sn = sn;
            if (fifo_writeable(g_fifo))
                fifo_write(g_fifo, (void *)&pduHeader);
            else {
                log_error("Packets continuous sent is too frequent!");
                PduHeader throw;
                fifo_read(g_fifo, (void *)&throw); /* throw the early packet */
                fifo_write(g_fifo, (void *)&pduHeader);
            }
        }
    } else if (Modem_Config_Set == pPhyInfo->type) {
        /* write register */
        err = modem_config(pPhyInfo->cfg.regId, pPhyInfo->cfg.field,
                    pPhyInfo->cfg.value);
        pPhyInfo->cfg.err = err;
        if (err)
            log_error("Register Status NOT available: %d.", err);
        else {
            log_info("Register write ok.");
        }
        /* internal packet, mac and net dest is src */
        /* return result to sealinx */
        //deliver_pdu(pbuf);    //Only for networking project/
    } else if (Modem_Config_Get == pPhyInfo->type) {
        /* read register */
        err = modem_status(pPhyInfo->cfg.regId, pPhyInfo->cfg.field,
                    &read_reg_value);
        pPhyInfo->cfg.value = read_reg_value;
        pPhyInfo->cfg.err = err;
        if (err)
            log_error("Register Status NOT available: %d.", err);
        else {
            log_info("Register read value: %d", pPhyInfo->cfg.value);
        }
        /* internal packet, mac and net dest is src */
        deliver_pdu(pbuf); /* return result to sealinx */
    } else if (Modem_Range == pPhyInfo->type) {
        pPhyInfo->range.distance = modem_range(pPhyInfo->range.remoteId,0);
        log_info("Distanse is: %.3f", pPhyInfo->range.distance);
        ProtocolInfo *pi = (ProtocolInfo *) pbuf->hdr_net.net_data;
        pi->pktType = 24;
        deliver_pdu(pbuf);
    } else {
        log_error("Unsupported modem phy type option: %d.", pPhyInfo->type);
    }

#ifdef IPC_UNITTEST
    param4--;
    if ((opt == 'a') && (param4 > 0))
        goto RESEND;
#endif
    return 0;
}

/**
 * Get packet from up layer of sealinx
 */
void *ipcThread_core(void *data)
{
    int ret = -1;

    while (g_running) {
        ret = ipc_readFromCore();
        if (ret) {
            log_error("ipcThread core thrad break!");
            break;
        }

        usleep(5*1000);
    }

    return NULL;
}

/**
 * Initialization.
 */
static int driver_init(void)
{
    int type = 0;

    /* Init logger. */
    if (!init_logger(g_logFolder, g_logId, g_logFile, TRUE, NULL, 0)) {
        fprintf(stderr, "Fail to init the log module.");
        return FALSE;
    }

#ifndef IPC_UNITTEST
    /* Init core. */
    RegistrationResponse serverResponse;
    g_connFd = client_connect(type, LAYER_PHYSICAL, NULL, &serverResponse, NULL, 0);
    if (g_connFd == -1) {
        return FALSE;
    }
    g_coreSharedMemId = serverResponse.coreShareMemId;
    log_info("Init: g_connFd %d, g_coreSharedMemId %d", g_connFd, g_coreSharedMemId);
    g_coreSharedData = (CoreSharedData *)shmat(g_coreSharedMemId, NULL, 0);
    if (g_coreSharedData == (CoreSharedData *) - 1) {
        log_error("Unable to attach the shared memory: %s",
              strerror(errno));
        return FALSE;
    }
#else /* IPC_UNITTEST */
    g_connFd = 0;
    g_coreSharedData = malloc(sizeof(g_coreSharedData));
    g_coreSharedData->macAddr = 1;
    g_coreSharedData->netAddr = 2;
#endif /* IPC_UNITTEST */

    logger_set_node_id(g_coreSharedData->macAddr, g_coreSharedData->netAddr);
    log_info("Mac address: %d, net address: %d",
         (int)g_coreSharedData->macAddr,
         (int)g_coreSharedData->netAddr);

    g_running = TRUE;

    return TRUE;
}

/**
 * Exit the program.
 */
static int driver_unit( )
{
    int type = 0;

#ifndef IPC_UNITTEST
    if (g_connFd > -1) {
        log_info("Close connection to core");
        client_close(type, g_connFd, NULL, 0);
        g_connFd = -1;
    }

    if (g_coreSharedData) {
        if (shmdt(g_coreSharedData) == -1) {
            log_error("Unable to detach shared data: %s",
                  strerror(errno));
        }
    }
#else /* IPC_UNITTEST */
    free(g_coreSharedData);
    g_connFd = -1;
#endif /* IPC_UNITTEST */

    close_logger();

    return 0;
}

/**
 * Exit the program.
 */
static void clean_up(void)
{
    g_running = FALSE;
    sleep(1);
    modem_stop();
    modem_close();
    driver_unit();
    fifo_delete(g_fifo);
}

/**
 * Exit the program.
 */
static void signal_handler(int sig)
{
    if (sig != SIGINT)
        return;

    g_running = FALSE;
    usleep(1000*100);
}

/**
 * Parse configuration of sealinx-driver-ipc -x
 */
static int parse_arguments(int argc, char **argv)
{
    int i = 0;

    while (i < argc) {
        char *t = argv[i];
        if (strcmp(t, "-c") == 0) {
            i++;
            if (i < argc) {
                g_cfgFileName = argv[i];
            }
        } else if (strcmp(t, "-g") == 0) {
            g_verbose = TRUE;
        } else if (strcmp(t, "-g2") == 0) {
            g_verbose = VERBOSE;
        } else if (strcmp(t, "-f") == 0) {
            i++;
            if (i < argc) {
                g_logFile = atoi(argv[i]);
                log_info("parse_arguments: change log file key %d", g_logFile);
            }
        }
        i++;
    }

    return TRUE;
}

/**
 * Read configuration file for driver-ipc
 *
 * @param confFileName Name of the config file.
 * @return TRUE if the operation succeeds; FALSE, otherwise.
 */
static int read_config(char *confFileName)
{
    char local_buff[FILE_BUFSIZE];
    char *token;

    gs_emulation_a_id = 1;
    gs_emulation_b_id = 2;
    gs_emulation_rate = 100;

#ifndef IPC_UNITTEST
    /* Open up modem configuration file */
    FILE *driver_cfg = fopen(confFileName, "r");
    if (!driver_cfg) {
        logInfo("Could not open config file: %s", strerror(errno));
        return FALSE;
    }
    memset(local_buff, 0, sizeof(local_buff));
    logInfo("Reading config file...");
    /* Reading the config file */
    while (fgets(local_buff, sizeof(local_buff), driver_cfg)) {
        token = strtok(local_buff, " :");
        if (*token == '#')
            continue;
        if (strstr(token, "EMULATION_NODE_A")) {
            token = strtok(NULL, " :");
            gs_emulation_a_id = atoi(token);
            logInfo("GS_EMULATION_A_ID: %d", gs_emulation_a_id);
            if (gs_emulation_a_id <= 0 || gs_emulation_a_id > 255) {
                logError("Emulation Node A Id is invalid");
                fclose(driver_cfg);
                return FALSE;
            }
            continue;
        } else if (strstr(token, "EMULATION_NODE_B")) {
            token = strtok(NULL, " :");
            gs_emulation_b_id = atoi(token);
            logInfo("GS_EMULATION_B_ID: %d", gs_emulation_b_id);
            if (gs_emulation_b_id <= 0 || gs_emulation_b_id > 255) {
                logError("Emulation Node B Id is invalid");
                fclose(driver_cfg);
                return FALSE;
            }
            continue;
        } else if (strstr(token, "EMULATION_RATE")) {
            token = strtok(NULL, " :");
            gs_emulation_rate = atoi(token);
            logInfo("GS_EMULATION_RATE: %d.", gs_emulation_rate);
            if (gs_emulation_rate < 0 || gs_emulation_rate > 100) {
                logError("Emulation rate is invalid");
                fclose(driver_cfg);
                return FALSE;
            }
            continue;
        } else if (strstr(token, "MODEM_MODE")) {
            token = strtok(NULL, " :");
            gs_modem_mode = atoi(token);
            logInfo("MODEM_MODE: %d.", gs_modem_mode);
            if (gs_modem_mode < 0 || gs_modem_mode > 100) {
                logError("Modem mode is invalid");
                fclose(driver_cfg);
                return FALSE;
            }
            continue;
        } else if (strstr(token, "MODEM_GUARD_TIME")) {
            token = strtok(NULL, " :");
            gs_modem_guard_time = atoi(token);
            logInfo("MODEM_GUARD_TIME: %d.", gs_modem_guard_time);
            if ((gs_modem_guard_time != 50 ) && (gs_modem_guard_time != 100)
                    && (gs_modem_guard_time != 150)) {
                logError("Modem guard time is invalid");
                fclose(driver_cfg);
                return FALSE;
            }
            continue;
        } else
            continue;
    }

    fclose(driver_cfg);
#endif /* IPC_UNITTEST */

    return TRUE;
}

#define LOG_BUF_LEN (4096 * 6)
char logBuf[LOG_BUF_LEN];
extern void LogWrite(void *data, int size);
#define LOG_W_LEN ((LOG_BUF_LEN - logLen) < 0 ? 0 : (LOG_BUF_LEN - logLen) )
/**
 * Callback of packet received of modem.
 *
 * @param(payload) payload of modem packet
 * @param(len) length of payload
 * @param(phy) param of dst/src/mode/type/guard_time/power of send
 * @param(err) error number of packet received: 0 normal, -1 trigger error, -2 block error
 * @param(dbg) string of debug information
 */
void rx(char *payload, int len, Modem_Phy_Params *phy,
                                int err, char *dbg)
{
    int i;
    int logLen;
    unsigned char *p;
    PduBuff pdu;
    float effsnr = 0;
    char *pSnr;

    log_info("ModemRecv: error %d, payload_size %d", err, len);
    if (g_verbose)
        ipc_printModemPacket(payload, len, phy, err, dbg);

    if ((len <= 0) || (!payload) || (err)) {
        /* packet of modem received error */
        return;
    }

    pSnr = strstr(dbg, "EFFSNR:");
    if (pSnr)
        effsnr = atof(pSnr + strlen("EFFSNR:"));
    log_info("effsnr: %f", effsnr);

    if (gs_emulation_rate != 100) {
        /* in debug */
        int successed = success_rate(phy->src, g_myMid);
        log_info("Success_rate ret %d, src %d, dst %d",
            successed, phy->src, g_myMid);
        if (successed) {
            if(!acioToPdu(payload, len, phy, effsnr, &pdu))
                deliver_pdu(&pdu);
        } else
            log_info("Emulated an unsuccessful communication from"
                    "modem %d to %d\n", phy->src, g_myMid);
    } else {
        if(!acioToPdu(payload, len, phy, effsnr, &pdu))
            deliver_pdu(&pdu);
    }

    /* Save log */
    /* e.g. the log info is
        CPSYNC:SRC:2,DST:0,TYPE:0,MODE:1,BLOCK:1,GUARDT:150
        preamble_start: 76776, fineTiming: 30784
        CPINFO:CHL,PSNR,CFO,DOP_SPD,N_CLUSTERS,CHL_DURATION
        CPINFO:1,18.0,0.1,0.0,1,2
        EFFSNR:17.1
        CPDECODETIME:0.1154s(MAX:0.1222s,AVE:-0.3725s)
        ZPINFO:CHL,PSNR,CFO
        ZPINFO:Blk:0/1,G,1,DT:0.0545s
        ZPINFO:1,14.6,0.0
        ZPINFO:DTPERBLK:MAX:0.0801s,AVE:-0.3725s
        RXWAVE:G
        TSTAMP:618.34668s
        INSNR:9.0,
        SIG/NOISE RMS:0.103588/0.011699,
        record_point: 43817, raw_prefix: G
        RXWAVE:G0000008.DAT(128727)
        RXSNR:17.065542
        RXMode:1
    */
    logLen = snprintf(logBuf, LOG_BUF_LEN, "\n** Received:\n");
    logLen += snprintf(logBuf + logLen, LOG_W_LEN,
            "\tError: %d\n", err);
    if (!err) {
        logLen += snprintf(logBuf + logLen, LOG_W_LEN,
                    "\tPayload: ");
        for (i=0, p=payload; i<len; i++, p++) {
            if (isprint(*p))
                logLen += snprintf(logBuf + logLen, LOG_W_LEN,
                        "%c", *p);
            else
                logLen += snprintf(logBuf + logLen, LOG_W_LEN,
                        "\\x%x%x", *p>>4, *p&0xF);
        }
        logLen += snprintf(logBuf + logLen, LOG_W_LEN, "\n");
    }
    logLen += snprintf(logBuf + logLen, LOG_W_LEN,
                "\n** Dbg:\n %s\n", dbg);

    LogWrite(logBuf, logLen);
}

/**
 * Callback function of transmitted.
 */
void txDone(int sn, int err, int len, char *dbg)
{
    int ret;
    PduBuff pdu;
    ModemInfo *pPhyInfo;
static PduHeader pduHeader = {0};
static int fifoFlag = 0;
    int whileFlag = 1;

    log_info("--------========>>>>Modem send done(times: %d)>>>>=======--------", sn);

    if (g_verbose)
        log_info("%s", dbg);

    if (fifoFlag && (sn < pduHeader.sn)) {
        log_error("The TxDone is too late!");
        return;
    } else if (fifoFlag && (sn == pduHeader.sn))
        ;   /* follow */
    else /* find the tx pdu header */
        do {
            if (fifo_readable(g_fifo)) {
                //todo: add fifo synchronization
                fifo_read(g_fifo, (void *)&pduHeader);
                fifoFlag = 1;
                if (sn == pduHeader.sn)
                    whileFlag = 0; /* found, exit */
                else if (sn > pduHeader.sn )
                    whileFlag = 1; /* throw the pdu header, continue */
                else { /* sn < pduHeader.sn */
                    log_error("This is early TxDone!");
                    return;
                }
            } else {
                log_error("The TxDone is not match with any tx!");
                return;
            }
        } while (whileFlag);

    log_info("Matched the sn: %d", pduHeader.sn);
    memset(&pdu, 0x00, sizeof(PduBuff));
    pdu.msg_len = 0;
    memcpy(&pdu.hdr_mac, &pduHeader.hdr_mac, sizeof(pdu.hdr_mac));
    memcpy(&pdu.hdr_net, &pduHeader.hdr_net, sizeof(pdu.hdr_net));
    memcpy(&pdu.hdr_tra, &pduHeader.hdr_tra, sizeof(pdu.hdr_tra));
    pdu.hdr_mac.dst_addr = pdu.hdr_mac.src_addr; /* internal packet, mac dest is src */
    pdu.hdr_net.dst_addr = pdu.hdr_net.src_addr; /* internal packet, net dest is src */

    pPhyInfo = (ModemInfo *)pdu.phy;
    pPhyInfo->type = Modem_Info_Tx_Done;

    pPhyInfo->txDone.err = err;
    /* sn is self-increase in modem tx AcommQueue */
    pPhyInfo->txDone.sn = sn;
    if (VERBOSE == g_verbose)
        ipcCommon_printPdu(&pdu, FromModem);

    deliver_pdu(&pdu);
}

/**
 * Callback function of ftp file received.
 */
void ftpRx(void *data, int size, char *fname)
{
    /* Not used now. */
}

/**
 * Callback function of modem.
 */
Modem_Ops ops = {
    .txDone = txDone,
    .txDbg = NULL,
    .rxcb = rx,
//    .usblcb = NULL,
    .rx_start_hook = NULL,
    .rx_stop_hook = NULL,
    .ftpRxDone = ftpRx
};

/**
 * Main function of sealinx-driver-ipc program.
 *
 * @param argc Number of arguments.
 * @param argv The arguments.
 * @retval EXIT_SUCCESS If the program exits normally.
 * @retval EXIT_FAILURE If an error occurs.
 */
int main(int argc, char **argv)
{
    pthread_t g_ipcCoreThread;

    atexit(clean_up);
    signal(SIGINT, signal_handler);

    if (!parse_arguments(argc, argv)) {
        return EXIT_FAILURE;
    }

    if (!read_config(g_cfgFileName)) {
        log_error("Failed to get the configurations!");
        return EXIT_FAILURE;
    }

    /* Initialise modem and register callback function. */
    if (modem_init(&ops)) {
        log_error("Failed to init modem!");
        return EXIT_FAILURE;
    }

    if (!driver_init()) {
        log_error("Ipc modem init error!");
        return EXIT_FAILURE;
    }

    log_info("Driver-modem %s %s: g_verbose %d", __DATE__, __TIME__, g_verbose);

    g_fifo = fifo_create(32, sizeof(PduHeader)); /* Cache 32 packet */
    modem_start(); /* Create modem recv thread. */

    /* Get modem config. */
    int err;
    err = modem_status(MODEM_MID, MODEM_Field_NONE, &g_myMid);
    if (err)
        log_error("Register Status NOT available: %d\n", err);
    else
        log_info("Mid register read: %d\n", g_myMid);

    log_info("gs_emulation_a_id = %d", gs_emulation_a_id);
    log_info("gs_emulation_b_id = %d", gs_emulation_b_id);
    log_info("gs_emulation_rate = %d", gs_emulation_rate);
    log_info("gs_modem_mode = %d", gs_modem_mode);
    log_info("gs_modem_guard_time = %d", gs_modem_guard_time);

    pthread_create(&g_ipcCoreThread, NULL, ipcThread_core, NULL);
    pthread_join(g_ipcCoreThread, NULL);
    modem_run();

    modem_stop();
    modem_close();
    fifo_delete(g_fifo);

    return 0;
}
