/*!
 * @file    modem.h
 * @brief   Operations of aquatic communicatory modem.
 */

#ifndef MODEM_H
#define MODEM_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    /** value -1 means using default value
       the struct has copied from Acomm_Params of acomm.h */
    int dst;   /**< 0~255, destination id of modem */
    int src;   /**< 1~255, source id of modem, valid only at receive */
    int mode;  /**< txmode, limited by enum Acomm_Mode, usually 1, 2, 11 */
    int type;  /**< txtype, limited by enum Acomm_Type, usually 0 */
    /** tx guard time between two data block, limited by struct Acomm_GuardTime,
       usually 150(ms)*/
    int guard_time;
    /** 0~100, tx power level between 1% and 100%, The maximum is equal to
       power value of register txpwr, 0 means 100% exceptive */
    int power_level;
    int fd;/* which freq to send */
    float timestamp;
} Modem_Phy_Params;

/** @brief Callback if packet has been sent successful.
 *
 *  Because the packet sending will taken a few seconds.
 *  The debug informations include time consumption and so on.
 *
 *  @param(sn) The serial number self-increased by modem after sent
 *  @param(err) 0 if succeeded otherwise failed
 *  @b(returns) NULL
 */
typedef void (*txDoneCallback)(int sn, int err);

/** @brief Callback if packet has been sent successful.
 *
 *  Because the packet sending will taken a few seconds.
 *  The debug informations include time consumption and so on.
 *
 *  @param(dbg_len) The length of debug informations
 *  @param(dbg) The packet send debug informations
 *  @b(returns) NULL
 */
typedef void (*txDbgCallback)(int dbg_len, char *dbg);


/** @brief Callback if get a packet from another modem.
 *
 *  The debug informations include noise-signal ratio, time consumption,
 *  error code and so on.
 *
 *  @param(payload) The packet data
 *  @param(len) The length of packet
 *  @param(phy) The parameters with packet received
 *  @param(err) 0 if succeeded otherwise failed
 *  @param(dbg) The packet receiving debug informations
 *  @b(returns) NULL
 */
typedef void (*rxCallback)(char *payload, int len, Modem_Phy_Params *phy,
                                int err, char *dbg);


typedef void (*usblRxCallback)(char *payload, int len, int err);


/** Hook function in modem start or stop */
typedef void (*Hook)(void);

/** Not used now */
typedef void (*ftpRxDoneCallback)(void *data, int size, char *fname);

typedef struct Modem_Ops {
    txDoneCallback txDone;
    txDbgCallback txDbg;
    rxCallback rxcb;
//    usblRxCallback usblcb;
    Hook rx_start_hook;
    Hook rx_stop_hook;
    ftpRxDoneCallback ftpRxDone;
} Modem_Ops;

/* =============================== MODEM API ================================ */
/** @brief Initialize the modem, and register callback function.
 *
 *  The function creating a file receiving thread and
 *  creating ./raw/'year'-'mon'-'day'_'hour'-'min'-'sec'/ directory.
 *  The directory is used as raw wave and log storage.
 *
 *  @param(ops) Struct of callback functions
 *  @b(returns) 0 if succeeded otherwise failed
 */
int modem_init(Modem_Ops *ops);

/** @brief Close the modem.
 *
 *  @b(returns) 0 if succeeded otherwise failed
 */
int modem_close(void);

/** @brief Send aquatic data.
 *
 *  The length is limited by mode of parameter.
 *
 *  @param(data) The sending data
 *  @param(len) The length of data
 *  @param(phy) The sending parameters
 *  @param(txSn) The serial number self-increased by modem after sent
 *  @b(returns) 0 if succeeded otherwise failed
 */
int modem_send(const void *data, int len, Modem_Phy_Params *phy, int *txSn);

/** @brief Start modem reception.
 *
 *  The function creating packet receiving thread.
 *
 *  @b(returns) 0 if succeeded otherwise failed
 */
int modem_start(void);

/** @brief Block running.
 *
 *  Running in the function until the modem be stoped.
 *  Exexute rx_start_hook callback in the function.
 *
 *  @b(returns) 0 if succeeded otherwise failed
 */
int modem_run(void);

/** @brief Stop the running of modem.
 *
 *  Exexute rx_stop_hook callback in the function.
 *
 *  @b(returns) 0 if succeeded otherwise failed
 */
int modem_stop(void);

/** @brief Get a parameter of modem.
 *
 *  The function will be blocking. It's usually very fast, max 12s.
 *
 *  @param(regId) The parameter id, limited by enum of Modem_Param_Id
 *  @param(field) The field of parameter ID, limited by enum of Modem_Param_Xxx_Id
 *  @param(data) The parameter value returned by modem
 *  @b(returns) 0 if succeeded otherwise failed
 */
int modem_status(int regId, int field, int *data);

/** @brief Set a parameter of modem.
 *
 *  The function will be blocking. It's usually very fast, max 12s.
 *
 *  @param(regId) The parameter id, limited by enum of Modem_Param_Id
 *  @param(field) The field of parameter ID, limited by enum of Modem_Param_Xxx_Id
 *  @param(data) The setting parameter value
 *  @b(returns) 0 if succeeded otherwise failed
 */
int modem_config(int regId, int field, int data);

/** @brief Distance measurement with another modem.
 *
 *  The function will be blocking, normally, it takes a few seconds, max 12s.
 *
 *  @param(remoteId) The ID of another modem
 *  @param(mode) The mode of communication(0 or 21)
 *  @b(returns) Positive number if succeeded, negative number failed
 */
int modem_range(int remoteId, int mode);

/** @brief Position measurement with another modem.
 *
 *  The function will be blocking, normally, it takes a few seconds.
 *
 *  @b(returns) Positive number if succeeded, negative number failed
 */
int modem_locate();

/**
 * @brief Get the modem src repos commit id as version messsage.
 * @param[out] versions The returns version message.
 * @param[out] len returned version message length.
 * @return 0 if succeeded otherwise -1;
*/
int modem_version(char *versions, int *len);

/*
* @param[in]  remoteId    the ID of dst modem
* @param[in]   mode        0->OFDM
* return value: 0 if succeeded otherwise failed
*              -METIME      fail,usbl timeout
*              -MEAGAIN     fail,Try again
*/
int modem_usbl(int remoteId, int mode);

/** @brief Transfer a file to the modem.
 *
 *  The function creating a file transfer thread and blocking
 *  until the transfer finished.
 *  Otherwise file receiving is saved in current directory automatically,
 *  file receiving only started by modem.
 *
 *  @param(data) The data of file will sending
 *  @param(size) The length of data
 *  @param(fname) The file name that saved in the modem.
 *  @b(returns) 0 if succeeded otherwise failed
 */
int modem_upload(void *data, int size, char *fname);

/** @brief Enter deepsleep mode.
 *
 *  @param(type) Reselved value
 *  @b(returns) Positive number if succeeded, negative number failed
 */
int modem_sleep(int type);

/**
 * @brief Get the modem SerialNo messsage.
 * @param[out] serialNo The returns serialNo message.
 * @param[out] len returned serialNo message length.
 * @return 0 if succeeded otherwise -1;
*/
int modem_GetSerialNo(char *serialNo, int *len);

/**
 * @brief Set the modem SerialNo messsage.
 * @param[in] serialNo The returns serialNo message.
 * @param[in] len returned serialNo message length.
 * @return 0 if succeeded otherwise -1;
*/

int modem_SetSerialNo(char *serialNo, int len);

/**
 * @brief modem performance testing.
 * @param(remoteId) The ID of another modem
 * @param(tsLoc) Performance test location
 * @param(tsType) Performance test type(0:rate, 1:ber)
 * @param(npkts) The number of packages send
 * @param(nblks) The number of block per packages (max 16)
 * @b(returns) 0 if succeeded otherwise failed
*/
int modem_pts(int remoteId, int loc, int type, int npkts, int nblks);
#ifdef __cplusplus
}
#endif

#endif /* MODEM_H */
