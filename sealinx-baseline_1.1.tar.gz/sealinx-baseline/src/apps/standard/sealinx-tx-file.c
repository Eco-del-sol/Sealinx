/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author haining
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/un.h>
#include <unistd.h>
#include <signal.h>
#include <sys/time.h>
#include <err.h>
#include <errno.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/time.h>
#include <fcntl.h>

#include <sealinx.h>
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>


/**
 * Default log identity for this module.
 */
#define DEFAULT_LOG_ID "TX_FILE"

/**
 * Default path to the folder consisting log files.
 */
#define DEFAULT_LOG_FOLDER "logs/"

#define DEFAULT_CONFIG_FILE "config_tx_file.cfg"

/** Log identity for this module. */
char * gLogId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char * gLogFolder = DEFAULT_LOG_FOLDER;

/** File descriptor of the connection to the core. */
int g_connFd;

/** ID of the current module. */
ModuleId g_moduleId;

/** ID of the MAC module. */
ModuleId g_macId;

/** ID of the network module. */
ModuleId g_netId;

/** ID of the transport module. */
ModuleId g_transId;

/**
 * Shared data by the core module.
 */
CoreSharedData *g_coreSharedData;

/*Read files to send*/
char * g_config_file=DEFAULT_CONFIG_FILE;

char g_terminator[32]="###@@@$$$%%%";

int g_coreSharedMemId;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 1;

#define MAX_BUF_SIZE 2048

typedef struct {
    int fileSize;
    short fileNameLength;
    char fileName[100];
} __attribute__((__packed__)) FileInfo;

unsigned short int g_local_addr=-1; 
unsigned short int g_remote_addr=-1;
int g_segment_size = 0;
int g_sending_interval = 1;
//extern const char *__progname;

#define TCP_HEADER_LENGTH (2 * sizeof(short int) + sizeof(sealinxTcpHeader))
#define FLAG_INIT_CONNECTION 4
#define FLAG_FREE_CONNECTION 8
#define FLAG_ENABLE_CLIENT 16

// Port number type
typedef short int PortNumber;

/*sealinx_tcp_header structure*/
typedef struct {
    PortNumber l_port;
    PortNumber r_port;
    u_char flag;
    u_char window;
    u_short seq_num;
    u_short ack_num;
    u_short rcv_bmp;
    //char md2[16];
} __attribute__((__packed__)) sealinxTcpHeader;


/**
 * Parse command line arguments.
 *
 * @param argc Number of arguments
 * @param argv The arguments
 * @return TRUE if the argument can be parse; FALSE, otherwise.
 */
int parse_arguments(int argc, char ** argv) {
    int i = 0;
    while (i < argc) {
	char * t = argv[i];
	if (strcmp(t, "-i") == 0) {
	    i ++;
	    if (i < argc)  {
		int moduleId = strtol(argv[i], NULL, 10);
		if (moduleId > MAX_MODULE_ID || moduleId < MIN_MODULE_ID) {
		    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
		    return FALSE;
		}
		g_moduleId = moduleId;
	    }
	} else if (strcmp(t, "-m") == 0) {
	    i ++;
	    if (i < argc)  {
		int macId = strtol(argv[i], NULL, 10);
		if (macId > MAX_MODULE_ID || macId < MIN_MODULE_ID) {
		    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
		    return FALSE;
		}
		g_macId = macId;
	    }
	} else if (strcmp(t, "-n") == 0) {
	    i ++;
	    if (i < argc)  {
		int netId = strtol(argv[i], NULL, 10);
		if (netId > MAX_MODULE_ID || netId < MIN_MODULE_ID) {
		    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
		    return FALSE;
		}
		g_netId = netId;
	    }
	} else if (strcmp(t, "-t") == 0) {
	    i ++;
	    if (i < argc)  {
		int transId = strtol(argv[i], NULL, 10);
		if (transId > MAX_MODULE_ID || transId < MIN_MODULE_ID) {
		    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
		    return FALSE;
		}
		g_transId = transId;
	    }
	} else if (strcmp(t, "-s") == 0) {
	    i ++;
	    if (i < argc)  {
		g_local_addr = strtol(argv[i], NULL, 10);
	    }
	} else if (strcmp(t, "-d") == 0) {
	    i ++;
	    if (i < argc)  {
		g_remote_addr= strtol(argv[i], NULL, 10);
	    }
	} else if (strcmp(t, "-l") == 0) {
	    i ++;
	    if (i < argc)  {
		g_segment_size = strtol(argv[i], NULL, 10);
	    }
	} else if (strcmp(t, "-f") == 0) {
	    i ++;
	    if (i < argc) {
		gLogFile = atoi(argv[i]);
	    }
	}
	i++;
    }

    return g_moduleId >= MIN_MODULE_ID && g_moduleId <= MAX_MODULE_ID && 
        g_macId >= MIN_MODULE_ID && g_macId <= MAX_MODULE_ID && 
        g_netId >= MIN_MODULE_ID && g_netId <= MAX_MODULE_ID && 
        g_transId >= MIN_MODULE_ID && g_transId <= MAX_MODULE_ID;
}

/**
 * Print the usage of the program.
 */
void print_usage(const char *progName) {
    printf("USAGE: %s "
           "-i <module id> -m <mac protocol id> -n <network protocol id> "
	   "-t <transport protocol id> "
	   "-l <data length> -r <data rate> -d <dest node> [-f <log file outoput flag>]\n", 
           progName);
}

/**
 * Calculate the actual size of data that is transmitted/received by this layer.
 * This size includes the size of headers of upper layers and the length of 
 * payload.
 *
 * @param pbuf The received/transmitted data.
 * @return The actual size.
 */
int calc_actual_size(PduBuff *pbuf) {
    return pbuf->msg_len + pbuf->hdr_tra.hdr_len;
}

/**
 * Initialize the program.
 */
int init(void) {
    int type = 0;
    ModuleId moduleIds[NUM_LAYERS];
    moduleIds[LAYER_MAC] = g_macId;
    moduleIds[LAYER_NETWORK] = g_netId;
    moduleIds[LAYER_TRANSPORT] = g_transId;
    moduleIds[LAYER_APPLICATION] = g_moduleId;

    if (!init_logger(gLogFolder, gLogId, gLogFile, TRUE, moduleIds, 4)) {
        fprintf(stderr, "Unable to init the log module.");
        return FALSE;
    }

    RegistrationResponse serverResponse;

    g_connFd = client_connect(type, LAYER_APPLICATION, moduleIds, &serverResponse, NULL, 0);

    g_coreSharedMemId = serverResponse.coreShareMemId;
    
    log_info("Key of shared memory by the core: %d", g_coreSharedMemId);
    
    g_coreSharedData = (CoreSharedData *) shmat(g_coreSharedMemId, NULL, 0);
    if (g_coreSharedData == (CoreSharedData *) -1) {
        fprintf(stderr, "Unable to attach the shared memory: %s", 
                strerror(errno));
        return FALSE;
    }

    logger_set_node_id(g_coreSharedData->macAddr, g_coreSharedData->netAddr);
    log_info("Mac address: %d, net address: %d", 
             (int) g_coreSharedData->macAddr, (int) g_coreSharedData->netAddr);
    return TRUE;
}


/**
 * Signal handler.
 *
 * @param sig Signal ID.
 */
void signal_handler(int sig) {
    int type = 0;
    log_info("Received signal (%d)", sig);

    if (g_connFd > -1) {
	client_close(type, g_connFd, NULL, 0);
        g_connFd = -1;
    }
}

/**
 * Clean up allocated resources.
 */
void clean_up(void) {
    int type = 0;
    log_info("Cleaning up ...");
    
    if (g_connFd > -1) {
	client_close(type, g_connFd, NULL, 0);
    }

    if (g_coreSharedData) {
	int rc = shmdt(g_coreSharedData);
	if (rc == -1) {
	    log_error("Unable to detach shared data: %s", strerror(errno));
	}
    }

    close_logger();
}

void initConnection() {
    PduBuff pbuf;
    pbuf.hdr_net.src_addr = g_local_addr;
    pbuf.hdr_net.dst_addr = g_remote_addr;
    //pbuf.pkt_type = PACKET_OUTGOING;
    pbuf.hdr_tra.hdr_len = TCP_HEADER_LENGTH;
    pbuf.hdr_tra.service_type = g_moduleId;
    sealinxTcpHeader *initAckHeader = (sealinxTcpHeader *) pbuf.hdr_tra.tra_data;
    initAckHeader->flag = FLAG_INIT_CONNECTION;
    client_send_down(g_connFd, &pbuf, sizeof(PduBuff), g_moduleId, NULL, 0);
}

void freeConnection() {
    PduBuff pbuf;
    pbuf.hdr_net.src_addr = g_local_addr;
    pbuf.hdr_net.dst_addr = g_remote_addr;
    //pbuf.pkt_type = PACKET_OUTGOING;
    pbuf.hdr_tra.hdr_len = TCP_HEADER_LENGTH;
    pbuf.hdr_tra.service_type = g_moduleId;
    sealinxTcpHeader *initAckHeader = (sealinxTcpHeader *) pbuf.hdr_tra.tra_data;
    initAckHeader->flag = FLAG_FREE_CONNECTION;
    client_send_down(g_connFd, &pbuf, sizeof(PduBuff), g_moduleId, NULL, 0);
}

int readWindowsize() {
    InternalMessageHeader dataHeader;
    PduBuff pbuf;
    int nBytesRead = client_read(g_connFd, &pbuf, IMSG_MAX_DATA_LENGTH, &dataHeader, NULL, 0);
    if (nBytesRead == -1) {
        log_error("System error occurred");
        return -1;
    }
        
    if (nBytesRead == -2) {
        log_warning("Data was not successfully received");
    }

    if (nBytesRead == 0) {
        logInfo("Connection closed by the core module");
        return -1;
    }
 
    if (from_lower_layer(dataHeader)) {
   	 sealinxTcpHeader *initAckHeader = (sealinxTcpHeader *) pbuf.hdr_tra.tra_data;
   	 if ((initAckHeader->flag & FLAG_ENABLE_CLIENT) == FLAG_ENABLE_CLIENT) {
      	   logInfo("Can send %d packets", initAckHeader->window);
      	   return initAckHeader->window;
  	 }
   	 logInfo("%s: packet type = %d", __PRETTY_FUNCTION__, initAckHeader->flag);
    }
    return 0;
}

void *tx_file_func(void *param) {
    char fileName[32];
    char buffer[IMSG_MAX_DATA_LENGTH];
    char g_send_buf[MAX_BUF_SIZE];
	
	int bytes_read=-1;
	FILE *fp=fopen(g_config_file,"r");
	if(fp==NULL){
		log_error("open config file failed");
		return NULL;
	}

	memset(fileName,0,sizeof(fileName));
	initConnection();
	int ws = readWindowsize();
	while(fgets(fileName,sizeof(fileName),fp)){
		logInfo("A new file %s needs to be sent out",fileName);
		fileName[strlen(fileName)-1]=0;
		int sendFD = open(fileName, O_CREAT | O_RDWR, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
		if (sendFD == -1) {
			logError("Failed to open sent file: %s", strerror(errno));
			return NULL;
		}	

		off_t file_length = lseek(sendFD, 0, SEEK_END);
		if (file_length == -1) {
			logError("Failed to get sent file length: %s", strerror(errno));
			close(sendFD);
			return NULL;
		}		
		
		lseek(sendFD, 0, SEEK_SET);
		
		FileInfo fInfo;
		fInfo.fileSize = file_length;
		char *startFileName = strrchr(fileName, '/');
		if (startFileName == NULL) {
			startFileName = fileName;
		}
		fInfo.fileNameLength = strlen(startFileName);
		memcpy(fInfo.fileName, startFileName, fInfo.fileNameLength);
		memset(fileName,0,sizeof(fileName));
		//initConnection();
		
		//int ws = readWindowsize();
		if (ws > -1) {
			ws --;
			
			PduBuff *pbuf = (PduBuff *) buffer;
			pbuf->hdr_tra.hdr_len = sizeof (struct type_tra_hdr) -sizeof (pbuf->hdr_tra.tra_data); //need double check
			memcpy(pbuf->pkt_data,&fInfo,sizeof(fInfo));
			pbuf->msg_len=sizeof(fInfo);
			pbuf->hdr_tra.service_type = g_moduleId;
			pbuf->hdr_net.src_addr = g_local_addr; //need double check
			pbuf->hdr_net.dst_addr = g_remote_addr; //need double check
			client_send_down(g_connFd, pbuf, sizeof(PduBuff), g_moduleId, NULL, 0);
			logInfo("File %s info sent out",fInfo.fileName);
			
			int nBytesRead = 0;
			while(file_length > nBytesRead && ws >= 0) {
				while (file_length > nBytesRead && ws > 0) {
					memset(g_send_buf,0,sizeof(g_send_buf));
					int nread = read(sendFD, g_send_buf, g_segment_size);                
					nBytesRead += nread;
					if (nread == 0) {
						logError("failed to read source file");
						break;
					}
					
					memset(pbuf,0,sizeof(PduBuff));
					pbuf->hdr_tra.hdr_len = sizeof (struct type_tra_hdr) -sizeof (pbuf->hdr_tra.tra_data); 
					memcpy(pbuf->pkt_data,g_send_buf,g_segment_size);
					pbuf->msg_len=nread;
					pbuf->hdr_tra.service_type = g_moduleId;
					pbuf->hdr_net.src_addr = g_local_addr; 
					pbuf->hdr_net.dst_addr = g_remote_addr; 
					client_send_down(g_connFd, pbuf, sizeof(PduBuff), g_moduleId, NULL, 0);
					logInfo("%d out of %d bytes of File %s sent out",nBytesRead,file_length,fInfo.fileName);
					
					sleep(g_sending_interval);
					ws --;
				}
				ws = readWindowsize();
				logInfo("Windowsize=%d",ws);
			}
		}		
		
		//freeConnection();
		close(sendFD); 
		logInfo("File %s sent out successfully",fInfo.fileName);
	}
	
	fclose(fp);
	
	//initConnection();
	//int ws = readWindowsize();
	logInfo("Windowsize=%d",ws);
	if(ws>-1){
		PduBuff *pbuf = (PduBuff *) buffer;
		memset(pbuf,0,sizeof(PduBuff));
		pbuf->hdr_tra.hdr_len = sizeof (struct type_tra_hdr) -sizeof (pbuf->hdr_tra.tra_data); 
		memcpy(pbuf->pkt_data,g_terminator,strlen(g_terminator));
		pbuf->msg_len=strlen(g_terminator);
		pbuf->hdr_tra.service_type = g_moduleId;
		pbuf->hdr_net.src_addr = g_local_addr; 
		pbuf->hdr_net.dst_addr = g_remote_addr; 
		client_send_down(g_connFd, pbuf, sizeof(PduBuff), g_moduleId, NULL, 0);	
		logInfo("File transfer completion signal %s sent out",pbuf->pkt_data);	
	}
	freeConnection();
	
    return NULL;
}

void cleanUp(void) {
    close(g_connFd);
    freeANLog();
}

int main(int argc, char** argv) {
    atexit(clean_up);
    signal(SIGINT, signal_handler);

    if (!parse_arguments(argc, argv) || g_local_addr==-1 || g_remote_addr==-1 || g_segment_size==0) {
	    print_usage(argv[0]);
	    return EXIT_FAILURE;
    }

    if (!init()) {
        return EXIT_FAILURE;
    }

    /* For signal handling */
    int sig;
    sigset_t termSig;
    sigemptyset(&termSig);
    sigaddset(&termSig, SIGINT);
    sigaddset(&termSig, SIGTERM);
    pthread_sigmask(SIG_BLOCK, &termSig, NULL);

    pthread_t thread_tx_file;
    if ((pthread_create(&thread_tx_file, NULL, tx_file_func, NULL)) != 0) {
        logError("create tx_file thread failed");
        return EXIT_FAILURE;
    }

    /* Wait for a termmination signal */
    if ((sigwait(&termSig, &sig)) != 0) {
        logError("sigwait failed");
    } else {
        logInfo("Termination signal received, exiting...");
    }
    
    pthread_cancel(thread_tx_file);

    pthread_sigmask(SIG_UNBLOCK, &termSig, NULL);
    pthread_join(thread_tx_file, NULL);
    
    return EXIT_SUCCESS;
}
