/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author yibo
 */

#ifndef __SEALINX_PKTQ_H__
#define __SEALINX_PKTQ_H__

#include "sealinx_pdu.h"

#define SFAMA_BUFFSIZE (1024*2)

typedef struct pdu_buff Packet;

struct pkt_elem {
	Packet *pkt;
	struct pkt_elem *next;
};

struct SentPktSet {
	int burst;
	unsigned long txtime;
	unsigned short slotnum;
	Packet *pkts[20];
};

#ifdef	__cplusplus
extern "C" {
#endif
	void pkt_queue_init(struct pkt_elem **head);

	/*insert a packet into the queue */
	void pkt_queue_insert_pkt(Packet * pkt, struct pkt_elem *head);
	
	/* Get the length of the queue */
	int pkt_queue_getLen (struct pkt_elem *head);

	/*delete the specified packet from the queue,
	   and free the packet if necessory outside this function */
	void pkt_queue_del_pkt(struct pkt_elem *head, Packet * pkt);

	/*get the first packet in the packet queue */
	Packet *pkt_queue_get_pkt(struct pkt_elem *head);
	void pkt_queue_deque(struct pkt_elem *head);
	
	/*get the addr of first packet in the packet queue */
	unsigned short pkt_queue_get_mac_recver_addr(struct pkt_elem *head);
	unsigned short pkt_queue_get_net_recver_addr(struct pkt_elem *head);
	
	/*free all packets in the queue */
	void pkt_queue_free(struct pkt_elem *head);

	int pkt_queue_empty(struct pkt_elem *head);

	void pkt_queue_get_pktburst(struct SentPktSet *pktset, int max_burst,
				    struct pkt_elem *head);
#ifdef	__cplusplus
}
#endif
#endif
