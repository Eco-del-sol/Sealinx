/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author yibo
 */
#include <stdio.h>
#include <string.h>
#include <sys/time.h>

#include "sealinx_trace.h"
long int base_time = 1302525700;
void pkt_trace(const char *cmd, char event, unsigned short node_addr,
		  char *layer,int pkt_id, unsigned short src_addr,
unsigned short dst_addr,char *packet_type, int pkt_size)
{
struct timeval cur_time;

	    // char trace_buf[500];
	    // gettimeofday(&cur_time, NULL);
	    // memset(trace_buf, 0, sizeof (trace_buf));
	    // cur_time.tv_sec -= base_time;
	    // sprintf(trace_buf,
	    //         "%c %ld.%06d %d %s --- %d %d %d %s %d",
	    //         event, /*r: receive, s: send*/
	    //         (long) cur_time.tv_sec, /*event time*/
	    //         (int) cur_time.tv_usec,
	    //         node_addr, /*address of node*/
	    //         layer, /*protocol layer*/
	    //         pkt_id, /*packet id*/
	    //         src_addr, /*source address of the packet*/
	    //         dst_addr, /*destination address of the packet*/
	    //         packet_type, /*packet type*/
	    //         pkt_size); /*packet size*/
	    // writeLog("%s", trace_buf);
gettimeofday(&cur_time, NULL);
cur_time.tv_sec -= base_time;
logInfo("%c %ld.%06d %d %s --- %d %d %d %s %d", event, /*r: receive, s: send */
		 (long)cur_time.tv_sec, /*event time */
		 (int)cur_time.tv_usec,node_addr, /*address of node */
		 layer, /*protocol layer */
		 pkt_id, /*packet id */
		 src_addr, /*source address of the packet */
		 dst_addr, /*destination address of the packet */
		 packet_type, /*packet type */
		 pkt_size);	/*packet size */
}
int getPktSize(struct pdu_buff *packet)
{
return packet->msg_len + packet->hdr_mac.hdr_len
	    +packet->hdr_net.hdr_len + packet->hdr_tra.hdr_len + sizeof(packet->msg_len);
}

unsigned short getPktSrc(struct pdu_buff *packet)
{
int src;
sscanf(packet->pkt_data, "[%d]", &src);
return (unsigned short)src;
} unsigned short getPktDst(struct pdu_buff *packet)
{
int dst;
sscanf(packet->pkt_data, "[%*d][%d]", &dst);
return (unsigned short)dst;
} unsigned short getPktID(struct pdu_buff *packet)
{
int id;
sscanf(packet->pkt_data, "[%*d][%*d][%d]", &id);
return (unsigned short)id;
} unsigned short getPktID_APP(char *buf)
{
int id;
sscanf(buf, "[%*d][%*d][%d]", &id);
return (unsigned short)id;
}
