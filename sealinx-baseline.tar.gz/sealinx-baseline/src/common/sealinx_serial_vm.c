/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author son
 */

#include <unistd.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <termios.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "sealinx_log.h"

#include "sealinx_serial_vm.h"

int internalModemSend(int sockfd, PacketHeader * header, char *data);

void advertise(int sockfd, int modemId, double x, double y, double z)
{
	PacketHeader header = { TYPE_INIT, modemId, sizeof(InitPacket) };
	InitPacket initPkt = { modemId, x, y, z };
	internalModemSend(sockfd, &header, (char *)&initPkt);
}

int internalModemSend(int sockfd, PacketHeader * header, char *data)
{
	int x = send(sockfd, header, sizeof(PacketHeader), 0);
	x += send(sockfd, data, header->len, 0);
	return x;
}

int _vm_serial_write(int sockfd, char *data, int dataLen)
{
	/*log_info("%s", __PRETTY_FUNCTION__); */
	PacketHeader header = { TYPE_DATA, /*modem_addr_local */ 0, dataLen };
	int x = internalModemSend(sockfd, &header, data);
	return x - sizeof(header);
}

int _vm_serial_read(int sockfd, char *data, int dataLen)
{
	/*log_info("%s", __PRETTY_FUNCTION__); */
	fd_set input;
	FD_ZERO(&input);
	FD_SET(sockfd, &input);
	int max_fd = sockfd + 1;
	struct timeval timeout;
	timeout.tv_sec = SERIAL_TIMEOUT;
	timeout.tv_usec = 0;
	int bytes_read = 0;
	bytes_read = select(max_fd, &input, NULL, NULL, &timeout);
	if (bytes_read == 0) {
		// Timeout
		return bytes_read;
	}
	if (bytes_read < 0) {
		fprintf(stderr, "Serial port read failed: %s\n",
			strerror(errno));
		return -1;
	}

	char *buffer = (char *)malloc(BUFFER_SIZE);
	PacketHeader header;
	char *x = data;
	int recvBytes = 0, totalBytes = 0;
	do {
		if (recv(sockfd, &header, sizeof(PacketHeader), 0) !=
		    sizeof(PacketHeader)) {
			return -1;
		}
		if (header.len > 0) {
			recvBytes = recv(sockfd, buffer, header.len, 0);
			if (recvBytes != header.len) {
				return -1;
			}
			memcpy(x, buffer, recvBytes);
			x += recvBytes;
			totalBytes += recvBytes;
		}
	} while (header.len > 0 && totalBytes < dataLen);

	free(buffer);
	data[totalBytes] = 0;
	return totalBytes;
}

int _vm_serial_open(char *svrAddr, int svrPort, int modemId, double x, double y,
		    double z)
{
	int sock;
	struct sockaddr_in server_addr;

	struct hostent *host = gethostbyname(svrAddr);

	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		perror("Failed to create socket");
		return -1;
	}

	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(svrPort);
	server_addr.sin_addr = *((struct in_addr *)host->h_addr);
	bzero(&(server_addr.sin_zero), 8);

	if (connect
	    (sock, (struct sockaddr *)&server_addr,
	     sizeof(struct sockaddr)) == -1) {
		perror("Failed to connect to server");
		return -1;
	}

	advertise(sock, modemId, x, y, z);
	return sock;
}

void _vm_serial_close(int sockfd)
{
	close(sockfd);
}
