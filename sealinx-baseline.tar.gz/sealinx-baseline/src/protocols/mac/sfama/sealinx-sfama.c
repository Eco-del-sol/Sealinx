/**
 * Copyright 2008~2016 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author yibo
 */

#include <sys/time.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <sys/un.h>
#include <err.h>
#include <sys/select.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <unistd.h>

#include <sealinx.h>
#include <sealinx_trace.h>
#include <amc.h>
#include <modem_info.h>

#include "sealinx-sfama.h"


#define DEFAULT_LOG_ID "SFAMA_MAC"
#define DEFAULT_LOG_FOLDER "logs/"
#define DEFAULT_PHY_TXMODE 1

/*add by yuansong 2018-5-4 for channel code speed macro, update 2018-5-8*/
#define CHANNEL_CODE_SPEED_1  1/*control pdu default code speed.*/
#define CHANNEL_CODE_SPEED_2  2
#define CHANNEL_CODE_SPEED_3  3
#define CHANNEL_CODE_SPEED_4  4
#define CHANNEL_CODE_SPEED_5  5
/*
	txmode is set by esnr vuale.
	1: esnr<4;
	2: 4=< esnr<6;
	3: 6=<esnr<8;
	4: 8=<esnr<11;
	5: 11=<esnr;
*/

ArpTable arpTable = NULL;

struct SentPktSet pktset;
int max_burst = 15;
struct timeval status_update_time;

int burst = 0;
int sfama_seqnum = 0;
int MAX_BACKOFF_SLOT_NUM = 0;
double max_tx_range = 1e3;
int band_width = 800;
double sound_speed = 1500;
unsigned short my_mac_addr = 0;

int baud_rate = 9600;		/*use 0 to denote there is no serial port used. in bps */
int max_queue_len = 0;
int queue_len = 0;
//time_t base_time = 0;
unsigned long slot_len;		/*in microsecond */
unsigned long guard_time;	/*in microsecond */
long SyncTxtime = 1500000;	/*in microsecond */
unsigned long tx_est_error = 0.25;

struct PktSeqSet sfama_seq_set;
unsigned short int data_sender_addr;

#define NAM_FILENAME  "sealinx-sfama.nam"
#define LOG_FILENAME "sealinx-sfama.log"
//char LOG_FILENAME[100];

/* Store the name of the program (i.e. argv[0]) */
const char *cmd_name;
extern const char *__progname;

int sfama_connection_fd;

sealinx_timer_t backoff_timer;
sealinx_timer_t delay_timer;
sealinx_timer_t wait_timer;
//------------draw slot line, added on 8/19/2012--------
sealinx_timer_t slotline_timer;

enum delay_timer_status sfama_status;

int sent_pkt = 0;
int recved_pkt = 0;
int overhead_bytes = 14;	//overhead introduced by the driver and stack

struct pkt_elem *sfama_queue_head;

fd_set write_fds;
int fdmax;

/** Log identity for this module. */
char *gLogId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char *gLogFolder = DEFAULT_LOG_FOLDER;

/** File descriptor of the connection to the core. */
int g_connFd;

/*add by yuansong for mutex access g_connFd 2018-6-9*/
pthread_mutex_t sf_mutex = PTHREAD_MUTEX_INITIALIZER;

/** ID of the current module. */
ModuleId g_moduleId;

/** Shared data by the core module. */
CoreSharedData *g_coreSharedData;

/** ID of the shared memory by the core module. */
int g_coreSharedMemId;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 1;

/*add by yuansong for retry transport times, 2018-8-6*/
#define MAX_RETRY_TIME 3

int retry_counter = 0;

/*add by yuansong for debug queue overflow 2018-8-29*/
pthread_mutex_t qlen_mutex = PTHREAD_MUTEX_INITIALIZER;

/*mutex operate queue_len, for multithread.2018-8-29*/
void operatequeue_len(int ctl)
{
    pthread_mutex_lock(&qlen_mutex);
	if (ctl)
        queue_len++;
	else
		queue_len--;
    pthread_mutex_unlock(&qlen_mutex);
}

#define SEALINX_MODUELID_APP 5
#define SEALINX_MODUELID_TRA 4
#define SEALINX_MODUELID_NET 3
#define SEALINX_MODUELID_MAC 2

#if 1
/******fellowing functions for printting PDU infomation******/
/*add by yuansong for debug function2018-5-23*/
int printMACHeaderInfo(MacHeader *pmach)
{
	unsigned short type   = 0;
	int            seq    = 0;
	unsigned short rslotn = 0;
	float        esnr   = 0;

	log_info("##MAC HEADER: hdr_len =%d##", pmach->hdr_len);
	log_info("##MAC HEADER: mac_type=%d##", pmach->mac_type);
	log_info("##MAC HEADER: src_addr=%d##", pmach->src_addr);
	log_info("##MAC HEADER: dst_addr=%d##", pmach->dst_addr);

	memcpy(&type, pmach->mac_data, sizeof(unsigned short));
	switch (type){
		case SEALINX_P_SFAMA_DATA:
			memcpy(&seq, pmach->mac_data+sizeof(type), sizeof(int));
			log_info("##MAC DATA type=SEALINX_P_SFAMA_DATA, seq=%d##", seq);
			break;
		case SEALINX_P_SFAMA_ACK:
	 	    log_info("##MAC DATA type=SEALINX_P_SFAMA_ACK");
			break;
		case SEALINX_P_SFAMA_RTS:
			memcpy(&rslotn, pmach->mac_data+sizeof(type), sizeof(unsigned short));
			log_info("##MAC DATA type=SEALINX_P_SFAMA_RTS, reserved slots=%d", rslotn);
			break;
		case SEALINX_P_SFAMA_CTS:
			memcpy(&rslotn, pmach->mac_data+sizeof(type), sizeof(unsigned short));
            //please modify
//			memcpy(&esnr, pmach->mac_data+sizeof(type)+sizeof(unsigned short), sizeof(uint8_t));
			log_info("##MAC DATA type=SEALINX_P_SFAMA_CTS, reserved slots=%d, esnr=%f", rslotn, esnr);
			break;
		default:
			log_info("##Recieved MAC DATA is error, type=%d##########",type);
	}
	log_info("#########End Printf MAC header Info#########");

	return 1;
}


/*add by yuansong for test need!!!2018-6-7*/
#define NET_PKT_DATA  90
#define NET_PKT_HELLO 99

int printNETHeaderInfo(NetHeader *pneth)
{
	uint8_t net_pkt_type = -1;

    /*buffer maxsize=MAX_HEADER_SIZE_NET - MIN_LENGTH_NET_HEADER = 100-5 =85*/
	log_info("---------Begin Printf NET header Info---------");
	log_info("--NET HEADER: hdr_len =%d--", pneth->hdr_len);
	log_info("--NET HEADER: net_type=%d--", pneth->net_type);
	log_info("--NET HEADER: src_addr=%d--", pneth->src_addr);
	log_info("--NET HEADER: dst_addr=%d--", pneth->dst_addr);
	log_info("--NET HEADER: next_hop=%d--", pneth->next_hop);

	memcpy(&net_pkt_type, pneth->net_data, sizeof(uint8_t));
	if (NET_PKT_DATA==net_pkt_type){
		log_info("--NET HEADER: net_data pkt type is NET_PKT_DATA--");
	}
	else if (NET_PKT_HELLO==net_pkt_type){
		log_info("--NET HEADER: net_data pkt type is NET_PKT_HELLO--");
	}
	else{
		log_info("--NET HEADER: net_data pkt type is ERROR******--");
	}

	log_info("---------End Printf NET header Info---------");

	return 1;
}


int printTRAHeaderInfo(TransportHeader *ptrah)
{
	int     ctrlID = 0;
	uint8_t txmode = 0;

    /*buffer maxsize=MAX_HEADER_SIZE_TRA - MIN_LENGTH_TRANS_HEADER = 20-3 =17*/
	log_info("********Begin Printf TRA header Info********");
	log_info("**TRA HEADER: hdr_len     =%d**", ptrah->hdr_len);
	log_info("**TRA HEADER: tra_type    =%d**", ptrah->tra_type);
	log_info("**TRA HEADER: service_type=%d**", ptrah->service_type);

	if (ptrah->hdr_len == sizeof(TransportHeader)-sizeof(ptrah->tra_data)+sizeof(int)+sizeof(uint8_t)){
		memcpy(&ctrlID, ptrah->tra_data, sizeof(int));
		memcpy(&txmode, ptrah->tra_data+sizeof(int), sizeof(uint8_t));
		log_info("TRA HEADER: tra_data, ctrlID=%d, txmode=%d",ctrlID, txmode);
	}
	log_info("********End Printf TRA header Info********");

	return 1;
}


int PrintfPDUbuff(char *array, int len)
{
	/*buffer size = MAX_DATA_PAYLOAD_SIZE =1200*/
	char buff[MAX_DATA_PAYLOAD_SIZE]={0};
	memcpy(buff, array, len);
	buff[len] = '\0';
	log_info("PDU pkt_data=%s", buff);
	return 1;
}

int PrintPDURemainPara(PduBuff *pdu)
{
//	log_info("PDU: pkt_type  =%d", pdu->pkt_type);
//	log_info("PDU: pkt_state =%d", pdu->pkt_state);
//	log_info("PDU: phy.esnr  =%f", pdu->phy.phy_recv.effsnr);
//	log_info("PDU: phy.txmode=%d", pdu->phy.phy_send.mode);
	return 1;
}

/*add by yuansong for debug function2018-5-23*/
#endif

/*add by yuanosng 2018-5*/

/*get route tabel and distance command macro, add by yuansong 2018-5-2*/

#define ERROR_CONTROL_MACRO    0x0
#define GET_DROUTE_TABLE_REQ   0x01
#define GET_DROUTE_TABLE_IND   0x02
#define GET_MODEN_DISTANCE_REQ 0x03
#define GET_MODEN_DISTANCE_IND 0x04

#define NET_PKT_DATA 90       /*add by yuansong 2018-5-21 for net packet.*/
#define BROADCAST_MAC_ADDR 99 /*add by yuansong 2018-5-21 for net packet.*/

/*I think a pkt need one slot, but it is not true ,it only about one slot*/
int MACGetControlMacro(TransportHeader *pth)
{
	int tmp = 0;

    /*it contains 3 bytes and buffer, if  > 3, then its buffer has  useful  data.*/
	if (pth->hdr_len > 3){
		memcpy(&tmp, pth->tra_data, sizeof(int));
		return tmp;
	}
	return ERROR_CONTROL_MACRO;/*return invalued macro value.*/
}

/*add list for distance record of modes*/
typedef struct _DistanceOfMode_t{
	uint8_t  macadrr;
	int      distance;
	struct   timeval LastTime;
	struct   _DistanceOfMode_t *pNext;
} DistanceOfMode_t;

DistanceOfMode_t *lstMD;

/*for MAC control designed, copy from Sealinx-droute.h*/
typedef struct {
    /** Packet type. */
	uint8_t pktType;
} __attribute__ ((__packed__)) ProtocolInfo;


struct timeval SendRtsTStamp;/*send RTS packet time stamp.*/

#define PROCESS_DELAY_TIME 2000 /*2ms for process delay.*/

/*add by yuansong 2018-6-2*/
void DelBroadData()
{
	int i;

	if (pktset.pkts[0]->hdr_mac.dst_addr != MAC_BROADCAST_ADDR){
		log_info("#####ERROR:This not broadcast data packet sequence in DelBroadData");
		return;
	}

	log_info("Del boardcast data packeta in DelBroadData,pktset.burst=%d, queue_len=%d", pktset.burst,queue_len);
	for (i=0; i<pktset.burst; i++){
		pkt_queue_del_pkt(sfama_queue_head, pktset.pkts[i]);
		free(pktset.pkts[i]);
		operatequeue_len(FALSE);
	}

	pktset.burst   = 0;
	pktset.txtime  = 0;
	pktset.slotnum = 0;
	memset(pktset.pkts, 0, sizeof(pktset.pkts));
	log_info("after del broadcast pkts, queue_len=%d, in DelBroadData", queue_len);
}


DistanceOfMode_t* FindDSRecord(int adrr)
{
	DistanceOfMode_t *p = NULL;

	p = lstMD;
	while (p != NULL){
		if (p->macadrr == adrr)
			return p;
		else
			p = p->pNext;
	}
	return p;
}


int AddRecordTolstMD(DistanceOfMode_t* precord)
{
	DistanceOfMode_t *ptr = NULL;

	if (NULL == lstMD){
		lstMD = precord;
		return 1;
	}

	ptr = lstMD;
	while (ptr->pNext != NULL)
		ptr = ptr->pNext;

	ptr->pNext = precord;
	return 1;
}

int ComputeProcessDelay();/*declare fucntion. add by yuansong 2018-5-31*/

int ProcessCTSForDistance(Packet *pkt)
{
	struct timeval   RecvCtsTStamp;
	DistanceOfMode_t *pdt = NULL;
	int              dt   = 0;
	int              dtl  = 0;

	memset(&RecvCtsTStamp, 0, sizeof(struct timeval));
	gettimeofday(&RecvCtsTStamp, NULL);

	if (pkt->hdr_mac.dst_addr != my_mac_addr){
		log_info("This is not my CTS pkt, destinate address = %d in ProcessCTSForDistance", pkt->hdr_mac.dst_addr);
		return -1;/*error beacuse not my addr*/
	}

	/*this is error CTS, perhapse it is delay CTS*/
	if (SendRtsTStamp.tv_sec*1000000+SendRtsTStamp.tv_usec == 0)	{
		log_info("Perhapse this is a latest CTS pkt, in ProcessCTSForDistance");
		return -1;
	}

	if ((RecvCtsTStamp.tv_sec*1000000+RecvCtsTStamp.tv_usec)-(SendRtsTStamp.tv_sec*1000000+SendRtsTStamp.tv_usec) >= slot_len*3)	{
	   /*CTS is losed, because if long time > 3 slot_len;*/
        log_info("It is a late CTS pkt,ProcessCTSForDistance", pkt->hdr_mac.dst_addr);
		SendRtsTStamp.tv_sec  = 0;
		SendRtsTStamp.tv_usec = 0;
		return 1;
	}

	/*compute distance of mode*/
	log_info("S_RTS time:tv_sec=%d, tv_usec=%d; R_CTS time:tv_sec=%d, tv_usec=%d",SendRtsTStamp.tv_sec, SendRtsTStamp.tv_usec,RecvCtsTStamp.tv_sec, RecvCtsTStamp.tv_usec);
	dt = (RecvCtsTStamp.tv_sec*1000000+RecvCtsTStamp.tv_usec)-(SendRtsTStamp.tv_sec*1000000+SendRtsTStamp.tv_usec)-ComputeProcessDelay();
	dtl= (RecvCtsTStamp.tv_sec*1000000+RecvCtsTStamp.tv_usec)-(SendRtsTStamp.tv_sec*1000000+SendRtsTStamp.tv_usec);
	// log_info("debug time type is, dt=%d, dtl=%ld, process time=%d", dt, dtl, ComputeProcessDelay());

	pdt = FindDSRecord(pkt->hdr_mac.src_addr);/*find mode record from lstMD.*/
	if (NULL == pdt){
		/*no record node in lstMD*/
		pdt = (DistanceOfMode_t*)malloc(sizeof(DistanceOfMode_t));
		if (NULL == pdt)
			return -1;/*error for malloc memory.*/

		memset(pdt, 0, sizeof(DistanceOfMode_t));
		pdt->macadrr          = pkt->hdr_mac.src_addr;
		pdt->distance         = dt*1500/1000000;
		pdt->LastTime.tv_sec  = RecvCtsTStamp.tv_sec;
		pdt->LastTime.tv_usec = RecvCtsTStamp.tv_usec;
		pdt->pNext            = NULL;
		AddRecordTolstMD(pdt);
		log_info("Add a node distance to list,macadrr=%d,distance=%d,in ProcessCTSForDistance", pdt->macadrr, pdt->distance);
	}
	else{
		pdt->distance         = dt*1500/1000000;
		pdt->LastTime.tv_sec  = RecvCtsTStamp.tv_sec;
		pdt->LastTime.tv_usec = RecvCtsTStamp.tv_usec;
		log_info("update a node distance,macadrr=%d,distance=%d,in ProcessCTSForDistance", pdt->macadrr, pdt->distance);
	}

	/*reset send RTS time stamp var*/
	SendRtsTStamp.tv_sec  = 0;
	SendRtsTStamp.tv_usec = 0;

	return 0;
}

int DealwithGetDistanceReq()
{
	PduBuff 	     pdu;
	int 		     ret    = 0;
	ProtocolInfo     pi;
	DistanceOfMode_t *pDM   = NULL;/*add 2018-5-27*/
	int              offset = 0;


	pi.pktType = NET_PKT_DATA;/*control info*/
	memset(&pdu, 0, sizeof(PduBuff));

	pdu.hdr_tra.hdr_len = sizeof(TransportHeader)-sizeof(pdu.hdr_tra.tra_data)+sizeof(int);
	int ctrl = GET_MODEN_DISTANCE_IND;
	memcpy(pdu.hdr_tra.tra_data, &ctrl, sizeof(int));
	pdu.hdr_tra.tra_type		 = g_moduleId + 2;/*test for unable to tra reason!!! 2018-5-25*/
	pdu.hdr_tra.service_type = g_moduleId + 3;
	pDM = lstMD;
	while (pDM != NULL){
		memcpy(pdu.pkt_data+offset, &(pDM->macadrr), sizeof(pDM->macadrr));
		offset += sizeof(pDM->macadrr);
		memcpy(pdu.pkt_data+offset, &(pDM->distance), sizeof(pDM->distance));
		offset += sizeof(pDM->distance);
		log_info("print node distance info: nid=%d, dis=%d in DealwithGetDistanceReq", pDM->macadrr, pDM->distance);
		pDM = pDM->pNext;
	}
	pdu.msg_len = offset;
	pdu.hdr_net.net_type = g_moduleId + 1;
	memcpy(pdu.hdr_net.net_data, &pi, sizeof(ProtocolInfo));
	pdu.hdr_net.hdr_len  = sizeof(NetHeader)-sizeof(pdu.hdr_net.net_data)+sizeof(ProtocolInfo);
	pdu.hdr_net.src_addr = g_coreSharedData->netAddr;
	pdu.hdr_net.dst_addr = g_coreSharedData->netAddr;
	pdu.hdr_net.next_hop = 0;

	pdu.hdr_mac.mac_type = g_moduleId;

	ret = client_send_up(g_connFd, &pdu, PDU_SIZE(pdu.msg_len), g_moduleId, NULL, 0);

	// log_info("Debug dump in DealwithGetDistanceReq #########1");

	return ret;
}

/*add by yuansong 2018-8-10 for hello*/
pthread_mutex_t sfama_queue_head_mutex = PTHREAD_MUTEX_INITIALIZER;
#define BURST_QUEUE_LEN 20

/*0:not in burst queue, 1: be in burst queue.*/
int HelloPktInBurstqueue(Packet * pkt)
{
    int i = 0;

	while (i < BURST_QUEUE_LEN){
		if (pktset.pkts[i] == pkt)
			return 1;
		i++;
	}
	return 0;
}

/*delete repeat hello packet, so we designe a new function. */
#define NET_PKT_HELLO 99
int pkt_queue_insert_hellopkt(Packet * pkt, struct pkt_elem *head)
{
	struct pkt_elem *pos  = head->next;
	struct pkt_elem *prev = head;
	ProtocolInfo    pt;

	memset(&pt, 0, sizeof(ProtocolInfo));
	Packet *tmp_pkt = (Packet *) malloc(sizeof(Packet));
	if (tmp_pkt == NULL)	{
		fprintf(stderr, "Memory allocation fails in pkt_queue_insert_hellopkt\n");
		exit(0);
	}
	memset(tmp_pkt, 0, sizeof(Packet));
	memcpy(tmp_pkt, pkt, sizeof(Packet));

	pthread_mutex_lock(&sfama_queue_head_mutex);

	struct pkt_elem *tmp = (struct pkt_elem *)malloc(sizeof(struct pkt_elem));
	if (tmp == NULL){
		fprintf(stderr, "Memory allocation fails in pkt_queue_insert_hellopkt\n");
		exit(0);
	}
	tmp->next = NULL;
	tmp->pkt  = tmp_pkt;
    while (pos != NULL){
		memcpy(&pt, pos->pkt->hdr_net.net_data, sizeof(ProtocolInfo));
		if (NET_PKT_HELLO==pt.pktType && !HelloPktInBurstqueue(pos->pkt)){
			// log_info("Replace old hello packet in pkt_queue_insert_hellopkt");
		    tmp->next  = pos->next;
			prev->next = tmp;
			// log_info("debug replace hello packet pointer=%d", pos->pkt);
			free(pos->pkt);
			free(pos);
			pthread_mutex_unlock(&sfama_queue_head_mutex);
			return 0;/*replace old hello*/
		}
		prev = pos;
		pos  = pos->next;
    }
	prev->next = tmp;
	pthread_mutex_unlock(&sfama_queue_head_mutex);
	return 1;/*insert hello*/
}

/*return -1:null, 99:broadcast addr, other: private addr.*/
int GetFirstPktDestAddr()
{
    Packet *pk = NULL;
	pthread_mutex_lock(&sfama_queue_head_mutex);
	pk = sfama_queue_head->next->pkt;

	if (NULL == pk)
	    return -1;
	else
	    return pk->hdr_mac.dst_addr;

	pthread_mutex_unlock(&sfama_queue_head_mutex);
}

void build_select_list(void)
{
	/* clear the FD sets */
	FD_ZERO(&write_fds);
	/* add the listening FDs to the read FD set */
	FD_SET(sfama_connection_fd, &write_fds);
	/* find the maximum listening FD */
	fdmax = sfama_connection_fd;
}

void slotline_timer_process(void *arg)
{
	slotline_timer.delay_time.tv_sec = slot_len / MillionMicroSecond;
	slotline_timer.delay_time.tv_usec = slot_len % MillionMicroSecond;
	if (!sealinx_timer_start(&slotline_timer)) {
		logError("Fail to restart slotline timer");
		return;
	}
	logInfo("----------------------------------------------------");
}

void *sfama_protocol()
{
	int result = sfama();
	if (result < 0)
		logError("The protocol detected error, stop here...");
	else
		logError
		    ("The protocol unexpectedly returned without reporting error, stop here...");
	return NULL;
}

int sfama()
{
	int recv_num = 0;
	PduBuff *pbuf;
	char recv_buf[IMSG_MAX_DATA_LENGTH];

	InternalMessageHeader dataHeader;
	while (1) {
		memset(recv_buf, 0, sizeof(recv_buf));
		/* read from the connection.  */
		// log_info("######debug for socket value, Now g_connFd = %d inf sfama function!!!!#######",g_connFd);
		recv_num =
		    client_read(g_connFd, recv_buf, IMSG_MAX_DATA_LENGTH,
				&dataHeader, NULL, 0);

		if (recv_num == -1) {
			logError("Connection error");
			exit(1);
		} else if (recv_num == -2) {
			log_warning("Data was not successfully received");
		} else if (recv_num == 0) {
			logInfo("Connection closed");
			break;
		}
		pbuf = (PduBuff *) recv_buf;
		if (from_upper_layer(dataHeader)) {
			/*add for get distance request function by yuanosng 2018-5-17*/
			if (GET_MODEN_DISTANCE_REQ == MACGetControlMacro(&(pbuf->hdr_tra))){
				log_info("SFAMA receive control msg ID=%d in sfama",MACGetControlMacro(&(pbuf->hdr_tra)));
				DealwithGetDistanceReq();
				// log_info("#Debug dump in sfama function@@@@@@@@@@@001");
			}

			/* Handle outgoing packets */
			// log_info("----------Begin print recieved data from NET in function sfama!----------");
			// printTRAHeaderInfo(&pbuf->hdr_tra);
			// printNETHeaderInfo(&pbuf->hdr_net);
			PrintfPDUbuff(pbuf->pkt_data,pbuf->msg_len);
			// log_info("----------End print recieved data from NET in function sfama!----------");
			uint8_t net_type;
			net_type = *(pbuf->hdr_net.net_data);
			sfama_tx_process(pbuf);
		} else if (from_lower_layer(dataHeader)) {

			/* Handle incoming packets */
			// printTRAHeaderInfo(&pbuf->hdr_tra);
			// printNETHeaderInfo(&pbuf->hdr_net);
			// printMACHeaderInfo(&pbuf->hdr_mac);
			PrintfPDUbuff(pbuf->pkt_data,pbuf->msg_len);
			sfama_recv_process(pbuf);
			recved_pkt++;
		} else {
			logError("Packet state error");
			continue;
		}
	}
	return EXIT_SUCCESS;
}

int main(int argc, char **argv)
{
	atexit(clean_up);
	signal(SIGINT, signal_handler);
	if (!parse_arguments(argc, argv)) {
		exit(EXIT_FAILURE);
	}
	if (!init_sfama()) {
		exit(EXIT_FAILURE);
	}
	logInfo("Starting Slotted FAMA");
	sfama_protocol();
	return EXIT_SUCCESS;
}

/*call this function in sealinx-mac*/
int init_sfama()
{
	int type = 0;
	queue_len = 0;
	pkt_queue_init(&sfama_queue_head);

	delay_timer.timer_status = SEALINX_TIMER_IDLE;
	backoff_timer.timer_status = SEALINX_TIMER_IDLE;
	wait_timer.timer_status = SEALINX_TIMER_IDLE;
	wait_timer.arg = malloc(sizeof(enum delay_timer_status));
	if (wait_timer.arg == NULL) {
		logError("Memory allocation fails");
		return FALSE;
	}
	set_sfama_status(IDLE);

	arpTable = readArpTable(ARP_FILE);

	struct timeval tmp_cur_time;
	gettimeofday(&tmp_cur_time, NULL);
	srandom(tmp_cur_time.tv_usec +
		(tmp_cur_time.tv_sec % 100) * MillionMicroSecond);
	init_slot_len();

	slotline_timer.timer_status = SEALINX_TIMER_IDLE;
	slotline_timer.timer_call_back = slotline_timer_process;
	slotline_timer.delay_time = get_interval_to_coming_slot();
	if (!sealinx_timer_start(&slotline_timer)) {
		logError("Fail to start slot line timer");
		return FALSE;
	}

	ModuleId moduleIds[NUM_LAYERS];
	moduleIds[LAYER_MAC] = g_moduleId;
	if (!init_logger(gLogFolder, gLogId, gLogFile, TRUE, moduleIds, 1)) {
		fprintf(stderr, "Unable to init the log module.");
		return FALSE;
	}

	RegistrationResponse serverResponse;

	g_connFd =
	    client_connect(type, LAYER_MAC, moduleIds, &serverResponse, NULL,
			   0);
	g_coreSharedMemId = serverResponse.coreShareMemId;

	log_info("Key of shared memory by the core: %d", g_coreSharedMemId);
	g_coreSharedData = (CoreSharedData *) shmat(g_coreSharedMemId, NULL, 0);
	if (g_coreSharedData == (CoreSharedData *) - 1) {
		fprintf(stderr, "Unable to attach the shared memory: %s",
			strerror(errno));
		return FALSE;
	}

	logger_set_node_id(g_coreSharedData->macAddr,
			   g_coreSharedData->netAddr);
	log_info("Mac address: %d, net address: %d",
		 (int)g_coreSharedData->macAddr,
		 (int)g_coreSharedData->netAddr);
	my_mac_addr = (int)g_coreSharedData->macAddr;
	amc_init();

	/*init for distance vars! add by yuansong 2018-5-17*/
	lstMD                 = NULL;
	SendRtsTStamp.tv_sec  = 0;
	SendRtsTStamp.tv_usec = 0;

	/*add by yuansong for debug 2018-6-7*/
	// log_info("Debug need print slot_len=%u", slot_len);

	return TRUE;
}

void release_sfama()
{
	pkt_queue_free(sfama_queue_head);
	close(sfama_connection_fd);
	free((enum delay_timer_status *)wait_timer.arg);
}

unsigned long gettxtimebylen(size_t len)
{
	return getfirstpkttxtime2(len);
}

unsigned long getfirstpkttxtime(size_t len)
{
	double txtime = 0;
	size_t len_bit = (len + overhead_bytes) * 8;
	int num_block;		//for OFDM modem
	switch (band_width) {
	case 140:
		txtime = len_bit * 0.0075 + 2.5391;
		break;
	case 300:
		txtime = len_bit * 0.0036 + 2.2261;
		break;
	case 600:
		txtime = len_bit * 0.0020 + 2.0261;
		break;
	case 800:
		txtime = len_bit * 0.0015 + 1.9615;
		break;
	case 2500:
		num_block = len_bit / 640;	//80B*8bit
		if (len_bit % 640 != 0)
			num_block++;
		txtime = 0.5 + num_block * 0.22 + 0.4;
		break;
	default:
		logError
		    ("The bit rate of modem is wrong. Should be 140, 300, 600, 800, 2500 bps");
		exit(1);
	}
	return (unsigned long)(tx_est_error + txtime * MillionMicroSecond);
}

unsigned long getfirstpkttxtime2(size_t len)
{
	double txtime = 0;
	size_t len_bit = (len + overhead_bytes) * 8;
	int num_block;		//for OFDM modem
	switch (band_width) {
	case 140:
		txtime = len_bit * 0.0075 + 2.5391;
		break;
	case 300:
		txtime = len_bit * 0.0036 + 2.2261;
		break;
	case 600:
		txtime = len_bit * 0.0020 + 2.0261;
		break;
	case 800:
		txtime = len_bit * 0.0015 + 1.9615;
		break;
	case 2500:
		txtime =
		    (len_bit + 7999) / 8000.0 * 0.9 + len_bit / 248.0 / 8.0 +
		    1.5;
		break;
	default:
		logError
		    ("The bit rate of modem is wrong. Should be 140, 300, 600, 800, 2500 bps");
		exit(1);
	}
	return (unsigned long)(tx_est_error + txtime * MillionMicroSecond);
}

unsigned long getnxtpkttxtime(size_t len)
{
	double txtime = 0;
	size_t len_bit = (len + overhead_bytes) * 8;
	int num_block;		//for OFDM modem
	switch (band_width) {
	case 140:
		txtime = len_bit * 0.0072 + 1.6650;
		break;
	case 300:
		txtime = len_bit * 0.0034 + 1.3350;
		break;
	case 600:
		txtime = len_bit * 0.0017 + 1.1511;
		break;
	case 800:
		txtime = len_bit * 0.0013 + 1.0870;
		break;
	case 2500:
		txtime =
		    (len_bit + 7999) / 8000.0 * 0.9 + len_bit / 248.0 / 8.0 +
		    1.5;
		//num_block = len_bit/640; //80B*8bit
		//if( len_bit%640 !=0 )
		//        num_block++;
		//txtime = 0.5+num_block*0.22 + 0.4;
		break;
	default:
		logError
		    ("The bit rate of modem is wrong. Should be 140, 300, 600, 800 or 2500 bps");
		exit(1);
	}
	return (unsigned long)(tx_est_error + txtime * MillionMicroSecond);
}

/*
unsigned short int getSlotNumbyTxtime(unsigned long Txtime)
{

        Txtime += (unsigned long)(max_tx_range/sound_speed*MillionMicroSecond + guard_time);
        unsigned long slot_num = Txtime/slot_len;

        if( Txtime%slot_len != 0 )
                slot_num++;

        //printf("Txtime is %ld, and is %ld slot\n", Txtime, slot_num);
        return (unsigned short int)slot_num;

}
*/

/*no broadcast in Slotted FAMA*/
void init_slot_len()
{
	/*cts tx time */
	slot_len = gettxtimebylen(sizeof(struct type_mac_hdr));
	slot_len +=
	    (unsigned long)(max_tx_range / sound_speed * MillionMicroSecond +
			    guard_time);
	/*add slot length, for prevent corrupt, by yuansong 201-6-13*/
	/*slot_len += 500*1000;*/ /*add 100ms*/
}

struct timeval get_interval_to_coming_slot()
{
	struct timeval cur_time, interval;
	unsigned long left_time = 0;	/*in millisecond */
	gettimeofday(&cur_time, NULL);
	left_time =
	    (cur_time.tv_sec % slot_len) * MillionMicroSecond +
	    cur_time.tv_usec;
	left_time %= slot_len;
	left_time = slot_len - left_time;
	interval.tv_sec = left_time / MillionMicroSecond;
	interval.tv_usec = left_time % MillionMicroSecond;

	return interval;
}


int ComputeProcessDelay()
{
	int bit_len = 0;

	int delay = 0;

	bit_len = sizeof(MacHeader)+sizeof(NetHeader)+sizeof(TransportHeader)+sizeof(uint16_t);

	delay = getfirstpkttxtime2(bit_len);

	return (4*delay);/*It ought to be 4 times wast time. not 2 times. modify by yuansong 2018-6-1*/
}

/*process the packet from upper layer*/
void sfama_tx_process(Packet * pkt)
{
	/*must be data packet */
	fill_data(pkt);
	logInfo("Get DATA Packet from Upper Layer");

	//namEnqueue(pkt->hdr_mac.src_addr, pkt->hdr_mac.dst_addr);
	if (queue_len >= max_queue_len) {
		//namDrop(pkt->hdr_mac.src_addr, pkt->hdr_mac.dst_addr);
		logDrop(PKT_DATA,
			pkt->hdr_mac.src_addr,
			pkt->hdr_mac.dst_addr,
			getPktSize(pkt), "Queue Overflow");
		return;
	}
	if (pkt_queue_empty(sfama_queue_head)
	    && !is_inround() && BACKOFF_FAIR != get_sfama_status()) {
		pkt_queue_insert_pkt(pkt, sfama_queue_head);
		/*queue_len++;*/
		operatequeue_len(TRUE);/*replace mutex operate*/

		init_handshake(get_interval_to_coming_slot());
	} else {
        /*add by yuansong for hello sepecial process!2018-8-11*/
		ProtocolInfo pt;
		int flag = 0;/*0:replace old;1:insert.*/
		memcpy(&pt, pkt->hdr_net.net_data, sizeof(ProtocolInfo));
		if (NET_PKT_HELLO == pt.pktType)	{
		    log_info("received a hello pk and insert it to queue!");
			flag = pkt_queue_insert_hellopkt(pkt,sfama_queue_head);
			if (flag)
				operatequeue_len(TRUE);
		}
		else
		{
			pkt_queue_insert_pkt(pkt, sfama_queue_head);
			/*queue_len++; */
		    operatequeue_len(TRUE);/*replaced by mutex oprate queue_len*/
		}
	}
	logInfo("Length of Packet Queue is %d in sfama_tx_process", queue_len);
}

/*process the packet from lower layer*/
void sfama_recv_process(Packet * pkt)
{
	//namReceive(pkt->hdr_mac.src_addr, pkt->hdr_mac.dst_addr, getPktSize(pkt));
	switch (pkt_get_pkttype(pkt)) {
	case SEALINX_P_SFAMA_RTS:
		logReceive(PKT_CONTROL,
			   pkt->hdr_mac.src_addr,
			   pkt->hdr_mac.dst_addr, getPktSize(pkt), "RTS");
		process_rts(pkt);
		break;
	case SEALINX_P_SFAMA_CTS:
		logReceive(PKT_CONTROL,
			   pkt->hdr_mac.src_addr,
			   pkt->hdr_mac.dst_addr, getPktSize(pkt), "CTS");
		process_cts(pkt);
		break;
	case SEALINX_P_SFAMA_ACK:
		logReceive(PKT_CONTROL,
			   pkt->hdr_mac.src_addr,
			   pkt->hdr_mac.dst_addr, getPktSize(pkt), "ACK");
		process_ack(pkt);
		break;
	case SEALINX_P_SFAMA_DATA:
		if (pkt->hdr_mac.dst_addr == my_mac_addr /*getPktDst(pkt) */ ) {
			logReceive(PKT_DATA,
				   pkt->hdr_mac.src_addr,
				   pkt->hdr_mac.dst_addr,
				   getPktSize(pkt), "DATA");
		}

		/*add for broadcast function  by yuansong 2018-5-7*/
		if (MAC_BROADCAST_ADDR == pkt->hdr_mac.dst_addr)
			client_send_up(g_connFd, pkt, sizeof(Packet), g_moduleId, NULL, 0);
		else
			process_data(pkt);

		break;
	default:
		logError("Received packet with unknown type", my_mac_addr);
	}
}

void pkt_set_seq(Packet * pkt, int seq)
{
	struct mac_data_subhdr *data_subhdr =
	    (struct mac_data_subhdr *)(pkt->hdr_mac.mac_data +
				       sizeof(struct mac_cmn_subhdr));
	data_subhdr->seq = seq;
}

int pkt_get_seq(Packet * pkt)
{
	struct mac_data_subhdr *data_subhdr =
	    (struct mac_data_subhdr *)(pkt->hdr_mac.mac_data +
				       sizeof(struct mac_cmn_subhdr));
	return data_subhdr->seq;
}

void pkt_set_slotnum(Packet * pkt, unsigned short slotnum)
{
	struct mac_ctrl_subhdr *ctrl_subhdr =
	    (struct mac_ctrl_subhdr *)(pkt->hdr_mac.mac_data +
				       sizeof(struct mac_cmn_subhdr));
	ctrl_subhdr->slotnum = slotnum;
}

unsigned short pkt_get_slotnum(Packet * pkt)
{
	struct mac_ctrl_subhdr *ctrl_subhdr =
	    (struct mac_ctrl_subhdr *)(pkt->hdr_mac.mac_data +
				       sizeof(struct mac_cmn_subhdr));
	return ctrl_subhdr->slotnum;
}

void pkt_set_pkttype(Packet * pkt, unsigned short mac_type)
{
	struct mac_cmn_subhdr *cmn_subhdr =
	    (struct mac_cmn_subhdr *)pkt->hdr_mac.mac_data;
	cmn_subhdr->mac_type = mac_type;
}

unsigned short pkt_get_pkttype(Packet * pkt)
{
	struct mac_cmn_subhdr *cmn_subhdr =
	    (struct mac_cmn_subhdr *)pkt->hdr_mac.mac_data;
	return cmn_subhdr->mac_type;
}

void getSlotNumofPktTrain()
{
	int i = 0;
	unsigned long pkt_interval = 100000;	//0.1 seconds between two packet
	pktset.txtime = 0;
	pktset.slotnum = 0;
	int pkt_size;

	pktset.txtime = getfirstpkttxtime(getPktSize(pktset.pkts[0]));
	;			//there are extra delay for the first packet
	i = 1;
	while (i < pktset.burst) {
		pkt_size = getPktSize(pktset.pkts[i]);

		pktset.txtime += getnxtpkttxtime(pkt_size);
		/*
		   (unsigned long)(pkt_size*MillionMicroSecond/(unsigned long)band_width*8
		   +SyncTxtime+1000000);
		   //+pkt_size*MillionMicroSecond/baud_rate*16);
		 */

		i++;
	}

	pktset.txtime += (pktset.burst - 1) * pkt_interval;
	pktset.txtime += max_tx_range / sound_speed * MillionMicroSecond;
	pktset.slotnum = 1 + pktset.txtime / slot_len;	//ceil the value

	if (pktset.slotnum * slot_len - pktset.txtime < 0.1)
		pktset.slotnum++;
	logInfo("estimated time:%d\t\treserved time:%d", pktset.txtime,
		pktset.slotnum * slot_len);
}

/*initialize a handshake to send out packet*/
void init_handshake(struct timeval delay_time)
{
	/*get the transmission time and translate it to number of slot */
	/*send rts packet "delay" tim */
	//Packet *data_pkt = pkt_queue_get_pkt(sfama_queue_head);

	pkt_queue_get_pktburst(&pktset, max_burst, sfama_queue_head);
	getSlotNumofPktTrain();	//record info in pktset

	Packet *rts_pkt = make_rts(pktset.slotnum);
//	logInfo("+++ function init_handshake pkt txmode is %d +++",
//		rts_pkt->phy.phy_send.mode);
	set_sfama_status(FOR_RTS);
	if (delay_time.tv_sec == 0 && delay_time.tv_usec == 0)
		delay_time.tv_usec = 500;

	if (delay_time.tv_sec >= 0 && delay_time.tv_usec >= 0) {
		//can not schedule events occuring in the past
		delay_timer.delay_time = delay_time;
		delay_timer.timer_call_back = delay_timer_process;
		delay_timer.arg = (void *)rts_pkt;
		if (!sealinx_timer_start(&delay_timer)) {
			logError("Fail to start timer");
			return;
		}
		logInfo("Node %d : will send RTS in %d seconds %d microseconds",
			my_mac_addr, delay_time.tv_sec, delay_time.tv_usec);
	}
}

void do_backoff(struct timeval delay_time, int for_fair)
{
	if (!for_fair) {
		set_sfama_status(BACKOFF);
	} else {
		set_sfama_status(BACKOFF_FAIR);
	}
	if (get_sealinx_timer_status(&backoff_timer) == SEALINX_TIMER_IDLE) {
		backoff_timer.delay_time = delay_time;
		backoff_timer.arg = NULL;
		backoff_timer.timer_call_back = backoff_timer_process;

		if (for_fair)
			logInfo
			    ("Node %d : Do backoff (for fairness) for %d seconds %d microseconds",
			     my_mac_addr, backoff_timer.delay_time.tv_sec,
			     backoff_timer.delay_time.tv_usec);
		else
			logInfo
			    ("Node %d : Keep silent to avoid collision for %d seconds %d microseconds",
			     my_mac_addr, backoff_timer.delay_time.tv_sec,
			     backoff_timer.delay_time.tv_usec);

		sealinx_timer_start(&backoff_timer);
	}
}

Packet *fill_cts(Packet * pkt, unsigned short recver_addr,
		 unsigned short resved_slot_num)
{
	struct amc_metric *mtc, *metric;
    ModemInfo *pPhyInfo;

    pPhyInfo = (ModemInfo *)pkt->phy;

	pkt->hdr_mac.hdr_len = sizeof(pkt->hdr_mac)
	    - sizeof(pkt->hdr_mac.mac_data)
	    + sizeof(struct mac_cmn_subhdr)
	    + sizeof(struct mac_ctrl_subhdr)
	    + sizeof(struct amc_metric);
	pkt->hdr_mac.mac_type = g_moduleId;
	pkt_set_pkttype(pkt, SEALINX_P_SFAMA_CTS);
	pkt->hdr_mac.src_addr = my_mac_addr;
	pkt->hdr_mac.dst_addr = recver_addr;
	pkt_set_slotnum(pkt, resved_slot_num);

	mtc = (struct amc_metric *)(pkt->hdr_mac.mac_data
				    + sizeof(struct mac_cmn_subhdr)
				    + sizeof(struct mac_ctrl_subhdr));
	metric = amc_get_metric(pkt->hdr_mac.dst_addr, pkt->hdr_mac.src_addr);
	if (!metric)
		return NULL;
	mtc->esnr = metric->esnr;
    pPhyInfo->type = Modem_Info_Tx;
    pPhyInfo->tx.phy_param.mode = DEFAULT_PHY_TXMODE;
	// *((unsigned short int*)(pkt->hdr_mac.mac_data)) = resved_slot_num;
	//pkt->pkt_type = PACKET_OUTGOING;
//	pkt->pkt_state = PKT_STATE_MAC;
	return pkt;
}

Packet *fill_rts(Packet * pkt, unsigned short recver_addr,
		 unsigned short int resved_slot_num)
{
    ModemInfo *pPhyInfo;

    pPhyInfo = (ModemInfo *)pkt->phy;

	pkt->msg_len = 0;
	pkt->hdr_mac.hdr_len = sizeof(pkt->hdr_mac)
	    - sizeof(pkt->hdr_mac.mac_data)
	    + sizeof(struct mac_cmn_subhdr)
	    + sizeof(struct mac_ctrl_subhdr);
	pkt->hdr_mac.mac_type = g_moduleId;
	pkt->hdr_mac.src_addr = my_mac_addr;
	pkt->hdr_mac.dst_addr = recver_addr;

	pkt_set_pkttype(pkt, SEALINX_P_SFAMA_RTS);
	pkt_set_slotnum(pkt, resved_slot_num);
    pPhyInfo->type = Modem_Info_Tx;
	pPhyInfo->tx.phy_param.mode = DEFAULT_PHY_TXMODE;
	// *((unsigned short int*)(pkt->hdr_mac.mac_data)) = resved_slot_num;
	//pkt->pkt_type = PACKET_OUTGOING;
//	pkt->pkt_state = PKT_STATE_MAC;
	return pkt;
}

Packet *fill_ack(Packet * pkt, unsigned short recver_addr)
{
	int i = 0;
    ModemInfo *pPhyInfo;

    pPhyInfo = (ModemInfo *)pkt->phy;

	pkt->hdr_mac.hdr_len =
	    sizeof(pkt->hdr_mac) - sizeof(pkt->hdr_mac.mac_data)
	    + sizeof(struct mac_cmn_subhdr);
	pkt->msg_len = 0;
	pkt->hdr_mac.mac_type = g_moduleId;
	pkt_set_pkttype(pkt, SEALINX_P_SFAMA_ACK);
	pkt->hdr_mac.src_addr = my_mac_addr;
	pkt->hdr_mac.dst_addr = recver_addr;
	//pkt->pkt_type = PACKET_OUTGOING;
//	pkt->pkt_state = PKT_STATE_MAC;

    pPhyInfo->type = Modem_Info_Tx;
	pPhyInfo->tx.phy_param.mode = DEFAULT_PHY_TXMODE;
	//add the seqence nums in payload part
	pkt->msg_len = sizeof(int) + sfama_seq_set.num * sizeof(int);
	char *walk = pkt->pkt_data;
	memcpy(walk, &(sfama_seq_set.num), sizeof(sfama_seq_set.num));
	/**(int *)walk = sfama_seq_set.num;*/ /*modify by yuansong 2018-6-8*/

	/*add by yuansong 2018-6-8 for debug*/
	walk += sizeof(int);
	for (i = 0; i < sfama_seq_set.num; i++) {
		//*(int *)walk = sfama_seq_set.seqnum[i];//modify by yuansong
		memcpy(walk, &(sfama_seq_set.seqnum[i]), sizeof(sfama_seq_set.seqnum[i]));
		log_info("ack data %d seq = %d####",i, sfama_seq_set.seqnum[i]);
		walk += sizeof(int);
	}
	return pkt;
}

/*fill the mac header of data packet*/
Packet *fill_data(Packet * pkt)
{
    ModemInfo *pPhyInfo;

    pPhyInfo = (ModemInfo *)pkt->phy;

	pkt->hdr_mac.hdr_len =
	    sizeof(pkt->hdr_mac) - sizeof(pkt->hdr_mac.mac_data)
	    + sizeof(struct mac_data_subhdr)
	    + sizeof(struct mac_ctrl_subhdr);
	pkt->hdr_mac.mac_type = g_moduleId;
	pkt_set_pkttype(pkt, SEALINX_P_SFAMA_DATA);
	pkt->hdr_mac.src_addr = my_mac_addr;

	/*Modify by yuansong for Broadcast function, 2018-5-7*/
	if (pkt->hdr_net.dst_addr == NET_BROADCAST_ADDR)
		pkt->hdr_mac.dst_addr = MAC_BROADCAST_ADDR;/* add boradcast function. 2018-5-7*/
	else
		pkt->hdr_mac.dst_addr = getMac(arpTable, pkt->hdr_net.next_hop);	/*for one hop communication */

	pkt_set_seq(pkt, sfama_seqnum++);

	#if 0/*del by yuansong 2018-5-4, for setting tx mode by user's setting.*/
	struct amc_mode *mode =
	    amc_get_mode(pkt->hdr_mac.src_addr, pkt->hdr_mac.dst_addr);
	if (!mode) {
		pkt->phy.txmode = 0;
		//return NULL;
	} else {
		pkt->phy.txmode = mode->txmode;
	}
	#endif

    /*add by yuansong 2018-5-4, 5-29  modify*/
	uint8_t txmode = 0;
    //please modify
	memcpy(&txmode, pkt->hdr_tra.tra_data+sizeof(int), sizeof(uint8_t));
    pPhyInfo->type = Modem_Info_Tx;
	pPhyInfo->tx.phy_param.mode = txmode;
	/*pkt->phy.txmode = *(pkt->hdr_tra.tra_data + sizeof(int));*//*txmode parameter.*/
	//(int*)(pkt->hdr_mac.mac_data+sizeof() ) = sfama_seqnum++;
	/*pkt->hdr_mac.dst_addr = pkt->hdr_net.next_hop; *//*multiple hop */
	//pkt->pkt_type = PACKET_OUTGOING;
//	pkt->pkt_state = PKT_STATE_MAC;
	return pkt;
}

/*debug by yuansong 2018-6-11 for hello pkt*/
#if 0
int backoff_slot_num()
{
	return (int)(MAX_BACKOFF_SLOT_NUM * ((random() % 1000) / 1000.0));
}
#endif

int backoff_slot_num()
{
	srand((unsigned int)time(NULL));
	return (int)(rand()%(MAX_BACKOFF_SLOT_NUM+1)?rand()%(MAX_BACKOFF_SLOT_NUM+1):1);
}

/*add for process broadcast by yuansong 2018-5-16*/
void process_rtsforbroadcast(Packet * pkt)
{
	unsigned short int resved_slot_num;

	resved_slot_num = pkt_get_slotnum(pkt);
	if (IDLE==sfama_status || BACKOFF_FAIR==sfama_status){
		sealinx_timer_cancel(&backoff_timer);
		sealinx_timer_cancel(&delay_timer);
		sealinx_timer_cancel(&wait_timer);

		wait_timer.delay_time = get_interval_to_coming_slot();//modify
		timeval_add_long(&wait_timer.delay_time, slot_len*resved_slot_num);
		wait_timer.arg             = NULL;
		wait_timer.timer_status    = SEALINX_TIMER_IDLE;
		wait_timer.timer_call_back = wait_timer_process;
		sealinx_timer_start(&wait_timer);
		sfama_status = RECEIVING_BDATA;
	}
}

void process_rts(Packet * pkt)
{
	//struct timeval delay_time;
	Packet *cts_pkt = NULL;
	struct timeval cur_time, interval;
	unsigned short int resved_slot_num = pkt_get_slotnum(pkt);
	unsigned long status_change_interval;
    ModemInfo *pPhyInfo;

    pPhyInfo = (ModemInfo *)pkt->phy;


	//writeLog("\n\nThe status is %d\n\n", get_sfama_status());
	gettimeofday(&cur_time, NULL);
	timeval_subtract(&interval, &cur_time, &status_update_time);
	status_change_interval =
	    interval.tv_sec * MillionMicroSecond + interval.tv_usec;

	if (pkt->hdr_mac.dst_addr == my_mac_addr) {
		if (!is_inround() || get_sfama_status() == FOR_RTS ||
		    (get_sfama_status() == FOR_DATA
		     && status_change_interval >= slot_len)) {
			struct amc_metric metric;

			sealinx_timer_cancel(&backoff_timer);
			sealinx_timer_cancel(&delay_timer);
			sealinx_timer_cancel(&wait_timer);
			metric.esnr = (uint8_t)pPhyInfo->rx.effsnr;
			amc_feed_metric(pkt->hdr_mac.src_addr,
					pkt->hdr_mac.dst_addr, &metric);
			//writeLog("the resved slot_num is %d\n", resved_slot_num);
			cts_pkt = make_cts(pkt, resved_slot_num);
			delay_timer.delay_time = get_interval_to_coming_slot();
			delay_timer.timer_call_back = delay_timer_process;
			delay_timer.arg = (void *)cts_pkt;

			if (!sealinx_timer_start(&delay_timer)) {
				logError("Fail to start timer");
				return;
			}
			set_sfama_status(GOT_RTS);

			logInfo
			    ("Node %d : will send CTS in %d seconds %d microseconds",
			     my_mac_addr, delay_timer.delay_time.tv_sec,
			     delay_timer.delay_time.tv_usec);
			return;
		}
	} else {

		/*add for boardcast by yuansog 2018-5-16*/
		if (BROADCAST_MAC_ADDR == pkt->hdr_mac.dst_addr){
			process_rtsforbroadcast(pkt);
			return;
		}
		/*other neighbors avoid collision */
		//writeLog("\ncancel backoff timer\n");
		sealinx_timer_cancel(&delay_timer);
		sealinx_timer_cancel(&wait_timer);
		sealinx_timer_cancel(&backoff_timer);
		/*avoid sending packet during futher several slots (including this slot) */
		struct timeval delay_time = get_interval_to_coming_slot();
		timeval_add_long(&delay_time, (2*resved_slot_num) * slot_len);/*add long 2 twince slot_len.*/
		do_backoff(delay_time, 0);
	}
	/*otherwise, ignore the packet */
}

void process_cts(Packet * pkt)
{
	//struct timeval delay_time;
	unsigned short int resved_slot_num = pkt_get_slotnum(pkt);
	struct amc_metric *metric;

	ProcessCTSForDistance(pkt);/*add by yuansong 2018-5-17.*/

	if (pkt->hdr_mac.dst_addr == my_mac_addr){
		if (get_sfama_status() == FOR_CTS){
			set_sfama_status(GOT_CTS);
			metric = (struct amc_metric *)(pkt->hdr_mac.mac_data+sizeof(struct mac_cmn_subhdr)+sizeof(struct mac_ctrl_subhdr));
			amc_feed_metric(pkt->hdr_mac.dst_addr,pkt->hdr_mac.src_addr, metric);
			sealinx_timer_cancel(&backoff_timer);
			sealinx_timer_cancel(&delay_timer);
			sealinx_timer_cancel(&wait_timer);

			delay_timer.delay_time = get_interval_to_coming_slot();
			delay_timer.timer_call_back = delay_timer_process;
			//delay_timer.arg = (void*)data_pkt;
			delay_timer.arg = NULL;

			if (!sealinx_timer_start(&delay_timer)){
				logError("Fail to start timer");
				return;
			}
			logInfo
			    ("Node %d : will start to send DATA in %d seconds %d microseconds",my_mac_addr, delay_timer.delay_time.tv_sec,delay_timer.delay_time.tv_usec);
		}
	}
	else{		/*if( !is_inround() ||get_sfama_status() == FOR_RTS ) */

		/*cancel the scheduled sending?????????????? */
		sealinx_timer_cancel(&backoff_timer);
		sealinx_timer_cancel(&delay_timer);
		sealinx_timer_cancel(&wait_timer);

		/*avoid sending packet durate futher several slots for data (including this slot) */
		struct timeval delay_time = get_interval_to_coming_slot();
		timeval_add_long(&delay_time, (resved_slot_num + 1) * slot_len);
		do_backoff(delay_time, 0);
	}
	/*otherwise, ignore the packet */
}

void process_data(Packet * pkt)
{
	//struct timeval delay_time;
	if (pkt->hdr_mac.dst_addr == my_mac_addr) {
		if (get_sfama_status() == FOR_DATA) {
			/*reply the ack after receive all packet: wait for wait_timer out */
			/*make the ack packet */
			//Packet *ack_pkt = make_ack(pkt);
			//set_sfama_status(GOT_DATA);

			sfama_seq_set.seqnum[sfama_seq_set.num++] =
			    pkt_get_seq(pkt);
			data_sender_addr = pkt->hdr_mac.src_addr;
			sealinx_timer_cancel(&backoff_timer);
			sealinx_timer_cancel(&delay_timer);
			//sealinx_timer_cancel(&wait_timer); //don't cancel wait timer, it will to trigger ack
			//client_send_up(g_connFd, pkt, PDU_SIZE(pkt->msg_len), g_moduleId, NULL, 0);


			client_send_up(g_connFd, pkt, sizeof(Packet),
				       g_moduleId, NULL, 0);
			/*
			   build_select_list();
			   if(select(fdmax+1, NULL, &write_fds, NULL, NULL) == -1) {
			   logError("Select() failed. %s", strerror(errno));
			   exit(1);
			   }
			   write(sfama_socket_fd, send_buf, sizeof(send_buf));
			 */
		}
	}
	/*add broadcast data process by yuansong 2018-5-31*/
	if (BROADCAST_MAC_ADDR==pkt->hdr_mac.dst_addr){
		if (get_sfama_status()==RECEIVING_BDATA){
			sealinx_timer_cancel(&backoff_timer);
			sealinx_timer_cancel(&delay_timer);
			client_send_up(g_connFd, pkt, sizeof(Packet),
				       g_moduleId, NULL, 0);
		}
	}

}

void process_ack(Packet * pkt)
{
	// log_info("Debug g_connFd = %d in process_ack####001!!!!!", g_connFd);

	retry_counter = 0;//reset, 2018-8-6 ys
	struct timeval delay_time;
	if (pkt->hdr_mac.dst_addr == my_mac_addr){
		if (get_sfama_status() == FOR_ACK){
			int i, j;
			Packet *tmp_pkt = NULL;
			//parse ack packet
			int ack_num, tmp_seq;
			char *walk = pkt->pkt_data;
			/*ack_num = *(int *)walk;*//*modify by  yuansong 20-18-6-8*/
			memcpy(&ack_num,walk, sizeof(int));
			// printf("debug memcpy and set value for ACK, set, ack_num=%d#####", ack_num);

			int tmp = 0;
			memcpy(&tmp, pkt->pkt_data, sizeof(int));
			// printf("debug memcpy and set value for ACK, memcpy, tmp=%d#####", tmp);

			// log_info("Debug g_connFd = %d in process_ack####002!!!!!", g_connFd);
			walk += sizeof(int);
			for (i = 0; i < ack_num; i++){
				// log_info("debug for app core dump, i=%d, ack_num=%d@@@@@@@@", i, ack_num);
				/*tmp_seq = *(int *)walk; */ /*modify by yuansong 2018-6-8*/
				memcpy(&tmp_seq, walk, sizeof(int));
				// log_info("debug for app core dump, for ACK tmp_seq=%d@@@@@@@@", tmp_seq);
				walk += sizeof(int);
				for (j = 0; j < pktset.burst; j++){
					// log_info("debug for app core dump, j=%d, tmp_seq=%d########", j, tmp_seq);
					if (pktset.pkts[j] == NULL)
							continue;
					if (tmp_seq == pkt_get_seq(pktset.pkts[j])){
						tmp_pkt = pktset.pkts[j];
						pkt_queue_del_pkt(sfama_queue_head, pktset.pkts[j]);
						free(pktset.pkts[j]);//debug core dump sfama App.2018-6-8 by yuansong 2 time free node.
						logInfo("Length of Packet Queue is %d in process_ack",queue_len);
						break;
					}
				}/*for (j = 0; j < pktset.burst; j++)*/
				// log_info("Debug sfama core dump **********####000");
			}//for (i = 0; i < ack_num; i++)

            /* debug queue over flow, 2018-9-3*/
			// log_info("ack_num=%d, queue_len=%d, pktset.burst=%d in process_ack",ack_num, queue_len, pktset.burst);
            queue_len = queue_len - ack_num;
			int size  = 0;
			for (size=0; size<BURST_QUEUE_LEN/*array size*/; size++)
				pktset.pkts[size] = NULL;

			/*debug queue over flow, 2018-9-3*/
			// log_info("Debug g_connFd = %d in process_ack####003!!!!!", g_connFd);

			// log_info("Debug sfama core dump **********####001");
			sealinx_timer_cancel(&wait_timer);
		    // log_info("Debug g_connFd = %d in process_ack####004!!!!!", g_connFd);
			sealinx_timer_cancel(&backoff_timer);
			// log_info("Debug g_connFd = %d in process_ack####005!!!!!", g_connFd);
			sealinx_timer_cancel(&delay_timer);
			// log_info("Debug g_connFd = %d in process_ack####006!!!!!", g_connFd);
			// log_info("Debug sfama core dump **********####002");
            // log_info("Debug g_connFd = %d in process_ack####007!!!!!", g_connFd);
			//if( !pkt_queue_empty(sfama_queue_head) ) {
			/*do backoff to reach fairness */
			delay_time = get_interval_to_coming_slot();
			// log_info("Debug g_connFd = %d in process_ack####008!!!!!", g_connFd);
			timeval_add_long(&delay_time, backoff_slot_num() * slot_len);
		    // log_info("Debug g_connFd = %d in process_ack####009!!!!!", g_connFd);
			do_backoff(delay_time, 1);
			// log_info("Debug g_connFd = %d in process_ack####010!!!!!", g_connFd);
			//}
			//else {
			//    set_sfama_status(IDLE);
			//}
		}//if (get_sfama_status() == FOR_ACK)
		// log_info("Debug sfama core dump  g_connFd = %d**********####003", g_connFd);
	}
	// log_info("Debug sfama core dump, g_connFd = %d **********####004", g_connFd);
}

void backoff_timer_process(void *arg)
{
	struct timeval delay_time;
	int random_backoff_num = 0;

	if (pkt_queue_empty(sfama_queue_head))
		set_sfama_status(IDLE);
	else{
		random_backoff_num = backoff_slot_num();
		// log_info("Debug sfama status=%d, random_backoff_num =%d##",get_sfama_status(), random_backoff_num);
		if (get_sfama_status() == BACKOFF_FAIR || random_backoff_num == 0){
			delay_time.tv_sec = 0;
			delay_time.tv_usec = 0;
			init_handshake(delay_time);
		}
		else{
			//state is BACKOFF and wants to send rts
			//do backoff for fair first
			delay_time = get_interval_to_coming_slot();
			timeval_add_long(&delay_time,
					 (random_backoff_num) * slot_len);
			do_backoff(delay_time, 1);
		}
	}
}

void delay_timer_process(void *arg)
{
	unsigned short mac_type;
	unsigned long txtime;
	int resved_slot_num;
	Packet *pkt = (Packet *) arg;
	delay_timer.arg = NULL;

	if (pkt != NULL) {
		mac_type = pkt_get_pkttype(pkt);
		txtime = gettxtimebylen(getPktSize(pkt));
		if (mac_type == SEALINX_P_SFAMA_CTS) {
			resved_slot_num = pkt_get_slotnum(pkt);
		}
	} else {
		mac_type = SEALINX_P_SFAMA_DATA;
		txtime = pktset.txtime;
	}

	#if 1 /*modify by yuansong 2018-5-31*/
	/*add by yuansong 2018-5-9*/
    if (SEALINX_P_SFAMA_RTS==mac_type){
		/*modify yuansong 2018-5-31*/
    	if (BROADCAST_MAC_ADDR == pkt->hdr_mac.dst_addr)	{
    		SendRtsTStamp.tv_sec  = 0;
			SendRtsTStamp.tv_usec = 0;
    	}
		else
			gettimeofday(&SendRtsTStamp, NULL);
    }
    #endif

	/*add by yuansong for broadcast data, 2018-5-16*/
	if (pkt!=NULL && SEALINX_P_SFAMA_RTS==mac_type && BROADCAST_MAC_ADDR==pkt->hdr_mac.dst_addr)
		sfama_status = PREPARE_BROADCAST;
	else
		updata_sfama_status(mac_type);

	/*send out this packet */
	if (pkt != NULL) {
		/*add by yuansong for broadcast function 2018-5-31 modify */
		if (BROADCAST_MAC_ADDR == pkt->hdr_mac.dst_addr){
		    // log_info("&&&&&&Send RTS pkt in function delay_timer_process branch BROADCAST_MAC_ADD&&&&&&&&&");
			struct timeval itime;
			itime = get_interval_to_coming_slot();
			if (itime.tv_sec==0 && itime.tv_usec<100000)
			{
				timeval_add_long(&itime, slot_len);
			}
			delay_timer.delay_time = itime;
			delay_timer.timer_call_back = delay_timer_process;
			delay_timer.arg = NULL;
			sealinx_timer_start(&delay_timer);
			send_pkt(pkt);
			return;
		}
		send_pkt(pkt);	/*NOTE: packet is freed in this function */
	} else {

		// log_info("Begin send pdu to PHY in function delay_timer_process");
		int i = 0;
		Packet *tmp_pkt = NULL;
		while (i < pktset.burst) {
			tmp_pkt = (Packet *) malloc(sizeof(Packet));
			memset(tmp_pkt, 0, sizeof(Packet));
			memcpy(tmp_pkt, pktset.pkts[i], sizeof(Packet));
			i++;
			send_pkt(tmp_pkt);
		}
		// log_info("End send %d pdu to PHY in function delay_timer_process", i);

		/*add for broadcast data function modify 2018-5-31*/
		if (pktset.pkts[0]->hdr_mac.dst_addr == BROADCAST_MAC_ADDR){
			// log_info("Send pdu to PHY,PDU is broadcast pkt in function delay_timer_process");
			sfama_status = BROADCASTING_DATA;
		}

	}
	if (mac_type != SEALINX_P_SFAMA_ACK) {
		/*set maximum waiting time:
		   two slots including current one */
		wait_timer.delay_time = get_interval_to_coming_slot();
		if (wait_timer.delay_time.tv_sec == 0 && wait_timer.delay_time.tv_usec < 100000)	{
		    // log_info("@@@debug time deviate, so add one slot_len,I think it is not occure!@@@@@");
			timeval_add_long(&wait_timer.delay_time, slot_len);
		}

		if (mac_type == SEALINX_P_SFAMA_DATA
		    || mac_type == SEALINX_P_SFAMA_RTS) {
			timeval_add_long(&wait_timer.delay_time, slot_len);
		}

		/*debug add time is not enough long 2018-6-8 by yuansong */
		if (mac_type == SEALINX_P_SFAMA_RTS)	{
			timeval_add_long(&wait_timer.delay_time, slot_len);/*modify esnr for wait CTS need 3 slots*/
		}

		if (mac_type == SEALINX_P_SFAMA_DATA) {
			//unsigned short int resved_slot_num =
			//*((unsigned short int*)(pkt->hdr_mac.mac_data));
			timeval_add_long(&wait_timer.delay_time,
					 slot_len * (pktset.slotnum * 2));/*modify for wait ACK ,add long 2 twince.*/
		}
		if (mac_type == SEALINX_P_SFAMA_CTS) {
			//timeval_add_long(&wait_timer.delay_time, slot_len);
			timeval_add_long(&wait_timer.delay_time,
					 slot_len * resved_slot_num);/*modify for data ,add long 2 slots*/
			timeval_add_long(&wait_timer.delay_time, 2*slot_len);/*ought to add 2 slots time!!!!2018-6-9 */
		}

		#if 0/*del by yuansong 2018-5-31 for modify broadcast function.*/
		//add boradcast by yuansong 2018-5-16,add one slot time than common CTS
		if (SEALINX_P_SFAMA_RTS==mac_type && BROADCASTING_DATA==sfama_status)
		{
			timeval_add_long(&wait_timer.delay_time, slot_len);
		}
		//add boradcast by yuansong 2018-5-16,add one slot time thran common CTS
		#endif

		wait_timer.arg = NULL;
		wait_timer.timer_status = SEALINX_TIMER_IDLE;
		wait_timer.timer_call_back = wait_timer_process;
		sealinx_timer_start(&wait_timer);

		logInfo
		    ("Node %d : wait timer starts and will expire in %d second %d microsecond",
		     my_mac_addr, wait_timer.delay_time.tv_sec,
		     wait_timer.delay_time.tv_usec);
	} else {
		/*if there is queued packet, send it after waiting random slots */
		struct timeval delay_time;
		if (!pkt_queue_empty(sfama_queue_head)) {

			delay_time = get_interval_to_coming_slot();
			timeval_add_long(&delay_time,
					 backoff_slot_num() * slot_len);
			do_backoff(delay_time, 1);
		} else {
			set_sfama_status(IDLE);
		}
	}
}

/*add for boardcast data function by yuansong 2018-5-16*/
void SendBroadcastData()
{
	int i           = 0;
	Packet *tmp_pkt = NULL;

	while (i < pktset.burst){
		tmp_pkt = (Packet *) malloc(sizeof(Packet));
		memset(tmp_pkt, 0, sizeof(Packet));
		memcpy(tmp_pkt, pktset.pkts[i], sizeof(Packet));
		i++;
		send_pkt(tmp_pkt);
	}

	for (i=0; i<pktset.burst; i++){
		pkt_queue_del_pkt(sfama_queue_head, pktset.pkts[i]);
		free(pktset.pkts[i]);
		/*queue_len--;*/
		operatequeue_len(FALSE);/*replace mutex operate*/
	}

	timeval_add_long(&wait_timer.delay_time, slot_len*(pktset.slotnum));
	wait_timer.arg             = NULL;
	wait_timer.timer_status    = SEALINX_TIMER_IDLE;
	wait_timer.timer_call_back = wait_timer_process;
	sealinx_timer_start(&wait_timer);

	sfama_status = BROADCASTING_DATA;

}

void wait_timer_process(void *arg)
{
	/*add for late ack process,2018-6-13, add new retry function, 2018-8-6*/
	if (FOR_ACK==sfama_status || (FOR_CTS==sfama_status&&retry_counter>=MAX_RETRY_TIME))
	{
		int i = 0;
		for (i=0; i<pktset.burst; i++){
			if (pktset.pkts[i] != NULL){
				pkt_queue_del_pkt(sfama_queue_head, pktset.pkts[i]);
				free(pktset.pkts[i]);/*add free content of node*/
				/*queue_len--;*/
				operatequeue_len(FALSE);/*replace mutex operate*/
			}
		}/*for (i=0; i<pktset.burst; i++)*/

		memset(&pktset, 0, sizeof(pktset));
		// log_info("Del packet queue, sfama_status=%d, retry_counter=%d", sfama_status, retry_counter);
	}

	/*for broadcasting data!!*/
	if (BROADCASTING_DATA == sfama_status){
		struct timeval delay_time;

		DelBroadData();/*send packet over!ougth to del sfama_queue_head, add by yuansong 2018-6-2*/
		if (!pkt_queue_empty(sfama_queue_head)){
			delay_time = get_interval_to_coming_slot();
			timeval_add_long(&delay_time, backoff_slot_num()*slot_len);
			do_backoff(delay_time, 1);
		}
		else
			set_sfama_status(IDLE);
	}

	/*add for broadcast by yuansong 2018-5-16, for received data over. */
	if (RECEIVING_BDATA == sfama_status)	{
		memset(&sfama_seq_set, 0, sizeof(struct PktSeqSet));/*set 0*/

		sealinx_timer_cancel(&backoff_timer);/*add 2018-5-31*/
		sealinx_timer_cancel(&delay_timer);/*add 2018-31*/
		/*later, it will enter into BACKOFF_FAIR, 2018-5-31.*/
	}

	/*timer timeouts, do backoff and then send packet */
	if (get_sfama_status() == FOR_DATA && sfama_seq_set.num != 0) {
		//got data packet, reply ack here
		Packet *ack_pkt = make_ack();
		sealinx_timer_cancel(&delay_timer);
		delay_timer.delay_time.tv_sec = 0;
		delay_timer.delay_time.tv_usec = 500;
		delay_timer.timer_call_back = delay_timer_process;
		delay_timer.arg = (void *)ack_pkt;
		/*
		   if( !sealinx_timer_start(&delay_timer) ) {
		   logError("Fail to start timer");
		   return;
		   }

		   logInfo( "Node %d : will send ACK in %d seconds %d microseconds",
		   my_mac_addr,
		   delay_timer.delay_time.tv_sec,
		   delay_timer.delay_time.tv_usec);
		 */
		delay_timer_process((void *)ack_pkt);
		sfama_seq_set.num = 0;
	} else {
		struct timeval delay_time = get_interval_to_coming_slot();
		logInfo("Node %d : wait timer expires", my_mac_addr);
		sealinx_timer_cancel(&backoff_timer);
		timeval_add_long(&delay_time, (backoff_slot_num()) * slot_len);
		do_backoff(delay_time, 1);
	}
}

void send_pkt(Packet * pkt)
{
    ModemInfo *pPhyInfo;

    pPhyInfo = (ModemInfo *)pkt->phy;

	// logInfo("+++ send_pkt is called +++");
	switch (pkt_get_pkttype(pkt)) {
	case SEALINX_P_SFAMA_RTS:
		//update the requested number of slots
		pkt_queue_get_pktburst(&pktset, max_burst, sfama_queue_head);
		getSlotNumofPktTrain();	//record info in pktset
		pkt_set_slotnum(pkt, pktset.slotnum);
		logSend(PKT_CONTROL,
			pkt->hdr_mac.src_addr,
			pkt->hdr_mac.dst_addr, getPktSize(pkt), "RTS");
		break;
	case SEALINX_P_SFAMA_CTS:
		logSend(PKT_CONTROL,
			pkt->hdr_mac.src_addr,
			pkt->hdr_mac.dst_addr, getPktSize(pkt), "CTS");
		sfama_seq_set.num = 0;
		break;
	case SEALINX_P_SFAMA_ACK:
		logSend(PKT_CONTROL,
			pkt->hdr_mac.src_addr,
			pkt->hdr_mac.dst_addr, getPktSize(pkt), "ACK");
		break;
	case SEALINX_P_SFAMA_DATA:
		logSend(PKT_DATA,
			pkt->hdr_mac.src_addr,
			pkt->hdr_mac.dst_addr, getPktSize(pkt), "DATA");
		//add the transmit modem
		//namDequeue(pkt->hdr_mac.src_addr, pkt->hdr_mac.dst_addr);
		//please modify
		pPhyInfo->type = Modem_Info_Tx;
		memcpy(&(pPhyInfo->tx.phy_param.mode), pkt->hdr_tra.tra_data+sizeof(int), sizeof(uint8_t));/*add by ys 2018-9-3*/
		break;
	default:
		logInfo("Node %d : unknown packet type", my_mac_addr);
	}

	//namHop(pkt->hdr_mac.src_addr, pkt->hdr_mac.dst_addr, getPktSize(pkt));
	/*
	   build_select_list();
	   if(select(fdmax+1, NULL, &write_fds, NULL, NULL) == -1) {
	   logError("Select() failed. %s", strerror(errno));
	   return;
	   }
	   write(sfama_socket_fd, send_buf, sizeof(send_buf));
	 */
	// logInfo("+++ send down tx_mode is %d+++", pkt->phy.txmode);
	//client_send_down(g_connFd, pkt, PDU_SIZE(pkt->msg_len), g_moduleId, NULL, 0);
	client_send_down(g_connFd, pkt, sizeof(Packet), g_moduleId, NULL, 0);

	/*add debug by yuansong 2018-6-6*/
	// log_info("##########Begin print Send data to PHY in function send_pkt!#########");
	// printTRAHeaderInfo(&pkt->hdr_tra);
	// printNETHeaderInfo(&pkt->hdr_net);
	// printMACHeaderInfo(&pkt->hdr_mac);
	PrintfPDUbuff(pkt->pkt_data,pkt->msg_len);
	// log_info("##########End print Send data to PHY in function send_pkt!#########");

    /*add by ys 2018-8-6 for retry transport.*/
	if (SEALINX_P_SFAMA_RTS == pkt_get_pkttype(pkt))
	    retry_counter++;
	else
	    retry_counter = 0;

    // log_info("free packet pointer = %d", pkt);
	free(pkt);
	sent_pkt++;
}

Packet *make_rts(unsigned short int resved_slot_num)
{
	Packet *rts_pkt = (Packet *) malloc(sizeof(Packet));
	if (rts_pkt == NULL) {
		logError("Memory allocation fails");
		exit(0);
	}
	memset(rts_pkt, 0, sizeof(Packet));
	fill_rts(rts_pkt, pkt_queue_get_mac_recver_addr(sfama_queue_head),
		 resved_slot_num);
	return rts_pkt;
}

Packet *make_cts(Packet * rts_pkt, unsigned short int resved_slot_num)
{
	Packet *cts_pkt = (Packet *) malloc(sizeof(Packet));
	if (cts_pkt == NULL) {
		logError("Memory allocation fails");
		exit(0);
	}
	memset(cts_pkt, 0, sizeof(Packet));
	fill_cts(cts_pkt, rts_pkt->hdr_mac.src_addr, resved_slot_num);
	return cts_pkt;
}

Packet *make_ack()
{
	Packet *ack_pkt = (Packet *) malloc(sizeof(Packet));
	if (ack_pkt == NULL) {
		logError("Memory allocation fails");
		exit(0);
	}
	memset(ack_pkt, 0, sizeof(Packet));
	fill_ack(ack_pkt, data_sender_addr);
	return ack_pkt;
}

void updata_sfama_status(unsigned short mac_type)
{
	gettimeofday(&status_update_time, NULL);
	switch (mac_type) {
	case SEALINX_P_SFAMA_RTS:
		sfama_status = FOR_CTS;
		break;
	case SEALINX_P_SFAMA_CTS:
		sfama_status = FOR_DATA;
		break;
	case SEALINX_P_SFAMA_DATA:
		sfama_status = FOR_ACK;
		break;
	case SEALINX_P_SFAMA_ACK:
		sfama_status = IDLE;
		break;
	default:
		logInfo("unknown packet type\n");
		exit(0);
	}
}

int is_inround()
{
	if (get_sfama_status() == IDLE || get_sfama_status() == BACKOFF_FAIR)
		return NOT_IN_ROUND;
	else
		return IN_ROUND;
}

void set_sfama_status(enum delay_timer_status status)
{
	sfama_status = status;
}

enum delay_timer_status get_sfama_status()
{
	return sfama_status;
}

int parse_arguments(int argc, char **argv)
{
	int i = 0;
	int code_readcfg = -1;
	while (i < argc) {
		char *t = argv[i];
		if (strcmp(t, "-i") == 0) {
			i++;
			if (i < argc) {
				int moduleId = strtol(argv[i], NULL, 10);
				if (moduleId > MAX_MODULE_ID
				    || moduleId < MIN_MODULE_ID) {
					fprintf(stderr,
						"Invalid module ID (%s)\n",
						argv[i]);
					return FALSE;
				}
				g_moduleId = moduleId;
			}
		} else if (strcmp(t, "-c") == 0) {
			i++;
			if (i < argc) {
				code_readcfg = load_cfgfile(argv[i]);
			}
		} else if (strcmp(t, "-f") == 0) {
			i++;
			if (i < argc) {
				gLogFile = atoi(argv[i]);
			}
		}
		i++;
	}
	return g_moduleId <= MAX_MODULE_ID && g_moduleId >= MIN_MODULE_ID
	    && (!code_readcfg);
}

/**
 *  * Print the usage of the program.
 *   */
void print_usage(const char *progName)
{
	printf("USAGE: %s -c <config file>[-f <log file outoput flag>]\n",
	       progName);
}

/**
 *  * Signal handler.
 *   *
 *    * @param sig Signal ID.
 *     */
void signal_handler(int sig)
{
	int type = 0;
	log_info("Received signal (%d)", sig);

	if (g_connFd > -1) {
		client_close(type, g_connFd, NULL, 0);
		g_connFd = -1;
	}
}

/**
 *  * Clean up allocated resources.
 *   */
void clean_up(void)
{
	int type = 0;
	log_info("Cleaning up ...");
	if (g_connFd > -1) {
		client_close(type, g_connFd, NULL, 0);
	}

	int rc = shmdt(g_coreSharedData);
	if (rc == -1) {
		log_error("Unable to detach shared data: %s", strerror(errno));
	}

	logInfo("Stopping Slotted-FAMA");
	logInfo("Closing opened connections...");
	release_sfama();
	logInfo("All done.\n");
	close_logger();
	//freeANNam();
}

int load_cfgfile(const char *configFile)
{
	char *token;
	char local_buff[sizeof(struct pdu_buff)];

	/*get the parameters of slotted fama */
	FILE *sfama_cfg = fopen(configFile, "r");
	if (!sfama_cfg) {
		logError("Fail to find the configuration file of Slotted FAMA");
		exit(EXIT_FAILURE);
	}
	memset(local_buff, 0, sizeof(local_buff));

	while (fgets(local_buff, sizeof(local_buff), sfama_cfg)){
		if (NULL == (token = strtok(local_buff, " :"))){
			logError
			    ("Wrong configration file format! The format should be\n Max_Tx_Range :  Bandwidth : SPEED : Guard_Time(microseconds) : Max_Queue_Len : MAX_BACKOFF_SLOT_NUM : Max_pkts_in_train");
			exit(1);
		}
		if (*token == '#')
			continue;
		max_tx_range = atof(token);
		if (NULL == (token = strtok(NULL, " :"))) {
			logError
			    ("Wrong configration file format! The format should be\n Max_Tx_Range :  Bandwidth : SPEED : Guard_Time(microseconds) : Max_Queue_Len : MAX_BACKOFF_SLOT_NUM : Max_pkts_in_train");
			exit(1);
		}
		band_width = atoi(token);
		if (!(band_width == 800 || band_width == 600 ||
		      band_width == 300 || band_width == 140
		      || band_width == 2500)) {
			logError
			    ("Bit rate of the modem should be 140, 300, 600, or 800, 2500 bps");
			exit(1);
		}
		if (NULL == (token = strtok(NULL, " :"))) {
			logError
			    ("Wrong configration file format! The format should be\n Max_Tx_Range :  Bandwidth : SPEED : Guard_Time(microseconds) : Max_Queue_Len : MAX_BACKOFF_SLOT_NUM : Max_pkts_in_train");
			exit(1);
		}
		sound_speed = atof(token);
		if (NULL == (token = strtok(NULL, " :"))) {
			logError
			    ("Wrong configration file format! The format should be\n Max_Tx_Range :  Bandwidth : SPEED : Guard_Time(microseconds) : Max_Queue_Len : MAX_BACKOFF_SLOT_NUM : Max_pkts_in_train");
			exit(1);
		}
		guard_time = atoi(token);
		if (NULL == (token = strtok(NULL, " :"))) {
			logError
			    ("Wrong configration file format! The format should be\n Max_Tx_Range :  Bandwidth : SPEED : Guard_Time(microseconds) : Max_Queue_Len : MAX_BACKOFF_SLOT_NUM : Max_pkts_in_train");
			exit(1);
		}
		max_queue_len = atoi(token);
		if (NULL == (token = strtok(NULL, " :"))) {
			logError
			    ("Wrong configration file format! The format should be\n Max_Tx_Range :  Bandwidth : SPEED : Guard_Time(microseconds) : Max_Queue_Len : MAX_BACKOFF_SLOT_NUM : Max_pkts_in_train");
			exit(1);
		}
		MAX_BACKOFF_SLOT_NUM = atoi(token);
		if (NULL == (token = strtok(NULL, " :"))) {
			logError
			    ("Wrong configration file format! The format should be\n Max_Tx_Range :  Bandwidth : SPEED : Guard_Time(microseconds) : Max_Queue_Len : MAX_BACKOFF_SLOT_NUM : Max_pkts_in_train");
			exit(1);
		}
		max_burst = atoi(token);
		if (max_burst <= 0) {
			logError
			    ("Wrong configration file format! The format should be\n Max_Tx_Range :  Bandwidth : SPEED : Guard_Time(microseconds) : Max_Queue_Len : MAX_BACKOFF_SLOT_NUM : Max_pkts_in_train");
			exit(1);
		}
		break;
	}
	logInfo
	    ("Tx Range: %f, bandwidth: %d, sound_speed: %f, guard_time: %d, Max Queue Len: %d, Max Backoff Slots: %d, Max Pkts in one Burst:%d",
	     max_tx_range, band_width, sound_speed, guard_time, max_queue_len,
	     MAX_BACKOFF_SLOT_NUM, max_burst);
	fclose(sfama_cfg);
	return 0;
}
