/*
* CopyRight Reserved: 智慧海洋
* Filename:          Serial.h
* Description:      串口驱动头文件
* Date:
* Author:
*/
#ifndef _SERIAL_H_
#define _SERIAL_H_

#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <termios.h>

#define SER_LIMIT            1024

int Serial_open(char *serial_name,int BaudSpeed,int DataBits,char Parity,int StopBits);
int Serial_close(int fd);

ssize_t Serial_read(int fd, char *buf, size_t count, unsigned int timeout);
#define Serial_read_b(fd, buf, count)	Serial_read(fd, buf, count, (unsigned int)-1)
ssize_t Serial_write(int fd, const char *buf, size_t count);
ssize_t ser_write_delay(int fd, const char *buf, size_t len);

#endif
