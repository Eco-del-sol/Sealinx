/**
 * SDDA_Terminal_MAC
 * date: 2019-2-28
 */
#ifndef _TER_H
#define _TER_H
#include "com.h"


typedef struct send_dataPkt_times {
    int seqNum;
    int times;
}Send_dataPkt_times;

// typedef struct {
//     /** Packet type. */
// 	uint8_t pktType;
// } __attribute__ ((__packed__)) ProtocolInfo;
#define BS_MAC_ADDR 9
#define MAX_QUEUE_LEN 100
sealinx_timer_t txrts_timer;

sealinx_timer_t wcts_timer;

sealinx_timer_t txdata_timer;

struct pkt_elem *sdda_pkt_queue_head;
struct pkt_elem *priority_pkt_queue;

time_t tr_recv_time;

time_t last_time_net;

time_t last_time_chn;

Send_dataPkt_times s_dataPkt_times[MAX_QUEUE_LEN];

int pkt_seqnum = 0;
int prio_queue_len = 0;

int cur_seq = -1;

int seqCount = 0;

/** 0, priority_pkt_queue is empty; 1, priority_pkt_queue isn't empty */
int flag = 0;

int burst = 0;

int accumulated_sendPktNum = 0;
int accumulated_recvPktNum = 0;
float pktLossRate_channel = 0;

int accumulated_lossPktNum = 0;
float pktLossRate_network = 0;
int curPktNum = -1;


typedef enum _status_channel{
     ter_INVALID_STATUS    = 0,
	 WAIT_RTS_CHANCE   = 1,
     WAIT_CTS          = 2,
     WAIT_SENDING_DATA = 3,
	 WAIT_ACK          = 4,
}status_channel;

void operate_prio_queue_len(int ctl);

int get_rts_chance_moment(char *buf);


double getNPktTxTime(uint8_t pktTxmode, size_t len);

/** Get the tx time of the data to send */
uint16_t getDATATxTime();

Packet *make_rts();

void process_cts(Packet *cts);

void process_ack(Packet *ack);

int get_data_chance_moment(char *buf);

void send_data();

void process_txdata_timer(void *arg);

void send_rts();

void process_txrts_timer(void *arg);

#endif
