#ifndef IPC_MAIN_H
#define IPC_MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

#include <sealinx_pdu.h>

typedef struct pdu_header {
	uint16_t msg_len;	/* Length of pkt_data */
	MacHeader hdr_mac;
	NetHeader hdr_net;
	TransportHeader hdr_tra;
    int sn;
} PduHeader;

typedef struct {
    /** Packet type. */
	uint8_t pktType;
} __attribute__ ((__packed__)) ProtocolInfo;

#ifdef __cplusplus
}
#endif

#endif /* IPC_MAIN_H */
