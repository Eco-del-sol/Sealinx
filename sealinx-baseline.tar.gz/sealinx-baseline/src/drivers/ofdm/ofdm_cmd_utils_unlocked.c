/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * Utility function for OFDM modem working in command mode.
 *
 * @author son
 */

#include <sealinx.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sealinx_serial.h>
#include <sealinx_utils.h>
#include <sealinx_common.h>
#include <math.h>
#include <pthread.h>

#include "ofdm_base.h"
#include "ofdm_cmd_utils.h"

#define ONLINE_MODE 1
#define COMMAND_MODE 2
#define MODEM_TIMEOUT 10
#define NAME_LENGTH 256
#define OFDM_BUFFER_SIZE_SMALL 200

/**
 * Sends a PDU.
 *
 * @param modem Descriptor of the modem.
 * @param pbuf The PDU to send
 * @retval CEXEC_SUCCESS if success
 * @retval CEXEC_RECOVERABLE if encountering recoverable error
 * @retval CEXEC_SYS_ERROR if encoutering unrecoverable error
 */
int ofdm_send_pdu(Modem * modem, PduBuff * pbuf)
{
	int pktId;

	char *sendBuffer = modem->sendBuffer;
	int sendBufLen =
	    sprintf(modem->sendBuffer, "$HHTXD,%d,%d,%d,", 0, 0, 0);
#ifdef DEBUG
	log_info("DBG_MSG: sendBufLen = %d", sendBufLen);
#endif
	sendBufLen += serialize_pdu(pbuf, sendBuffer + sendBufLen);
#ifdef DEBUG
	log_info("DBG_MSG: sendBufLen = %d", sendBufLen);
#endif
	sendBuffer[sendBufLen++] = '\r';
	sendBuffer[sendBufLen++] = '\n';

#ifdef DEBUG
	log_data(sendBuffer, sendBufLen);
#endif

	int rv = write(modem->fd, sendBuffer, sendBufLen);
	if (rv == -1)		/* file closed */
		return CEXEC_SYS_ERROR;
	else if (rv < sendBufLen)	/* cannot write the whole command */
		return CEXEC_RECOVERABLE;

	/* find the corresponding $MMOKY,HHTXD,<pkt number> */
	int respType = RESP_UNDEFINED, nRespRetries = 3;
	while (respType == RESP_UNDEFINED && nRespRetries > 0) {
		nRespRetries--;
		rv = ofdm_read_wait(modem, 2, 0);
		if (rv < 0) {	/* file closed */
			return CEXEC_SYS_ERROR;
		}
		if (rv == 0 || !ofdm_fetch_data(modem)) {
			continue;	/* time out or no data */
		}

		while (respType == RESP_UNDEFINED && resp_in_buffer(modem)) {
			log_info("current response: %s", modem->cmdResponse);
			if (strncmp(modem->cmdResponse, "$MMERR,", 7) == 0) {
				if (strncmp(modem->cmdResponse + 7, "HHTXD", 5)
				    == 0) {
					respType = RESP_MMERR;
				}
			}
			if (strncmp(modem->cmdResponse, "$MMOKY,", 6) == 0) {
				if (strncmp(modem->cmdResponse + 7, "HHTXD,", 6)
				    == 0) {
					respType = RESP_MMOKY;
					pktId = atoi(modem->cmdResponse + 13);
				}
			}
			ofdm_remove_cmd_resp(modem);
		}
	}

	if (respType != RESP_MMOKY) {
		ofdm_release(modem);
	}

	/* Find MMTDN following MMOKY */
	respType = RESP_UNDEFINED;
	nRespRetries = 3;
	while (respType == RESP_UNDEFINED && nRespRetries > 0) {
		nRespRetries--;
		if (!resp_in_buffer(modem)) {
			rv = ofdm_read_wait(modem, 20, 0);
			if (rv < 0) {
				return CEXEC_SYS_ERROR;
			}
			if (rv == 0 || !ofdm_fetch_data(modem))
				continue;
		}

		while (respType == RESP_UNDEFINED && resp_in_buffer(modem)) {
			log_info("current response: %s", modem->cmdResponse);
			if (strncmp(modem->cmdResponse, "$MMTDN,", 7) == 0) {
				char *endParam =
				    strchr(modem->cmdResponse + 7, ',');
				if (!endParam) {
					return CEXEC_RECOVERABLE;
				}
				if (atoi(endParam + 1) == pktId) {
					return CEXEC_SUCCESS;
				}
			}
			ofdm_remove_cmd_resp(modem);
		}
	}

	return CEXEC_RECOVERABLE;
}

/**
 * Switch the modem to command mode.
 *
 * @param modem Modem descriptor.
 * @return TRUE if success; FALSE, otherwise.
 */
int ofdm_to_cmd(Modem * modem)
{
	const char *cmd = "+++A\r\n";
	int retVal, cmdLen = 6, foundResponse = FALSE;
	int nCmdRetries = 2, nRespRetries;

	if (ofdm_write_wait(modem, 1, 0) != 1) {
		log_info("Unable to write to modem");
		return FALSE;
	}

	log_info("command: %s", cmd);

	while (nCmdRetries > 0 && !foundResponse) {
		nCmdRetries--;
		if (write(modem->fd, cmd, cmdLen) < cmdLen)
			return FALSE;

		nRespRetries = 3;
		while (nRespRetries > 0 && !foundResponse) {
			nRespRetries--;
			if (ofdm_read_wait(modem, 1, 0) <= 0
			    || !ofdm_fetch_data(modem)) {
				return FALSE;
			}

			while (resp_in_buffer(modem)) {
				log_info("current response: %s",
					 modem->cmdResponse);
				if (strncmp(modem->cmdResponse, "$MMERR,", 7) ==
				    0) {
					if (strncmp
					    (modem->cmdResponse + 7, "+++A",
					     4) == 0) {
						foundResponse = TRUE;
						retVal = FALSE;
					}
				}
				if (strncmp(modem->cmdResponse, "$MMOKY,", 7) ==
				    0) {
					if (strncmp
					    (modem->cmdResponse + 7, "+++A",
					     4) == 0) {
						foundResponse = TRUE;
						retVal = TRUE;
					}
				}
				ofdm_remove_cmd_resp(modem);
				if (foundResponse)
					return retVal;
			}
		}
	}

	return FALSE;
}

/**
 * Switch transmission completion notification.
 *
 * @param on TRUE if the notification is enabled; FALSE, otherwise.
 * @return TRUE if success; FALSE, otherwise.
 */
int ofdm_switch_tx_complete(Modem * modem, int on)
{
	int retVal = FALSE, cmdLen, foundResponse = FALSE;
	int nCmdRetries = 2, nRespRetries, rv;
	const char *cmd = on ? "$HHCRW,TXDONE,1\r\n" : "$HHCRW,TXDONE,0\r\n";

	if (ofdm_write_wait(modem, 2, 0) != 1) {
		log_info("Unable to write to modem");
		return FALSE;
	}

	log_info("command: %s", cmd);
	cmdLen = strlen(cmd);

	while (nCmdRetries > 0 && !foundResponse) {
		nCmdRetries--;
		if (write(modem->fd, cmd, cmdLen) < cmdLen)
			return FALSE;

		nRespRetries = 3;
		while (!foundResponse && nRespRetries > 0) {
			nRespRetries--;
			rv = ofdm_read_wait(modem, 2, 0);
			if (rv < 0)
				return FALSE;
			if (rv == 0 || !ofdm_fetch_data(modem))
				continue;

			while (resp_in_buffer(modem)) {
				log_info("current response: %s",
					 modem->cmdResponse);
				if (strncmp(modem->cmdResponse, "$MMERR,", 7) ==
				    0) {
					if (strncmp
					    (modem->cmdResponse + 7,
					     "HHCRW,TXDONE", 12) == 0) {
						foundResponse = TRUE;
						retVal = FALSE;
					}
				}
				if (strncmp(modem->cmdResponse, "$MMOKY,", 7) ==
				    0) {
					if (strncmp
					    (modem->cmdResponse + 7,
					     "HHCRW,TXDONE", 12) == 0) {
						foundResponse = TRUE;
						retVal = TRUE;
					}
				}
				ofdm_remove_cmd_resp(modem);
				if (foundResponse)
					return retVal;
			}
		}
	}
	return FALSE;
}

/**
 * Switches the modem to its normal operation mode.
 *
 * @param modem Descriptor of the modem
 * @return TRUE if success; FALSE, otherwise.
 */
int ofdm_to_operation_mode(Modem * modem)
{
	modem->initialized = FALSE;
	if (ofdm_to_cmd(modem)) {
		log_info("Modem switched to command mode");
		if (ofdm_switch_tx_complete(modem, TRUE)) {
			log_info("Complete transmission notification on");
			modem->initialized = TRUE;
		}
	}
	return modem->initialized;
}
