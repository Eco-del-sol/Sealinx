/*
* CopyRight Reserved: 智慧海洋
* Filename:         StreamDelimit.h
* Description:      接收数据处理头文件
* Date:             2017.07.07
* Author:           Lxt
*/
#ifndef _STREAMDELIMIT_H_
#define _STREAMDELIMIT_H_

#include "Delimit.h"
#include "Circularbuffer.h"
#include "VarArray.h"

#define HEADER_BIT	1
#define TRAILER_BIT	2
#define setHeader(dd)	(dd)->flag |= HEADER_BIT
#define setTrailer(dd)	(dd)->flag |= TRAILER_BIT
#define hasHeader(dd)	(dd)->flag & HEADER_BIT
#define hasTrailer(dd)	(dd)->flag & TRAILER_BIT

typedef struct DELIMITED_DATA {
	ListHead node;
	short hasHeader;
	short hasTrailer;
	int len;
	char buf[0];
} DelimitedData;
/*
#define DelimitedData_init(ddlist) ({list_init(&(ddlist)->node);})
*/

static inline void DelimitedData_init(DelimitedData * dlmtd)
{
	list_init(&dlmtd->node);
	dlmtd->len = 0;
}

typedef struct STREAM_DELIMIT {
	CircularBuffer *cirBuf;
	Delimiter delimiters;
	Delimiter *header;
	Delimiter *trailer;
	DelimitedData results;
	struct {
		VarArray *va;
		int hasHeader;
		int hasTrailer;
	} dataBuf;
} StreamDelimit;

StreamDelimit *StreamDelimit_create(int bufSize);

int StreamDelimit_addDelimiters(StreamDelimit * sd, const char *header,
				int headerLen, const char *trailer,
				int trailerLen);

int StreamDelimit_input(StreamDelimit * sd, char *buf, int len);

DelimitedData *StreamDelimit_output(StreamDelimit * sd);

int StreamDelimit_delimit(StreamDelimit * sd);

void StreamDelimit_delete(StreamDelimit * sd);

#define StremDelimit_output_isEmpty(sd)	list_empty(&sd->results.node)

#endif
