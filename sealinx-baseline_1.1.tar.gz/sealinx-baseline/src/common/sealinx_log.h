/**
 * Copyright 2008~2016 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author son
 */

#ifndef __SEALINX_LOG_H__
#define __SEALINX_LOG_H__

#include "sealinx_system.h"

#define MAX_LEN_PROC_NAME 10
#define MAX_LEN_FMT_STRING 200

#define SEQUENCE_FILE_POSTFIX   "__seq"
#define MAX_LEN_PROTOCOL_ID     10
#define MAX_LEN_NODE_ID         6
#define MAX_LEN_LOG_LINE        512
#define LOG_FILE_EXTENSION      ".log"
#define NAM_FILE_EXTENSION      ".nam"

//#define writeLog(...) anWriteLog(getLogInstance(), __VA_ARGS__)
#define namPosition(latitude, longitude, depth) anNamPosition(getNamInstance(), latitude, longitude, depth)
#define namEnqueue(src_id, dest_id) anNamEnqueue(getNamInstance(), (src_id), (dest_id))
#define namDequeue(src_id, dest_id) anNamDequeue(getNamInstance(), (src_id), (dest_id))
#define namDrop(src_id, dest_id) anNamDrop(getNamInstance(), (src_id), (dest_id))
#define namHop(src_id, dest_id, extent) anNamHop(getNamInstance(), (src_id), (dest_id), (extent))
#define namReceive(src_id, dest_id, extent) anNamReceive(getNamInstance(), (src_id), (dest_id), (extent))

#define LOG_EOL "\n"

#define PKT_DATA        0
#define PKT_CONTROL     1

#define log_data(data, dataLen) \
    write_data(getLogInstance(), (data), (dataLen))

#define SEND_FORMAT "SEND %c %d>%d>%d -- "
#define log_send(isCtl, src, dst, length, commentFmt, ...)      \
    write_log(getLogInstance(), SEND_FORMAT commentFmt LOG_EOL, \
              (isCtl) ? 'C':'D', (int)(src), (int)(length),     \
              (int)(dst), ##__VA_ARGS__)

#define RECV_FORMAT "RECV %c %d>%d>%d -- "
#define log_receive(isCtl, src, dst, length, commentFmt, ...)   \
    write_log(getLogInstance(), RECV_FORMAT commentFmt LOG_EOL, \
              (isCtl) ? 'C':'D', (int)(src), (int)(length),     \
              (int)(dst), ##__VA_ARGS__)

#define FRWD_FORMAT "FRWD %c %d>%d>%d->%d -- "
#define log_forward(isCtl, src, nxtHop, dst, length, commentFmt, ...)   \
    write_log(getLogInstance(), FRWD_FORMAT commentFmt LOG_EOL,         \
              (isCtl) ? 'C':'D', (int)(src), (int)(length),             \
              (int)(nxtHop), (int)(dst), ##__VA_ARGS__)

#define DROP_FORMAT "DROP %c %d>%d>%d -- "
#define log_drop(isCtl, src, dst, length, commentFmt, ...)      \
    write_log(getLogInstance(), DROP_FORMAT commentFmt LOG_EOL, \
              (isCtl) ? 'C':'D', (int)(src), (int)(length),     \
              (int)(dst), ##__VA_ARGS__)

#define DUPLICATE_FORMAT "DUPL %c %d>%d>%d -- "
#define log_duplicate(isCtl, src, dst, length, commentFmt, ...)      \
    write_log(getLogInstance(), DUPLICATE_FORMAT commentFmt LOG_EOL, \
              (isCtl) ? 'C':'D', (int)(src), (int)(length),          \
              (int)(dst), ##__VA_ARGS__)

#define INFO_FORMAT "INFO -- "
#define log_info(commentFmt, ...)                               \
    write_log(getLogInstance(), INFO_FORMAT commentFmt LOG_EOL, \
              ##__VA_ARGS__)

#define WARN_FORMAT "WARN -- "
#define log_warning(commentFmt, ...)                            \
    write_log(getLogInstance(), WARN_FORMAT commentFmt LOG_EOL, \
              ##__VA_ARGS__)

#define ERROR_FORMAT "ERRR -- "
#define log_error(commentFmt, ...)                               \
    write_log(getLogInstance(), ERROR_FORMAT commentFmt LOG_EOL, \
	      ##__VA_ARGS__)

#define RECV_SERIAL_FORMAT "SERIAL>%d "
#define log_receive_from_serial(size, commentFmt, ...)              \
    log_info(RECV_SERIAL_FORMAT commentFmt, size, ##__VA_ARGS__)

#define RECV_STACK_FORMAT "STACK>%d "
#define log_receive_from_stack(size, commentFmt, ...)           \
    log_info(RECV_STACK_FORMAT commentFmt, size, ##__VA_ARGS__)

#define SEND_SERIAL_FORMAT "%d>SERIAL "
#define log_send_to_serial(size, commentFmt, ...)                   \
    log_info(SEND_SERIAL_FORMAT commentFmt, size, ##__VA_ARGS__)

#define SEND_STACK_FORMAT "%d>STACK "
#define log_send_to_stack(size, commentFmt, ...)                \
    log_info(SEND_STACK_FORMAT commentFmt, size, ##__VA_ARGS__)

#define logSend log_send
#define logReceive log_receive
#define logForward log_forward
#define logDrop log_drop
#define logDuplicate log_duplicate
#define logInfo log_info
#define logWarning log_warning
#define logError log_error
#define logReceiveFromSerial log_receive_from_serial
#define logReceiveFromStack log_receive_from_stack
#define logSendToSerial log_send_to_serial
#define logSendToStack log_send_to_stack

/**
 * Descriptor of a log system.
 */
typedef struct {
	char protocolID[MAX_LEN_PROTOCOL_ID + 1];
	char nodeID[MAX_LEN_NODE_ID + 1];
	int logFD;
	int toScreen;
	int toFile;
} Log;

typedef struct {
	int logFD;
} Nam;

#ifdef	__cplusplus
extern "C" {
#endif

/**
 * Init the logger system (for several modules).
 *
 * @param logFolder The folder containing log files.
 * @param protocolId The identity to distinguish a protocol with another. The
 * length of this argument should be no more than MAX_LEN_PROTOCOL_ID;
 * otherwise, it will be truncated.
 * @param toFile The boolean argument determining whether logs are ouput to
 * a file or not.
 * @param toScreen The boolean argument determining whether logs are ouput to
 * screen or not.
 * @param moduleIds The ModuleId pointer argument containing the information of
 * the ID of all the modules.
 * @param lenModuleIds The int argument containing the number of modules.
 * @return TRUE, if the initialization is successful; FALSE, otherwise.
 */
	int init_logger(const char *logFolder, const char *protocolID,
			int toFile, int toScreen, ModuleId * moduleIds,
			int lenModuleIds);

	int init_log(const char *logFolder, const char *protocolID, int toFile,
		     int toScreen, ModuleId moduleIds);

/**
 * Close the logging system.
 */
	void close_logger(void);

	int logger_set_node_id(int macId, int netId);

	int logger_get_node_id();

	int core_get_port();

/**
 * Write a log message.
 * @param log The descriptor of the logging system.
 * @param fmt Similar to that of printf().
 */
	void write_log(Log * log, const char *fmt, ...);
	void write_short_log(Log * log, const char *fmt, ...);
	void write_data(Log * log, const char *data, int dataLen);

	int initANLog(const char *logFolder, const char *protocolID, int toFile,
		      int toScreen);
	void freeANLog();
	Log *getLogInstance();
	void anWriteLog(Log * log, const char *fmt, ...);

	int initANNam(const char *logFolder);
	void freeANNam();
	Nam *getNamInstance();
	void anNamPosition(Nam * log, double latitude, double longitude,
			   double depth);
	void anNamEnqueue(Nam * log, int src_id, int dest_id);
	void anNamDequeue(Nam * log, int src_id, int dest_id);
	void anNamDrop(Nam * log, int src_id, int dest_id);
	void anNamHop(Nam * log, int src_id, int dest_id, int extent);
	void anNamReceive(Nam * log, int src_id, int dest_id, int extent);
#ifdef	__cplusplus
}
#endif
#endif
