#include "tdma.h"


/// @brief tdmaStart需要使用
static sealinx_timer_t timer_delay_send;
/// @brief tdmaStart需要使用
static sealinx_timer_t timer_next;

static tdmaArg g_tdmaArg;


void printCurrentTime(void *arg) 
{
    time_t rawtime;
    struct tm *timeinfo;

    int *p = (int *)arg;

    time(&rawtime);
    timeinfo = localtime(&rawtime);
    log_info("=======================================");
    log_info("\033[32m[%02d:%02d:%02d] \033[0m", timeinfo->tm_hour, timeinfo->tm_min, timeinfo->tm_sec);
    log_info("===============%d========================", *p);
}

int tdmaParamInit(uint32_t txSlotLen_tv_sec, uint32_t txSlotTotal, uint32_t txSlotNum, void (*txSlotFun)(void *), void *txSlotFunParam) 
{
    // g_tdmaArg = (tdmaArg *)malloc(sizeof(tdmaArg));
    tdmaArg *p = &g_tdmaArg;

    p->atTxSlotCallbackFun = txSlotFun;
    p->atTxSlotCallbackFunParam = txSlotFunParam;

    p->tdma.txSlotLen.tv_sec =txSlotLen_tv_sec;
    p->tdma.txSlotLen.tv_usec = 0;

    p->tdma.txSlotNum =txSlotNum ;
    p->tdma.txSlotTotal = txSlotTotal;

}

/**
 * @brief 计算当前处于哪个时隙上
 * 
 * @param slotTotal 一个周期的时隙数量（节点数量）
 * @param slotLenTime 每个时隙长度
 * @return uint32_t 
 */
uint32_t _calCurTxSlot(int slotTotal, int slotLenTime)
{
    time_t curTimestamp;
    time(&curTimestamp);

    //计算当前经总共过了多少个时隙
    int curSlot = (curTimestamp/slotLenTime);

    int curAtSlot = 0;

    //如果不是经过了整数个时隙，那么时隙加1
    if(curTimestamp%slotLenTime != 0)
    {
        curSlot += 1;
    }

    //计算当前处于周期的哪个时隙内
    int temp = curSlot%slotTotal;
    // log_info("temp:%d", temp);

    //整数的话说明处于最后一个时隙
    if(temp == 0)
    {
        curAtSlot = slotTotal;
    }
    else
    {
        curAtSlot = temp;
    }

    return curAtSlot;
}

/**
 * @brief 计算还差多久到发送数据的时隙上
 * 
 */
uint32_t _calTimeToTxMomentDelay(struct timeval slotTime)
{
    int slotLenTime = slotTime.tv_sec;

    time_t curTimestamp;
    time(&curTimestamp);
    // log_info("curTimestamp:%d", curTimestamp);

    int delay = 0;

    //如果不是经过了整数个时隙，那么时隙加1
    if(curTimestamp%slotLenTime != 0)
    {
        delay = slotLenTime - curTimestamp%slotLenTime;
    }

    return delay;
}

int tdmaStart(tdmaArg *Arg)
{
    tdmaArg *arg = Arg;

    int txSlotNum = arg->tdma.txSlotNum;//send data moment(1-2-3)   
    void(*atTxSlotCallbackFun)(void) = arg->atTxSlotCallbackFun;
    void *callbackFun = arg->atTxSlotCallbackFunParam;

    struct timeval txSlotLen = arg->tdma.txSlotLen;//一个时隙的长度，比如说10s
    int txSlotTotal = arg->tdma.txSlotTotal;//总设备数量（多少个设备就有多少个时隙 19--11--12） 3
    int slotLenTime = txSlotLen.tv_sec;

    int TimeToTxMomentDelay = _calTimeToTxMomentDelay(txSlotLen);
    int timerTonextSlotdelay = TimeToTxMomentDelay + 1;

    if(_calCurTxSlot(txSlotTotal, slotLenTime) == txSlotNum)
    {
        sealinx_timer_init(&timer_delay_send, SEALINX_TIMER_IDLE , TimeToTxMomentDelay, 0, atTxSlotCallbackFun, callbackFun);

        if(!sealinx_timer_start(&timer_delay_send))
        {
            log_info("timer_delay_send start is failed");
        }
    }

    sealinx_timer_init(&timer_next, SEALINX_TIMER_IDLE , timerTonextSlotdelay, 0, tdmaStart, &g_tdmaArg);

    if(!sealinx_timer_start(&timer_next))
    {
        log_info("timer_next start is failed");
    }
}


int TDMA_BASELINE()// void (*txSlotFun)(void *), void *txSlotFunParam)//, tdmaArg *_tdmaArg)
{
    //初始化传进来的参数
    //  tdmaParamInit(tdma);// txSlotFun, txSlotFunParam);
    
    //启动TDMA
    tdmaStart(&g_tdmaArg);
}

void TDMA_BASELINE_test(tdmaArg *_tdmaArg)
{
    TDMA_BASELINE(_tdmaArg);//5,3,2, printCurrentTime, (void *)p, _tdmaArg);
}


int main1(int argc, char **argv)
{
    tdmaArg *_tdmaArg  = (tdmaArg *)malloc(sizeof(tdmaArg));
    int *p = malloc(sizeof(int));
    *p = 31221;
    log_info("*p = %d", *p);

    TDMA_BASELINE_test(_tdmaArg);


    while(1)
    {
        sleep(5);
        log_info("+++++++++++++++++++++++");
    }


    free(_tdmaArg);
    free(p);

    return 0;
}




