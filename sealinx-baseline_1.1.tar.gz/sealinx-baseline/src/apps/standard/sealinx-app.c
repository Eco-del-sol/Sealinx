#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <signal.h>
#include <pthread.h>

#include <sys/un.h>
#include <sys/socket.h>

#include <sealinx.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>

#include "Serial.h"

typedef struct {
    unsigned int status;
    int mutex;
    pthread_mutex_t linuxMutex;
    int fdSocket;
    int type;
    char path[256];
} SocketClientMsg;

#define SOCKET_CLIENT_SATRT             0
#define SOCKET_CLIENT_INIT              1
#define SOCKET_CLIENT_RUN               2
#define SOCKET_CLIENT_CLEAR             4
#define SOCKET_CLIENT_GET_STATUS        5

#define PDU_LEN                         4096
#define MAX_CMD_BUF                     1024
#define MAX_DATA_BUF                    1200

/* define the data type: send data or request sth */
#define NORMAL_DATA                     1
#define DISTANCE                        2
#define ROUTE_TABLE                     4

/*get route tabel command macro, add by yuansong 2018-5-2*/
/* NOTE: THE  ERROR_CONTROL_MACRO means NOEMAL DATA */
#define ERROR_CONTROL_MACRO             0
#define GET_DROUTE_TABLE_REQ            1
#define GET_DROUTE_TABLE_IND            2
#define GET_MODEN_DISTANCE_REQ          3
#define GET_MODEN_DISTANCE_IND          4

/** Default log identity for this module. */
#define DEFAULT_LOG_ID "APP_SENDER"

/** Default path to the folder consisting log files.*/
#define DEFAULT_LOG_FOLDER "logs/"

/** Log identity for this module. */
char *gLogId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char *gLogFolder = DEFAULT_LOG_FOLDER;

/** File descriptor of the connection to the core. */
int g_connFd;

/** ID of the current module. */
ModuleId g_moduleId;

/** ID of the MAC module. */
ModuleId g_macId;

/** ID of the network module. */
ModuleId g_netId;

/** ID of the transport module. */
ModuleId g_transId;

/** Shared data by the core module. */
CoreSharedData *g_coreSharedData;

int g_coreSharedMemId;
int g_running;

/** Data length. */
int g_dataLength;

/** Data rate. */
float g_dataRate;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 1;

static int read_distance = 0;
static int read_route_table = 0;

static int fd_serial;
static int dest_node;

static int CMD_MODE = 0;
static int pkt_head = 0;
static int half_pkt = 0;

static char pkt_msg[MAX_DATA_BUF];
static void *socket_handle = NULL;

/**
 * Parse command line arguments.
 *
 * @param argc Number of arguments
 * @param argv The arguments
 * @return TRUE if the argument can be parse; FALSE, otherwise.
 */
static int parse_arguments(int argc, char **argv)
{
    int i = 0;
    while (i < argc) {
        char * t = argv[i];
        if (strcmp(t, "-i") == 0) {
            i++;
            if (i < argc) {
                int moduleId = strtol(argv[i], NULL, 10);
                if (moduleId > MAX_MODULE_ID || moduleId < MIN_MODULE_ID) {
                    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
                    return FALSE;
                }
                g_moduleId = moduleId;
            }
        } else if (strcmp(t, "-m") == 0) {
            i++;
            if (i < argc) {
                int macId = strtol(argv[i], NULL, 10);
                if (macId > MAX_MODULE_ID || macId < MIN_MODULE_ID) {
                    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
                    return FALSE;
                }
                g_macId = macId;
            }
        } else if (strcmp(t, "-n") == 0) {
            i++;
            if (i < argc) {
                int netId = strtol(argv[i], NULL, 10);
                if (netId > MAX_MODULE_ID || netId < MIN_MODULE_ID) {
                    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
                    return FALSE;
                }
                g_netId = netId;
            }
        } else if (strcmp(t, "-t") == 0) {
            i++;
            if (i < argc) {
                int transId = strtol(argv[i], NULL, 10);
                if (transId > MAX_MODULE_ID || transId < MIN_MODULE_ID) {
                    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
                    return FALSE;
                }
                g_transId = transId;
            }
        } else if (strcmp(t, "-f") == 0) {
            i ++;
            if (i < argc)
                gLogFile = atoi(argv[i]);
        }
        i++;
    }
    return g_moduleId >= MIN_MODULE_ID && g_moduleId <= MAX_MODULE_ID &&
            g_macId >= MIN_MODULE_ID && g_macId <= MAX_MODULE_ID &&
            g_netId >= MIN_MODULE_ID && g_netId <= MAX_MODULE_ID &&
            g_transId >= MIN_MODULE_ID && g_transId <= MAX_MODULE_ID;
}

/**
 * Print the usage of the program.
 */
static void print_usage(const char *progName)
{
    printf("USAGE: %s -i <module id> -m <mac protocol id> -n <network protocol id> "
            "-t <transport protocol id> [-f <log file outoput flag>]\n", progName);
}

#define HEX(a)  (((a)<10) ? (a)+'0' : (a) - 10 + 'A')
static int str2hex(const char *src, char *dst, int len)
{
    int i;
    unsigned char c;
    for (i = 0; i < len; i++) {
        c = (unsigned char)src[i];
        *dst++ = HEX(c>>4);
        *dst++ = HEX(c&0xF);
    }
    return 0;
}

static int hex2dec(char a)
{
    if ('0' <= a && '9' >= a)
        return a - '0';
    else if ('a' <= a && 'f' >= a)
        return a - 'a' + 10;
    else if ('A' <= a && 'F' >= a)
        return a - 'A' + 10;
    return -1;
}

static int interpret_hex_data(const char *src, char *dst, int len)
{
    int i, k = 0;
    int n = len % 2 ? len - 1 : len;
    for (i = 0; i < n - 1; i += 2) {
        int a = hex2dec(src[i]), b = hex2dec(src[i + 1]);
        if (a == -1 || b == -1)
            break;
        dst[k++] = (a << 4) | b;
    }
    return k * 2;
}

static ssize_t socket_write(int fd, char *vptr, size_t n)
{
    size_t nleft;
    ssize_t nwritten;
    char *ptr;

    ptr = vptr;
    nleft = n;
    while (nleft > 0) {
        if ((nwritten = write(fd, ptr, nleft)) <= 0) {
            if (errno == EINTR)
                nwritten = 0; /* and call write() again */
            else
                return -1; /* error */
        }
        if (errno == 5)
            return -1;
        nleft -= nwritten;
        ptr += nwritten;
    }
    return n;
}

static int  socket_read(int fdSocket, char *buf, int bufLen, int *getLen)
{
    int len = 0;
    int rtn = -1;
    len = recv(fdSocket, buf, bufLen, 0);
    if (len < 0) {
        rtn = -1;
    } else if (len == 0) {
        rtn = 0;
    } else if(len > 0) {
        *getLen = len;
        rtn = len;
    }
    return rtn;
}

static int socket_client_open (SocketClientMsg *pc)
{
    int connect_fd;
    int ret;
    static struct sockaddr_un srv_addr;
    // creat unix socket
    connect_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if (connect_fd < 0) {
        log_error("Can NOT creat socket");
        sleep(1);
        return -1;
    }
    srv_addr.sun_family = AF_UNIX;
    strcpy(srv_addr.sun_path, pc->path);
    //connect server
    ret = connect(connect_fd, (struct sockaddr*)&srv_addr, sizeof(srv_addr));
    if (ret < 0) {
        log_error("Can NOT connect server: %s", srv_addr.sun_path);
        close(connect_fd);
        sleep(1);
        return -1;
    }
    pc->fdSocket = connect_fd;
    return 0;
}

static int socket_client_slect (int fdSocket)
{
    int ret, state;
    struct timeval timeout;
    fd_set fd;

    FD_ZERO(&fd);
    FD_SET(fdSocket, &fd);

    timeout.tv_sec = 0;
    timeout.tv_usec = 1000;

    ret = select(fdSocket + 1, &fd, NULL, NULL, &timeout);
    if (ret > 0)
        state = FD_ISSET(fdSocket, &fd) ? 1 : 0;
    return ret;
}

static int socket_client_status(SocketClientMsg *pc, int type)
{
    int ret;

    if (1 == pc->mutex)
        pthread_mutex_lock(&(pc->linuxMutex));

    if (SOCKET_CLIENT_CLEAR == type)
        pc->status =  type;

    switch (pc->status) {
    case SOCKET_CLIENT_SATRT:
    case SOCKET_CLIENT_INIT:
        pc->fdSocket = -1;
        if (-1 == socket_client_open(pc)) {
            log_error("socket_client_open Error");
        } else {
            log_info("Tcp init socket");
            pc->status = SOCKET_CLIENT_RUN;
        }
        break;
    case SOCKET_CLIENT_RUN:
        break;
    case SOCKET_CLIENT_CLEAR:
        log_info("socket_client_status close %d", pc->fdSocket);
        if (-1 != pc->fdSocket) {
            close(pc->fdSocket);
            pc->fdSocket = -1;
            pc->status = SOCKET_CLIENT_SATRT;
        }
        break;
    default:
        break;
    }
    if (1 == pc->mutex)
        pthread_mutex_unlock(&pc->linuxMutex);

    return pc->status;
}

static void *socket_client_init(char *path, int type, int mutex)
{
    if (NULL == path)
        return NULL;

    SocketClientMsg *pc = malloc(sizeof(SocketClientMsg));
    if (NULL == pc)
        return NULL;

    memset(pc, 0x00, sizeof(SocketClientMsg));
    strcpy(pc->path, path);
    pc->mutex = mutex;
    pc->type = type;

    if(1 == pc->mutex)
        pthread_mutex_init(&pc->linuxMutex, NULL);

    return pc;
}

static int socket_client_clear(void *handle)
{
    if (NULL == handle)
        return -1;
    SocketClientMsg *pc = (SocketClientMsg *)handle;
    socket_client_status(pc, SOCKET_CLIENT_CLEAR);

    if (1 == pc->mutex)
        pthread_mutex_destroy(&pc->linuxMutex);

    return 0;
}

static int socket_client_read(void *handle, char *buf, int bufLen, int *getLen)
{
    if (NULL == handle)
        return -1;
    SocketClientMsg *pc = (SocketClientMsg *)handle;

    int status = -1;
    status = socket_client_status(pc, SOCKET_CLIENT_GET_STATUS);
    if (SOCKET_CLIENT_RUN == status) {
        int ret = socket_client_slect(pc->fdSocket);
        if (ret < 0) {
            socket_client_status(pc, SOCKET_CLIENT_CLEAR);
        } else if (0 == ret) {
            /* timeout, no data to read */
        } else if (ret > 0) {
            ret = socket_read(pc->fdSocket, buf, bufLen, getLen);
            if ((0 == ret) || (-1 == ret)) {
                socket_client_status(pc, SOCKET_CLIENT_CLEAR);
            } else {
                status = 0;
                *getLen = ret;
            }
        }
    }
    return status;
}

static int socket_client_write(void *handle, char *buf, int bufLen)
{
    if (NULL == handle)
        return -1;
    SocketClientMsg *pc = (SocketClientMsg *)handle;

    int status = -1;
    int ret = -1;
    status = socket_client_status(pc, SOCKET_CLIENT_GET_STATUS);
    if (SOCKET_CLIENT_RUN == status) {
        ret = socket_write(pc->fdSocket, buf, bufLen);
        if (ret < 0)
            socket_client_status(pc, SOCKET_CLIENT_CLEAR);
    }
    return ret;
}

static int send_data_down(int dest_node, char *payload)
{
    char buffer[PDU_LEN];
    memset(buffer, 0, PDU_LEN);
    int data_length = strlen(payload);
    PduBuff *pbuf = (PduBuff *) buffer;

    char *data = pbuf->pkt_data;

    memcpy(data, payload, data_length);
    /* use txmode = 1 as default */
    *(pbuf->hdr_tra.tra_data + sizeof(int)) = 1;
    pbuf->hdr_net.src_addr = g_coreSharedData->netAddr;
    pbuf->hdr_net.dst_addr = dest_node;
    pbuf->msg_len = data_length;
    pbuf->hdr_tra.service_type = g_moduleId;
    client_send_down(g_connFd, pbuf, PDU_SIZE(data_length), g_moduleId, NULL, 0);
    log_info("Sending data ... ... ...");

    return 0;
}

static int msg_request(int type)
{
    char buffer[PDU_LEN];
    memset(buffer, 0, PDU_LEN);
    PduBuff *pbuf = (PduBuff *) buffer;

    /* request distance */
    /*control id:sizeof(int), txmode:sizeof(char)*/
    memcpy(pbuf->hdr_tra.tra_data, &type, sizeof(int));
    pbuf->hdr_net.src_addr = g_coreSharedData->netAddr;
    pbuf->msg_len = 0;
    pbuf->hdr_tra.hdr_len = sizeof(TransportHeader)
                           - sizeof(pbuf->hdr_tra.tra_data)
                           + sizeof(int)
                           + sizeof(char);
    pbuf->hdr_tra.service_type = g_moduleId;
    client_send_down(g_connFd, pbuf, PDU_SIZE(0), g_moduleId, NULL, 0);
    return 0;
}

static int parse_pkt()
{
    char *token;
    int type, dest_node;
    char payload[MAX_DATA_BUF];
    memset(payload, 0, sizeof(payload));
    if (NULL != (token = strtok(pkt_msg, ":"))) {
        type = atoi(token);
        if (type == DISTANCE) {
            msg_request(GET_MODEN_DISTANCE_REQ);
            // log_info("request distance");
        } else if (type == ROUTE_TABLE) {
            msg_request(GET_DROUTE_TABLE_REQ);
            // log_info("request route table");
        } else if (type == NORMAL_DATA) {
            if (NULL != (token = strtok(NULL, ":")))
                dest_node = atoi(token);
            if (NULL != (token = strtok(NULL, ":"))) {
                interpret_hex_data(token, payload, strlen(token));
                send_data_down(dest_node, payload);
            }
        }
    }
    usleep(100000);
    return 0;
}

static int process_pkt(const char *buf, int len)
{
    int i;
    int start = 0;
    for (i = 0; i < len; i++) {
        if (buf[i] == '@') { /* get a msg header */
            if (pkt_head)
                /* already got a header which means loss the tail */
                memset(pkt_msg, 0, sizeof(pkt_msg));
            else
                pkt_head = 1;

            start = i + 1;
        } else if (buf[i] == '#') { /* get a msg tail */
            if (pkt_head) {
                if (strlen(pkt_msg) + i - start < MAX_DATA_BUF) {
                    strncat(pkt_msg, buf+start, i-start);
                    parse_pkt(pkt_msg);
                }
            }
            pkt_head = 0;
            memset(pkt_msg, 0, sizeof(pkt_msg));
        }
    }
    if (pkt_head) {
        if (strlen(pkt_msg) + len - start >= MAX_DATA_BUF)
            memset(pkt_msg, 0, sizeof(pkt_msg));

        strncat(pkt_msg, buf+start, len-start);
    }
    return 0;
}

static int process_cmd(char *buf)
{
    socket_client_write(socket_handle, buf, strlen(buf));
    return 0;
}

static void *recv_from_serial(void *param)
{
    int len = 0;
    char buf[MAX_DATA_BUF];
    while (g_running) {
        memset(buf, 0, sizeof(buf));
        if ((len = Serial_read(fd_serial, buf, MAX_DATA_BUF, 100)) <= 0) {
            usleep(100000); // 100ms
        } else {
            if (strcmp(buf, "+++A\r\n") == 0) {
                socket_client_write(socket_handle, "+++A", 4);
                CMD_MODE = 1;
                Serial_write(fd_serial, "$MMOKY,+++A\r\n", 13);
            } else if (strcmp(buf, "---A\r\n") == 0) {
                CMD_MODE = 0;
            } else {
                CMD_MODE ? process_cmd(buf) : process_pkt(buf, len);
            }
        }
    }
    return NULL;
}

static int init(char *port, int baud, char *path)
{
    int type = 0;
    ModuleId moduleIds[NUM_LAYERS];
    moduleIds[LAYER_MAC] = g_macId;
    moduleIds[LAYER_NETWORK] = g_netId;
    moduleIds[LAYER_TRANSPORT] = g_transId;
    moduleIds[LAYER_APPLICATION] = g_moduleId;

    g_running = TRUE;

    if (!init_logger(gLogFolder, gLogId, gLogFile, TRUE, moduleIds, 4)) {
        fprintf(stderr, "Unable to init the log module.");
        return FALSE;
    }

    RegistrationResponse serverResponse;

    g_connFd = client_connect(type, LAYER_APPLICATION, moduleIds, &serverResponse, NULL, 0);

    g_coreSharedMemId = serverResponse.coreShareMemId;

    log_info("Key of shared memory by the core: %d", g_coreSharedMemId);

    g_coreSharedData = (CoreSharedData *) shmat(g_coreSharedMemId, NULL, 0);
    if (g_coreSharedData == (CoreSharedData *) - 1) {
        fprintf(stderr, "Unable to attach the shared memory: %s", strerror(errno));
        return FALSE;
    }

    logger_set_node_id(g_coreSharedData->macAddr, g_coreSharedData->netAddr);
    log_info("Mac address: %d, net address: %d",
            (int) g_coreSharedData->macAddr, (int) g_coreSharedData->netAddr);

    /* serial initialize */
    if ((fd_serial = Serial_open(port, baud, 8, 'n', 1)) < 0) {
        log_error("Open serial %s error", port);
        return -1;
    }

    /* socket initialize */
    // socket_handle = socket_client_init(path, 0, 0);
    //if (!socket_handle) {
    //    log_error("Socket initialize error");
    //    return -1;
    //}
    return TRUE;
}

/** Clean up allocated resources. */
static void clean_up(void)
{
    int type = 0;
    log_info("Cleaning up ...");

    if (g_connFd > -1)
        client_close(type, g_connFd, NULL, 0);

    if (g_coreSharedData) {
        int rc = shmdt(g_coreSharedData);
        if (rc == -1)
            log_error("Unable to detach shared data: %s", strerror(errno));
    }

    if (!socket_client_clear(socket_handle))
        log_error("Unable to close socket connect");

    close_logger();
}

/**
 * Signal handler.
 *
 * @param sig Signal ID.
 */
static void signal_handler(int sig)
{
    int type = 0;
    log_info("Received signal (%d)", sig);

    g_running = FALSE;

    if (g_connFd > -1) {
        client_close(type, g_connFd, NULL, 0);
        g_connFd = -1;
    }
}

static int return_data(PduBuff *pbuf, int type)
{
    char buf[MAX_DATA_BUF];
    char payload[MAX_DATA_BUF];
    memset(buf, 0, MAX_DATA_BUF);
    memset(payload, 0, MAX_DATA_BUF);

    if (type == NORMAL_DATA) {
        str2hex(pbuf->pkt_data, buf, pbuf->msg_len);
        sprintf(payload, "@%d:%d:%s#", type, pbuf->hdr_net.src_addr, buf);
        log_info("get %d bytes from node %d", pbuf->msg_len, pbuf->hdr_net.src_addr);
    } else if (type == DISTANCE) {
        str2hex(pbuf->pkt_data, buf, pbuf->msg_len);
        sprintf(payload, "@%d:%d:%s#", type, pbuf->msg_len, buf);
        log_info("Get msg for distance");
    } else if (type == ROUTE_TABLE) {
        str2hex(pbuf->pkt_data, buf, pbuf->msg_len);
        sprintf(payload, "@%d:%d:%s#", type, pbuf->msg_len, buf);
        log_info("Get msg for route table");
    } else {
        log_error("Undefined type [%d]", type);
    }
    Serial_write(fd_serial, payload, strlen(payload));
    return 0;
}

static void process_pdu(PduBuff *pbuf)
{
    int type;
    memcpy(&type, pbuf->hdr_tra.tra_data, sizeof(int));
    switch (type) {
    case GET_DROUTE_TABLE_REQ:
        log_error("Error: Should not be GET_DROUTE_TABLE_REQ");
        break;
    case GET_DROUTE_TABLE_IND:
        return_data(pbuf, ROUTE_TABLE);
        break;
    case GET_MODEN_DISTANCE_REQ:
        log_error("Error: Should not be GET_MODEN_DISTANCE_REQ");
        break;
    case GET_MODEN_DISTANCE_IND:
        return_data(pbuf, DISTANCE);
        break;
    case ERROR_CONTROL_MACRO: /* NOTE: this means normal data */
        return_data(pbuf, NORMAL_DATA);
        break;
    default:
        log_info("Undefined Control Macro [%d]", type);
        break;
    }
}

static void *sealinx_listener(void *param)
{
    char buffer[MAX_DATA_BUF];
    InternalMessageHeader dataHeader;

    PduBuff *pbuf = (PduBuff *)buffer;

    int nBytesRead;

    while (g_running) {
        nBytesRead = client_read(g_connFd, buffer, MAX_DATA_BUF,
                &dataHeader, NULL, 0);
        if (nBytesRead == -1) {
            log_error("System error occurred");
            break;
        }
        if (nBytesRead == -2) {
            log_warning("Data was not successfully received");
            continue;
        }
        if (nBytesRead == 0) {
            logInfo("Connection closed by the core module");
            break;
        }
        if (from_lower_layer(dataHeader)) {
            log_receive(NORMAL_DATA, pbuf->hdr_mac.src_addr,
                    pbuf->hdr_mac.dst_addr, pbuf->msg_len,
                    "DATA");
            process_pdu(pbuf);
        } else if (from_upper_layer(dataHeader)) {
            log_warning("There is no layer higher than this one");
        } else {
            log_error("Packet state error");
            continue;
        }
    }
}

static void *socket_listener(void *param)
{
    int len;
    char recv_cmd[MAX_CMD_BUF];
    while (g_running) {
        len = 0;
        memset(recv_cmd, 0, MAX_CMD_BUF);
        socket_client_read(socket_handle, recv_cmd, MAX_CMD_BUF, &len);
        if (len > 0) {
            // log_info("Get cmd: %s", recv_cmd);
            Serial_write(fd_serial, recv_cmd, len);
        }
        usleep(50000); // 50ms
    }
}

int main(int argc, char **argv)
{
    atexit(clean_up);
    signal(SIGINT, signal_handler);

    char path[256] = "/home/root/soc";

    pthread_t serial_id;
    pthread_t sealinx_id;
    //pthread_t socket_id;

    if (!parse_arguments(argc, argv)) {
        print_usage(argv[0]);
        return EXIT_FAILURE;
    }

    if (!init("/dev/ttyS1", 9600, path))
        return EXIT_FAILURE;

    pthread_create(&serial_id, NULL, recv_from_serial, NULL);
    pthread_create(&sealinx_id, NULL, sealinx_listener, NULL);
    //pthread_create(&socket_id, NULL, socket_listener, NULL);

    pthread_join(serial_id, NULL);
    pthread_join(sealinx_id, NULL);
    //pthread_join(socket_id, NULL);
    return EXIT_SUCCESS;
}
