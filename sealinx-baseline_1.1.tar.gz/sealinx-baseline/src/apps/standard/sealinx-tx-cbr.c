/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * Constant rate sender.
 *
 * @author yibo, james, son
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/un.h>
#include <unistd.h>
#include <sys/select.h>
#include <err.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>
#include <sys/shm.h>
#include <sys/time.h>
#include <math.h>

#include <sealinx.h>
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>
#include <modem_info.h>

/**
 * Default log identity for this module.
 */
#define DEFAULT_LOG_ID "CBR_SENDER"

/**
 * Default path to the folder consisting log files.
 */
#define DEFAULT_LOG_FOLDER "logs/"

/** Log identity for this module. */
char * gLogId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char * gLogFolder = DEFAULT_LOG_FOLDER;

/** File descriptor of the connection to the core. */
int g_connFd;

/** ID of the current module. */
ModuleId g_moduleId;

/** ID of the MAC module. */
ModuleId g_macId;

/** ID of the network module. */
ModuleId g_netId;

/** ID of the transport module. */
ModuleId g_transId;

/**
 * Shared data by the core module.
 */
CoreSharedData *g_coreSharedData;

int g_coreSharedMemId;

int g_running;

/** Data length. */
int g_dataLength;

/** Data rate. */
float g_dataRate;

/** Destination node. */
int g_destNode;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 1;




////////////////////////////add test function for develop by yuansong 2018-5-21///////////////////////////


/*get route tabel command macro, add by yuansong 2018-5-2*/

#define ERROR_CONTROL_MACRO    0x0

#define GET_DROUTE_TABLE_REQ   0x01

#define GET_DROUTE_TABLE_IND   0x02

#define GET_MODEN_DISTANCE_REQ 0x03

#define GET_MODEN_DISTANCE_IND 0x04

////////////////////////////////////////////////////////

#define PAYLOAD_SIZE 1000

int MakeSendDataPacket()
{
	int i = 0;
	char buff[IMSG_MAX_DATA_LENGTH];

	memset(buff, 0,IMSG_MAX_DATA_LENGTH);

	PduBuff *pdu = (PduBuff*)buff;

	uint8_t txmode = -1;

	for (i=0; i<PAYLOAD_SIZE; i++)
	{
		if (i%2 == 0)
		{
			pdu->pkt_data[i] = 'A';
		}
		else
		{
			pdu->pkt_data[i] = 'B';
		}
	}

	pdu->hdr_net.src_addr = g_coreSharedData->netAddr;
	pdu->hdr_net.dst_addr = g_destNode;

	pdu->msg_len = PAYLOAD_SIZE;

	pdu->hdr_tra.hdr_len = sizeof(pdu->hdr_tra)-sizeof(pdu->hdr_tra.tra_data);
	pdu->hdr_tra.service_type = g_moduleId;

	client_send_down(g_connFd, pdu, sizeof(PduBuff), g_moduleId, NULL, 0);

	log_info("APP-CBR Send test data  in MakeSendDataPacket########");

	return 1;
}


int testcompile(int ctrl)
{

	typedef struct teststruct {
		/** Actual length of the whole header. */
			uint8_t hdr_len;
		/** ID of transport layer protocols. */
			uint8_t tra_type;
		/** Types of transport layer services. */
			uint8_t service_type;
		/** Extra data to the transport layer. */
			char tra_data[MAX_HEADER_SIZE_TRA - MIN_LENGTH_TRANS_HEADER];
	}/* __attribute__ ((__packed__)) */teststrcut;


	typedef struct packedstruct {
		/** Actual length of the whole header. */
			uint8_t hdr_len;
		/** ID of transport layer protocols. */
			uint8_t tra_type;
		/** Types of transport layer services. */
			uint8_t service_type;
		/** Extra data to the transport layer. */
			char tra_data[MAX_HEADER_SIZE_TRA - MIN_LENGTH_TRANS_HEADER];
	} __attribute__ ((__packed__)) packedstruct;



	teststrcut   test;
	packedstruct pack;

	char cc;
	cc = ctrl;
	int tmp = ctrl;
	int exdata = 0;
	memcpy(test.tra_data, &tmp, sizeof(int));

	memcpy(&exdata,test.tra_data, sizeof(int));

	log_info("APP-CBR test compile, tmp=%d, exdata=%d\r\n", tmp, exdata);


	*(test.tra_data) = cc;
	*(pack.tra_data) = cc;

	log_info("APP-CBR debug compile error,nopacked=%d, packed=%d, ctrl=%d, cc=%d in testcompile\r\n",*(int*)(test.tra_data),*(int*)(pack.tra_data), ctrl, cc);

	return 1;
}

int SendControlPacket(int ctrl)
{

	int  tmp = 0;
	char buff[IMSG_MAX_DATA_LENGTH];

	memset(buff, 0,IMSG_MAX_DATA_LENGTH);

	PduBuff *pdu = (PduBuff*)buff;

	pdu->msg_len = 0;

	pdu->hdr_net.src_addr = g_coreSharedData->netAddr;
	pdu->hdr_net.dst_addr = g_destNode;

	pdu->hdr_tra.hdr_len      = sizeof(TransportHeader)-sizeof(pdu->hdr_tra.tra_data)+sizeof(int)+sizeof(char);/*control id:sizeof(int), txmode:sizeof(char)*///add by yuansong
	pdu->hdr_tra.service_type = g_moduleId;
	tmp = ctrl;
	memcpy(pdu->hdr_tra.tra_data, &tmp, sizeof(int));

	//len  = MAX_HEADER_SIZE_TRA - MIN_LENGTH_TRANS_HEADER;
	log_info("APP-CBR send control msg ID=%d, hdr_tra.hdr_len=%d\r\n", ctrl, pdu->hdr_tra.hdr_len);

	client_send_down(g_connFd, pdu, PDU_SIZE(0), g_moduleId, NULL, 0);
	return 1;
}




int MakeSendBroadcastPacket()
{
	int i = 0;
	char buff[IMSG_MAX_DATA_LENGTH];

	memset(buff, 0,IMSG_MAX_DATA_LENGTH);

	PduBuff *pdu = (PduBuff*)buff;

	for (i=0; i<PAYLOAD_SIZE; i++)
	{
		if (i%2 == 0)
		{
			pdu->pkt_data[i] = '1';
		}
		else
		{
			pdu->pkt_data[i] = '2';
		}
	}

	pdu->hdr_net.src_addr = g_coreSharedData->netAddr;
	pdu->hdr_net.dst_addr = NET_BROADCAST_ADDR;

	pdu->msg_len = PAYLOAD_SIZE;

	pdu->hdr_tra.hdr_len = sizeof(pdu->hdr_tra)-sizeof(pdu->hdr_tra.tra_data) + sizeof(int) +sizeof(char);
	pdu->hdr_tra.service_type = g_moduleId;
	*(pdu->hdr_tra.tra_data+sizeof(int)) =  1;//set user txmode for test.

	client_send_down(g_connFd, pdu, PDU_SIZE(PAYLOAD_SIZE), g_moduleId, NULL, 0);

	log_info("APP-CBR Send broad data  in MakeSendDataPacket########\r\n");

	return 1;
}





void *TestSender(void *param)
{

	#define MAX_NUM 1
	int i = 0;
	int j = 0;
	log_info("APP-CBR Enter into TestSender function!######\r\n");
	//sleep(20);

	#if 0
	while (1) {

		MakeSendDataPacket();
		sleep(40);
	}
	#endif


	for (i=0; i<1024; i++)
	{
		MakeSendDataPacket();
		sleep(60);
	}


	//sleep(10);
   // MakeSendBroadcastPacket();

	//sleep(2);


//	SendControlPacket(GET_DROUTE_TABLE_REQ);

	//testcompile(GET_DROUTE_TABLE_REQ);

	//sleep(2);

//	SendControlPacket(GET_MODEN_DISTANCE_REQ);

	return NULL;
}


int PrintRecvCtrlPkt(PduBuff *pbuff)
{
	int tmp = 0;

	memcpy( &tmp, pbuff->hdr_tra.tra_data, sizeof(int));
	log_info("Control packet's control ID = %d", tmp);
}





/**
 * Parse command line arguments.
 *
 * @param argc Number of arguments
 * @param argv The arguments
 * @return TRUE if the argument can be parse; FALSE, otherwise.
 */
int parse_arguments(int argc, char ** argv) {
    int i = 0;
    g_destNode = -1;
    while (i < argc) {
        char * t = argv[i];
        if (strcmp(t, "-i") == 0) {
            i++;
            if (i < argc) {
                int moduleId = strtol(argv[i], NULL, 10);
                if (moduleId > MAX_MODULE_ID || moduleId < MIN_MODULE_ID) {
                    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
                    return FALSE;
                }
                g_moduleId = moduleId;
            }
        } else if (strcmp(t, "-m") == 0) {
            i++;
            if (i < argc) {
                int macId = strtol(argv[i], NULL, 10);
                if (macId > MAX_MODULE_ID || macId < MIN_MODULE_ID) {
                    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
                    return FALSE;
                }
                g_macId = macId;
            }
        } else if (strcmp(t, "-n") == 0) {
            i++;
            if (i < argc) {
                int netId = strtol(argv[i], NULL, 10);
                if (netId > MAX_MODULE_ID || netId < MIN_MODULE_ID) {
                    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
                    return FALSE;
                }
                g_netId = netId;
            }
        } else if (strcmp(t, "-t") == 0) {
            i++;
            if (i < argc) {
                int transId = strtol(argv[i], NULL, 10);
                if (transId > MAX_MODULE_ID || transId < MIN_MODULE_ID) {
                    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
                    return FALSE;
                }
                g_transId = transId;
            }
        } else if (strcmp(t, "-l") == 0) {
            i++;
            if (i < argc) {
                g_dataLength = strtol(argv[i], NULL, 10);
                if (g_dataLength <= 0) {
                    log_error("No data will be sent: invalid data length (%d)",
                            g_dataLength);
                    g_dataLength = 0;
                } else if (g_dataLength > IMSG_MAX_DATA_LENGTH) {
                    log_error("Only %d bytes in each chunk be sent",
                            IMSG_MAX_DATA_LENGTH);
                    g_dataLength = IMSG_MAX_DATA_LENGTH;
                }
            }
        } else if (strcmp(t, "-r") == 0) {
            i++;
            if (i < argc) {
                g_dataRate = atof(argv[i]);
                if (g_dataRate <= 0) {
                    log_error("No data will be sent: invalid data rate (%f)",
                            g_dataRate);
                    g_dataRate = 0;
                } else if (g_dataRate > 1) {
                    log_warning("Data rate (%f) is too high",
                            g_dataRate);
                }
            }
        } else if (strcmp(t, "-d") == 0) {
            i++;
            if (i < argc) {
                g_destNode = strtol(argv[i], NULL, 10);
            }
        } else if (strcmp(t, "-f") == 0) {
	    i ++;
	    if (i < argc) {
		gLogFile = atoi(argv[i]);
	    }
	}
        i++;
    }
    return g_moduleId >= MIN_MODULE_ID && g_moduleId <= MAX_MODULE_ID &&
            g_macId >= MIN_MODULE_ID && g_macId <= MAX_MODULE_ID &&
            g_netId >= MIN_MODULE_ID && g_netId <= MAX_MODULE_ID &&
            g_transId >= MIN_MODULE_ID && g_transId <= MAX_MODULE_ID;
}

/**
 * Print the usage of the program.
 */
void print_usage(const char *progName) {
    printf("USAGE: %s -i <module id> -m <mac protocol id> -n <network protocol id> "
            "-t <transport protocol id> "
            "-l <data length> -r <data rate> -d <dest node> [-f <log file outoput flag>]\n",
            progName);
}

/**
 * Initialize the program.
 */
int init(void) {
    int type = 0;
    ModuleId moduleIds[NUM_LAYERS];
    moduleIds[LAYER_MAC] = g_macId;
    moduleIds[LAYER_NETWORK] = g_netId;
    moduleIds[LAYER_TRANSPORT] = g_transId;
    moduleIds[LAYER_APPLICATION] = g_moduleId;

    g_running = TRUE;

    if (!init_logger(gLogFolder, gLogId, gLogFile, TRUE, moduleIds, 4)) {
        fprintf(stderr, "Unable to init the log module.");
        return FALSE;
    }

    RegistrationResponse serverResponse;

    g_connFd = client_connect(type, LAYER_APPLICATION, moduleIds, &serverResponse, NULL, 0);

    g_coreSharedMemId = serverResponse.coreShareMemId;

    log_info("Key of shared memory by the core: %d", g_coreSharedMemId);

    g_coreSharedData = (CoreSharedData *) shmat(g_coreSharedMemId, NULL, 0);
    if (g_coreSharedData == (CoreSharedData *) - 1) {
        fprintf(stderr, "Unable to attach the shared memory: %s",
                strerror(errno));
        return FALSE;
    }

    logger_set_node_id(g_coreSharedData->macAddr, g_coreSharedData->netAddr);
    log_info("Mac address: %d, net address: %d",
            (int) g_coreSharedData->macAddr, (int) g_coreSharedData->netAddr);
    return TRUE;
}

/**
 * Signal handler.
 *
 * @param sig Signal ID.
 */
void signal_handler(int sig) {
    int type = 0;
    log_info("Received signal (%d)", sig);

    g_running = FALSE;

    if (g_connFd > -1) {
        client_close(type, g_connFd, NULL, 0);
        g_connFd = -1;
    }
}

/**
 * Clean up allocated resources.
 */
void clean_up(void) {
    int type = 0;
    log_info("Cleaning up ...");

    if (g_connFd > -1) {
        client_close(type, g_connFd, NULL, 0);
    }

    if (g_coreSharedData) {
        int rc = shmdt(g_coreSharedData);
        if (rc == -1) {
            log_error("Unable to detach shared data: %s", strerror(errno));
        }
    }

    close_logger();
}

void generateSampleString(char *str, int len) {
    int i;
    char *s = str;
    char x = 'a';
    for (i = 0; i < len; i++) {
        *s = x;
        s++;
        x++;
        if (x == 'z' + 1) {
            x = 'A';
        } else if (x == 'Z' + 1) {
            x = '0';
        } else if (x == '9' + 1) {
            x = 'a';
        }
    }
}

void *sender(void *param) {
    char buffer[IMSG_MAX_DATA_LENGTH];

    PduBuff *pbuf = (PduBuff *) buffer;
    
    ModemInfo *pPhyInfo;
    pPhyInfo = (ModemInfo *)pbuf->phy;

    int seqNum = 0;
    struct timeval start, end;
    char *dataToSend = (char *) malloc(sizeof (char) * g_dataLength);
    generateSampleString(dataToSend, g_dataLength);

    while (g_running) {
        gettimeofday(&start, NULL);

        char *data = pbuf->pkt_data;

        int idLen = sprintf(data, "[%hu][%hu][%d] ",
                g_coreSharedData->netAddr, g_destNode, seqNum);
        int nCharLeft = g_dataLength - idLen;
        int timeLen = get_timestring_sec(data + idLen, nCharLeft);
        nCharLeft -= timeLen;

        log_send(PKT_DATA, 
                 g_coreSharedData->netAddr, 
                 g_destNode,
                 g_dataLength, 
                 "%s", data);

        memcpy(data + idLen + timeLen, dataToSend, nCharLeft);

        pbuf->hdr_net.src_addr = g_coreSharedData->netAddr;
        pbuf->hdr_net.dst_addr = g_destNode;

        pbuf->msg_len = g_dataLength;
        pbuf->hdr_tra.service_type = g_moduleId;
        
		pPhyInfo->type = Modem_Info_Tx;
	    pPhyInfo->tx.phy_param.dst  = -1;
	    pPhyInfo->tx.phy_param.src  = -1;
	    pPhyInfo->tx.phy_param.mode = 1;
	    pPhyInfo->tx.phy_param.dst  = Modem_Type_DATA;
	    pPhyInfo->tx.phy_param.guard_time  = -1;
	    pPhyInfo->tx.phy_param.power_level = -1;
		
        client_send_down(g_connFd, pbuf, sizeof(PduBuff), g_moduleId, NULL, 0);

        gettimeofday(&end, NULL);
        int timeDiff = end.tv_sec - start.tv_sec;
        seqNum++;

        int sleepTime = (int) ceil(1 / g_dataRate);
        log_info("Sleep for %d seconds", sleepTime);
        sleepTime -= timeDiff;
        if (sleepTime > 0) {
            sleep(sleepTime);
        }
    }
    free(dataToSend);

    return NULL;
}

void start_listener(void) {
    char buffer[IMSG_MAX_DATA_LENGTH];
    InternalMessageHeader dataHeader;

    PduBuff *pbuf = (PduBuff *) buffer;

    int totalDataSize = 0, nBytesRead;
    struct timeval start, now;
    gettimeofday(&start, NULL);

	log_info("###Enter int APP-CBR start_listener####\r\n");
    while (g_running)
	{
        nBytesRead = client_read(g_connFd, buffer, IMSG_MAX_DATA_LENGTH,
                &dataHeader, NULL, 0);

        if (nBytesRead == -1) {
            log_error("System error occurred");
            break;
        }

        if (nBytesRead == -2) {
            log_warning("Data was not successfully received");
            continue;
        }

        if (nBytesRead == 0) {
            logInfo("Connection closed by the core module");
            break;
        }

        if (from_lower_layer(dataHeader))
		{
			log_info("###APP-CBR Receive data from tra layer in start_listener####\r\n");

			if (pbuf->hdr_tra.hdr_len > 3)//add by yuansong 2018-5-31 for test object.
			{
				PrintRecvCtrlPkt(pbuf);
			}

            log_receive(PKT_DATA, pbuf->hdr_mac.src_addr,pbuf->hdr_mac.dst_addr, pbuf->msg_len,"DATA");
            totalDataSize += pbuf->msg_len;
            gettimeofday(&now, NULL);
            float time_diff = now.tv_sec - start.tv_sec;
            float throughput = (float) totalDataSize * 8 / time_diff;
            log_info("Throughput = %.2f bps", throughput);
        }
		else if (from_upper_layer(dataHeader))
		{
            log_warning("There is no layer higher than this one");
        }
		else
		{
            log_error("Packet state error");
            continue;
        }
    }
}

/**
 * Main program.
 *
 * @param argc Number of parameters.
 * @param argv Array of parameters.
 */
int main(int argc, char ** argv) {

	//log_info("Enter APP-CBR main function##############\r\n");///add by yuansong 2018-5-23
	atexit(clean_up);
    signal(SIGINT, signal_handler);
    if (!parse_arguments(argc, argv)) {
        print_usage(argv[0]);
        return EXIT_FAILURE;
    }
    if (!init()) {
        return EXIT_FAILURE;
    }
    int isSender = g_dataRate <= 0 || g_dataLength <= 0 || g_destNode <= -1;
	log_info("APP-CBR g_dataRate=%d, g_dataLengt=%d g_destNode=%d,####\r\n", g_dataRate, g_dataLength, g_destNode);
	log_info("APP-CBR Debug isSender = %d in man function########\r\n ", isSender);

    pthread_t sendThreadId;
    if (!isSender) //for old code
  	{
		log_info("Enter branch create sender thead follow in main function#######\r\n");///add by yuansong 2018-5-23
        int error = pthread_create(&sendThreadId, NULL, sender/*TestSender*/, NULL);
        if (error != 0)
		{
			log_info("Create sender thead failed!!!!!!!  in main function#######\r\n");///add by yuansong 2018-5-23
            log_error("Create sending thread: %s", strerror(error));
        }
    }
	else
	{
        log_info("Operate in listening mode");
    }

    start_listener();


    pthread_join(sendThreadId, NULL);


    return EXIT_SUCCESS;
}
