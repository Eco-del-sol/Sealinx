#ifndef __ANG_H__
#define __ANG_H__

#include <pthread.h>
#include "StreamDelimit.h"
/**
 * Size of OFDM physical packet size.
 */
#define OFDM_PHY_PACKET_SIZE 1280

#define OFDM_MAX_CONFIG_CMD_LEN	64

typedef enum {
	OfdmType_DATA,		/* MMRXD, MMRXA */
	OfdmType_RSP,		/* MMOKY, MMERR */
	OfdmType_DEBUG,		/* Ending with terminators */
	OfdmType_ERROR
} OfdmType;

typedef struct {
	OfdmType type;
	int length;
	union {
		char data[0];	/* when type is _DATA, _DEBUG, _ERROR */
		struct {
			int success;	/* Boolean */
			int value;
			char cmd[0];	/* string */
		} rsp;
	};
} OfdmData;

//todo: struct ModemCfg

/**
 * Descriptor of a modem.
 */
typedef struct {
	int fd;
	char *serReadBuf;

	/** Serial Stream Delimitting */
	StreamDelimit *sdlmt;
	/** rsp data*/
	ListHead responses;
	/** receive data*/
	ListHead rvData;
	/** debug data*/
	ListHead debugData;
	/** Thread reading serial port and parse its stream */
	pthread_t serialThread;

	/** Mutex for reading the modem. */
	pthread_mutex_t lock;
	pthread_mutexattr_t attr;

	int initialized;
} Modem;

#ifdef	__cplusplus
extern "C" {
#endif

/**
 * Initialize the OFDM modem.
 *
 * @param fd File descriptor of the serial port connecting to the modem.
 * @param sdBufSize Size of circular buffer in StreamDelimit.
 *
 * @return Descriptor of the modem if successfully initialized; NULL, otherwise.
 */
	Modem *ofdm_init(int sdBufSize);

/**
 * Release the modem.
 *
 * @param modem Descriptor of the modem.
 */
	void ofdm_free(Modem * modem);

/**
 * Have the modem running
 *
 * @param modem Descriptor of the modem
 */
	int ofdm_run(Modem * modem);

/**
 * Init Nestlock the modem.
 *
 * @param modem Descriptor of the modem.
 */
	int ofdm_nestlock_init(Modem * modem);

/**
 * Lock the modem.
 *
 * @param modem Descriptor of the modem.
 */

	int ofdm_lock(Modem * modem);

/**
 * Unlock the modem.
 *
 * @param modem Descriptor of the modem.
 */
	int ofdm_release(Modem * modem);

/**
 * Checks if there is any delimited data
 *
 * @param modem Descriptor of the modem.
 *
 * @retval TRUE if there is delimited data.
 * @retval FALSE otherwise.
 */
//int ofdm_has_data(Modem * modem);

/**
 * Switch the modem to command mode.
 * modem Modem Descriptor
 * @return TRUE if success; FALSE, otherwise.
 */
	int ofdm_to_cmd(Modem * modem);

	int Put_DelimitOfdmData_Enlist(Modem * modem);

 /**
  * Fetch debug data from debugdata list.
  *
  * @param modem Descriptor of the modem.
  * @return Pointer to DelimitedData or NULL if there is debugdata.
  */
	DelimitedData *ofdm_fetch_debugdata(Modem * modem);
/**
 * Fetch Data from recv list.
 *
 * @param modem Descriptor of the modem.
 * @return Pointer to OfdmData or NULL if there is data.
 */
	OfdmData *ofdm_fetch_data(Modem * modem);

/**
 * Fetch rsp data from rspdata list.
 *
 * @param modem Descriptor of the modem.
 * @return Pointer to OfdmData or NULL if there is data.
 */
	OfdmData *ofdm_fetch_resp(Modem * modem);
/**
 * Transmitting acoustic packet from modem.
 * Before returnning,  MMOKY/MMTDN or MMERR must be registered.
 *
 * @param modem Descriptor of the modem
 * @param data Pointer to the data to transmit
 * @param len Length of the data to transmit
 * @return 0 if succeeded, error # from MMERR if falied
 */
	int ofdm_transmit(Modem * modem, int send_mode, char *data, int len);

/**
 * Configure modem.
 * Before returnning, MMOKY o r MMERR must be registered.
 *
 * @param modem Descriptor of the modem
 * @param reg register name string
 * @param field optional field string. NULL if not used
 * @param value Pointer to the confguration value. NULL if not used
 * @return 0 if succeeded, error # in MMERR if failed
 */
	int ofdm_configure(Modem * modem, char *reg, char *field, int *value);

/**
 * Get configuration from modem.
 * Before returnning, MMOKY o r MMERR must be registered.
 *
 * @param modem Descriptor of the modem
 * @param reg register name string
 * @param field optional field string. NULL if not used
 * @param value Pointer to configuration value.
 * @return 0 if succeeded, error # in MMERR if failed
 */
	int ofdm_get_configuration(Modem * modem, char *reg, char *field,
				   int *value);

#ifdef	__cplusplus
}
#endif
#endif				/* __OFDM_BASE_H__ */
