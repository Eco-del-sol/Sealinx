/**
  *Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
  *All rights reserved. Proprietary property of AquaSeNT LLC.
 *
  *@author yibo
 */

#ifndef __SEALINX_SFAMA_H__
#define __SEALINX_SFAMA_H__

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <err.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>
#include <sys/shm.h>

#include <sealinx.h>
#include "sealinx_pktq.h"
#include "sealinx_timer.h"
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>

/*the IDs of packets in SFAMA*/
#define SEALINX_P_SFAMA 0x0002	/* Slotted FAMA */
#define SEALINX_P_SFAMA_RTS 0x1002
#define SEALINX_P_SFAMA_CTS 0x1003
#define SEALINX_P_SFAMA_ACK 0x1004
#define SEALINX_P_SFAMA_DATA 0x1005

#define IN_ROUND 1
#define NOT_IN_ROUND 0
extern int MAX_BACKOFF_SLOT_NUM;
/*time interval is in millisecond and absolute time is in struct timeval*/

/*maximum packet in this burst*/
extern int max_burst;

struct PktSeqSet {
	int num;
	int seqnum[20];
};

struct mac_cmn_subhdr {
	unsigned short mac_type;	//type of packet
};

struct mac_data_subhdr {
	int seq;
};

struct mac_ctrl_subhdr {
	unsigned short slotnum;
};

/******************definition of slotted fama************************/
enum delay_timer_status {
	IDLE,
	FOR_RTS,
	GOT_RTS,
	FOR_CTS,
	GOT_CTS,
	FOR_DATA,
	GOT_DATA,
	FOR_ACK,		 /*GOT ACK is IDLE */
	PREPARE_BROADCAST,/*for broadcast, add by yuansong 2018-5-16*/
	BROADCASTING_DATA,/*for broadcast, add by yuansong 2018-5-16*/
	RECEIVING_BDATA,  /*for broadcast, add by yuansong 2018-5-16*/
	BACKOFF,
	BACKOFF_FAIR		/*the backoff for fair purpose, can response RTS */
};

extern unsigned short my_mac_addr;
extern double max_tx_range;
extern int band_width;
extern double sound_speed;
extern unsigned long guard_time;
extern unsigned long slot_len;	//in microsecond
//extern time_t base_time; /*the based time of synchronization*/

/*backoff if detect any carrier*/
extern sealinx_timer_t backoff_timer;
/*delay the packet sending time to the begging of a slot*/
extern sealinx_timer_t delay_timer;

/*wait for the response from the other packet*/
extern sealinx_timer_t wait_timer;

//------------draw slot line, added on 8/19/2012--------
extern sealinx_timer_t slotline_timer;

extern enum delay_timer_status sfama_status;

extern int sfama_connection_fd;
extern long SyncTxtime;		/*The transmission time of syncronization header */
extern int queue_len;		/*the number of packets in the queue */
extern int max_queue_len;	/*the maximum number of packets in the queue, if it exceeds this value, the new packet will be droped */
extern int baud_rate;		/*for evaluating the serial port delay, use 0 to denote there is no serial port used */
extern struct pkt_elem *sfama_queue_head;

extern int sfama_seqnum;	/*the sequence number of */
void *sfama_protocol();

int sfama();

void init_slot_len();

int init_sfama();
void release_sfama();

struct timeval get_interval_to_coming_slot();

/*the packet gotten from upper layer*/
void sfama_tx_process(Packet * pkt);
/*the packet gotten from lower layer*/
void sfama_recv_process(Packet * pkt);

/*if delay <0, start immediately*/
void init_handshake(struct timeval delay_time);
void do_backoff(struct timeval delay_time, int for_fair);

void pkt_set_seq(Packet * pkt, int seq);
int pkt_get_seq(Packet * pkt);
void pkt_set_slotnum(Packet * pkt, unsigned short slotnum);
unsigned short pkt_get_slotnum(Packet * pkt);

Packet *make_rts(unsigned short int resved_slot_num);
Packet *make_cts(Packet * rts_pkt, unsigned short int resved_slot_num);
Packet *make_ack();

Packet *fill_cts(Packet * pkt, unsigned short recver_addr,
		 unsigned short int resved_slot_num);
Packet *fill_rts(Packet * pkt, unsigned short recver_addr,
		 unsigned short int resved_slot_num);
Packet *fill_ack(Packet * pkt, unsigned short recver_addr);
Packet *fill_data(Packet * pkt);

void process_cts(Packet * pkt);
void process_rts(Packet * pkt);
void process_ack(Packet * pkt);
void process_data(Packet * pkt);

void send_pkt(Packet * pkt);

void cancel_delay_timer();
/*callback function when backoff_timer time out*/
void backoff_timer_process(void *arg);
/*callback function when delay_timer time out*/
void delay_timer_process(void *arg);
void wait_timer_process(void *arg);

//------------draw slot line, added on 8/19/2012--------
void slotline_timer_process(void *arg);

/*in microsecond*/
unsigned long gettxtimebylen(size_t len);
//unsigned short int getSlotNumbyTxtime(unsigned long Txtime);
unsigned long getfirstpkttxtime(size_t len);
unsigned long getfirstpkttxtime2(size_t len);
unsigned long getnxtpkttxtime(size_t len);

void set_sfama_status(enum delay_timer_status status);
enum delay_timer_status get_sfama_status();
void updata_sfama_status(unsigned short mac_type);

int is_inround();
int backoff_slot_num();

int parse_arguments(int argc, char **argv);
void print_usage(const char *progName);
void signal_handler(int sig);
void clean_up(void);

int load_cfgfile(const char *configFile);

void pkt_set_pkttype(Packet * pkt, unsigned short mac_type);
unsigned short pkt_get_pkttype(Packet * pkt);

#endif
