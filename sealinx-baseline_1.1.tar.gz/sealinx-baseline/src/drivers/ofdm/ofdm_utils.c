/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author jun, son
 */

/**
 * Ofdm Modem Physical Layer Wrapper
 * Assuming the modem initially works in online mode
 * Switching between modes would cost at least 1 second
 */

#include <sealinx.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sealinx_serial.h>
#include <sealinx_utils.h>
#include <math.h>

#include "ofdm_utils.h"

#define ONLINE_MODE 1
#define COMMAND_MODE 2
#define MODEM_TIMEOUT 10
#define NAME_LENGTH 256
#define OFDM_BUFFER_SIZE_SMALL 200

/* Set the output file name */
#define OUTPUT_FILE "./logs/sealinx-ofdm.out"

int debug_mode = FALSE;

//struct timeval timeout; /* Timeout for select */

void fillSignature(PhysicalDataPacket * pdp)
{
	pdp->signature[0] = 0x55;
	pdp->signature[1] = 0x55;

}

int verifySignature(PhysicalDataPacket * pdp)
{
	//writeLog("0x%2x 0x%2x", (int) pdp->signature[0], (int) pdp->signature[1]);
	if (pdp->signature[0] == 0x55 && pdp->signature[1] == 0x55)
		return 1;

	logError("Invalid signature (0x%2x 0x%2x )", (int)pdp->signature[0],
		 (int)pdp->signature[1]);
	return 0;
}

void generatePdu(char *bp, struct pdu_buff *pdu);

/**
 * Process the raw data read from the modem serial port.
 *
 * @param inData the raw data
 * @param inDataLen the length of the raw data
 * @param outData data extracted from the raw data. If the DATA segment is located at the start of inData and it is complete, outData will be the DATA segment and inData is shifted to the piece of information following the DATA segment.  If the DATA segment is not located at the start of inData, the piece of information in front of DATA is returned and inData is shifted so that the DATA segment is located at the start of it.
 * @param maxOutDataLen the length of data that outData can hold
 * @param outDataLen the length of the outData
 * @param numBytesLeft the length of the remaining data in inData.
 * @return FALSE if the operation failed; TRUE, otherwise.
 */
int processData(char *inData, int inDataLen, char *outData, int maxOutDataLen,
		int *outDataLen, int *numBytesLeft);

int write_to_file(const char *input, int input_size)
{
	FILE *fp = fopen(OUTPUT_FILE, "a");
	if (fp == NULL) {
		logError("failed to open the output file: %s", strerror(errno));
		return -1;
	}
	if (fwrite(input, input_size, 1, fp) < 0) {
		logError("failed to write to the output file: %s",
			 strerror(errno));
		fclose(fp);
		return -1;
	}
	fclose(fp);
	return 0;
}

// Send @len bytes of @buffer using benthos modem
// From @src to @dst
// Return the bytes sent
// or -1 on errors
int ofdm_send(int fd, char *buffer, int len, unsigned short int src,
	      unsigned short int dst)
{
	if (debug_mode == VERBOSE)
		logInfo("enter ofdm_send");
	int bytes_send = -1;

	bytes_send = serial_write(fd, buffer, len);
	if (bytes_send != len) {
		logError("%s failed to configure modem dst address",
			 __PRETTY_FUNCTION__);
		if (debug_mode == VERBOSE)
			logInfo("leave ofdm_send");
		return -1;
	}

	logSendToSerial(bytes_send, "");
	if (debug_mode == VERBOSE)
		logInfo("leave ofdm_send");
	return bytes_send;
}

// Receive data using ofdm modem
// Store into @buffer with len @bytes
// Return the bytes received
// 0 when timeout
// or -1 on errors
int ofdm_read(int fd, char *buffer, int len, int *moreData)
{
	if (debug_mode == VERBOSE)
		logInfo("enter ofdm_read");
	static char local_recv_buff[OFDM_BUFFER_SIZE];
	static int curr_size_recv_buff = 0;
	int outDataLength = 0;

	while (outDataLength == 0) {
		//memset(local_recv_buff, 0, sizeof (local_recv_buff));
		int bytes_read =
		    serial_read(fd, local_recv_buff + curr_size_recv_buff,
				sizeof(local_recv_buff) - curr_size_recv_buff);
		if (bytes_read < 0) {
			logError("%s failed: Error in receiving",
				 __PRETTY_FUNCTION__);
			curr_size_recv_buff = 0;
			if (debug_mode == VERBOSE)
				logInfo("leave ofdm_read");
			return -1;
		}

		if (bytes_read > 0) {
			if (debug_mode == VERBOSE)
				logInfo("***received %d bytes***", bytes_read);
			if (debug_mode != FALSE && bytes_read > 0)
				write_to_file(local_recv_buff +
					      curr_size_recv_buff, bytes_read);
			curr_size_recv_buff += bytes_read;
			if (processData
			    (local_recv_buff, curr_size_recv_buff, buffer, len,
			     &outDataLength, &curr_size_recv_buff) == FALSE) {
				if (debug_mode == VERBOSE)
					logInfo("leave ofdm_read");
				return 0;
			}
			//writeLog("%s outDataLength = %d, current receive buffer size = %d", __PRETTY_FUNCTION__, outDataLength, curr_size_recv_buff);
		}
	}

	/*if (outDataLength > 104 && strncmp(buffer, "\r\nDATA", 6) == 0) {
	   char dataHeader[11], dataTrailer[92];
	   dataHeader[10] = '\0';
	   dataTrailer[91] = '\0';
	   strncpy(dataHeader, buffer + 2, 10);
	   strncpy(dataTrailer, buffer + outDataLength - 91, 91);
	   writeLog("%s ... %s\n", dataHeader, dataTrailer);
	   } else {
	   writeLog("%s\n", buffer);
	   } */
	*moreData = curr_size_recv_buff;
	if (debug_mode == VERBOSE)
		logInfo("leave ofdm_read");
	return outDataLength;
}

/**
 * Process the raw data read from the modem serial port.
 *
 * @param inData the raw data
 * @param inDataLen the length of the raw data
 * @param outData data extracted from the raw data.
 *    If the DATA segment is located at the start of inData and it is complete,
 *    outData will be the DATA segment and inData is shifted to the piece of information following the DATA segment.
 *    If the DATA segment is not located at the start of inData, the piece of information in front of DATA is returned and inData is shifted so that the DATA segment is located at the start of it.
 * @param maxOutDataLen the length of data that outData can hold
 * @param outDataLen the length of the outData
 * @param numBytesLeft the length of the remaining data in inData.
 * @return FALSE if the operation failed; TRUE, otherwise.
 */
int processData(char *inData, int inDataLen, char *outData, int maxOutDataLen,
		int *outDataLen, int *numBytesLeft)
{
	if (debug_mode == VERBOSE)
		logInfo("enter processData");
	char tmp[3];
	tmp[0] = 0x55;
	tmp[1] = 0x55;
	tmp[2] = 0x00;
	int n = 0;

	char *startData = strInMem(inData, tmp, inDataLen);

	if (inDataLen < 8) {
		*outDataLen = 0;
		*numBytesLeft = inDataLen;
		if (debug_mode == VERBOSE)
			logInfo("leave processData");
		return TRUE;
	}

	if (startData == NULL) {	//3---length of the signature
		logWarning("receive something, not our frame format, discard");
		*numBytesLeft = 0;
		if (debug_mode == VERBOSE)
			logInfo("leave processData");
		return FALSE;
	}

	if (startData != inData) {
		n = startData - inData;
		if (n > maxOutDataLen) {
			logWarning
			    ("receive buffer overflow, reset input stream");
			*numBytesLeft = 0;
			if (debug_mode == VERBOSE)
				logInfo("leave processData");
			return FALSE;
		}
		logInfo("receive %d bytes of redundancy data", n);
		memcpy(inData, startData, inDataLen - n);
		inDataLen -= n;
	}

	PhysicalDataPacket *check_length = (PhysicalDataPacket *) inData;
	if (inDataLen < (check_length->length + sizeof(PhysicalDataPacket))) {
		*outDataLen = 0;
		*numBytesLeft = inDataLen;
		if (debug_mode == VERBOSE)
			logInfo("leave processData");
		return TRUE;
	}

	memcpy(outData, inData,
	       check_length->length + sizeof(PhysicalDataPacket));
	*outDataLen = check_length->length + sizeof(PhysicalDataPacket);
	*numBytesLeft -= check_length->length + sizeof(PhysicalDataPacket) + n;
	memcpy(inData, inData + *outDataLen, *numBytesLeft);

	if (debug_mode == VERBOSE)
		logInfo("leave processData");
	return TRUE;
}

// Modem Send Interface
// Pull out the information in the @pdu structure
// and send them via OFDM Modem
// Return actual bytes sent
int modem_send2(int fd, struct pdu_buff *pdu)
{
	if (debug_mode == VERBOSE)
		logInfo("enter modem_send");
	int bytes_send;
	//int bytes_pdu; // The meaningful information in pdu
	int src_addr, dst_addr;
	int total_num = 0;	//, counter = 0;
	char local_send_buff[sizeof(struct pdu_buff) + sizeof(PhysicalDataPacket)];	//add by jun

	PhysicalDataPacket *pdp = (PhysicalDataPacket *) local_send_buff;
	char *bp = pdp->data;
	//memset(local_send_buff, 0, sizeof (local_send_buff));
/*    if (pdu->pkt_type != PACKET_OUTGOING) {
        logError("%s failed: Not an outgoing packet", __PRETTY_FUNCTION__);
        if (debug_mode == VERBOSE) logInfo("leave modem_send");
        return -1;
	}*/
	// Preparing outgoing frame in the following sequence:
	// 0x5555 : frame length : mac header : network header : transport header : payload
	// Start copying the frame header (0x5555)

	//*bp = 'U', *(bp + 1) = 'U', *(bp + 2) = ':';
	//bp += 3;
	//total_num += 3;
	fillSignature(pdp);

	// Start copying frame length
	memcpy(bp, &(pdu->msg_len), sizeof(pdu->msg_len));
	bp += sizeof(pdu->msg_len);
	total_num += sizeof(pdu->msg_len);
	// Start copying mac header
	memcpy(bp, &(pdu->hdr_mac), pdu->hdr_mac.hdr_len);
	bp += pdu->hdr_mac.hdr_len;
	total_num += pdu->hdr_mac.hdr_len;
	// Start copying network header
	*bp++ = ':';		/* Use ':' to seperate headers */
	total_num++;
	memcpy(bp, &(pdu->hdr_net), pdu->hdr_net.hdr_len);
	bp += pdu->hdr_net.hdr_len;
	total_num += pdu->hdr_net.hdr_len;
	// Start copying transport header
	*bp++ = ':';		/* Use ':' to seperate headers */
	total_num++;
	memcpy(bp, &(pdu->hdr_tra), pdu->hdr_tra.hdr_len);
	bp += pdu->hdr_tra.hdr_len;
	total_num += pdu->hdr_tra.hdr_len;
	// Start copying data payload
	*bp++ = ':';		/* Use ':' to seperate headers and payload */
	total_num++;
	memcpy(bp, &(pdu->pkt_data), pdu->msg_len);
	bp += pdu->msg_len;
	total_num += pdu->msg_len;
	*bp++ = ':';		/* Use ':' to mark the end of payload */
	total_num++;
	// Getting destination and source phy addresses
	src_addr = pdu->hdr_mac.src_addr;
	dst_addr = pdu->hdr_mac.dst_addr;
	// Start sending the packet

	pdp->length = total_num;
	pdp->crc = sl_crc32(pdp->data, pdp->length);

	bytes_send =
	    ofdm_send(fd, (char *)pdp, total_num + sizeof(PhysicalDataPacket),
		      src_addr, dst_addr);

	if (bytes_send != total_num + sizeof(PhysicalDataPacket)) {
		logError("%s failed: benthos_send", __PRETTY_FUNCTION__);
		if (debug_mode == VERBOSE)
			logInfo("leave modem_send");
		return -1;
	}
	//  mdm_stat.num_sent += 1;
	if (debug_mode == VERBOSE)
		logInfo("leave modem_send");
	return bytes_send;
}

// Modem Receive Interface
// Copy ofdm modem received data into pdu
// Return the length of the frame
// or 0 if no data, or -1 on errors
int modem_recv(int fd, struct pdu_buff *pdu, int *moreData)
{
	if (debug_mode == VERBOSE)
		logInfo("enter modem_recv");
	static char local_recv_buff[OFDM_BUFFER_SIZE];
	static char *buffer;
	static int bufferLength = 0;

	int bytes_recv = -1;	//, src_addr = 0, dst_addr = 0;

	if (bufferLength == 0) {
		// Read from the modem
		bytes_recv =
		    ofdm_read(fd, local_recv_buff, sizeof(local_recv_buff),
			      /*& */ moreData);

		// Write everything to a output file if in DEBUG mode
		/*logInfo("Writing received data to output file, debug_mode = %d, bytes_recv = %d", debug_mode, bytes_recv);
		   if (debug_mode != FALSE && bytes_recv > 0)
		   write_to_file(local_recv_buff, bytes_recv); */

		if (bytes_recv > 0) {
			buffer = local_recv_buff;
			memcpy(buffer, local_recv_buff, bytes_recv);
			bufferLength = bytes_recv;
		} else {
			bufferLength = 0;
			*moreData = 0;
			if (debug_mode == VERBOSE)
				logInfo("leave modem_recv");
			return bytes_recv;
		}
	}

	PhysicalDataPacket *pdp = (PhysicalDataPacket *) buffer;
	if (!verifySignature(pdp)) {
		bufferLength = 0;
		*moreData = 0;
		if (debug_mode == VERBOSE)
			logInfo("leave modem_recv");
		return 0;
	}
	// consider it later
	if (pdp->length + sizeof(PhysicalDataPacket) > bufferLength
	    || pdp->crc != sl_crc32(pdp->data, pdp->length)) {
		bufferLength -= (pdp->length + sizeof(PhysicalDataPacket));	// does not make sense here
		buffer += pdp->length + sizeof(PhysicalDataPacket);	//does not make sense here
		*moreData = bufferLength > 0;
		if (debug_mode == VERBOSE)
			logInfo("leave modem_recv");
		return 0;
	}

	generatePdu(pdp->data, pdu);
	bufferLength -= (pdp->length + sizeof(PhysicalDataPacket));
	// buffer += pdp->length + sizeof(PhysicalDataPacket);
	//  *moreData = bufferLength > 0;
	if (debug_mode == VERBOSE)
		logInfo("leave modem_recv");
	return pdp->length;
}

void generatePdu(char *bp, struct pdu_buff *pdu)
{
	if (debug_mode == VERBOSE)
		logInfo("enter generatePdu");
	struct type_mac_hdr m_hdr;
	struct type_net_hdr n_hdr;
	struct type_tra_hdr t_hdr;
	unsigned short int header_len = 0;
	unsigned short int recv_frame_len = 0;
	// Then get the DATA length of the frame
	memcpy(&recv_frame_len, bp, sizeof(pdu->msg_len));	/* recv_frame_len is the size of DATA */
	bp += sizeof(pdu->msg_len);

	// Then copy the hearders into the pdu
	// Starting from MAC header
	memset(&m_hdr, 0, sizeof(struct type_mac_hdr));
	memcpy(&header_len, bp, sizeof(m_hdr.hdr_len));
	memcpy(&m_hdr, bp, header_len);
	memcpy(&(pdu->hdr_mac), &m_hdr, sizeof(struct type_mac_hdr));
	bp += header_len;
	bp++;			/* Jump over the ':' between MAC and NET headers */
	// Processing the NET header
	if (*bp != ':') {
		/* Meaning there is a NET header */
		memset(&n_hdr, 0, sizeof(struct type_net_hdr));
		memcpy(&header_len, bp, sizeof(n_hdr.hdr_len));
		memcpy(&n_hdr, bp, header_len);
		memcpy(&(pdu->hdr_net), &n_hdr, sizeof(struct type_net_hdr));
		bp += header_len;
	}
	bp++;			/* Jump over the ':' between NET and TRA headers */
	// Processing the TRA header
	if (*bp != ':') {
		/* Meaning there is a TRA header */
		memset(&t_hdr, 0, sizeof(struct type_tra_hdr));
		memcpy(&header_len, bp, sizeof(t_hdr.hdr_len));
		memcpy(&t_hdr, bp, header_len);
		memcpy(&(pdu->hdr_tra), &t_hdr, sizeof(struct type_tra_hdr));
		bp += header_len;
	}
	bp++;			/* Jump over the ':' between TRA header and APP payload */
	// Copy the payload into the pdu
	if (*bp != ':')		/* Meaning there is a APP payload */
		memcpy(&(pdu->pkt_data), bp, recv_frame_len);
	bp++;			/* Jump over the ':' after the APP payload */
	// Set the payload length
	pdu->msg_len = recv_frame_len;
	//pdu->pkt_type = PACKET_INCOMING;
//	pdu->pkt_state = PKT_STATE_PHY;
	if (debug_mode == VERBOSE)
		logInfo("leave generatePdu");
}
