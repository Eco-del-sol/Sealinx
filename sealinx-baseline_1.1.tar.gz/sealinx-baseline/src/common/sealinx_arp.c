/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author son
 */

#include <glib.h>
#include <stdio.h>
#include <stdlib.h>

#include "sealinx_log.h"
#include "sealinx_arp.h"

#define LINE_SIZE 100

/**
 * Read arpTable from configFile.
 * @param  fname The name of configFile to read.
 * @return arpTable if success; NULL,otherwise.
 */
ArpTable readArpTable(const char *fname)
{
	GSList *arpTable;
	FILE *f = fopen(fname, "r");
	if (f == NULL)
		return NULL;
	arpTable = NULL;
	char buffer[LINE_SIZE + 1];

	while (fgets(buffer, LINE_SIZE, f)) {
		if (buffer[0] == '#')
			continue;
		int net = -1, mac = -1;
		sscanf(buffer, "%d : %d", &net, &mac);
		if (net > 0 && mac > 0) {
			ArpEntry *entry = (ArpEntry *) malloc(sizeof(ArpEntry));
			entry->netAddr = net;
			entry->macAddr = mac;
			arpTable = g_slist_prepend(arpTable, entry);
		}
	}
	fclose(f);
	return arpTable;
}

gint arpNetComparator(gconstpointer a, gconstpointer b)
{
	ArpEntry *ea = (ArpEntry *) a;
	ArpEntry *eb = (ArpEntry *) b;
	return ea->netAddr - eb->netAddr;
}

/**
 * Get the MAC address according to the given network address.
 * @param  arpTable The given arpTable.
 * @param  netAddr  The given network address.
 * @return The MAC address if success; -1, otherwise.
 */
int getMac(ArpTable arpTable, int netAddr)
{
	if (!arpTable)
		return -1;
	ArpEntry entry;
	entry.netAddr = netAddr;
	GSList *res = g_slist_find_custom((GSList *) arpTable, &entry,
					  arpNetComparator);
	if (!res)
		return -1;

	return ((ArpEntry *) res->data)->macAddr;
}

gint arpMacComparator(gconstpointer a, gconstpointer b)
{
	ArpEntry *ea = (ArpEntry *) a;
	ArpEntry *eb = (ArpEntry *) b;
	return ea->macAddr - eb->macAddr;
}

/**
 * Get the network address according to the given MAC address.
 * @param  arpTable The given arpTable.
 * @param  macAddr  The given MAC address.
 * @return The network address if success; -1, otherwise.
 */
int getNet(ArpTable arpTable, int macAddr)
{
	if (!arpTable)
		return -1;
	ArpEntry entry;
	entry.macAddr = macAddr;

	GSList *res =
	    g_slist_find_custom((GSList *) arpTable, &entry, arpMacComparator);
	if (!res)
		return -1;

	return ((ArpEntry *) res->data)->netAddr;
}

void freeArpTable(ArpTable arpTable)
{
	if (!arpTable)
		return;
	GSList *l = (GSList *) arpTable;
	while (l) {
		if (l->data)
			free(l->data);
		l = g_slist_next(l);
	};
	g_slist_free((GSList *) arpTable);
}
