#/bin/bash

make clean

make maintainer-clean

rm INSTALL aclocal.m4 compile config.guess config.h.in config.h.in~ config.sub configure depcomp install-sh missing
rm -rf logs/ build/
find . -name Makefile.in -exec rm {} \;

