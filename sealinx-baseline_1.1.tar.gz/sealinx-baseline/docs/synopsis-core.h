/**
\page overview_page

\section overview_core_sec Core Component

The core component is responsible for dispatching data among
layers. The component waits for connections from protocol stack
layers. It can be started by running

\code
sealinx-core -p <core port>
\endcode

where <tt>\<core port\></tt> is the port that the core is listening on.

Settings for the core can be found in the file <tt>settings.ini</tt> in the same folder as where <tt>sealinx-core</tt> is running. A sample content of the file follows

\code
[General Settings]
MacAddress = 1
NetworkAddress = 1
PacketSize = 1024
\endcode

in which
 - <tt>MacAddress</tt> is the MAC address of the node
 - <tt>NetworkAddress</tt> is the Network address of the node
 - <tt>PacketSize</tt> is the maximum packet size that is transmitted between layers.
 */
