#include <inttypes.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <pthread.h>
#include "sealinx_mfifo.h"

#define is_power_of_2(x) ((x) != 0 && (((x) & ((x) - 1)) == 0))
#define min(a, b) (((a) < (b)) ? (a) : (b))

struct mfifo *mfifo_init(unsigned char *buffer, unsigned int size, pthread_mutex_t *f_lock)
{
    struct mfifo *mfifo_buf = NULL;
    if (!is_power_of_2(size)) {
        fprintf(stderr, "size must be power of 2.\n");
        return NULL;
    }
    mfifo_buf = (struct mfifo *)malloc(sizeof(struct mfifo));
    if (!mfifo_buf) {
        fprintf(stderr,"Failed to malloc memory,errno: %u, reason: %s",
                errno, strerror(errno));
        return NULL;
    }
    memset(mfifo_buf, 0, sizeof(struct mfifo));
    mfifo_buf->buffer = buffer;
    mfifo_buf->size = size;
    mfifo_buf->in = 0;
    mfifo_buf->out = 0;
    mfifo_buf->f_lock = f_lock;
    return mfifo_buf;
}

void mfifo_free(struct mfifo *mfifo_buf)
{
    if (mfifo_buf) {
        if (mfifo_buf->buffer) {
            free(mfifo_buf->buffer);
            mfifo_buf->buffer = NULL;
        }
        free(mfifo_buf);
        mfifo_buf = NULL;
    }
    return;
}

unsigned int __mfifo_len(const struct mfifo *mfifo_buf)
{
    return (mfifo_buf->in - mfifo_buf->out);
}

unsigned int __mfifo_get(struct mfifo *mfifo_buf, void *buffer, unsigned int size)
{
    unsigned int len = 0;
    size  = min(size, mfifo_buf->in - mfifo_buf->out);
    /* first get the data from fifo->out until the end of the buffer */
    len = min(size, mfifo_buf->size - (mfifo_buf->out & (mfifo_buf->size - 1)));
    memcpy(buffer, mfifo_buf->buffer + (mfifo_buf->out & (mfifo_buf->size - 1)), len);
    /* then get the rest (if any) from the beginning of the buffer */
    memcpy(buffer + len, mfifo_buf->buffer, size - len);
    mfifo_buf->out += size;
    return size;
}

unsigned int __mfifo_put(struct mfifo *mfifo_buf, void *buffer, unsigned int size)
{
    unsigned int len = 0;
    size = min(size, mfifo_buf->size - mfifo_buf->in + mfifo_buf->out);
    /* first put the data starting from fifo->in to buffer end */
    len  = min(size, mfifo_buf->size - (mfifo_buf->in & (mfifo_buf->size - 1)));
    memcpy(mfifo_buf->buffer + (mfifo_buf->in & (mfifo_buf->size - 1)), buffer, len);
    /* then put the rest (if any) at the beginning of the buffer */
    memcpy(mfifo_buf->buffer, buffer + len, size - len);
    mfifo_buf->in += size;
    return size;
}

unsigned int mfifo_len(const struct mfifo *mfifo_buf)
{
    unsigned int len = 0;
    pthread_mutex_lock(mfifo_buf->f_lock);
    len = __mfifo_len(mfifo_buf);
    pthread_mutex_unlock(mfifo_buf->f_lock);
    return len;
}

unsigned int mfifo_get(struct mfifo *mfifo_buf, void *buffer, unsigned int size)
{
    unsigned int ret;
    pthread_mutex_lock(mfifo_buf->f_lock);
    ret = __mfifo_get(mfifo_buf, buffer, size);

    if (mfifo_buf->in == mfifo_buf->out)
        mfifo_buf->in = mfifo_buf->out = 0;
    pthread_mutex_unlock(mfifo_buf->f_lock);
    return ret;
}

unsigned int mfifo_put(struct mfifo *mfifo_buf, void *buffer, unsigned int size)
{
    unsigned int ret;
    pthread_mutex_lock(mfifo_buf->f_lock);
    ret = __mfifo_put(mfifo_buf, buffer, size);
    pthread_mutex_unlock(mfifo_buf->f_lock);
    return ret;
}
