/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author yibo
 */
#ifndef __SEALINX_TIMER_H__
#define __SEALINX_TIMER_H__

#include <pthread.h>

#define MillionMicroSecond	1000000

#define SEALINX_TIMER_ERROR 0
#define SEALINX_TIMER_OK 1

enum sealinx_timer_status {
	SEALINX_TIMER_IDLE,
	SEALINX_TIMER_PENDING
};

typedef struct sealinx_timer_t {
	pthread_t tid;		/*the id of timer */
	struct timeval delay_time;
	void (*timer_call_back) (void *);
	void *arg;		/*other parameters want to
				   be transfered to callback function */
	enum sealinx_timer_status timer_status;
} sealinx_timer_t;

#ifdef	__cplusplus
extern "C" {
#endif
	int sealinx_timer_init(sealinx_timer_t * sealinx_timer,enum sealinx_timer_status status,int tv_sec,int tv_usec,void (*timer_call_back) (void *),void *arg);

	void *sealinx_timer_delay(void *arg);

	/*after delay_time, timer_call_back will be called */
	int sealinx_timer_start(sealinx_timer_t * sealinx_timer);

	enum sealinx_timer_status get_sealinx_timer_status(sealinx_timer_t *
							   sealinx_timer);

	void sealinx_timer_cancel(sealinx_timer_t * sealinx_timer);

	void timeval_add(struct timeval *result, struct timeval *t1,
			 struct timeval *t2);

	/*minuend */
	void timeval_subtract(struct timeval *result, struct timeval *minuend,
			      struct timeval *subtrahend);

	struct timeval *timeval_add_long(struct timeval *t1, unsigned long t2);
#ifdef	__cplusplus
}
#endif
#endif
