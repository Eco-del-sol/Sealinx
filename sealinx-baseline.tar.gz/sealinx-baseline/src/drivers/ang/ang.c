#include <errno.h>
#include <sys/select.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <termios.h>
#include <pthread.h>
#include <sys/select.h>
#include <semaphore.h>
#include <time.h>
#include <sealinx.h>
#include <sealinx_common.h>
#include <sealinx_utils.h>
#include "StreamDelimit.h"
#include <sealinx_serial.h>
#include "ang.h"

#define MAX_N_TOKENS 8
#define MAX_DATA_BLOCK 1024
#define cmd_append(...) snprintf(cmd+clen, OFDM_MAX_CONFIG_CMD_LEN, __VA_ARGS__)

static int hex_to_dec(char a);
static int interpret_hex_data(char *src, int len, char *dst);
static void *serial_thread(void *data);

const char *HEX_MAP = "0123456789ABCDEF";
const int MAX_PACKET_LEN[] = { 0, 608, 1280, 1952, 2624, 3968 };

struct mc_tokens {
	int n;
	struct {
		char *token;
		int len;
	} tokens[MAX_N_TOKENS];
};

/*
 * Use comma ',' to tokenize
 * tk: output */
static int tokenize(char *data, int len, struct mc_tokens *tk)
{
	int i, start;
	tk->n = 0;
	start = 0;

	for (i = 0; i < len; i++) {
		if (data[i] == ',') {
			tk->tokens[tk->n].token = &data[start];
			tk->tokens[tk->n].len = i - start;
			tk->n++;
			if (tk->n >= MAX_N_TOKENS)
				return -1;
			start = i + 1;
		}
	}
	tk->tokens[tk->n].token = &data[start];
	tk->tokens[tk->n].len = i - start;
	tk->n++;
	if (tk->n > MAX_N_TOKENS)
		return -1;

	return 0;
}

/**
 * Init Nestlock the modem.
 *
 * @param modem Descriptor of the modem.
 */
int ofdm_nestlock_init(Modem * modem)
{
	if ((pthread_mutexattr_init(&modem->attr)) != 0)
		return -1;
	pthread_mutexattr_settype(&modem->attr, PTHREAD_MUTEX_RECURSIVE);
	pthread_mutex_init(&modem->lock, &modem->attr);
	return 0;
}

/**
 * Lock the modem.
 *
 * @param modem Descriptor of the modem.
 */
int ofdm_lock(Modem * modem)
{
	pthread_mutex_lock(&modem->lock);
#ifdef DEBUG
	log_info("Lock modem");
#endif
}

/**
 * Unlock the modem.
 *
 * @param modem Descriptor of the modem.
 */
int ofdm_release(Modem * modem)
{
#ifdef DEBUG
	log_info("Release modem");
#endif
	pthread_mutex_unlock(&modem->lock);
}

int ofdm_write_wait(Modem * modem, long int sec, long int usec)
{
	fd_set set;
	struct timeval timeout;

	FD_ZERO(&set);
	FD_SET(modem->fd, &set);

	timeout.tv_sec = sec;
	timeout.tv_usec = usec;
	return select(FD_SETSIZE, NULL, &set, NULL, &timeout);
}

int ofdm_read_wait(Modem * modem, long int sec, long int usec)
{
	fd_set set;
	struct timeval timeout;

	FD_ZERO(&set);
	FD_SET(modem->fd, &set);

	timeout.tv_sec = sec;
	timeout.tv_usec = usec;
	return select(FD_SETSIZE, &set, NULL, NULL, &timeout);
}

/**
 * Converts a hexadecimal digit to a byte value.
 *
 * @param a The hexadecimal digit.
 * @return The byte value if valid; -1, otherwise.
 */
static int hex_to_dec(char a)
{
	if ('0' <= a && '9' >= a)
		return a - '0';
	else if ('a' <= a && 'f' >= a)
		return a - 'a' + 10;
	else if ('A' <= a && 'F' >= a)
		return a - 'A' + 10;

	return -1;
}

/**
 * Interprets the data part following $MMRXD.
 *
 * @param src The octet stream.
 * @param len Size of the octet stream.
 * @param dst The destination byte stream.
 *
 * @retval Length of the octet data that is interpreted.
 */
static int interpret_hex_data(char *src, int len, char *dst)
{
	int i, k = 0;
	int n = len % 2 ? len - 1 : len;

	for (i = 0; i < n - 1; i += 2) {
		int a = hex_to_dec(src[i]), b = hex_to_dec(src[i + 1]);
		if (a == -1 || b == -1) {
			break;
		}
		dst[k++] = (a << 4) | b;
	}
	return k * 2;
}

/*
 * The DEBUG information of an ofdm packet is splitted into several
 * delimited data (multiple lines). So we need to combine the delimited
 * data into one or pick up information as needed
 */

static DelimitedData *process_debug(DelimitedData * dd)
{
#define WAIT_FOR_START 	0
#define WAIT_FOR_END 	1
#define FILTER		2
	static int state = WAIT_FOR_START;
	static DelimitedData *target;
	int found, failed;

	switch (state) {
	case WAIT_FOR_START:
		target = NULL;
		found = !strncmp(dd->buf, "CPSYNC:", 7);	//todo: find "CPSYNC:"
		if (!found)
			break;
		failed = strncmp(dd->buf, "CPSYNC:FAILED", 13);	//todo: check if it is CPSYNC:FAILED
		if (!failed)
			break;
		state = FILTER;
		break;
	case FILTER:
		found = !strncmp(dd->buf, "EFFSNR:", 7);	//todo: find "EFFSNR" (risky!!)
		if (!found)
			break;
		target = dd;
		state = WAIT_FOR_END;
		return NULL;	// important!
	case WAIT_FOR_END:
		found = !strncmp(dd->buf, "ERR BLKS:", 9);	//todo: find "ERRBLK:"
		if (found) {
			free(target);
			target = NULL;
		}
		found = !strncmp(dd->buf, "CPDECODETIME:", 13);	//todo: find "CPDECODETIME"
		if (found) {
			state = WAIT_FOR_START;
			if (target) {
				//free(dd);
				return target;
			}
		}
		break;
	default:
		if (target)
			free(target);
		state = WAIT_FOR_START;
	}

	free(dd);
	return NULL;
}

/**
* process delimited data
* modem Modem Descriptor
* @return TRUE if data process, otherwise false
*/
static bool process_delimitedData(Modem * modem)
{
	DelimitedData *dd;

	dd = StreamDelimit_output(modem->sdlmt);
	if (!dd)
		return FALSE;

	if (!dd->hasHeader && dd->hasTrailer) {	/* DEBUG */
		//log_info("Discard DEBUG info from modem");
		//goto free_data;

		DelimitedData *debug = process_debug(dd);
		if (debug)
			list_add_tail(&debug->node, &modem->debugData);

	} else if (dd->hasHeader && dd->hasTrailer) {	/* Got data or responses */
		if (!strncmp(dd->buf, "$MMRXD", 6)
		    || !strncmp(dd->buf, "$MMRXA", 6)) {
			list_add_tail(&dd->node, &modem->rvData);
		} else if (!strncmp(dd->buf, "$MMOKY", 6)
			   || !strncmp(dd->buf, "$MMERR", 6)
			   || !strncmp(dd->buf, "$MMTDN,", 6)) {
			list_add_tail(&dd->node, &modem->responses);
		} else {
			log_info("Unhandled COMMAND from modem");
			goto free_data;
		}
	} else {
		log_info("Unformated/Error stream from modem: %s", dd->buf);
		goto free_data;
	}
	return TRUE;

free_data:
	free(dd);
	return TRUE;
}

static void *serial_thread(void *data)
{
	int nread;
	int ret;
	int freeLen;
	Modem *modem = (Modem *) data;

	while (1) {
		int ret = ofdm_read_wait(modem, 0, 50 * 1000);
		if (ret == 0)
			continue;
		if (ret == -1) {
			log_error("Error in reading serial port");
			break;
		}

		freeLen = CircularBuffer_getFreeLen(modem->sdlmt->cirBuf);
		nread = read(modem->fd, modem->serReadBuf, freeLen);
		StreamDelimit_input(modem->sdlmt, modem->serReadBuf, nread);

		/* stream delimit till no data left */
		while ((StreamDelimit_delimit(modem->sdlmt)) == 0) ;

		ofdm_lock(modem);
		while (process_delimitedData(modem)) ;

		ofdm_release(modem);
	}
}

/**
 * Initialize the OFDM modem.
 * @param sdBufSize Size of serReadBuf.
 *
 * @return Descriptor of the modem if successfully initialized; NULL, otherwise.
 */
Modem *ofdm_init(int sdBufSize)
{
	Modem *modem = (Modem *) malloc(sizeof(Modem));

	//todo: open serial port and create serReadBuf
	//modem->fd = Serial_open("/dev/ttyUSB0",38400,8,'n',1);
	modem->fd = serial_open();
	if (modem->fd <= 0) {
		log_error("Fail to open serial port: %s", strerror(errno));
		goto free_modem;
	}

	if (tcflush(modem->fd, TCIOFLUSH)) {
		log_error("input and output buffers flush failed");
		goto free_modem;
	}

	modem->serReadBuf = (char *)malloc(sdBufSize);
	modem->sdlmt = StreamDelimit_create(2 * sdBufSize);
	if (modem->sdlmt == NULL)
		goto free_serBuf;
	/* Initialize two lists that store modem responses and data */
	list_init(&modem->responses);
	list_init(&modem->rvData);
	list_init(&modem->debugData);
	/*Nestlock */
	if (ofdm_nestlock_init(modem) != 0)
		return NULL;
	/* add Delimiters, todo: read from configuration file */
	StreamDelimit_addDelimiters(modem->sdlmt, "$", 1, "\r\n", 2);
	/* serial thread */
	pthread_create(&modem->serialThread, NULL, serial_thread, modem);

	modem->initialized = TRUE;

	return modem;

free_serBuf:
	free(modem->serReadBuf);
free_modem:
	free(modem);
	return NULL;
}

/**
 * Release the modem.
 *
 * @param modem Descriptor of the modem.
 */
void ofdm_free(Modem * modem)
{
	DelimitedData *iter, *iter_n;

	if (!modem)
		return;

	pthread_mutex_destroy(&modem->lock);
	//free StreamDelimit
	StreamDelimit_delete(modem->sdlmt);

	list_for_each_entry_safe(iter, iter_n, &modem->responses, node) {
		free(iter);
	}
	list_for_each_entry_safe(iter, iter_n, &modem->rvData, node) {
		free(iter);
	}
	list_for_each_entry_safe(iter, iter_n, &modem->debugData, node) {
		free(iter);
	}
	if (modem->fd > -1) {
		log_info("Close modem serial port");
		serial_close(modem->fd);
	}
	free(modem->serReadBuf);
	free(modem);
}

/**
 * Have the modem running
 *
 * @param modem Descriptor of the modem
 */
int ofdm_run(Modem * modem)
{
	pthread_join(modem->serialThread, NULL);
}

/**
 * Resets parameter of an ofdm modem.
 *
 * @param modem Descriptor of the modem.
 */
void ofdm_reset(Modem * modem)
{
	//todo: reset stream delimit
	modem->initialized = FALSE;
}

/**
 * Fetch debug data from debugdata list.
 *
 * @param modem Descriptor of the modem.
 * @return Pointer to DelimitedData or NULL if there is debugdata.
 */
DelimitedData *ofdm_fetch_debugdata(Modem * modem)
{
	DelimitedData *dd;
	ofdm_lock(modem);
	//log_info("////////////////input ofdm_fetch_debugdata");
	if (list_empty(&modem->debugData)) {
		ofdm_release(modem);
		return NULL;
	}
	dd = list_first_entry(&modem->debugData, typeof(*dd), node);
	list_del(&dd->node);
	ofdm_release(modem);
	//log_info("////////////////output ofdm_fetch_debugdata");
	return dd;
}

/**
 * Fetch recv data from recvdata list.
 *
 * @param modem Descriptor of the modem.
 * @return Pointer to OfdmData or NULL if there is data.
 */
OfdmData *ofdm_fetch_data(Modem * modem)
{
	OfdmData *od;
	DelimitedData *dd;
	struct mc_tokens tokens;
	int err;
	ofdm_lock(modem);
	if (list_empty(&modem->rvData)) {
		ofdm_release(modem);
		return NULL;
	}
	dd = list_first_entry(&modem->rvData, typeof(*dd), node);
	list_del(&dd->node);
	ofdm_release(modem);

	/* convert DelimitedData to OfdmData */
	err = tokenize(dd->buf, dd->len, &tokens);
	if (err) {
		log_error("Error in tokenized delimited data");
		return NULL;
	}
	if (tokens.n != 4) {
		log_error("Format error in delimited data");
		goto error;
	}

	/* Do not include the '$' in comparison */
	if (!strncmp
	    ("MMRXD", &tokens.tokens[0].token[1], tokens.tokens[0].len - 1)) {
		/* get rid of the trailing '\r\n' */
		int payload_size = (tokens.tokens[3].len - 2) / 2;
		od = malloc(sizeof(*od) + payload_size);
		if (!od) {
			log_error("Failed to allocate memory");
			goto error;
		}
		od->type = OfdmType_DATA;
		od->length = payload_size;
		interpret_hex_data(tokens.tokens[3].token, payload_size * 2,
				   od->data);
	} else
	    if (!strncmp
		("MMRXA", &tokens.tokens[0].token[1],
		 tokens.tokens[0].len - 1)) {
		/* get rid of the trailing '\r\n' */
		int payload_size = tokens.tokens[3].len - 2;
		od = malloc(sizeof(*od) + payload_size);
		if (!od) {
			log_error("Failed to allocate memory");
			goto error;
		}
		od->type = OfdmType_DATA;
		od->length = payload_size;
		memcpy(od->data, tokens.tokens[3].token, payload_size);
	} else {
		log_error("Invalid keyword");
		goto error;
	}
	free(dd);
	return od;
error:
	free(dd);
	return NULL;
}

/**
 * Fetch rsp data from rspdata list.
 *
 * @param modem Descriptor of the modem.
 * @return Pointer to OfdmData or NULL if there is data.
 */
OfdmData *ofdm_fetch_resp(Modem * modem)
{
	OfdmData *od;
	DelimitedData *dd;
	struct mc_tokens tokens;
	int err;

	ofdm_lock(modem);
	if (list_empty(&modem->responses)) {
		ofdm_release(modem);
		return NULL;
	}
	dd = list_first_entry(&modem->responses, typeof(*dd), node);
	list_del(&dd->node);
	ofdm_release(modem);

	/* convert DelimitedData to OfdmData */
	err = tokenize(dd->buf, dd->len, &tokens);
	if (err) {
		log_error("Error in tokenized delimited data");
		return NULL;
	}

	od = malloc(sizeof(*od) + 16);	/* todo: replace the magic number for command length */
	od->type = OfdmType_RSP;
	/* no '$' in comparison */
	if (!strncmp
	    ("MMERR", &tokens.tokens[0].token[1], tokens.tokens[0].len - 1)) {
		int v = tokens.n - 1;	/* error # is the last token */
		/* Supposed to be a terminator at this location */
		tokens.tokens[v].token[tokens.tokens[v].len - 1] = 0;
		od->rsp.value = strtol(tokens.tokens[v].token, NULL, 10);

		od->rsp.success = FALSE;
	} else
	    if (!strncmp
		("MMOKY", &tokens.tokens[0].token[1],
		 tokens.tokens[0].len - 1)) {
		od->rsp.success = TRUE;
		if (tokens.n > 2) {
			if (!strncmp
			    ("HHCRR", tokens.tokens[1].token,
			     tokens.tokens[1].len)) {
				int v = tokens.n - 1;	/* value is the last token */
				/* Supposed to be a terminator at this location */
				tokens.tokens[v].token[tokens.tokens[v].len -
						       1] = 0;
				od->rsp.value =
				    strtol(tokens.tokens[v].token, NULL, 10);
			}
		}
	} else
	    if (!strncmp
		("MMTDN", &tokens.tokens[0].token[1],
		 tokens.tokens[0].len - 1)) {
		od->rsp.success = TRUE;
		/* we don't interpret the value for now */
		strcpy(od->rsp.cmd, "MMTDN");
	} else {
		log_error("Unexpected response keyword: %s",
			  tokens.tokens[0].token);
		goto free_rsp;
	}
	free(dd);
	return od;
free_rsp:
	free(dd);
	free(od);
	return NULL;
}

char *ofdm_choose_cmd(char *data, int len)
{
	int i;
	char *cmd;
	for (i = 0; i < len; i++) {
		if (data[i] < 0x20 || data[i] >= 0x7F)
			break;
	}
	cmd = i == len ? "$HHTXA" : "$HHTXD";
	return cmd;
}

char *ofdm_fill_send_buffer(char *data_block, int block_len,
			    char *cmd, int send_mode,
			    int end_packet, int *send_buffer_len)
{
	int i;
	char *send_buffer;

	send_buffer = (char *)malloc(2 * block_len + 16);
	if (end_packet)		/* the lasted data_block */
		*send_buffer_len = sprintf(send_buffer,
					   "%s,%d,%d,%d,", cmd, 0, send_mode,
					   0);
	else
		*send_buffer_len = sprintf(send_buffer, "%s", cmd);

	if (cmd == "$HHTXA") {
		memcpy(&send_buffer[*send_buffer_len], data_block, block_len);
		*send_buffer_len += block_len;
	} else {		/* cmd == "$HHTXD" */
		int c;
		for (i = block_len - 1; i >= 0; i--) {
			c = data_block[i];
			send_buffer[*send_buffer_len + i * 2 + 1] =
			    HEX_MAP[c & 15];
			send_buffer[*send_buffer_len + i * 2] =
			    HEX_MAP[(c >> 4) & 15];
		}
		*send_buffer_len += block_len * 2;
	}
	send_buffer[(*send_buffer_len)++] = '\r';
	send_buffer[(*send_buffer_len)++] = '\n';
	return send_buffer;
}

int ofdm_write_serial(Modem * modem, char *send_buffer, int send_buffer_len)
{
	OfdmData *od;
	if (ofdm_write_wait(modem, 2, 0) != 1) {
		log_info("Unable to write to modem");
		free(send_buffer);
		return -1;
	}

	ofdm_lock(modem);
	if (write(modem->fd, send_buffer, send_buffer_len) < send_buffer_len) {
		ofdm_release(modem);
		free(send_buffer);
		return -1;
	}
	ofdm_release(modem);

	/* wait for the MMOKY,HHTXx */
	int rsp_retry = 0;
	while (!(od = ofdm_fetch_resp(modem)) && (rsp_retry++ < 10))
		usleep(500000);

	if (!od->rsp.success) {
		log_error("Modem failed to register the HHTXx command");
		return -2;
	}
	rsp_retry = 0;
	while (!(od = ofdm_fetch_resp(modem)) && (rsp_retry++ < 6))
		usleep(1000000);

	if (!od->rsp.success && strcmp(od->rsp.cmd, "MMTDN")) {
		log_error("Modem failed to return the TX Done");
		return -2;
	}
	log_info("Transmission completed");

	free(od);
	return 0;
}

/*
 * Transmitting acoustic packet from modem.
 * Before returnning,  MMOKY/MMTDN or MMERR must be registered.
 *
 * @param modem Descriptor of the modem
 * @param data Pointer to the data to transmit
 * @param len Length of the data to transmit
 * @return 0 if succeeded, error # from MMERR if falied
 */
int ofdm_transmit(Modem * modem, int send_mode, char *data, int len)
{
	char *cmd;
	char *send_buffer;
	int send_buffer_len;
	int block_num;
	int end_packet;
	int i;

	// bad solution, waitting for upgrade
	send_mode = (send_mode == 0) ? 1 : send_mode;

	if (len > MAX_PACKET_LEN[send_mode]) {
		log_info("packet is too lange for mode %d", send_mode);
		return -1;
	}

	cmd = ofdm_choose_cmd(data, len);
	block_num = len / MAX_DATA_BLOCK;

	for (i = 0; i < block_num; ++i) {
		//send data block
		end_packet = 0;
		send_buffer = ofdm_fill_send_buffer(&data[i * MAX_DATA_BLOCK],
						    MAX_DATA_BLOCK, cmd,
						    send_mode, end_packet,
						    &send_buffer_len);
		ofdm_write_serial(modem, send_buffer, send_buffer_len);
	}
	end_packet = 1;
	send_buffer = ofdm_fill_send_buffer(&data[i * MAX_DATA_BLOCK],
					    len % MAX_DATA_BLOCK, cmd,
					    send_mode, end_packet,
					    &send_buffer_len);
	ofdm_write_serial(modem, send_buffer, send_buffer_len);
	return 0;
}

/**
 * Switch the modem to command mode.
 * modem Modem Descriptor
 * @return TRUE if success; FALSE, otherwise.
 */
int ofdm_to_cmd(Modem * modem)
{
	const char *cmd = "+++A\r\n";
	int cmdLen = strlen(cmd);
	OfdmData *od;
	int rsp_retry = 0;

	if (ofdm_write_wait(modem, 1, 0) != 1) {
		log_info("Unable to write to modem");
		return FALSE;
	}

	ofdm_lock(modem);
	if (write(modem->fd, cmd, cmdLen) < cmdLen) {
		ofdm_release(modem);
		return FALSE;
	}
	ofdm_release(modem);

	/* wait for the MMOKY,HHTXx */
	while (!(od = ofdm_fetch_resp(modem)))	// && (rsp_retry++ < 10))
		usleep(100000);	/* sleep for 100ms */

	if (!od->rsp.success)
		log_error("Modem failed to register +++A command");

	free(od);
	return TRUE;
}

static int build_configure_command(int rnw, char *reg, char *field, int *value,
				   char *cmd)
{
	int clen = 0;

	clen += cmd_append("$HHCR%c,%s", (!rnw) ? 'R' : 'W', reg);
	if (field)
		clen += cmd_append(",%s", field);
	if (rnw && value)
		clen += cmd_append(",%d", *value);
	/* todo: get the terminators from configuration file */
	clen += cmd_append("\r\n");

	return clen;
}

/**
 * Configure modem.
 * Before returnning, MMOKY o r MMERR must be registered.
 *
 * @param modem Descriptor of the modem
 * @param reg register name string
 * @param field optional field string. NULL if not used
 * @param value Pointer to the confguration value. NULL if not used
 * @return 0 if succeeded, error # in MMERR if failed
 */

int ofdm_configure(Modem * modem, char *reg, char *field, int *value)
{
	char cmd[OFDM_MAX_CONFIG_CMD_LEN];
	int clen;
	OfdmData *od;
	int rsp_retry = 0;

	clen = build_configure_command(1, reg, field, value, cmd);
	ofdm_lock(modem);
	if (write(modem->fd, cmd, clen) < clen) {
		log_error("Failed to write to serial");
		ofdm_release(modem);
		return -1;
	}
	ofdm_release(modem);

	while (!(od = ofdm_fetch_resp(modem)) && (rsp_retry++ < 10))
		usleep(100000);	/* sleep for 100ms */

	if (!od->rsp.success) {
		log_error("Failed to configure modem");
		free(od);
		return -2;
	}

	free(od);
	return 0;
}

/**
 * Get configuration from modem.
 * Before returnning, MMOKY o r MMERR must be registered.
 *
 * @param modem Descriptor of the modem
 * @param reg register name string
 * @param field optional field string. NULL if not used
 * @param value Pointer to configuration value.
 * @return 0 if succeeded, error # in MMERR if failed
 */

int ofdm_get_configuration(Modem * modem, char *reg, char *field, int *value)
{
	char cmd[OFDM_MAX_CONFIG_CMD_LEN];
	int clen;
	OfdmData *od;
	int rsp_retry = 0;

	clen = build_configure_command(0, reg, field, NULL, cmd);
	ofdm_lock(modem);
	if (write(modem->fd, cmd, clen) < clen) {
		log_error("Failed to write to serial");
		ofdm_release(modem);
		return -1;
	}
	ofdm_release(modem);

	while (!(od = ofdm_fetch_resp(modem)) && (rsp_retry++ < 10))
		usleep(100000);	/* sleep for 100ms */

	if (!od->rsp.success) {
		log_error("Failed to get modem configuration");
		return -2;
	}

	*value = od->rsp.value;

	free(od);
	return 0;
}
