#ifndef _SEALINX_APP_1
#define _SEALINX_APP_H

#include "sealinx-app-func.h"


/************************************宏定义************************************/

/*配置文件参数宏*/
#define PROTOCOL_PARAMS_GROUP	"Protocol Parameters"
#define APP_MODULE_ID			"app_module_id"
#define TRA_MODULE_ID			"tra_module_id"
#define NET_MODULE_ID			"net_module_id"
#define MAC_MODULE_ID			"mac_module_id"

#define GATEWAY_TXMODE_KEY		"pub_tx_mode"
#define TX_POWER_LEVEL_KEY		"pub_tx_power"
#define BAUD_KEY                "app_serial_baud"
#define PORT_KEY                "app_serial_port"
#define LOG_FILE_KEY            "app_log_flag"
#define DELAY_TIME_KEY          "app_heart_time"
#define SOCKET_FILE_KEY         "app_socket_file"
#define SEARIAL_OR_SOCKET		"app_serial_or_socket"


#define DEFAULT_LOG_FOLDER "logs/"
#define DEFAULT_LOG_ID "APP_XGD"


typedef struct app_module_config_s
{
	int32_t 		connect_fd; 			/* 客户端链接ID */
	int32_t			core_shared_mem_id;		/* 共享内存memoryID */
	CoreSharedData	*core_shared_data;		/* 共享数据 */
	int8_t 			tx_mode;				/* 数据传输模式，参考文档水声通信 */
	int8_t 			tx_power;				/*传输功率*/
	int32_t			terminal_num;			/* 记录信标的总数 */

	int32_t 		fd_serial;				/* 串口链接ID */	
	int8_t 			port[24];				/* 端口名称 */
	int32_t 		baud;					/* 波特率 */
	
	int32_t 		fd_socket;				/* socket套接字 */
	int8_t 			*socket_file;			/* socket链接文件 */
	//ipv4结构体变量
	struct sockaddr_in server_addr;
	struct sockaddr_in client_addr;
	socklen_t client_addr_len;
	
	int32_t			is_running;				/* 线程运行标志 */
	int32_t			log_file;				/* 日志文件输出标志（默认情况下，会有一个日志文件） */
	int8_t			log_id[MAX_PATH_STR_LEN];/*本模块日志ID*/
	int8_t			log_folder[MAX_PATH_STR_LEN];/*日志文件存储路径*/
	int32_t 		delay_time;				/* 心跳包线程延时时间 */
	int32_t 		judge_searial_socket;	/* 用于判断采用串口还是网口进行数据交互                   0:searial  1:socket*/
	
	ModuleId 		module_id;				/* 协议层app模块ID */
	ModuleId 		tra_module_id;			/* 协议层tra模块ID */
	ModuleId 		net_module_id;			/* 协议层net模块ID */
	ModuleId 		mac_module_id;			/* 协议层mac模块ID */

	int8_t	 		*cfg_file_name;			/* 配置文件路径 */
	
	pthread_mutex_t f_lock;					/* 线程锁 */
	uint8_t 		*fifo_buffer;			/* mfifo的buffer空间 */
	struct mfifo 	*mfifo_buf;				/* FIFO缓存区 */

	uint32_t beaconLat;						/* 纬度 */
	uint32_t beaconLon;						/* 经度 */
	uint16_t master_deep;					/* 深度 */
}app_module_config_t;



/************************************业务数据结构体************************************/

/* Data head */
typedef struct
{
    uint8_t opt;
    uint32_t checkSum;
    uint32_t dataLen;
    int8_t data[0];
} __attribute__ ((__packed__)) busi_data_head;


typedef struct
{
	uint8_t dest_id;
	uint8_t send_mode;
	uint8_t retrans_flag;
	uint8_t auto_flag;
	uint32_t timestamp;
	int8_t data[0];
}__attribute__ ((__packed__)) transparency_send_data;

typedef struct
{
	uint8_t  src_id;
	float 	 effsnr;
	uint32_t send_timestamp;
	uint32_t data_delay;
	uint32_t longitude;
	uint32_t latitude;
	uint32_t deep_value;
	int8_t 	 data[0];
}__attribute__ ((__packed__)) transparency_upload_data;



/************************************业务数据结构体end************************************/



#endif /* _SEALINX_APP_H */

