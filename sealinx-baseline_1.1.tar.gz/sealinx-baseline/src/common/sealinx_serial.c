/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author james
 */

#include <unistd.h>
#include <stdlib.h>
#include <termios.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "sealinx_log.h"
#include "sealinx_serial.h"

struct termios newtio, oldtio;

struct {
	speed_t speed;
	unsigned baud_rate;
} gBaudTable[] = {
	{
	B50, 50}, {
	B75, 75}, {
	B110, 110}, {
	B134, 134}, {
	B150, 150}, {
	B200, 200}, {
	B300, 300}, {
	B600, 600}, {
	B1200, 1200}, {
	B1800, 1800}, {
	B2400, 2400}, {
	B4800, 4800}, {
	B9600, 9600}, {
	B19200, 19200}, {
	B38400, 38400}, {
	B57600, 57600}, {
	B115200, 115200}, {
	B230400, 230400}
};
/**
 * Open the serial port, return the file descriptor 
 */
int _rm_serial_open(void)
{
	int err;
	char dev_name[40];
	char baud_str[40];
	//char port_str[40];
	speed_t baud_rate;

	memset(dev_name, 0, sizeof(dev_name));

	// Open up and read serial config file
	FILE *serial_cfg_fp = fopen(SERIAL_CONFIG_FILE, "r");
	if (serial_cfg_fp == NULL) {
		logError("Unable to open serial config file '%s': %s\n",
			 SERIAL_CONFIG_FILE, strerror(errno));
		return -1;
	}
	// Start reading line by line
	char serial_cfg_buff[SERIAL_BUFFER_SIZE];
	memset(serial_cfg_buff, 0, sizeof(serial_cfg_buff));
	while (fgets(serial_cfg_buff, sizeof(serial_cfg_buff), serial_cfg_fp)) {
		// Get rid of the trailing '\n'
		err = strlen(serial_cfg_buff) - 1;
		serial_cfg_buff[err] = '\0';
		// Ignore the lines with leading # sign
		if (serial_cfg_buff[0] == '#')
			continue;
		// Get the device path
		if (strstr(serial_cfg_buff, "/"))
			strcpy(dev_name, serial_cfg_buff);
		else {
			// Treat whatever else as baud rate
			strcpy(baud_str, serial_cfg_buff);
		}
		memset(serial_cfg_buff, 0, sizeof(serial_cfg_buff));
	}
	// Close the config file
	fclose(serial_cfg_fp);

	// Check if the baud rate is valid
	baud_rate = B0;
	if (baud_str == NULL) {
		baud_rate = B9600;
	} else {
		int baud_idx;
		int test_raud = atoi(baud_str);
		for (baud_idx = 0; baud_idx < ARRAY_LEN(gBaudTable); baud_idx++) {
			if (gBaudTable[baud_idx].baud_rate == test_raud) {
				baud_rate = gBaudTable[baud_idx].speed;
				break;
			}
		}

		if (baud_rate == B0) {
			logError("Unrecognized baud rate: '%s'\n", baud_str);
			return -1;
		}
	}

	int serial_fd;

	if ((serial_fd = open(dev_name, O_RDWR | O_EXCL)) == -1) {
		logError("Unable to open serial port '%s': %s\n", dev_name,
			 strerror(errno));
		return -1;
	}

	if (tcgetattr(serial_fd, &oldtio) == -1) {
		logError("Call to tcgetattr failed: %s\n", strerror(errno));
		return -1;
	}

	cfmakeraw(&newtio);	// Clean all settings
	cfsetispeed(&newtio, baud_rate);	// Set speed for input
	cfsetospeed(&newtio, baud_rate);	// Set speed for output
	newtio.c_cflag = (newtio.c_cflag & ~CSIZE) | CS8;	// 8 databits
	// CLOCAL - Disable modem control lines
	// CREAD  - Enable Receiver
	newtio.c_cflag |= (CLOCAL | CREAD);
	newtio.c_cflag &= ~(PARENB | PARODD);	// No parity
	newtio.c_cflag &= ~CRTSCTS;	// No hardware handshake
	newtio.c_cflag &= ~CSTOPB;	// 1 stopbit
	newtio.c_iflag = IGNBRK;
	newtio.c_iflag &= ~(IXON | IXOFF | IXANY);	// No software handshake
	newtio.c_lflag = 0;
	newtio.c_oflag = 0;
	newtio.c_cc[VTIME] = 1;
	newtio.c_cc[VMIN] = 60;

	if (tcsetattr(serial_fd, TCSANOW, &newtio) == -1) {
		logError("Call to tcsetattr failed: %s\n", strerror(errno));
		return -1;
	}
	tcflush(serial_fd, TCIOFLUSH);	// Clear IO buffer
	return serial_fd;
}
/** 
 * Close the serial port indicated by @fd 
 */
void _rm_serial_close(int fd)
{
	tcsetattr(fd, TCSANOW, &oldtio);	// Restore the configuration
	close(fd);
}

/**
 * Read from the serial port
 * Store the received data into a @buffer with @len bytes
 * Return the number of bytes read from serial port
 * Return -1 on errors 
 */

int _rm_serial_read(int fd, char *buffer, int len)
{
	int bytes_read = 0;

	fd_set input;
	FD_ZERO(&input);
	FD_SET(fd, &input);
	int max_fd = fd + 1;
	struct timeval timeout;
	timeout.tv_sec = 0;
	timeout.tv_usec = 100000;	// 0.1 second timeout

	bytes_read = select(max_fd, &input, NULL, NULL, &timeout);
	if (bytes_read == 0) {
		//puts("Oh timeout!");
		// Timeout
		return bytes_read;
	}
	if (bytes_read < 0) {
		logError("Serial port read failed: %s\n", strerror(errno));
		return -1;
	}

	/*printf("++++++++++%s fd = %d\n", __PRETTY_FUNCTION__, fd);

	   if (!FD_ISSET(fd, &input)) {
	   printf("++++++++++%s fd = %d\n", __PRETTY_FUNCTION__, fd);
	   fprintf( stderr, "Serial port read failed: %s\n", strerror( errno ));
	   return -1;
	   } */

	//char local_buff[SERIAL_BUFFER_SIZE];
	//memset(local_buff, 0, sizeof (local_buff));
	//if ((bytes_read = read(fd, local_buff, sizeof (local_buff))) < 0) {
	if ((bytes_read = read(fd, buffer, len)) == -1) {
		logError("Serial port read failed: %s\n", strerror(errno));
		return -1;
	}
	// Check if received data is larger than pdu_buff data size
	//if (bytes_read > len) {
	//    writeLog("Serial port read failed: exceed max pdu data size\n");
	//}
	// Start copying data over to pdu_buff
	// Copy data, note we should use memcpy here
	//memcpy(buffer, local_buff, bytes_read);
	//printf("serial_read: %s\n", buffer);
	return bytes_read;
}

/**
 * Write @len bytes data in @buffer to serial port
 * Return the number of bytes written to serial port
 * or -1 on errors 
 */

int _rm_serial_write(int fd, char *buffer, int len)
{
	int bytes_sent;
	char local_buff[SERIAL_BUFFER_SIZE];
	// Check if data plus header are larger than local buffer size
	if (len > sizeof(local_buff)) {
		logError("Serial port write failed: exceed max buffer size");
		return -1;
	}
	// Writing
	memset(local_buff, 0, sizeof(local_buff));
	memcpy(local_buff, buffer, len);
	if ((bytes_sent = write(fd, buffer, len)) == -1) {
		logError("%s: Failed to write to serial port: %s",
			 __PRETTY_FUNCTION__, strerror(errno));
		return -1;
	}
	if (bytes_sent < len) {
		logError("%s: Failed to write the whole buffer to serial port",
			 __PRETTY_FUNCTION__);
		return -1;
	}
	return bytes_sent;
}

/**
 * Read one NMEA format message from
 * serial port indicated by @fd
 * Return the number of bytes of the message, or -1 on error
 * Store the message in @buf which is @len long 
 */

/// Haven't tested 

int nmea_read(int fd, char *buf, int buf_len)
{
	int recv_num = 0;
	char ch;

	/* The flag to indicate if a NMEA message if received */
	int flag_cmd_start = 0;

	/* The buffer to store */
	char nmea_buffer[NMEA_BUFFER_SIZE];
	char *bp = nmea_buffer;
	memset(nmea_buffer, 0, sizeof(nmea_buffer));

	/* Prepare for select() */
	fd_set input;
	int max_fd;
	struct timeval timeout;

	while (!flag_cmd_start) {
		/* Reset the parameters of select() */
		FD_ZERO(&input);
		FD_SET(fd, &input);
		max_fd = fd + 1;
		timeout.tv_sec = SERIAL_TIMEOUT;
		timeout.tv_usec = 0;

		/* Wait for data from serial port to be available */
		if ((recv_num =
		     select(max_fd, &input, NULL, NULL, &timeout)) < 0) {
			logError("%s: select() failed: %s", __PRETTY_FUNCTION__,
				 strerror(errno));
			return -1;
		} else if (recv_num == 0) {
			logError("%s: select() on serial port timeout",
				 __PRETTY_FUNCTION__);
			printf(".");
			fflush(stdout);
			continue;
		} else
			printf("\n");

		/* Read the serial port once data are available */
		if ((recv_num = read(fd, &ch, 1)) < 0) {
			logError("%s: Serial port read failed: %s",
				 __PRETTY_FUNCTION__, strerror(errno));
			return -1;
		} else if (recv_num == 0) {
			logError
			    ("%s: Got ZERO bytes from serial port, keep reading",
			     __PRETTY_FUNCTION__);
			continue;
		} else {
			if (ch == '$') {
				/* Got the starting sign of a NMEA message */
				if (flag_cmd_start == 0) {
					/* This is start of a fresh new message */
					*bp++ = ch;
					flag_cmd_start = 1;
					continue;
				} else {
					/* Got two or more '$', should not happened */
					logError
					    ("%s: Got two or more '$', something wrong, quit...",
					     __PRETTY_FUNCTION__);
					return -1;
				}
			} else if (ch == '*') {
				/* Got the ending sign of the message */
				if (flag_cmd_start == 0) {
					/* Haven't found the start of a message, ignore it */
					continue;
				} else {
					/* Reaching the end of a message */
					/* Reset the flag */
					flag_cmd_start = 0;
					/* Break the loop without copying the '*' or reading the checksum */
					break;
				}
			} else {
				/* Got some normal characters */
				if (flag_cmd_start == 0) {
					/* Haven't found the start of a message, ignore it */
					continue;
				} else {
					/* GPS message, copy it to the buffer */
					*bp++ = ch;
					continue;
				}
			}
		}
	}			/* end of the while loop */

	/* Now we have the GPS message in the buffer
	 * copy it to the user buffer */
	if (strlen(nmea_buffer) > buf_len) {
		logError("%s: User buffer smaller than received data, quit...",
			 __PRETTY_FUNCTION__);
		return -1;
	}
	strcpy(buf, nmea_buffer);
	return strlen(buf);
}
