/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author son
 */

#ifndef __OFDM_CMD_UTILS_H__
#define __OFDM_CMD_UTILS_H__

#include <stdint.h>
#include "ofdm_base.h"

#define OFDM_BUFFER_SIZE (1024*2)

#ifndef VERBOSE
#define VERBOSE (2)		/* For extended debug mode */
#endif

/** Response type. */
/** Undefined response */
#define RESP_UNDEFINED 0
/** MMERR */
#define RESP_MMERR 1
/** MMOKY */
#define RESP_MMOKY 2
/** MMTDN */
#define RESP_MMTDN 4

/** Command execution return code */
/** System error (unrecoverable) */
#define CEXEC_SYS_ERROR (-1)
/** Completed successfully */
#define CEXEC_SUCCESS 0
/** Failed, but recoverable */
#define CEXEC_RECOVERABLE 1

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Sends a PDU.
 *
 * @param modem Descriptor of the modem.
 * @param pbuf The PDU to send
 * @return TRUE if the modem is working; FALSE, otherwise.
 */
	int ofdm_send_pdu(Modem * modem, PduBuff * pbuf);

/**
 * Switch the modem to command mode.
 *
 * @param modem Modem descriptor.
 * @return TRUE if the modem is working; FALSE, otherwise.
 */
	int ofdm_to_cmd(Modem * modem);

/**
 * Resets parameter of an ofdm modem.
 *
 * @param modem Descriptor of the modem.
 */
	void ofdm_reset(Modem * modem);

/**
 * Switches the modem to its normal operation mode.
 *
 * @param modem Descriptor of the modem
 * @return TRUE if success; FALSE, otherwise.
 */
	int ofdm_to_operation_mode(Modem * modem);

/**
 * Switches the modem to its normal operation mode (modem will be locked exclusively).
 *
 * @param modem Descriptor of the modem
 * @return TRUE if success; FALSE, otherwise.
 */
	int ofdm_to_operation_mode_lock(Modem * modem);
	int ofdm_send_pdu_locked(Modem * modem, PduBuff * pbuf);
	int ofdm_to_operation_mode_locked(Modem * modem);

#ifdef	__cplusplus
}
#endif
#endif				/* __OFDM_CMD_UTILS_H__ */
