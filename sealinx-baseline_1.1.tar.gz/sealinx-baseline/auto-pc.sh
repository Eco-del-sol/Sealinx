#!/bin/bash
echo "autoreconfig ..."
autoreconf -i --force --verbose

echo "Building PC version"
./configure --enable-debug=yes

make clean
make
make install
 
