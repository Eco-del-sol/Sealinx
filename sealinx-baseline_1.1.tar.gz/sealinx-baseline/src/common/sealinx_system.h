/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * System wide setting of SeaLinx.
 *
 * @author son
 */

#ifndef __SEALINX_SYSTEM_H__
#define __SEALINX_SYSTEM_H__

#include <stdint.h>

/**
 * Number of layers.
 */
#define NUM_LAYERS 4

/* ID of the physical layer */
#define LAYER_PHYSICAL ((LayerId) -1)

/* ID of the MAC layer */
#define LAYER_MAC ((LayerId) 0)

/* ID of the network layer */
#define LAYER_NETWORK ((LayerId) 1)

/* ID of the transport layer */
#define LAYER_TRANSPORT ((LayerId) 2)

/* ID of the application layer */
#define LAYER_APPLICATION ((LayerId) 3)

/**
 * ID of a network layer.
 */
typedef int8_t LayerId;

/**
 * ID of the core module.
 */
typedef uint16_t CoreId;

/**
 * Maximal value of a module ID.
 */
#define MAX_MODULE_ID 254

/**
 * Minimal value of a module ID.
 */
#define MIN_MODULE_ID 2

#define INVALID_MODULE_ID 0

/**
 * ID of a module on a network layer.
 */
typedef uint32_t ModuleId;

#define valid_module_id(mId) ((int32_t) (mId) >= MIN_MODULE_ID && (int32_t)(mId) <= MAX_MODULE_ID)

#define MIN_PORT_NUM 1
#define MAX_PORT_NUM 65535
#define INVALID_PORT_NUM 0
#define valid_port_num(pId) ((int32_t) (pId) >= MIN_PORT_NUM && (int32_t) (pId) <= MAX_PORT_NUM)

#ifdef __cplusplus
extern "C" {
#endif				/* __cplusplus */

#ifdef __cplusplus
}
#endif				/* __cplusplus */
#endif				/* __SEALINX_SYSTEM_H__ */
