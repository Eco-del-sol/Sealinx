#ifndef _MFIFO_H_
#define _MFIFO_H_

struct mfifo
{
    unsigned char    *buffer;    /* the buffer holding the data */
    unsigned int     size;       /* the size of the malloced buffer */
    unsigned int     in;         /* data is added at offset (in % size) */
    unsigned int     out;        /* data is extracted from off (out % size) */
    pthread_mutex_t *f_lock;     /* protects concurrent modifications */
};

struct mfifo *mfifo_init(unsigned char *buffer, unsigned int size, pthread_mutex_t *f_lock);
void mfifo_free(struct mfifo *mfifo_buf);
unsigned int __mfifo_len(const struct mfifo *mfifo_buf);
unsigned int __mfifo_get(struct mfifo *mfifo_buf, void *buffer, unsigned int size);
unsigned int __mfifo_put(struct mfifo *mfifo_buf, void *buffer, unsigned int size);
unsigned int mfifo_len(const struct mfifo *mfifo_buf);
unsigned int mfifo_get(struct mfifo *mfifo_buf, void *buffer, unsigned int size);
unsigned int mfifo_put(struct mfifo *mfifo_buf, void *buffer, unsigned int size);

#endif /* _MFIFO_H_ */
