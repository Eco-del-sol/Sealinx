/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * Sample code for the network protocol.
 *
 * @author son
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <err.h>
#include <signal.h>
#include <sys/socket.h>
#include <errno.h>
#include <sealinx.h>
#include <sys/shm.h>

#include <sealinx.h>
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>
#include <sealinx_trace.h>
#include <modem_info.h>
#include <amc.h>

#include "tdma.h"

/** Default log identity for this module. */
#define DEFAULT_LOG_ID "DUMMY_MAC"

/** Default path to the folder consisting log files. */
#define DEFAULT_LOG_FOLDER "logs/"

/** Log identity for this module. */
char *gLogId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char *gLogFolder = DEFAULT_LOG_FOLDER;

/** ID of the current module. */
ModuleId g_moduleId;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 1;

/** Shared data by the core module. */
CoreSharedData *g_coreSharedData;

/** ID of the shared memory by the core module. */
int g_coreSharedMemId;

/** File descriptor of the connection to the core. */
int g_connFd;

struct pkt_elem *data_queue;
int data_queue_len = 0;

uint32_t pktSeq = 0;

int myMacAddr;
//////////////////////////////
int txSlotLen_tv_sec;

int txSlotTotal;

int txSlotNum;
///////////////////////////////////




static void printMacHdr(PduBuff *pbuf)
{
    //    uint32_t seq;
    //    memcpy(&seq, pbuf->hdr_mac.mac_data, 4);
    log_info("Mac Hdr Len : %d", pbuf->hdr_mac.hdr_len);
    log_info("Mac Src Addr: %d", pbuf->hdr_mac.src_addr);
    log_info("Mac Dst Addr: %d", pbuf->hdr_mac.dst_addr);
    log_info("Mac ModuleId: %d", pbuf->hdr_mac.mac_type);
    //    log_info("Mac Pkt Seq : %d", seq);
    return;
}

static void printNetHdr(PduBuff *pbuf)
{
    log_info("Net Hdr Len : %d", pbuf->hdr_net.hdr_len);
    log_info("Net Src Addr: %d", pbuf->hdr_net.src_addr);
    log_info("Net Dst Addr: %d", pbuf->hdr_net.dst_addr);
    log_info("Net Next Hop: %d", pbuf->hdr_net.next_hop);
    log_info("Net ModuleId: %d", pbuf->hdr_net.net_type);
    log_info("Net Pkt Type: %d", pbuf->hdr_net.net_data[0]);
    return;
}

/**
 * Clean up allocated resources.
 */
void clean_up(void)
{
    int type = 0;
    log_info("Cleaning up ...");

    if (g_connFd > -1)
    {
        client_close(type, g_connFd, NULL, 0);
    }

    if (g_coreSharedData)
    {
        int rc = shmdt(g_coreSharedData);
        if (rc == -1)
        {
            log_error("Unable to detach shared data: %s", strerror(errno));
        }
    }

    close_logger();
}

/**
 * Signal handler.
 *
 * @param sig Signal ID.
 */
void signal_handler(int sig)
{
    int type = 0;
    log_info("Received signal (%d)", sig);

    if (g_connFd > -1)
    {
        client_close(type, g_connFd, NULL, 0);
        g_connFd = -1;
    }
}

/**
 * Parse command line arguments.
 *
 * @param argc Number of arguments
 * @param argv The arguments
 * @return TRUE if the argument can be parse; FALSE, otherwise.
 */
int parse_arguments(int argc, char **argv)
{
    int c;
    int moduleId;
    int macId;
    int netId;

    while ((c = getopt(argc, argv, "i:f:v:a:b:c")) != -1)
    {
        switch (c)
        {
        case 'i':
            moduleId = atoi(optarg);
            if (moduleId > MAX_MODULE_ID || moduleId < MIN_MODULE_ID)
            {
                fprintf(stderr, "Invalid module ID (%s)\n", optarg);
                return FALSE;
            }
            g_moduleId = moduleId;
            break;

        case 'f':
            gLogFile = atoi(optarg);
            break;

        case 'v':
            log_info("build time: %s %s", __DATE__, __TIME__);
            log_info("SEALINX_VERSION: %s", SEALINX_VERSION);
            exit(0);
        
        case 'a':
            txSlotLen_tv_sec = atoi(optarg);
            log_info("txSlotLen = %d", txSlotLen_tv_sec );

        case 'b':
            txSlotTotal = atoi(optarg);
            log_info("txSlotTotal = %d", txSlotTotal);

        case 'c':
            txSlotNum = atoi(optarg);
            log_info("txSlotNum = %d", txSlotNum);

        case '?':
            return FALSE;
        }
    }
    return g_moduleId >= MIN_MODULE_ID && g_moduleId <= MAX_MODULE_ID;
}

/**
 * Print the usage of the program.
 */
void print_usage(const char *progName)
{
    printf("USAGE: %s -i <module id> [-f <log file outoput flag>]\n",
           progName);
}

/**
 * Initialize the program.
 */
int init_mac(void)
{
    int type = 0;
    ModuleId moduleIds[NUM_LAYERS];
    moduleIds[LAYER_MAC] = g_moduleId;

    if (!init_logger(gLogFolder, gLogId, gLogFile, TRUE, moduleIds, 1))
    {
        fprintf(stderr, "Unable to init the log module.");
        return FALSE;
    }

    RegistrationResponse serverResponse;
    g_connFd = client_connect(type, LAYER_MAC, moduleIds, &serverResponse, NULL, 0);
    g_coreSharedMemId = serverResponse.coreShareMemId;
    log_info("Key of shared memory by the core: %d", g_coreSharedMemId);
    g_coreSharedData = (CoreSharedData *)shmat(g_coreSharedMemId, NULL, 0);

    if (g_coreSharedData == (CoreSharedData *)-1)
    {
        fprintf(stderr, "Unable to attach the shared memory: %s", strerror(errno));
        return FALSE;
    }

    logger_set_node_id(g_coreSharedData->macAddr, g_coreSharedData->netAddr);
    log_info("Mac address: %d, net address: %d",
             (int)g_coreSharedData->macAddr,
             (int)g_coreSharedData->netAddr);

    myMacAddr = (int)g_coreSharedData->macAddr;

    pkt_queue_init(&data_queue); // 存储中心网关发往其他终端的数据的链表

    return TRUE;
}

void sealinx_recv_from_up_process(PduBuff *pkt)
{
    if (pkt->bInternal == 1)
    {
        client_send_down(g_connFd, pkt, sizeof(PduBuff), g_moduleId, NULL, 0);
    }

    pkt->hdr_mac.mac_type = g_moduleId;
    pkt->hdr_mac.src_addr = myMacAddr;
    pkt->hdr_mac.dst_addr = pkt->hdr_net.next_hop;

    pkt_queue_insert_pkt(pkt, data_queue);
    // operatequeue_len(data_queue_len, TRUE);
}

void sealinx_recv_from_down_process(PduBuff *pkt)
{
    log_info("Get data from PHY layer");

    if (pkt->hdr_mac.dst_addr == myMacAddr || pkt->hdr_mac.dst_addr == MAC_BROADCAST_ADDR)
    {
        printNetHdr(pkt);
        printMacHdr(pkt);
        log_receive(PKT_DATA, pkt->hdr_mac.src_addr, pkt->hdr_mac.dst_addr,
                    pkt->msg_len + pkt->hdr_tra.hdr_len + pkt->hdr_net.hdr_len + pkt->hdr_mac.hdr_len, "DATA");
        client_send_up(g_connFd, pkt, sizeof(PduBuff), g_moduleId, NULL, 0);
    }
    else
    {
        log_drop(PKT_DATA, pkt->hdr_mac.src_addr, pkt->hdr_mac.dst_addr,\
                    pkt->msg_len + pkt->hdr_tra.hdr_len + pkt->hdr_net.hdr_len + pkt->hdr_mac.hdr_len, "Packet is not for me");
    }
}
 


void sealinx_recv_process()
{

    char recv_buf[IMSG_MAX_DATA_LENGTH];
    InternalMessageHeader dataHeader;
    PduBuff *pbuf = (PduBuff *)recv_buf;
    while (TRUE)
    {
        memset(recv_buf, 0, sizeof(recv_buf));

        int retCode = client_read(g_connFd, recv_buf, IMSG_MAX_DATA_LENGTH, &dataHeader, NULL, 0);
        if (retCode <= 0)
        {
            // TODO check retCode here
            break;
        }

        if (from_upper_layer(dataHeader))
        {

            /* TODO process message from upper layer */
            printNetHdr(pbuf);
            printMacHdr(pbuf);
            sealinx_recv_from_up_process(pbuf);
        }
        else if (from_lower_layer(dataHeader))
        {
            
            /* TODO process message from lower layer */
            sealinx_recv_from_down_process(pbuf);
        }
        else
        {
            log_error("Packet state error");
            continue;
        }
    }
}







void atTxSlotCallbackFun()
{
    log_info("please check get data fun of pkt_queue_get_pkt(data_queue)");
    PduBuff *pkt = (PduBuff *)malloc(sizeof(PduBuff));
    pkt = pkt_queue_get_pkt(data_queue);    //TODO: 这个函数有问题

    if(!pkt)
    {
        free(pkt);
        log_error("data_queue have no pkt");
        exit(0);
    }
    log_send(PKT_DATA, pkt->hdr_mac.src_addr, pkt->hdr_mac.dst_addr, getPktSize(pkt), "DATA");
    client_send_down(g_connFd, pkt, sizeof(PduBuff), g_moduleId, NULL, 0);

    free(pkt);
    pkt_queue_deque(data_queue);
}



/**
 * Main program.
 *
 * @param argc Number of parameters.
 * @param argv Array of parameters.
 */
int main(int argc, char **argv)
{
    atexit(clean_up);
    signal(SIGINT, signal_handler);

    if (!parse_arguments(argc, argv))
    {
        print_usage(argv[0]);
        return EXIT_FAILURE;
    }

    if (!init_mac())
        return EXIT_FAILURE;
    int *p = (int *)malloc(sizeof(int));
    *p = 4523;
    //TODO: TDMA需要填的参数//////////////////////////////////////////////////////////////
    //init tdma param
    // tdmaParamInit(5, 3, 3, printCurrentTime, p); //test

    //atTxSlotCallbackFun，注意：这回调函数里调用的从队列里获取pkt的函数pkt_queue_get_pkt()返回值有问题
    tdmaParamInit(txSlotLen_tv_sec, txSlotTotal, txSlotNum, printCurrentTime, NULL);    


    //tdma start
    TDMA_BASELINE();

    sealinx_recv_process();

    return EXIT_SUCCESS;
}
