#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <stdio.h>
#include <errno.h>
#include <glib.h>

#include "sealinx_log.h"
#include "sealinx_loadconfig.h"

int copy_string(int num, char *configFile, char *string);

/**
 * Load configFile.
 * @param  configFile The configFile to load.
 * @return TRUE, if success; FALSE, otherwise.
 */
int loadconfig(char *configFile)
{
	GKeyFile *keyFile = g_key_file_new();
	GError *error = NULL;
	int retVal = TRUE;
	int mac_num, nwk_num, trans_num, app_num;

	if (g_key_file_load_from_file(keyFile, configFile,
				      G_KEY_FILE_NONE, &error)) {

	/**Get the number from each area**/
		mac_num =
		    g_key_file_get_integer(keyFile, "MAC Layer",
					   "MAC_number", &error);
		if (error != NULL) {
			log_info("Unable to load MAC number from %s: %s",
				 configFile, error->message);
			error = NULL;
			retVal = FALSE;
		}
//      log_info("MAC_number = %d", mac_num);

		nwk_num =
		    g_key_file_get_integer(keyFile, "NWK Layer",
					   "NWK_number", &error);
		if (error != NULL) {
			log_info("Unable to load NWK number from %s: %s",
				 configFile, error->message);
			error = NULL;
			retVal = FALSE;
		}
//      log_info("NWK_number = %d", nwk_num);

		trans_num =
		    g_key_file_get_integer(keyFile, "TRANS Layer",
					   "TRANS_number", &error);
		if (error != NULL) {
			log_info("Unable to load TRANS number from %s: %s",
				 configFile, error->message);
			error = NULL;
			retVal = FALSE;
		}
//      log_info("TRANS_number = %d", trans_num);

		app_num =
		    g_key_file_get_integer(keyFile, "APP Layer",
					   "APP_number", &error);
		if (error != NULL) {
			log_info("Unable to load APP number from %s: %s",
				 configFile, error->message);
			error = NULL;
			retVal = FALSE;
		}
//      log_info("APP_number = %d", app_num);

	} else {
		log_info("Unable to load configfile %s: %s",
			 configFile, error->message);
		retVal = FALSE;
	}

	g_key_file_free(keyFile);
	int fd = open("script.sh", O_RDWR | O_CREAT | O_TRUNC, 0);
	close(fd);
	copy_string(1, configFile, "PHY");
	copy_string(mac_num, configFile, "MAC");
	copy_string(nwk_num, configFile, "NWK");
	copy_string(trans_num, configFile, "TRANS");
	copy_string(app_num, configFile, "APP");

	return retVal;
}

/**
 * Copy string to script file
 * @param  num        The layer number.
 * @param  configFile The configFile.
 * @param  string     The string to copy.
 * @return            TRUE, if success; FALSE, otherwise.
 */
int copy_string(int num, char *configFile, char *string)
{
	int retVal = TRUE;
	GKeyFile *keyFile = g_key_file_new();
	GError *error = NULL;
	char *layer, *layer_p, *level;
	char *delim = ",";
	char *temp = (char *)malloc(20 * sizeof(char));
	char *buf = (char *)malloc(50 * sizeof(char));
	int i = 0, count = 0;
	int layer_num = num;
	char *sub = "SUBLayer";
	int sub_num = 0;
	char layers[] = { 'm', 'n', 't', 'a' };

	if (string != NULL)
		level = string;
#if defined(__linux__)
	if (level == "NWK")
		sub_num = 1;
	else if (level == "TRANS")
		sub_num = 2;
	else if (level == "APP")
		sub_num = 3;
	else
		sub_num = 0;
	count = sub_num;
#elif defined(__APPLE__)
	if (strcmp(level, "NWK")==0)
		sub_num = 1;
	else if (strcmp(level, "TRANS")==0)
		sub_num = 2;
	else if (strcmp(level, "APP")==0)
		sub_num = 3;
	else
		sub_num = 0;
	count = sub_num;
#endif
	int fd = open("script.sh", O_RDWR | O_CREAT, 0);
	lseek(fd, 0, SEEK_END);

	if (g_key_file_load_from_file(keyFile, configFile,
				      G_KEY_FILE_NONE, &error)) {
		while (layer_num) {
			sprintf(temp, "%s%d", level, ++i);
			log_info("String is %s", temp);
		/** Get protocol name */
			sprintf(buf, "%s Layer", level);
			layer =
			    g_key_file_get_string(keyFile, buf, temp, &error);
			if (error != NULL) {
				log_info("Unable to load Layer from %s: %s",
					 configFile, error->message);
				error = NULL;
				retVal = FALSE;
			}
			log_info("layer name is %s", layer);

		/** Divid string to seperate strings  */
			layer_p = strsep(&layer, delim);

		/** Copy string to script file  */
			lseek(fd, 0, SEEK_END);
			sprintf(buf, "./%s -i %d", layer_p, i + 1);
			write(fd, buf, strlen(buf));
			snprintf(buf, 2, "%s", layer);
			layer_p = strsep(&layer, delim);
			if (layer_p != NULL) {
				if (buf[0] != ',') {
					sprintf(buf, " -c %s", layer_p);
					write(fd, buf, strlen(buf));
				}
				layer_p = strsep(&layer, delim);
				if (layer_p != NULL) {
					sprintf(buf, " -t %s", layer_p);;
					write(fd, buf, strlen(buf));
				}
			}
		/** Read sublayers  */
			if (sub_num != 0) {
				sprintf(temp, "%s%d", sub, i);
				sprintf(buf, "%s Layer", level);

				layer =
				    g_key_file_get_string(keyFile, buf, temp,
							  &error);
				if (error != NULL) {
					log_info
					    ("Unable to load Sub layer from %s: %s",
					     configFile, error->message);
					error = NULL;
					retVal = FALSE;
				}
			}

			while (count) {
				layer_p = strsep(&layer, delim);
				sprintf(buf, " -%c %s", layers[count - 1],
					layer_p + strlen(layer_p) - 1);
				write(fd, buf, strlen(buf));
				count--;
			}
			count = sub_num;
			sprintf(buf, " & \n");
			write(fd, buf, strlen(buf));

			layer_num--;
		}
	}

	free(temp);
	free(buf);

	g_key_file_free(keyFile);
	close(fd);
	return retVal;
}
