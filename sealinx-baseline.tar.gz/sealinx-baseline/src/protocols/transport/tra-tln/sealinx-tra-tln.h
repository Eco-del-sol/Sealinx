/**
 * Two level network TRA layer.
 * Unpack jumbo packets to transport
 * Pack jumbo packets depend of different src_node
 * Select retransmission
 *
 * @Author	Jifeng Zhu
 * @Date	2020-03-05
 * @Version	0.1
 */

#ifndef _SEALINX_TRA_TLN_H
#define _SEALINX_TRA_TLN_H

#define MAX_PKT_SIZE 4096

/** Default log identity for this module. */
#define DEFAULT_LOG_ID "TLN-TRA"

/** Default path to the folder consisting log files. */
#define DEFAULT_LOG_FOLDER "logs/"

/** Data Type */
#define TX_DATA_CTD             0
#define TX_DATA_OIMG            1
#define TX_DATA_AUV             2
#define TX_DATA_USV             3
#define TX_DATA_USER            4

#define REQ_TX_DATA_OIMG        10
#define CMD_CHECK_ROUTE         11
#define RSP_CHECK_ROUTE         12
#define CMD_CHECK_BSID          13
#define RSP_CHECK_BSID          14
#define CMD_CHECK_MDMID         15
#define RSP_CHECK_MDMID         16
#define CMD_TEST_SEND           17
#define SET_UPDATE_CTD_TIME     18
#define RSP_UPDATE_CTD_TIME     19
#define SET_COLLECT_CTD_TIME    20
#define RSP_COLLECT_CTD_TIME    21
#define SET_TX_MODE             22
#define CMD_MEASURE_RANGE       23
#define RSP_MEASURE_RANGE       24
#define TEST_SEND_DATA          25
#define SET_TX_POWER            26

#define TEST_SEND_END           40
#define REQ_TX_NEXT_DATA        41
#define AUV_EXIST               42

#define FW_DATA                 50

/** ID of Core BaseStation */
#define CORE_BS_ID              9


typedef struct {
	uint8_t id;		/*pkt_id:0~3, all recv:9*/
	uint8_t Nid;	/*negate id*/
	uint8_t n_pkt_left;
	uint16_t current_pkt_len;
    uint8_t group;
    uint8_t payload[MAX_PKT_SIZE];
} __attribute__ ((__packed__)) DatPacket;

typedef struct {
    /** Packet type. */
	uint8_t pktType;
} __attribute__ ((__packed__)) ProtocolInfo;

typedef struct {
	uint8_t appUnpack; /* unpack: 1, not unpack: 0 */
	uint8_t traUnpack; /* unpack: 1, not unpack: 0 */
} __attribute__ ((__packed__)) TraInfo;

#define GetDatPacketSize(p)     ((p)->current_pkt_len + 4*sizeof(uint8_t) + sizeof(uint16_t))
#define GetTotalPackets(p)      ((p)->id + (p)->n_pkt_left + 1)
#define ValidatePacket(p)       (((p)->id ^ (p)->Nid) == 0xFF) /* crc is not sued */

#endif /* _SEALINX_TRA_TLN_H */
