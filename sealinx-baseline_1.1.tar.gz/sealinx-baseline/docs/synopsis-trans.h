/**
\page overview_page
\section overview_trans_sec Transport layer

<tt>sealinx-tra</tt> is a dummy transport layer, whose syntax is

<pre>
sealinx-tra -i \<protocol ID\> -p \<core port\> -m \<MAC protocol ID\> -n \<net protocol ID\>
</pre>

where
 - <tt>\<protocol ID\></tt> is the identifier of the protocol, which will be filled in the type field in the network header. 
 - <tt>\<core port\></tt> is the port that the core is listening on.
 - <tt>\<mac protocol ID\></tt> is the identifier of the underlying MAC protocol.
 - <tt>\<net protocol ID\></tt> is the identifier of the underlying network protocol. Note that the network protocol must be registered with the MAC protocol.
 */
