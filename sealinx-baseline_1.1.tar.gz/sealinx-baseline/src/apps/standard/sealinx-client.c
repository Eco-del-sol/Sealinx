/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * Sample code for the application.
 *
 * @author son
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <sys/select.h>
#include <err.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>
#include <sys/shm.h>

#include <sealinx.h>
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>

/**
 * Default log identity for this module.
 */
#define DEFAULT_LOG_ID "DUMMY_CLI"

/**
 * Default path to the folder consisting log files.
 */
#define DEFAULT_LOG_FOLDER "logs/"

/** Log identity for this module. */
char * gLogId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char * gLogFolder = DEFAULT_LOG_FOLDER;

/** File descriptor of the connection to the core. */
int g_connFd;

/** ID of the current module. */
ModuleId g_moduleId;

/** ID of the MAC module. */
ModuleId g_macId;

/** ID of the network module. */
ModuleId g_netId;

/** ID of the transport module. */
ModuleId g_transId;

/**
 * Shared data by the core module.
 */
CoreSharedData *g_coreSharedData;

int g_coreSharedMemId;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 1;

/**
 * Parse command line arguments.
 *
 * @param argc Number of arguments
 * @param argv The arguments
 * @return TRUE if the argument can be parse; FALSE, otherwise.
 */
int parse_arguments(int argc, char ** argv) {
    int i = 0;
    while (i < argc) {
	char * t = argv[i];
	if (strcmp(t, "-i") == 0) {
	    i ++;
	    if (i < argc)  {
		int moduleId = strtol(argv[i], NULL, 10);
		if (moduleId > MAX_MODULE_ID || moduleId < MIN_MODULE_ID) {
		    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
		    return FALSE;
		}
		g_moduleId = moduleId;
	    }
	} else if (strcmp(t, "-m") == 0) {
	    i ++;
	    if (i < argc)  {
		int macId = strtol(argv[i], NULL, 10);
		if (macId > MAX_MODULE_ID || macId < MIN_MODULE_ID) {
		    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
		    return FALSE;
		}
		g_macId = macId;
	    }
	} else if (strcmp(t, "-n") == 0) {
	    i ++;
	    if (i < argc)  {
		int netId = strtol(argv[i], NULL, 10);
		if (netId > MAX_MODULE_ID || netId < MIN_MODULE_ID) {
		    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
		    return FALSE;
		}
		g_netId = netId;
	    }
	} else if (strcmp(t, "-t") == 0) {
	    i ++;
	    if (i < argc)  {
		int transId = strtol(argv[i], NULL, 10);
		if (transId > MAX_MODULE_ID || transId < MIN_MODULE_ID) {
		    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
		    return FALSE;
		}
		g_transId = transId;
	    }
	} else if (strcmp(t, "-f") == 0) {
	    i ++;
	    if (i < argc) {
		gLogFile = atoi(argv[i]);
	    }
	}
	i++;
    }
    return g_moduleId >= MIN_MODULE_ID && g_moduleId <= MAX_MODULE_ID && 
        g_macId >= MIN_MODULE_ID && g_macId <= MAX_MODULE_ID && 
        g_netId >= MIN_MODULE_ID && g_netId <= MAX_MODULE_ID && 
        g_transId >= MIN_MODULE_ID && g_transId <= MAX_MODULE_ID;
}

/**
 * Print the usage of the program.
 */
void print_usage(const char *progName) {
    printf("USAGE: %s "
           "-i <module id> -m <mac protocol id> -n <network protocol id> "
	   "-t <transport protocol id> [-f <log file outoput flag>]\n", 
           progName);
}

/**
 * Calculate the actual size of data that is transmitted/received by this layer.
 * This size includes the size of headers of upper layers and the length of 
 * payload.
 *
 * @param pbuf The received/transmitted data.
 * @return The actual size.
 */
int calc_actual_size(PduBuff *pbuf) {
    return pbuf->msg_len + pbuf->hdr_tra.hdr_len;
}

/**
 * Initialize the program.
 */
int init(void) {
    int type = 0;
    ModuleId moduleIds[NUM_LAYERS];
    moduleIds[LAYER_MAC] = g_macId;
    moduleIds[LAYER_NETWORK] = g_netId;
    moduleIds[LAYER_TRANSPORT] = g_transId;
    moduleIds[LAYER_APPLICATION] = g_moduleId;

    if (!init_logger(gLogFolder, gLogId, gLogFile, TRUE, moduleIds, 4)) {
        fprintf(stderr, "Unable to init the log module.");
        return FALSE;
    }

    RegistrationResponse serverResponse;

    g_connFd = client_connect(type, LAYER_APPLICATION, moduleIds, &serverResponse, NULL, 0);

    g_coreSharedMemId = serverResponse.coreShareMemId;
    
    log_info("Key of shared memory by the core: %d", g_coreSharedMemId);
    
    g_coreSharedData = (CoreSharedData *) shmat(g_coreSharedMemId, NULL, 0);
    if (g_coreSharedData == (CoreSharedData *) -1) {
        fprintf(stderr, "Unable to attach the shared memory: %s", 
                strerror(errno));
        return FALSE;
    }

    logger_set_node_id(g_coreSharedData->macAddr, g_coreSharedData->netAddr);
    log_info("Mac address: %d, net address: %d", 
             (int) g_coreSharedData->macAddr, (int) g_coreSharedData->netAddr);
    return TRUE;
}

/**
 * Signal handler.
 *
 * @param sig Signal ID.
 */
void signal_handler(int sig) {
    int type = 0;
    log_info("Received signal (%d)", sig);
    
    if (g_connFd > -1) {
	client_close(type, g_connFd, NULL, 0);
        g_connFd = -1;
    }
}

/**
 * Clean up allocated resources.
 */
void clean_up(void) {
    int type = 0;
    log_info("Cleaning up ...");
    
    if (g_connFd > -1) {
	client_close(type, g_connFd, NULL, 0);
    }

    int rc = shmdt(g_coreSharedData);
    if (rc == -1) {
        log_error("Unable to detach shared data: %s", strerror(errno));
    }

    close_logger();
}

/**
 * Main program.
 *
 * @param argc Number of parameters.
 * @param argv Array of parameters.
 */
int main(int argc, char ** argv) {
    atexit(clean_up);
    signal(SIGINT, signal_handler);

    char buffer[IMSG_MAX_DATA_LENGTH];
    InternalMessageHeader dataHeader;

    if (!parse_arguments(argc, argv)) {
	    print_usage(argv[0]);
	    return EXIT_FAILURE;
    }

    if (!init()) {
        return EXIT_FAILURE;
    }

    while (TRUE) {
        PduBuff *pbuf = (PduBuff *) buffer;
        
        pbuf->hdr_tra.hdr_len = sizeof (struct type_tra_hdr) - 
            sizeof (pbuf->hdr_tra.tra_data);
        //gets(pbuf->pkt_data);
        fgets(pbuf->pkt_data, sizeof(pbuf->pkt_data), stdin);
        puts(pbuf->pkt_data);
        pbuf->msg_len = strlen(pbuf->pkt_data);
        pbuf->hdr_tra.service_type = g_moduleId;
        client_send_down(g_connFd, pbuf, sizeof(PduBuff), g_moduleId, NULL, 0);
        
    	int nBytesRead = client_read(g_connFd, buffer, IMSG_MAX_DATA_LENGTH,
                    					&dataHeader, NULL, 0);

        if (nBytesRead == -1) {
            log_error("System error occurred");
            break;
        }
        
	    if (nBytesRead == -2) {
	        log_warning("Data was not successfully received");
	    }

        if (nBytesRead == 0) {
            logInfo("Connection closed by the core module");
    	    break;
        } 
       
        if (from_lower_layer(dataHeader)) {
            /* TODO process message from lower layer */
            log_receive(PKT_DATA, pbuf->hdr_mac.src_addr, 
		                pbuf->hdr_mac.dst_addr, calc_actual_size(pbuf), 
		                "DATA");
		    puts(pbuf->pkt_data);
        } else if (from_upper_layer(dataHeader)) {
            /* TODO process message from upper layer */
            log_warning("There is no layer higher than this one");
        } else {
            log_error("Packet state error");
            continue;
        }
    }

    return EXIT_SUCCESS;
}

