/**
\page overview_page
\section overview_net_sec Network layer
\subsection sealinx-net
<tt>sealinx-net</tt> is a dummy network protocol. The syntax for <tt>sealinx-net</tt> is

\code
sealinx-net -i <protocol ID> -p <core port> -m <MAC protocol ID>
\endcode

where
 - <tt>\<protocol ID\></tt> is the identifier of the protocol, which will be filled in the type field in the network header.
 - <tt>\<core port\></tt> is the port that the core is listening on.
 - <tt>\<mac protocol ID\></tt> is the identifier of the underlying MAC protocol.

\subsection sealinx-sroute
<tt>sealinx-sroute</tt> implements static routing. The syntax of <tt>sealinx-sroute</tt> is

\code
sealinx-sroute -i <protocol ID> -p <core port> -m <MAC protocol ID> -c <routing table file>
\endcode

where
 - The first three parameters are the same as sealinx-net
 - <tt>\<routing table file\></tt> is the file listing routes in the network.

Each line in a routing table file describes a route with the following
information: the source node, the relay node and the destination
node. The line format follows:

\code
<source node> : <relay node> : <dest node>
\endcode

\subsection sealinx-droute

<tt>sealinx-droute</tt> implement dynamic routing. The syntax of <tt>sealinx-droute</tt> is

\code
sealinx-droute-i <protocol ID> -p <core port> -m <MAC protocol ID> -c <dynamic routing config>
\endcode

where
 - The first three parameters are the same as <tt>sealinx-net</tt>.
 - The last parameter is the configuration file of dynamic routing.

A sample configuration file for <tt>sealinx-droute</tt> follows
\code{.ini}
[Protocol Parameters]
StableHelloPeriod = 180
UnstableHelloPeriod = 20
NumRoutingEntries = 10
EntryTimeout = 190
MinimumUpdateWait = 10
MaximumUpdateWait = 30
\endcode

In this file:
- <tt>StableHelloPeriod</tt>: The frequency of sending <tt>HELLO</tt> messages when the routing table is stable. A routing table is determined to be stable if at least two <tt>HELLO</tt> messages from its neighbors which do not incur any update to the local routing table.
- <tt>UnstableHelloPeriod</tt>: The frequency of sending <tt>HELLO</tt> message when the routing table is unstable. A routing table is unstable after initialization or after the node receives a <tt>HELLO</tt> message from one of its neighbors, which changes the table.
- <tt>NumRoutingEntries</tt>: the maximal number of routes, which should be at least the number of nodes.
- <tt>EntryTimeOut</tt>: The validity interval of a routing entry. After a routing entry is updated, the countdown timer associated with it is reset to <tt>EntryTimeOut</tt>. If this timer times out, the entry is deleted.
- <tt>MinimumUpdateWait</tt>, <tt>MaximumUpdateWait</tt>: the minimum/maximum time that a node needs to wait before it broadcast changes to its routing table. After a change to the routing table is detected, a node set up a timer, whose interval is from <tt>MinimumUpdateWait</tt> to <tt>MaximumUpdateWait</tt>, to broadcast the changes.
*/
