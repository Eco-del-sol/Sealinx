/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author jun, son
 */  
    
#ifndef __OFDM_UTILS_H__
#define __OFDM_UTILS_H__
    
#define OFDM_BUFFER_SIZE (1024*2)
    
#ifndef FALSE
#define FALSE (0)
#define TRUE (!(FALSE))
#endif	/*  */
    
#ifndef VERBOSE
#define VERBOSE (2) /* For extended debug mode */
#endif	/*  */
    typedef struct {
	uint8_t signature[2];
	uint16_t length;
	uint32_t crc;
	uint8_t data[0];
} __attribute__ ((__packed__)) PhysicalDataPacket;
 
#ifdef	__cplusplus
extern "C" {
	
#endif	/*  */
	extern int debug_mode;
	 
	    /* General modem interface */ 
	int modem_send2(int fd, struct pdu_buff *pdu);
	int modem_recv(int fd, struct pdu_buff *pdu, int *moreData);
	
#ifdef	__cplusplus
} 
#endif	/*  */

#endif	/*  */

