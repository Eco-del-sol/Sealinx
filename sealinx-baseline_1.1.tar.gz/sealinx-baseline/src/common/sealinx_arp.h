/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author son.
 */

#ifndef __SEALINX_ARP_H__
#define __SEALINX_ARP_H__

/**
 * For ARP
 */

#define ARP_FILE        "config_arp.cfg"
typedef void *ArpTable;

typedef struct {
	int netAddr;
	int macAddr;
} ArpEntry;

#ifdef	__cplusplus
extern "C" {
#endif

	ArpTable readArpTable(const char *fname);
	int getMac(ArpTable arpTable, int netAddr);
	int getNet(ArpTable arpTable, int macAddr);
	void freeArpTable(ArpTable arpTable);

#ifdef	__cplusplus
}
#endif
#endif
