/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author yibo
 */

#ifndef __SEALINX_TIME_H__
#define __SEALINX_TIME_H__

#ifdef	__cplusplus
extern "C" {
#endif
	/* Return the current time to the array pointed by @time_string
	 * The size of the array is specified in @max_size
	 * Time is accurate in seconds
	 */
	int get_timestring_sec(char *time_string, int max_size);
	void get_fulltimestring_sec(char *time_string, int max_size);
#ifdef	__cplusplus
}
#endif
#endif
