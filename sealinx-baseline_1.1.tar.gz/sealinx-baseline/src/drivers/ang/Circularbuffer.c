/*
*CopyRight Reserved: 智慧海洋
* Filename:          Circularbuffer.c
* Description:      循环缓冲区接收数据
* Date:             2017.07.04
* Author:           Lxt
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "Circularbuffer.h"

CircularBuffer *CircularBuffer_create(int maxLen)
{
	CircularBuffer *cbuf;

	cbuf = malloc(sizeof(*cbuf) + maxLen + 1);
	if (!cbuf)
		return NULL;

	cbuf->head = 0;
	cbuf->tail = 0;
	cbuf->maxLen = maxLen;

	return cbuf;
}

void CircularBuffer_delete(CircularBuffer * cbuf)
{
	free(cbuf);
}

/*******************************************************
 * @description 得到循环缓冲区已填充数据字节数
 * @param[in]   cirbuf    缓冲区地址
 * @param[out]  无
 * @return      已填充数据字节数
 *****************************************************/
int CircularBuffer_getLen(CircularBuffer * cirbuf)
{
	int len;

	len = cirbuf->tail + CircularBuffer_getPhyLen(cirbuf) - cirbuf->head;
	if (len >= CircularBuffer_getPhyLen(cirbuf))
		len -= CircularBuffer_getPhyLen(cirbuf);

	return len;
}

/*******************************************************
 * @description 得到循环缓冲区未填充数据字节数
 * @param[in]   cirbuf    缓冲区地址
 * @param[out]  无
 * @return      未填充数据字节数
 *****************************************************/
int CircularBuffer_getFreeLen(CircularBuffer * cirbuf)
{
	return CircularBuffer_getMaxLen(cirbuf) - CircularBuffer_getLen(cirbuf);
}

/*******************************************************
 * @description 往循环缓冲区填充数据
 * @param[in]   cirbuf   缓冲区地址
*  @param[in]   buf      要填的数据缓冲区地址
*  @param[in]   len      要填的数据长度
 * @param[out]  无
 * @return
 *****************************************************/
int CircularBuffer_append(CircularBuffer * cirbuf, char *buf, int len)
{
	int len1, newtail;
	//printf("********************\n");
	if (len == 0)
		return 0;	//要填充的数据为空

	//缓冲区空间不足
	if (len > CircularBuffer_getFreeLen(cirbuf))
		len = CircularBuffer_getFreeLen(cirbuf);
	//填充数据到缓冲区
	newtail = cirbuf->tail + len;
	if (newtail >= CircularBuffer_getPhyLen(cirbuf)) {
		newtail -= CircularBuffer_getPhyLen(cirbuf);
		memcpy(&cirbuf->buf[cirbuf->tail], buf,
		       CircularBuffer_getPhyLen(cirbuf) - cirbuf->tail);
		memcpy(cirbuf->buf,
		       &buf[CircularBuffer_getPhyLen(cirbuf) - cirbuf->tail],
		       newtail);
	} else {
		memcpy(&cirbuf->buf[cirbuf->tail], buf, len);
	}
	cirbuf->tail = newtail;

	return len;
}
