/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * @author james
 */

/**
 *  Need the support of GPSD, i.e. GPSD has to be working correctly
 * To use, just include this file and call read_gps
 */

#ifndef __SEALINX_GPS_H__
#define __SEALINX_GPS_H__

#define NAME_LENGTH 256
//#define BUF_SIZE 1024
#define PORT	2947
#define HOST	"localhost"

#ifdef	__cplusplus
extern "C" {
#endif

	typedef struct _GPS_INFO {
		double lat;	/* latitudes ddmm.mmmm */
		char lat_hemi;
		double lon;	/* longitudes dddmm.mmmm */
		char lon_hemi;
		double spd;
		/* speed over ground, knots */ ;
		int day;	/* day of the monty */
		int mon;	/* month of the year */
		int year;	/* year */
	} GPS_INFO;

#define GPS_DATA_LEN 10

	typedef struct _GPS_MSG {
		char lat[GPS_DATA_LEN];	/* latitudes ddmm.mmmm */
		char lat_hemi;
		char lon[GPS_DATA_LEN];	/* longitudes dddmm.mmmm */
		char lon_hemi;
		char spd[GPS_DATA_LEN];
		/* speed over ground, knots */ ;
		char time[GPS_DATA_LEN];	/* Time Stamp */
		char date[GPS_DATA_LEN];	/* Date Stamp */
	} GPS_MSG;

	/* Obtain the latest GPS information, i.e. location, speed and time
	 * Save into a buffer @buf which is @len bytes in length
	 * Return -1 on errors
	 *
	 * GPS info format:
	 * GPSD,P=41.716037 -72.201972,V=0.060,D=2010-06-18T04:34:04.00Z
	 * P means location
	 * V means ground speed (in knots)
	 * D is the date
	 * T is the time (Greenwich time)
	 *
	 * NOTE if a information is not available at this time '?' will be
	 * returned, e.g. the following message would be possible:
	 * GPSD,P=?,V=?,D=?*/
	int read_gps(char *buf, int len);

	/* For Yibo's VBF implementation */

#define PI 3.14159265358979
//#define BUFSIZE (sizeof(struct pdu_buff))
#define square(x) (x)*(x)

	typedef struct _GLOBAL_LOCATION {
		double lat;	/* latitudes dd.ddddd */
		double lon;	/* longitudes ddd.ddddd */
		/*short int id; */
	} Global_Location;

	/*get the location information of this node in latitude and longitude */
	void getGPS_Location(Global_Location * gl, char *gps_info);

	/*return the distance between these two points in meter */
	double getDistance(Global_Location * r1, Global_Location * r2);

#ifdef	__cplusplus
}
#endif
#endif
