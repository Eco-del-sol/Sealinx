/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * Dynamic routing.
 *
 * @author son
 */

#include <sys/time.h>
#include <stdlib.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <err.h>
#include <glib.h>
#include <errno.h>
#include <sys/shm.h>

#include <sealinx.h>
#include <sealinx_utils.h>
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>

#include "sealinx-droute.h"

#define MAX_NUM_UNCHANGES 2

#define BUFSIZE sizeof(struct pdu_buff)

/** Log identity for this module. */
char *gLogId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char *gLogFolder = DEFAULT_LOG_FOLDER;

/** File descriptor of the connection to the core. */
int g_connFd;

/** ID of the current module. */
ModuleId g_moduleId;

/** ID of the MAC module */
ModuleId g_macId;

/** Shared data by the core module. */
CoreSharedData *g_coreSharedData;

/** Key of the shared memory by the core. */
int g_coreSharedMemId;

/** Config file name. */
char *g_configFileName;

/** Randomness generator. */
GRand *g_randGen;

/** Queue of HELLO message from neighboring nodes. */
GAsyncQueue *g_pendingHelloQueue = NULL;

/** Configuration of the module. */
DRConfig *g_config = NULL;

/** Local routing table. */
GSequence *g_localRoutingTable;

/** Access lock to the local routing table. */
GMutex *g_lrtLock = NULL;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 1;

/**
 * Each neighbor is associated with a timer. After this timer expires,
 * and there is no update, the route through this neighbor will be deleted.
 */
GSequence *g_aliveNeighborTimers;

/**
 * This lock prevent the removal of a route while the route is being
 * accessed by another thread.
 */
GMutex *neighborTimeoutLock = NULL;

/** Main loop of the module. */
GMainLoop *g_mainLoop = NULL;

GIOChannel *channel;

uint8_t tag = 0;

/**
 * ID of the timer that makes changes to the local routing table broadcast.
 * The change is not broadcast right after it is made, but after some delay.
 */
guint g_changeTimer = 0;

/**
 * ID of the timer that makes HELLO message sent periodically.
 */
guint g_sendHelloTimer = 0;

// Number of consecutive times the routing table stay unchanged.
int numUnchanges = 0;

int g_running;

#define HELLO_PK_TXMODE 1


#if 1
/*add by yuansong for debug function2018-5-23*/
int printMACHeaderInfo(MacHeader *pmach)
{
	char str[28+1] = {0};
	
    /*buffer maxsize=MAX_HEADER_SIZE_MAC - MIN_LENGTH_MAC_HEADER = 32-4 =28*/
	log_info("#########Begine Printf MAC header Info#########");
	log_info("##MAC HEADER: hdr_len =%d##", pmach->hdr_len);
	log_info("##MAC HEADER: mac_type=%d##", pmach->mac_type);
	log_info("##MAC HEADER: src_addr=%d##", pmach->src_addr);
	log_info("##MAC HEADER: dst_addr=%d##", pmach->dst_addr);

	if (pmach->hdr_len>0 && pmach->hdr_len<=28){
		str[pmach->hdr_len] = '\0';
		memcpy(str, pmach->mac_data, pmach->hdr_len);
		log_info("##MAC HEADER: mac_data=%s##",str);		
	}

	log_info("#########End Printf MAC header Info#########");

	return 1;
}


int printNETHeaderInfo(NetHeader *pneth)
{
	uint8_t net_pkt_type = -1;
	
    /*buffer maxsize=MAX_HEADER_SIZE_NET - MIN_LENGTH_NET_HEADER = 100-5 =85*/
	log_info("---------Begin Printf NET header Info---------");
	log_info("--NET HEADER: hdr_len =%d--", pneth->hdr_len);
	log_info("--NET HEADER: net_type=%d--", pneth->net_type);
	log_info("--NET HEADER: src_addr=%d--", pneth->src_addr);
	log_info("--NET HEADER: dst_addr=%d--", pneth->dst_addr);
	log_info("--NET HEADER: next_hop=%d--", pneth->next_hop);	

	memcpy(&net_pkt_type, pneth->net_data, sizeof(uint8_t));
	log_info("--NET HEADER: net_data contain net pkt type=%d--", net_pkt_type);

	log_info("---------End Printf NET header Info---------");

	return 1;
}


int printTRAHeaderInfo(TransportHeader *ptrah)
{
	int     ctrlID = 0;
	uint8_t txmode = 0;
	
    /*buffer maxsize=MAX_HEADER_SIZE_TRA - MIN_LENGTH_TRANS_HEADER = 20-3 =17*/
	log_info("********Begin Printf TRA header Info********");
	log_info("**TRA HEADER: hdr_len     =%d**", ptrah->hdr_len);
	log_info("**TRA HEADER: tra_type    =%d**", ptrah->tra_type);
	log_info("**TRA HEADER: service_type=%d**", ptrah->service_type);

	if (ptrah->hdr_len == sizeof(TransportHeader)-sizeof(ptrah->tra_data)+sizeof(int)+sizeof(uint8_t)){
		memcpy(&ctrlID, ptrah->tra_data, sizeof(int));
        //please modify
		memcpy(&txmode, ptrah->tra_data+sizeof(int), sizeof(uint8_t));
		/*log_info("**TRA HEADER: tra_data=%s**\r\n",str);*/
		log_info("TRA HEADER: tra_data, ctrlID=%d, txmode=%d",ctrlID, txmode);
	}
	log_info("********End Printf TRA header Info********");

	return 1;
}


int PrintfPDUbuff(char *array, int len)
{	
	/*buffer size = MAX_DATA_PAYLOAD_SIZE =1200*/
	char buff[MAX_DATA_PAYLOAD_SIZE]={0};
	memcpy(buff, array, len);
	buff[len] = '\0';
	log_info("$$$$$$$$PDU pkt_data=%s$$$$$$$$", buff);
	return 1;
}

int PrintPDURemainPara(PduBuff *pdu)
{	
//	log_info("@@@@@@@@PDU: pkt_type  =%d@@@@@@@@", pdu->pkt_type);
//	log_info("@@@@@@@@PDU: pkt_state =%d@@@@@@@@", pdu->pkt_state);
//	log_info("@@@@@@@@PDU: phy.esnr  =%f@@@@@@@@", pdu->phy.phy_recv.effsnr);
//	log_info("@@@@@@@@PDU: phy.txmode=%d@@@@@@@@", pdu->phy.phy_send.mode);

	return 1;
}

/*add by yuansong for debug function2018-5-23*/
#endif


/*get route tabel command macro, add by yuansong 2018-5-2*/
#define ERROR_CONTROL_MACRO    0x0
#define GET_DROUTE_TABLE_REQ   0x01
#define GET_DROUTE_TABLE_IND   0x02
#define GET_MODEN_DISTANCE_REQ 0x03
#define GET_MODEN_DISTANCE_IND 0x04


int GetControlMacro(TransportHeader *pth)
{
	int tmp = 0;

	/*it contains 3 bytes and buffer, if  > 3, then its buffer has  useful  data.*/
	if (pth->hdr_len > 3){
		memcpy(&tmp, pth->tra_data, sizeof(int));
		return tmp;
	}
	
	return ERROR_CONTROL_MACRO;/*return invalued macro value.*/
}


/* copy from app and debug get route info assistance function. 2018-8-30*/
#define APP_NET_MAX_HOPS 10

typedef struct _RouteInfo{
	int     numHops;
	uint8_t dest;
	uint8_t nextHop;
	uint8_t relays[APP_NET_MAX_HOPS];
	uint8_t tag;
}RouteInfo;


void printRouteInfo(PduBuff *prt)
{
	uint16_t offset = 0;
	RouteInfo ri;
	memset(&ri, 0, sizeof(RouteInfo));

	if (0 == prt->msg_len){
		log_info("No route info in control pkt!########\r\n");
		return;
	}

	log_info("--- ######Begin Routing Table for DEBUG###### ---");
	log_info("Dest | Next | Count");
	
	while (prt->msg_len > offset+1){
	    /*ought to add 1.*/
		memcpy(&(ri.numHops), prt->pkt_data + offset, sizeof(int));
		offset += sizeof(int);
		memcpy(&(ri.dest), prt->pkt_data + offset, sizeof(uint8_t));
		offset += sizeof(uint8_t);
		memcpy(&(ri.nextHop), prt->pkt_data + offset, sizeof(uint8_t));
		offset += sizeof(uint8_t);
		if (ri.numHops > 2){
			memcpy(&(ri.relays), prt->pkt_data + offset, sizeof(uint8_t)*(ri.numHops-2));
			offset += sizeof(uint8_t)*(ri.numHops-2);
		}
		memcpy(&(ri.tag), prt->pkt_data + offset, sizeof(uint8_t));
		offset += sizeof(uint8_t);

		log_info("%4d | %4d | %5d", ri.dest, ri.nextHop, ri.numHops);
		memset(&ri, 0, sizeof(RouteInfo));
	}
	
	log_info("--- ######End Routing Table for DEBUG###### ---");

}


int DealwithGetTableReq()
{
	PduBuff               pdu;
	LocalRoutingEntry     *lre   = NULL;
	GSequenceIter         *iter  = NULL;
	char                  *p     = NULL;
	int                   offset = 0;// counter of payload buffer length.
	int                   ret    = 0;
	ProtocolInfo          pi;
	
	pi.pktType = NET_PKT_DATA;//control info
	memset(&pdu, 0, sizeof(PduBuff));

	log_info("Debug ###########Now we dealwith GET_DROUTE_TABLE_REQ control request!!!");
	/*3 + sizeof(int);3 is length of  member:	uint8_t hdr_len, uint8_t tra_type,	uint8_t service_type; */
	pdu.hdr_tra.hdr_len = sizeof(TransportHeader)-sizeof(pdu.hdr_tra.tra_data)+sizeof(int);
	int ctrl = GET_DROUTE_TABLE_IND;
	memcpy(pdu.hdr_tra.tra_data, &ctrl, sizeof(int));
	pdu.hdr_tra.tra_type     = g_moduleId + 1;/*test for unable to tra reason!!!!! 2018-5-25*/
	pdu.hdr_tra.service_type = g_moduleId + 2;

	/*fill route table to payload buffer, offset = length of  payload*/
	p = pdu.pkt_data;

	/*add mutex by yuansong for 2018-5-30*/
	g_mutex_lock(g_lrtLock);
	iter = g_sequence_get_begin_iter(g_localRoutingTable);
	while (!g_sequence_iter_is_end(iter))//copy route item to pdu payload buffer.
	{
		lre = (LocalRoutingEntry *)g_sequence_get(iter);
		log_info("debug####:lre->numHops=%d, lre->dest=%d, lre->nextHop=%d,", 
		                lre->numHops, lre->dest, lre->nextHop);
		memcpy(p+offset, &lre->numHops, sizeof(int));/**((int*)(p)) = lre->numHops;*/
		offset += sizeof(int);
		memcpy(p+offset, &lre->dest, sizeof(uint8_t));/**(p + offset) = lre->dest;*/
		offset += sizeof(uint8_t);
		memcpy(p+offset, &lre->nextHop, sizeof(uint8_t));/**(p + offset) = lre->nextHop;*/
		offset += sizeof(uint8_t);;
		if (lre->numHops > 2){
			memcpy(p+offset, lre->relays, (lre->numHops-2)*sizeof(uint8_t));
			offset	+= sizeof(uint8_t)*(lre->numHops-2);			
		}
		memcpy(p+offset, &lre->tag, sizeof(uint8_t));/**(p+offset) = lre->tag;*/
		offset      += sizeof(uint8_t);		
		iter        = g_sequence_iter_next(iter);		
	}
	g_mutex_unlock(g_lrtLock);/*add by yuansong 2018-5-30*/

	pdu.msg_len          = offset;
	pdu.hdr_net.net_type = g_moduleId;
	memcpy(pdu.hdr_net.net_data, &pi, sizeof(ProtocolInfo));
	pdu.hdr_net.hdr_len  = sizeof(NetHeader)-sizeof(pdu.hdr_net.net_data)+sizeof(ProtocolInfo);
	pdu.hdr_net.src_addr = g_coreSharedData->netAddr;
	pdu.hdr_net.dst_addr = g_coreSharedData->netAddr;
	pdu.hdr_net.next_hop = 0;

    printRouteInfo(&pdu);/*add  for debug function, 2018-8-30*/	
    /*this state is error ,because send buffer is not whole buffer ,you ought to anasyse it!!!!!!*/
	ret = client_send_up(g_connFd, &pdu, PDU_SIZE(pdu.msg_len), g_moduleId, NULL, 0);
	log_info("###########Send GET_DROUTE_TABLE_IND control to tra, ret=%d######!!!", ret);
	log_info("###debug up following for GET_DROUTE_TABLE_IND, pdu.msg_len=%d, hdr_tra.service_type=%d", 
	            pdu.msg_len, pdu.hdr_tra.service_type);

	return ret;
}


int DealwithToMACCtrlMsg(PduBuff *pbuf)
{
    /*GET_MODEN_DISTANCE_REQ*/
	log_info("DROUTE receive for mac control msg ID=%d in DealwithToMACCtrlMsg#######",GetControlMacro(&(pbuf->hdr_tra)));
	pbuf->hdr_net.net_type = g_moduleId;
	ProtocolInfo *pi = (ProtocolInfo *) pbuf->hdr_net.net_data;
	pi->pktType = NET_PKT_DATA;
	pbuf->hdr_net.hdr_len = sizeof(pbuf->hdr_net) - sizeof(pbuf->hdr_net.net_data) + sizeof(ProtocolInfo);
	client_send_down(g_connFd, pbuf, PDU_SIZE(pbuf->msg_len), g_moduleId, NULL, 0);
	return 1;
}


int DealwithFromMACCtrlMsg(PduBuff *pbuf)
{
#if 1
	PduBuff 	 pdu;
	int 		 ret = 0;
	ProtocolInfo pi;

	pi.pktType = NET_PKT_DATA;//control info
	memset(&pdu, 0, sizeof(PduBuff));

	pdu.hdr_tra.hdr_len = sizeof(TransportHeader)-sizeof(pdu.hdr_tra.tra_data)+sizeof(int);
	int ctrl = GET_MODEN_DISTANCE_IND;
	memcpy(pdu.hdr_tra.tra_data, &ctrl, sizeof(int));
	pdu.hdr_tra.tra_type	     = g_moduleId + 1;/*test for unable to tra reason!!!!! 2018-5-25*/
	pdu.hdr_tra.service_type = g_moduleId + 2;

	/*fill route table to payload buffer, offset = length of  payload*/
	pdu.msg_len = pbuf->msg_len;

	if (pdu.msg_len > 0)
		memcpy(pdu.pkt_data, pbuf->pkt_data, pdu.msg_len);

	pdu.hdr_net.net_type = g_moduleId;
	memcpy(pdu.hdr_net.net_data, &pi, sizeof(ProtocolInfo));
	pdu.hdr_net.hdr_len  = sizeof(NetHeader)-sizeof(pdu.hdr_net.net_data)+sizeof(ProtocolInfo);
	pdu.hdr_net.src_addr = g_coreSharedData->netAddr;
	pdu.hdr_net.dst_addr = g_coreSharedData->netAddr;
	pdu.hdr_net.next_hop = 0;

	/*this state is error ,because send buffer is not whole buffer ,you ought to anasyse it!!!!!!*/
	ret = client_send_up(g_connFd, &pdu, PDU_SIZE(pdu.msg_len), g_moduleId, NULL, 0);

	log_info("###########Send GET_MODEN_DISTANCE_IND control to tra, ret=%d######!!!", ret);
	log_info("###debug up following for GET_MODEN_DISTANCE_IND, pdu.msg_len=%d, hdr_tra.service_type=%d", 
	            pdu.msg_len, pdu.hdr_tra.service_type);

	return ret;

#endif 
}


#define NET_MAX_HOPS 10

typedef struct _UserRouteTable{
	int     numHops;
	uint8_t dest;
	uint8_t nextHop;
	uint8_t relays[NET_MAX_HOPS];
	uint8_t tag;
}UserRouteTable;


UserRouteTable ExplainRouteBuff(int *offset, char *buff)
{
	UserRouteTable rt;

	memset(&rt, 0, sizeof(UserRouteTable));
	memcpy(&(rt.numHops), buff+(*offset), sizeof(int));/*rt.numHops = *((int*)(buff));*/
	*offset += sizeof(int);
	memcpy(&(rt.dest), buff+(*offset), sizeof(uint8_t));/*rt.dest    = *((uint8_t*)(buff+(*offset)));*/
	*offset += sizeof(uint8_t);
	memcpy(&(rt.nextHop), buff+(*offset), sizeof(uint8_t));/*rt.nextHop = *((uint8_t*)(buff+(*offset)));*/
	*offset += sizeof(uint8_t);
	if (rt.numHops > 2){
		memcpy(&(rt.relays), buff+(*offset), sizeof(uint8_t)*(rt.numHops-2));
		*offset += sizeof(uint8_t)*(rt.numHops-2);
	}
	memcpy(&(rt.tag), buff+(*offset), sizeof(uint8_t));/*rt.tag  = *((uint8_t*)(buff+(*offset)));*/
	*offset += sizeof(uint8_t);
	
	return rt;
}


/*debug route process 2018-8-4*/
gboolean UnStableHello(gpointer data)
{
	sendHello(NULL);
	logInfo("******Switch HELLO period to unstable mode******", __PRETTY_FUNCTION__);
	g_sendHelloTimer =
	    g_timeout_add_seconds(g_config->unstableHelloPeriod, UnStableHello,
				  NULL);
	return FALSE;

}

gboolean StableHello(gpointer data)
{
	sendHello(NULL);
	logInfo("------Switch HELLO period to stable mode------", __PRETTY_FUNCTION__);
	g_sendHelloTimer =
	    g_timeout_add_seconds(g_config->stableHelloPeriod, StableHello,
				  NULL);
	return FALSE;

}
/*debug route process 2018-8-4, add by yuansong*/


/**
 * Frees a local routing entry.
 *
 * @param data A local routing entry whose format is specified by
 * LocalRoutingEntry.
 */
void free_lre(gpointer data)
{
	LocalRoutingEntry *lre = (LocalRoutingEntry *) data;
	if (lre->relays)
		g_free(lre->relays);

	g_free(data);
}

/**
 * Init a local routing entry.
 *
 * @param dest The destination of the route.
 * @param nextHop The neighboring node that lead to the destination.
 * @param numHop Number of hops to the destination.
 * @return The local routing entry whose structure is specified by
 * LocalRoutingEntry.
 */
LocalRoutingEntry *init_lre(int dest, int nextHop, int numHops)
{
	LocalRoutingEntry *result = g_new(LocalRoutingEntry, 1);
	result->numHops = numHops;
	if (numHops > 1 && numHops < MAX_HOP_COUNT)
		result->relays = g_new(uint8_t, numHops - 1);
	else
		result->relays = NULL;

	result->dest = dest;
	result->nextHop = nextHop;
	return result;
}

/**
 * Compare local two local routing entries.
 *
 * @param a One local routing entry.
 * @param b Another local routing entry.
 * @param extradata UNUSED
 *
 * @retval 1 if a goes after b
 * @retval -1 if a goes before b
 * @retval 0 if a and b are considered equal.
 */
gint compare_lre(gconstpointer a, gconstpointer b, gpointer extradata)
{
	LocalRoutingEntry *entry1 = (LocalRoutingEntry *) a;
	LocalRoutingEntry *entry2 = (LocalRoutingEntry *) b;
	if (entry1->dest > entry2->dest)
		return 1;
	else if (entry1->dest < entry2->dest)
		return -1;
	return 0;
}

/**
 * Free an alive-neighbor timer. Specifically used with
 * g_aliveNeighborTimers.
 *
 * @param data Pointer to the timer.
 */
void free_ant(gpointer data)
{
	g_free(data);
}

/**
 * Parse command line arguments.
 *
 * @param argc Number of arguments
 * @param argv The arguments
 * @return TRUE if the argument can be parse; FALSE, otherwise.
 */
int parse_arguments(int argc, char **argv)
{
	int i = 0;

	g_configFileName = DEFAULT_CFG_FILE_NAME;

	while (i < argc) {
		char *t = argv[i];
		if (strcmp(t, "-i") == 0) {
			i++;
			if (i < argc) {
				int moduleId = strtol(argv[i], NULL, 10);
				if (moduleId > MAX_MODULE_ID
				    || moduleId < MIN_MODULE_ID) {
					fprintf(stderr,
						"Invalid module ID (%s)\n",
						argv[i]);
					return FALSE;
				}
				g_moduleId = moduleId;
			}
		} else if (strcmp(t, "-m") == 0) {
			i++;
			if (i < argc) {
				int macId = strtol(argv[i], NULL, 10);
				if (macId > MAX_MODULE_ID
				    || macId < MIN_MODULE_ID) {
					fprintf(stderr,
						"Invalid module ID (%s)\n",
						argv[i]);
					return FALSE;
				}
				g_macId = macId;
			}
		} else if (strcmp(t, "-c") == 0) {
			i++;
			if (i < argc)
				g_configFileName = argv[i];
		} else if (strcmp(t, "-f") == 0) {
			i++;
			if (i < argc)
				gLogFile = atoi(argv[i]);
		}
		i++;
	}
	return g_moduleId >= MIN_MODULE_ID && g_moduleId <= MAX_MODULE_ID
	    && g_macId >= MIN_MODULE_ID && g_macId <= MAX_MODULE_ID;
}

/**
 * Print the usage of the program.
 */
void print_usage(const char *progName)
{
	printf("USAGE: %s "
	       "-i <module id> -m <net id> -c <g_config file> [-f <log file outoput flag>]\n",
	       progName);
}

/**
 * Initialize the program.
 */
int init(void)
{
	int type = 0;
	ModuleId moduleIds[NUM_LAYERS];
	moduleIds[LAYER_MAC] = g_macId;
	moduleIds[LAYER_NETWORK] = g_moduleId;

	if (!init_logger(gLogFolder, gLogId, gLogFile, TRUE, moduleIds, 2)) {
		fprintf(stderr, "Unable to init the log module.");
		return FALSE;
	}

	RegistrationResponse serverResponse;

	g_connFd =
	    client_connect(type, LAYER_NETWORK, moduleIds, &serverResponse,
			   NULL, 0);
	g_coreSharedMemId = serverResponse.coreShareMemId;
	log_info("Key of shared memory by the core: %d", g_coreSharedMemId);
	g_coreSharedData = (CoreSharedData *) shmat(g_coreSharedMemId, NULL, 0);
	if (g_coreSharedData == (CoreSharedData *) - 1) {
		fprintf(stderr, "Unable to attach the shared memory: %s",
			strerror(errno));
		return FALSE;
	}

	logger_set_node_id(g_coreSharedData->macAddr,
			   g_coreSharedData->netAddr);
	log_info("Mac address: %d, net address: %d",
		 (int)g_coreSharedData->macAddr,
		 (int)g_coreSharedData->netAddr);

	g_running = TRUE;

	return TRUE;
}

#ifdef __GNUC__
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"
#endif
int main(int argc, char **argv)
{
	atexit(clean_up);
	signal(SIGINT, signal_handler);

	if (!parse_arguments(argc, argv)) {
		print_usage(argv[0]);
		return EXIT_FAILURE;
	}

	if (!init())
		return EXIT_FAILURE;

	g_mainLoop = g_main_loop_new(NULL, TRUE);

	if (!g_thread_supported())
		g_thread_init(NULL);

	if (!load_config(g_configFileName)) {
		fprintf(stderr, "Error while loading g_config file (%s).\n",
			g_configFileName);
		exit(EXIT_FAILURE);
	}

	log_config();
	initVariables();

	GThread *helloHandlingThread =
	    g_thread_create(helloHandler, NULL, TRUE, NULL);

	if (helloHandlingThread == NULL)
		exit(EXIT_FAILURE);

	initTimers();
	g_io_add_watch(channel, G_IO_IN | G_IO_HUP | G_IO_ERR, data_ready,
		       NULL);
	g_main_loop_run(g_mainLoop);
	g_thread_join(helloHandlingThread);
	exit(EXIT_SUCCESS);
}
#ifdef __GNUC__
#pragma GCC diagnostic pop
#endif

/**
 * This function is triggered when there is data in the connection to the core module.
 *
 * @param source UNUSED
 * @param condition UNUSED
 * @param data UNUSED
 * @retval FALSE if errors occur and there is no need to monitor the stream.
 * @retval TRUE indicates keeping monitoring the stream.
 */
gboolean data_ready(GIOChannel * source, GIOCondition condition, gpointer data)
{
	char buffer[IMSG_MAX_DATA_LENGTH];
	InternalMessageHeader dataHeader;

	memset(buffer, 0, IMSG_MAX_DATA_LENGTH);//add,2018-8-31
	memset(&dataHeader, 0, sizeof(InternalMessageHeader));//add 2018-8-31

	int nBytesRead = client_read(g_connFd, buffer, IMSG_MAX_DATA_LENGTH,
				     &dataHeader, NULL, 0);
	if (nBytesRead == -1) {
		log_error("System error occurred");
		return FALSE;
	}

	if (nBytesRead == -2) {
		log_warning("Data was not successfully received");
	} else if (nBytesRead == 0) {
		logInfo("Connection closed by the core module");
		return FALSE;
	}

	PduBuff *pbuf = (PduBuff *) buffer;
	if (from_upper_layer(dataHeader))
	{
		/*add by yuansong 2018-5-25*/
		log_info("Debug######Receive data from Sealinx-tra in data_ready!!!");
		/*this branch is  for debug!*/
		if (pbuf->msg_len > 0){
			char dstr[10];
			memset(dstr, 0, sizeof(dstr));
			dstr[9] = '\0';
			memcpy(dstr, pbuf->pkt_data, 9);
			log_info("Debug #######Printf data string from Sealinx-tra in data_ready :%s", dstr);
		}
		else
			log_info("Debug ######This Data ought to be control packet, msg_len=%d, control ID=%d", 
			        pbuf->msg_len, GetControlMacro(&(pbuf->hdr_tra)));

		/*add by yuansong 2018-5-23*/
		if (GET_DROUTE_TABLE_REQ == GetControlMacro(&(pbuf->hdr_tra))){
		    /*process get route table command. 2018-5-4*/
		    log_info("Receive control info from Sealinx-tra, control ID is GET_DROUTE_TABLE_REQ");
		 	DealwithGetTableReq();
		}
		else if (GET_MODEN_DISTANCE_REQ == GetControlMacro(&(pbuf->hdr_tra))){
		    log_info("Receive control info from Sealinx-tra, control ID is GET_MODEN_DISTANCE_REQ");
			DealwithToMACCtrlMsg(pbuf);
		}
		else{
		     /*add by yuansong 2018-5-25*/
			log_info("----------Begin print recieved data from TRA in function data_ready!----------");
			printTRAHeaderInfo(&pbuf->hdr_tra);
			printNETHeaderInfo(&pbuf->hdr_net);
			PrintfPDUbuff(pbuf->pkt_data,pbuf->msg_len);
			log_info("----------End print recieved data from TRA in function data_ready!----------");			
		
			processOutgoingPacket(pbuf);
		}
	}
	else if (from_lower_layer(dataHeader))
	{
		/*add by yuansong for contol msg from MAC 2018-5-27*/
		if (GET_MODEN_DISTANCE_IND == GetControlMacro(&(pbuf->hdr_tra))){
			log_info("Receive control info from Sealinx-sfama, control ID is GET_MODEN_DISTANCE_IND");
			DealwithFromMACCtrlMsg(pbuf);
		}
		else{
			log_info("##########Begin print recieved data from MAC in function data_ready!#########");
			printTRAHeaderInfo(&pbuf->hdr_tra);
			printNETHeaderInfo(&pbuf->hdr_net);
			PrintfPDUbuff(pbuf->pkt_data,pbuf->msg_len);
			log_info("##########End print recieved data from MAC in function data_ready!#########");
		
			processIncomingPacket(pbuf);
		}
	}
	else
		logError("Unrecognized packet.");

	return TRUE;
}

/**
 * Signal handler.
 * @param sig Signal ID.
 */
void signal_handler(int sig)
{
	int type = 0;
	log_info("Received signal (%d)", sig);

	g_running = FALSE;

	/*g_source_remove(g_sendHelloTimer);
	   g_source_remove(g_changeTimer); */

	if (g_connFd > -1) {
		client_close(type, g_connFd, NULL, 0);
		g_connFd = -1;
	}
}

void clean_up(void)
{
	int type = 0;
	log_info("Cleaning up ...");

	if (g_connFd > -1)
		client_close(type, g_connFd, NULL, 0);

	int rc = shmdt(g_coreSharedData);
	if (rc == -1)
		log_error("Unable to detach shared data: %s", strerror(errno));

	dealloc_resources();
	close_logger();
}

gboolean load_config(const char *fileName)
{
	gboolean result = FALSE;
	GKeyFile *keyfile = g_key_file_new();

	gboolean canOpen =
	    g_key_file_load_from_file(keyfile, fileName, G_KEY_FILE_NONE, NULL);

	if (canOpen) {
		result = TRUE;
		g_config = g_new(DRConfig, sizeof(DRConfig));
		g_config->stableHelloPeriod =
		    g_key_file_get_integer(keyfile, PROTOCOL_PARAMS_GROUP,
					   STABLE_HELLO_PERIOD_KEY, NULL);
		g_config->unstableHelloPeriod =
		    g_key_file_get_integer(keyfile, PROTOCOL_PARAMS_GROUP,
					   UNSTABLE_HELLO_PERIOD_KEY, NULL);
		g_config->entryTimeout =
		    g_key_file_get_integer(keyfile, PROTOCOL_PARAMS_GROUP,
					   ENTRY_TIMEOUT_KEY, NULL);
		g_config->numRoutingEntries =
		    g_key_file_get_integer(keyfile, PROTOCOL_PARAMS_GROUP,
					   NUM_ROUTING_ENTRIES_KEY, NULL);
		g_config->minUpdateWait =
		    g_key_file_get_integer(keyfile, PROTOCOL_PARAMS_GROUP,
					   MIN_UPDATE_WAIT_KEY, NULL);
		g_config->maxUpdateWait =
		    g_key_file_get_integer(keyfile, PROTOCOL_PARAMS_GROUP,
					   MAX_UPDATE_WAIT_KEY, NULL);
	}
	g_key_file_free(keyfile);
	return result;
}

/**
 * Logs module configurations.
 */
void log_config(void)
{
	logInfo(">> Begin parameters");
	logInfo("%s = %d", STABLE_HELLO_PERIOD_KEY,
		g_config->stableHelloPeriod);
	logInfo("%s = %d", UNSTABLE_HELLO_PERIOD_KEY,
		g_config->unstableHelloPeriod);
	logInfo("%s = %d", ENTRY_TIMEOUT_KEY, g_config->entryTimeout);
	logInfo("%s = %d", NUM_ROUTING_ENTRIES_KEY,
		g_config->numRoutingEntries);
	logInfo("%s = %d", MIN_UPDATE_WAIT_KEY, g_config->minUpdateWait);
	logInfo("%s = %d", MAX_UPDATE_WAIT_KEY, g_config->maxUpdateWait);
	logInfo(">> End parameters");
}

#ifdef __GNUC__
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"
#endif
void initVariables()
{
	tag = 0;
	g_randGen = g_rand_new();
	g_lrtLock = g_mutex_new();
	neighborTimeoutLock = g_mutex_new();
	g_pendingHelloQueue = g_async_queue_new();

	g_localRoutingTable = g_sequence_new(free_lre);
	LocalRoutingEntry *current =
	    init_lre(g_coreSharedData->netAddr, g_coreSharedData->netAddr, 0);
	g_sequence_insert_sorted(g_localRoutingTable, current, compare_lre, NULL);

	g_aliveNeighborTimers = g_sequence_new(free_ant);
	NeighborTimeout *nt = g_new(NeighborTimeout, 1);
	nt->neighbor = g_coreSharedData->netAddr;
	nt->timerId = 0;
    g_sequence_insert_sorted(g_aliveNeighborTimers, nt, neighborTimeoutCmp, NULL);
	
	channel = g_io_channel_unix_new(g_connFd);
}
#ifdef __GNUC__
#pragma GCC diagnostic pop
#endif

/**
 * Deallocate resources used by the module.
 */
#ifdef __GNUC__
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wdeprecated-declarations"
#endif
void dealloc_resources(void)
{
	if (g_randGen)
		g_rand_free(g_randGen);
	if (channel)
		g_io_channel_shutdown(channel, TRUE, NULL);
	if (neighborTimeoutLock)
		g_mutex_free(neighborTimeoutLock);
	if (g_lrtLock)
		g_mutex_free(g_lrtLock);
	if (g_pendingHelloQueue)
		g_async_queue_unref(g_pendingHelloQueue);
	if (g_localRoutingTable)
		g_sequence_free(g_localRoutingTable);
	if (g_aliveNeighborTimers)
		g_sequence_free(g_aliveNeighborTimers);
	if (g_config)
		g_free(g_config);
}
#ifdef __GNUC__
#pragma GCC diagnostic pop
#endif

/**
 * This callback function is activated after the local routing table is
 * updated.
 *
 * @param data UNUSED
 * @return (always) FALSE because this is not a repeated event.
 */
gboolean updateCallback(gpointer data)
{
	logInfo("Table updated, notifying neighbors.");
	sendHello(NULL);

	g_changeTimer = 0;
	return FALSE;
}

/**
 * Main function of the thread handling HELLO messages from remote nodes.
 *
 * @param data UNUSED
 */
void *helloHandler(void *data)
{
	while (g_running) {
		RoutingTable *rt =
		    (RoutingTable *) g_async_queue_try_pop(g_pendingHelloQueue);
		if (rt == NULL) {
			if (!g_main_loop_is_running(g_mainLoop))
				g_thread_exit(NULL);
			continue;
		}

		gboolean changed = processRemoteRoutingTable(rt);
		if (changed) {
			if (numUnchanges >= MAX_NUM_UNCHANGES) {
				logInfo
				    ("%s Switch HELLO period to unstable mode",
				     __PRETTY_FUNCTION__);
				g_source_remove(g_sendHelloTimer);
				g_sendHelloTimer =
				    g_timeout_add_seconds(g_config->
							  unstableHelloPeriod,
							  UnStableHello/*sendHello*/, NULL);/*modify by yuansong 2018-8-4*/
			}
			numUnchanges = 0;
			if (g_changeTimer == 0) {
				gint32 waitTime =
				    g_rand_int_range(g_randGen,
						     g_config->minUpdateWait,
						     g_config->maxUpdateWait);
				g_changeTimer =
				    g_timeout_add_seconds(waitTime,
							  updateCallback, NULL);
			}
		} else {
			numUnchanges++;

			/*modify by yuansong 2018-8-4 for debug route*/
			if (numUnchanges >= MAX_NUM_UNCHANGES/*numUnchanges == MAX_NUM_UNCHANGES*/) {
				logInfo("%s Switch HELLO period to stable mode",
					__PRETTY_FUNCTION__);
				g_source_remove(g_sendHelloTimer);
				g_sendHelloTimer =
				    g_timeout_add_seconds(g_config->
							  stableHelloPeriod,
							  StableHello/*sendHello*/, NULL);/*modify by yuansong 2018-8-4*/
			}
		}
		logInfo("%d times routing table unchanged consecutively",
			numUnchanges);
		g_free(rt);
	}
	g_main_loop_quit(g_mainLoop);
	return NULL;
}

void initTimers(void)
{
	logInfo("Initializing the timer to send HELLO.");
	gint32 waitTime =
	    g_rand_int_range(g_randGen, g_config->unstableHelloPeriod / 4,
			     g_config->unstableHelloPeriod);
	g_sendHelloTimer =
	    g_timeout_add_seconds(waitTime, sendFirstHello, NULL);
}



/*debug long time no hello packet for timeout, 2018-8-14*/
gboolean TimerSendHello(gpointer data)
{
	sendHello(NULL);
	log_info("enter into TimerSendHello function!\r\n");
	g_sendHelloTimer =
	    g_timeout_add_seconds(g_config->entryTimeout, StableHello, NULL);
	return FALSE;
}


gboolean sendFirstHello(gpointer data)
{
	sendHello(NULL);
	logInfo("%s Switch HELLO period to unstable mode", __PRETTY_FUNCTION__);
	g_sendHelloTimer =
	    g_timeout_add_seconds(g_config->unstableHelloPeriod, sendHello,
				  NULL);

    /*add by yuansong 2018-8-14 for long time no hello info*/
	g_sendHelloTimer = g_timeout_add_seconds(g_config->entryTimeout, TimerSendHello, NULL);
	
	return FALSE;
}



gboolean sendOneHello(gpointer data)
{
	logInfo("Preparing HELLO packet in sendOneHello\r\n.");
	PduBuff pbuf;
    uint8_t txmode = -1;

	memset(&pbuf, 0, sizeof(PduBuff));//add for setting 0 for buffer.2018-8-31.
	
	pbuf.hdr_net.src_addr = g_coreSharedData->netAddr;	/*g_config->netAddr; */
	pbuf.hdr_net.dst_addr = NET_BROADCAST_ADDR;
	pbuf.hdr_net.next_hop = NET_BROADCAST_ADDR;
	pbuf.hdr_net.net_type = g_moduleId;
	ProtocolInfo *pi = (ProtocolInfo *) pbuf.hdr_net.net_data;
	pi->pktType = NET_PKT_HELLO;
	pbuf.hdr_net.hdr_len =
	    sizeof(pbuf.hdr_net) - sizeof(pbuf.hdr_net.net_data) +
	    sizeof(ProtocolInfo);
	/*pbuf.hdr_tra.hdr_len = 0; *//*del by yuansong 2018-7-25*/
	
    /*add by yuansong 2018-7-25 for txmode and route info*/
	pbuf.hdr_tra.hdr_len      = sizeof(pbuf.hdr_tra)-sizeof(pbuf.hdr_tra.tra_data) + sizeof(int) +sizeof(char);
	pbuf.hdr_tra.tra_type     = g_moduleId + 1;
	pbuf.hdr_tra.service_type = g_moduleId + 2;
	txmode = HELLO_PK_TXMODE;
	memcpy(pbuf.hdr_tra.tra_data+sizeof(int), &txmode, sizeof(uint8_t));
    /*add by yuansong 2018-7-25 for txmode and route info*/
	
	g_mutex_lock(g_lrtLock);
	pbuf.msg_len = prepareSentRoutingTable(pbuf.pkt_data);
	g_mutex_unlock(g_lrtLock);
	namHop(g_coreSharedData->netAddr, pbuf.hdr_net.next_hop,
	       calcActualSize(&pbuf));
	//dispatchMessage(&pbuf);

	logSend(PKT_CONTROL, 
	        pbuf.hdr_net.src_addr, 
	        pbuf.hdr_net.dst_addr,
		    calcActualSize(&pbuf), 
		    "HELLO");
	log_info("*****Begin printf Hello pkt, in sendOneHello*****");
	printTRAHeaderInfo(&(pbuf.hdr_tra));
	printNETHeaderInfo(&(pbuf.hdr_net));
	log_info("*****End printf Hello pkt, in sendOneHello*****");
	client_send_down(g_connFd, &pbuf, PDU_SIZE(pbuf.msg_len), g_moduleId,
			 NULL, 0);
	return FALSE;
}

gboolean sendHello(gpointer data)
{

	/*add by yuansong for test , close hello pkt send 2018-6-7*/
	#if 1/*open by yuansong 2018-6-20*/
	logInfo("Preparing HELLO packet in sendHello.");
	PduBuff pbuf;
    uint8_t txmode = -1;/*dd by yuansong 2018-7-25*/

	memset(&pbuf, 0, sizeof(PduBuff));/*dd for setting 0 for buffer.2018-8-31.*/
	
	pbuf.hdr_net.src_addr = g_coreSharedData->netAddr;	/*g_config->netAddr; */
	pbuf.hdr_net.dst_addr = NET_BROADCAST_ADDR;
	pbuf.hdr_net.next_hop = NET_BROADCAST_ADDR;
	pbuf.hdr_net.net_type = g_moduleId;
	ProtocolInfo *pi = (ProtocolInfo *) pbuf.hdr_net.net_data;
	pi->pktType = NET_PKT_HELLO;
	pbuf.hdr_net.hdr_len =
	    sizeof(pbuf.hdr_net) - sizeof(pbuf.hdr_net.net_data) +
	    sizeof(ProtocolInfo);
	
	/*pbuf.hdr_tra.hdr_len = 0; */ /*del by yuansong 2018-7-25*/
    /*add by yuansong 2018-7-25 for txmode and route info*/
	pbuf.hdr_tra.hdr_len = sizeof(pbuf.hdr_tra)-sizeof(pbuf.hdr_tra.tra_data) + sizeof(int) +sizeof(char);
	pbuf.hdr_tra.tra_type = g_moduleId + 1;/*add 2018-8-31*/
	pbuf.hdr_tra.service_type = g_moduleId + 2;/*modify by yuansong 2018-8-31*/
	txmode = HELLO_PK_TXMODE;
	memcpy(pbuf.hdr_tra.tra_data+sizeof(int), &txmode, sizeof(uint8_t));
	
	g_mutex_lock(g_lrtLock);
	pbuf.msg_len = prepareSentRoutingTable(pbuf.pkt_data);
	g_mutex_unlock(g_lrtLock);
	namHop(g_coreSharedData->netAddr, pbuf.hdr_net.next_hop,
	       calcActualSize(&pbuf));
	//dispatchMessage(&pbuf);

	log_info("msg_len = %d, sizeof(ProtocolInfo) = %d", pbuf.msg_len,
		 sizeof(ProtocolInfo));
	logSend(PKT_CONTROL, pbuf.hdr_net.src_addr, pbuf.hdr_net.dst_addr,
		calcActualSize(&pbuf), "HELLO");

    log_info("-----Begin printf Hello pkt, in sendHello-----");
	printTRAHeaderInfo(&(pbuf.hdr_tra));
	printNETHeaderInfo(&(pbuf.hdr_net));
	log_info("-----End printf Hello pkt, in sendHello-----");
    	
	int errCode =
	    client_send_down(g_connFd, &pbuf, PDU_SIZE(pbuf.msg_len),
			     g_moduleId, NULL, 0);
	if (errCode == -1)	/* system error */
		return FALSE;
	#endif

	return TRUE;
}

int prepareSentRoutingTable(void *dest)
{
	logInfo("Computing routing table to send.");
	HelloPayload *payload = (HelloPayload *) dest;
	int vectorLen = 0;
	uint8_t *rVec = payload->routingVectors;

	GSequenceIter *iter = g_sequence_get_begin_iter(g_localRoutingTable);
	logInfo(">> Begin advertised routes");
	while (!g_sequence_iter_is_end(iter)) {
		LocalRoutingEntry *lre =
		    (LocalRoutingEntry *) g_sequence_get(iter);
		if (lre->dest != g_coreSharedData->netAddr) {
			rVec[vectorLen++] = lre->dest;
			int vlensaved = vectorLen;
			rVec[vectorLen++] = lre->numHops;
			if (lre->numHops > 1)
				rVec[vectorLen++] = lre->nextHop;

			if (lre->numHops > 2) {
				g_memmove(rVec + vectorLen, lre->relays,
					  lre->numHops - 2);
				vectorLen += lre->numHops - 2;
			}
			char line[100];
			int n = sprintf(line, "dest = %d, path = ", lre->dest);
			int nhops = rVec[vlensaved++], i;
			for (i = 0; i < nhops - 1; i++)
				n += sprintf(line + n, "%d-",
					     rVec[vlensaved + i]);
			logInfo("%s", line);
		}
		iter = g_sequence_iter_next(iter);
	}
	logInfo(">> End advertised routes");

	payload->vectorLen = vectorLen;
	payload->crc = sl_crc32((char *)payload->routingVectors, vectorLen);
	/*log_info("vectorLen = %d, CRX = %x", vectorLen, payload->crc); */

	return vectorLen + sizeof(payload->vectorLen) + sizeof(payload->crc);
}

void processOutgoingPacket(PduBuff * pbuf)
{
	/*add broadcast function by yuansong 2018-5-31 modify*/
	int nextHop = 0;

	if (pbuf->hdr_net.dst_addr == NET_BROADCAST_ADDR)
		nextHop = NET_BROADCAST_ADDR;
	else{
	    nextHop = findNextHop(pbuf->hdr_net.dst_addr);
		if (-1 == nextHop){
			log_info("debug send data pkt can't get next hop value print route tabler");
			printRoutingTable();
			namDrop(g_coreSharedData->netAddr, pbuf->hdr_net.next_hop);
			logDrop(PKT_DATA, 
			        pbuf->hdr_net.src_addr,
			        pbuf->hdr_net.dst_addr,
			        calcActualSize(pbuf),
			        "unreachable destination");
			return;
		}
	}/*modify by yuansong 2018-5-31 for broadcast.*/
	
	/*printf("Next hop = %d\n", nextHop);*/
	pbuf->hdr_net.next_hop = nextHop;
	pbuf->hdr_net.net_type = g_moduleId;
	ProtocolInfo *pi = (ProtocolInfo *) pbuf->hdr_net.net_data;
	pi->pktType = NET_PKT_DATA;
	pbuf->hdr_net.hdr_len = sizeof(pbuf->hdr_net) -
	    sizeof(pbuf->hdr_net.net_data) + sizeof(ProtocolInfo);
	logSend(PKT_DATA, pbuf->hdr_net.src_addr, pbuf->hdr_net.dst_addr,
		calcActualSize(pbuf), "");
	//dispatchMessage(pbuf);
	client_send_down(g_connFd, pbuf, PDU_SIZE(pbuf->msg_len), g_moduleId,
			 NULL, 0);
}

void processIncomingPacket(PduBuff * pbuf)
{
	if (pbuf->hdr_net.net_type != g_moduleId) {
		log_error("Packet not for dynamic routing");
		return;
	} else {
		log_info("Processing incoming message");
	}

	ProtocolInfo *pi = (ProtocolInfo *) pbuf->hdr_net.net_data;
	switch (pi->pktType) {
	case NET_PKT_DATA:
		/*add by yuansong 2018-5-19 for get distance for modes.*/
		if (*((int*)pbuf->hdr_tra.tra_data) == GET_MODEN_DISTANCE_IND)
            client_send_up(g_connFd, pbuf, PDU_SIZE(pbuf->msg_len), g_moduleId, NULL, 0);

		/*add by yuansong 2018-5-7 for broadcast data.*/
		if (pbuf->hdr_mac.dst_addr == MAC_BROADCAST_ADDR){
			pbuf->hdr_net.dst_addr = NET_BROADCAST_ADDR;/*add by yuansong 2018-5-9*/
			client_send_up(g_connFd, pbuf, PDU_SIZE(pbuf->msg_len), g_moduleId, NULL, 0);
		}
		else
			processIncomingDataPacket(pbuf);
		
		break;
	case NET_PKT_HELLO:
		processHelloPacket(pbuf);
		break;
	}
}

void processIncomingDataPacket(PduBuff * pbuf)
{
	if (pbuf->hdr_net.next_hop == pbuf->hdr_net.dst_addr) {
		if (pbuf->hdr_net.dst_addr != g_coreSharedData->netAddr) {
			namDrop(pbuf->hdr_net.src_addr,
				g_coreSharedData->netAddr);
			logDrop(PKT_DATA, pbuf->hdr_net.src_addr,
				pbuf->hdr_net.dst_addr, calcActualSize(pbuf),
				"not for me");
			return;
		}
		logReceive(PKT_DATA, pbuf->hdr_net.src_addr,
			   pbuf->hdr_net.dst_addr, calcActualSize(pbuf), "");
		namReceive(pbuf->hdr_net.src_addr, pbuf->hdr_net.dst_addr,
			   calcActualSize(pbuf));
		client_send_up(g_connFd, pbuf, PDU_SIZE(pbuf->msg_len),
			       g_moduleId, NULL, 0);
	} else if (pbuf->hdr_net.next_hop != g_coreSharedData->netAddr) {
		// packet not for me, ignore this packet
		logDrop(PKT_DATA, pbuf->hdr_net.src_addr,
			pbuf->hdr_net.dst_addr, calcActualSize(pbuf),
			"not selected as relay");
		namDrop(pbuf->hdr_net.src_addr, g_coreSharedData->netAddr);
	} else {
		int nextHop = findNextHop(pbuf->hdr_net.dst_addr);
		if (nextHop == -1) {
			namDrop(g_coreSharedData->netAddr, nextHop);
			logDrop(PKT_DATA, pbuf->hdr_net.src_addr,
				pbuf->hdr_net.dst_addr, calcActualSize(pbuf),
				"unreachable destination");
			return;
		}
		pbuf->hdr_net.next_hop = nextHop;
		logForward(PKT_DATA, pbuf->hdr_net.src_addr, nextHop,
			   pbuf->hdr_net.dst_addr, calcActualSize(pbuf), "");
		namHop(g_coreSharedData->netAddr, nextHop,
		       calcActualSize(pbuf));
		client_send_down(g_connFd, pbuf, PDU_SIZE(pbuf->msg_len),
				 g_moduleId, NULL, 0);
	}
	//dispatchMessage(pbuf);
}

void processHelloPacket(PduBuff * pbuf)
{
	logReceive(PKT_CONTROL, pbuf->hdr_net.src_addr, pbuf->hdr_net.dst_addr,
		   calcActualSize(pbuf), "HELLO packet");
	namReceive(pbuf->hdr_net.src_addr, pbuf->hdr_net.dst_addr,
		   calcActualSize(pbuf));

	/*log_info("msg_len = %d", pbuf->msg_len); */
	HelloPayload *payload = (HelloPayload *) pbuf->pkt_data;
	uint32_t crc =
	    sl_crc32((char *)payload->routingVectors, payload->vectorLen);
	/*log_info("vectorLen = %d, CRX = %x", payload->vectorLen, crc); */
	if (crc != payload->crc) {
		namDrop(pbuf->hdr_net.src_addr, pbuf->hdr_net.dst_addr);
		logDrop(PKT_CONTROL, pbuf->hdr_net.src_addr,
			pbuf->hdr_net.dst_addr, calcActualSize(pbuf),
			"HELLO packet dropped, CRC mismatch (%x != %x).", crc,
			payload->crc);
		return;
	}

	RoutingTable *newRT =
	    (RoutingTable *) g_malloc(sizeof(RoutingTable) +
				      payload->vectorLen);
	newRT->from = pbuf->hdr_net.src_addr;
	newRT->vectorLen = payload->vectorLen;
	g_memmove(newRT->rtVector, payload->routingVectors, payload->vectorLen);
	g_async_queue_push(g_pendingHelloQueue, newRT);
}

gint neighborTimeoutCmp(gconstpointer a, gconstpointer b, gpointer userData)
{
	NeighborTimeout *nt1 = (NeighborTimeout *) a;
	NeighborTimeout *nt2 = (NeighborTimeout *) b;
	if (nt1->neighbor > nt2->neighbor)
		return 1;
	else if (nt1->neighbor < nt2->neighbor)
		return -1;
	else
		return 0;
}

gboolean processRemoteRoutingTable(RoutingTable * rt)
{
	gboolean changed = FALSE;
	g_mutex_lock(neighborTimeoutLock);
	NeighborTimeout nt;
	nt.neighbor = rt->from;
	GSequenceIter *iter =
	    g_sequence_search(g_aliveNeighborTimers, &nt, neighborTimeoutCmp,
			      NULL);
	GSequenceIter *iter1 = g_sequence_iter_prev(iter);

	NeighborTimeout *nt1 = (NeighborTimeout *) g_sequence_get(iter1);
	if (nt1->neighbor == rt->from) {
		g_source_remove(nt1->timerId);
	} else {
		nt1 = g_new(NeighborTimeout, 1);
		nt1->neighbor = rt->from;
		iter1 = g_sequence_insert_before(iter, nt1);
	}
	nt1->timerId =
	    g_timeout_add_seconds(g_config->entryTimeout,
				  alive_neighbor_timeout, iter1);
	g_mutex_unlock(neighborTimeoutLock);

	logInfo("process routing table from node %d", rt->from);
	int i;
	LocalRoutingEntry sampleRE;
	//logger(DR_LOG_NAME, "begin processRemoteRoutingTable");
	if (rt->from == g_coreSharedData->netAddr) {
		logWarning("remote address equals local address");
		return FALSE;
	}

	g_mutex_lock(g_lrtLock);
	tag++;
	// create a route to the neighbor node
	sampleRE.dest = rt->from;
	iter =
	    g_sequence_search(g_localRoutingTable, &sampleRE, compare_lre,
			      NULL);
	iter1 = iter;
	iter = g_sequence_iter_prev(iter);
	LocalRoutingEntry *lre = g_sequence_get(iter);

	if (lre->dest != rt->from) {
		lre = init_lre(rt->from, rt->from, 1);
		g_sequence_insert_before(iter1, lre);
		changed = TRUE;
	} else if (lre->numHops > 1) {
		lre->numHops = 1;
		lre->nextHop = rt->from;
		if (lre->relays) {
			g_free(lre->relays);
			lre->relays = NULL;
		}
		changed = TRUE;
	}
	lre->tag = tag;

	i = 0;
	while (i < rt->vectorLen) {
		uint8_t dest = rt->rtVector[i++];
		if (i >= rt->vectorLen)
			break;

		uint8_t numHops = rt->rtVector[i++];

		int j;
		gboolean loop = (dest == g_coreSharedData->netAddr);
		// checking if the route already includes this node.
		for (j = 0; j < numHops - 1 && !loop; j++) {
			if (i + j >= rt->vectorLen) {
				logWarning("corrupted remote routing table");
				return changed;
			}
			uint8_t node = rt->rtVector[i + j];
			loop = (node == g_coreSharedData->netAddr);
		}
		if (loop) {
			i += (numHops - 1);
			continue;
		}
		sampleRE.dest = dest;
		GSequenceIter *iter = g_sequence_search(g_localRoutingTable,
							&sampleRE, compare_lre,
							NULL), *iter1 = iter;
		iter = g_sequence_iter_prev(iter);
		LocalRoutingEntry *lre = g_sequence_get(iter);

		if (lre->dest != dest) {
			lre = init_lre(dest, 0, MAX_HOP_COUNT);
			g_sequence_insert_before(iter1, lre);
			changed = TRUE;
		}
		if (lre->numHops > numHops + 1) {
			lre->numHops = numHops + 1;
			lre->nextHop = rt->from;
			if (lre->relays)
				g_free(lre->relays);
			lre->relays = g_memdup(rt->rtVector + i, numHops - 1);
			changed = TRUE;
		}
		lre->tag = tag;
		i += (numHops - 1);
	}

	iter = g_sequence_get_begin_iter(g_localRoutingTable);
	while (!g_sequence_iter_is_end(iter)) {
		LocalRoutingEntry *lre =
		    (LocalRoutingEntry *) g_sequence_get(iter);
		iter1 = iter;
		iter = g_sequence_iter_next(iter);
		if (lre->tag != tag && lre->nextHop == rt->from) {
			g_sequence_remove(iter1);
			changed = TRUE;
		}
	}
	g_mutex_unlock(g_lrtLock);
    log_info("Print route info in processRemoteRoutingTable\r\n");
	printRoutingTable();

	if (changed) {
		nt1->numRecvHellos = 0;
	} else {
		nt1->numRecvHellos++;
		logInfo("received %d updates from %d", nt1->numRecvHellos,
			nt1->neighbor);
		if (nt1->numRecvHellos > 3 * MAX_NUM_UNCHANGES) {
			if (g_rand_boolean(g_randGen)) {
				logInfo
				    ("received too many unnecessary updates from %d, send back a HELLO",
				     nt1->neighbor);
				gint32 waitTime =
				    g_rand_int_range(g_randGen,
						     g_config->minUpdateWait,
						     g_config->maxUpdateWait);
				g_sendHelloTimer =
				    g_timeout_add_seconds(waitTime,
							  sendOneHello, NULL);
				nt1->numRecvHellos = 0;
			}
		}
	}
	return changed;
}

/**
 * Removes all routes whose next hop is specified by nextHop.
 *
 * @param nextHop Address of a neighboring node.
 */
void remove_routes(int nextHop)
{
	GSequenceIter *iter = g_sequence_get_begin_iter(g_localRoutingTable);
	GSequenceIter *iter1;
	while (!g_sequence_iter_is_end(iter)) {
		LocalRoutingEntry *lre =
		    (LocalRoutingEntry *) g_sequence_get(iter);
		iter1 = iter;
		iter = g_sequence_iter_next(iter);
		if (lre->nextHop == nextHop)
			g_sequence_remove(iter1);
	}
}

/**
 * This function is triggered when the local node does not receive any
 * update from a neighboring node.
 *
 * @param data the iterator in the timer list (g_aliveNeighborTimers).
 * @return (always) FALSE, meaning that this is triggered only once.
 */
gboolean alive_neighbor_timeout(gpointer data)
{
	GSequenceIter *iter = (GSequenceIter *) data;
	NeighborTimeout *nt = g_sequence_get(iter);

	logInfo("route to %d timed out", nt->neighbor);

	g_mutex_lock(g_lrtLock);
	#if 0
	if (nt->neighbor!=g_coreSharedData->netAddr)
	{
	    remove_routes(nt->neighbor);
	}//we no del owner route info, for ever. add by yuansong 2018-8-8
    #endif
    remove_routes(nt->neighbor);
	if (!g_changeTimer) {
		gint32 waitTime =
		    g_rand_int_range(g_randGen, g_config->minUpdateWait,
				     g_config->maxUpdateWait);
		g_changeTimer =
		    g_timeout_add_seconds(waitTime, updateCallback, NULL);
	}
	g_mutex_unlock(g_lrtLock);
	g_mutex_lock(neighborTimeoutLock);
	g_sequence_remove(iter);
	g_mutex_unlock(neighborTimeoutLock);
	log_info("route info timeout, remove it, left route info, in alive_neighbor_timeout\r\n");//add by yuansong 2018-7-17
	printRoutingTable();
	return FALSE;
}

int findNextHop(int dest)
{
	LocalRoutingEntry sampleRE;
	sampleRE.dest = dest;
	GSequenceIter *iter =
	    g_sequence_search(g_localRoutingTable, &sampleRE, compare_lre,
			      NULL);
	iter = g_sequence_iter_prev(iter);
	LocalRoutingEntry *lre = g_sequence_get(iter);

	if (lre->dest != dest) {
		return -1;
	} else {
		lre = g_sequence_get(iter);
		return lre->nextHop;
	}
}

uint64_t nowMs(void)
{
	struct timeval t;
	gettimeofday(&t, NULL);
	return timevalToMs(&t);
}

uint64_t timevalToMs(struct timeval * t)
{
	return t->tv_sec * 1000 + t->tv_usec / 1000;
}

void printRoutingTable(void)
{
	logInfo("--- Begin Routing Table ---");
	GSequenceIter *iter = g_sequence_get_begin_iter(g_localRoutingTable);
	logInfo("Dest | Next | Count");
	while (!g_sequence_iter_is_end(iter)) {
		LocalRoutingEntry *lre =
		    (LocalRoutingEntry *) g_sequence_get(iter);
		logInfo("%4d | %4d | %5d", lre->dest, lre->nextHop,
			lre->numHops);
		iter = g_sequence_iter_next(iter);
	}
	logInfo("--- End Routing Table ---");
}

int calcActualSize(PduBuff * buf)
{
	int size = buf->msg_len + buf->hdr_tra.hdr_len + buf->hdr_net.hdr_len;
	return size;
}
