#ifndef _SEALINX_PROTOCOLS_COMMON_H
#define _SEALINX_PROTOCOLS_COMMON_H


/******************业务数据类型******************/

#define SEALINX_BTYPE_DATA_TRANSPARENCY        		1
#define SEALINX_BTYPE_ASK_PLATFORM_DATA    			2


/******************业务数据类型  ******************/


/*****************************pdubuff data struct****************************/
/**=======NET==============**/
typedef struct
{
	uint8_t  retrans_flag;			//是否需要重传
	uint8_t  auto_manual_flag;		//自动或手动
	uint32_t time_stamp;			//时间戳
} __attribute__ ((__packed__))net_data_struct;


/**=======mac==============**/
typedef struct
{
	uint32_t pkt_seq;	  /**包序号**/
}__attribute__ ((__packed__))mac_data_struct;


/**=======tran==============**/

typedef struct {
	uint8_t appUnpack; /* unpack: 1, not unpack: 0 */
	uint8_t traUnpack; /* unpack: 1, not unpack: 0 */
} __attribute__ ((__packed__)) TraInfo;

/*****************************pdubuff data struct****************************/


#endif /* _SEALINX_PROTOCOLS_COMMON_H */
