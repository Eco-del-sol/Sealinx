/**
 * Copyright 2008, 2009, 2010, 2011, 2012, 2013 by AquaSeNT LLC
 * All rights reserved. Proprietary property of AquaSeNT LLC.
 *
 * Constant rate sender.
 *
 * @author yibo, james, son
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/un.h>
#include <unistd.h>
#include <sys/select.h>
#include <err.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>
#include <sys/shm.h>
#include <sys/time.h>
#include <math.h>

#include <sealinx.h>
#include <sealinx_system.h>
#include <sealinx_common.h>
#include <sealinx_imsg.h>
#include <sealinx_shmem.h>


//////////add by command mode client 2018-7-9/////////////////

#include<stdlib.h> 
#include<stdio.h> 
#include<string.h> 
#include<sys/types.h> 
#include<netinet/in.h> 
#include<netdb.h> 
#include<sys/socket.h> 
#include<sys/wait.h> 
#include<arpa/inet.h> 
///////////////////////////////////////////////////////////





/**
 * Default log identity for this module.
 */
#define DEFAULT_LOG_ID "CBR_SENDER"

/**
 * Default path to the folder consisting log files.
 */
#define DEFAULT_LOG_FOLDER "logs/"

/** Log identity for this module. */
char * gLogId = DEFAULT_LOG_ID;

/** Path to the folder consisting of log files. */
char * gLogFolder = DEFAULT_LOG_FOLDER;

/** File descriptor of the connection to the core. */
int g_connFd;

/** ID of the current module. */
ModuleId g_moduleId;

/** ID of the MAC module. */
ModuleId g_macId;

/** ID of the network module. */
ModuleId g_netId;

/** ID of the transport module. */
ModuleId g_transId;

/**
 * Shared data by the core module.
 */
CoreSharedData *g_coreSharedData;

int g_coreSharedMemId;

int g_running;

/** Data length. */
int g_dataLength;

/** Data rate. */
float g_dataRate;

/** Destination node. */
int g_destNode;

/** Log file output flag (by default, there will be a log file). */
int gLogFile = 1;




////////////////////////////add test function for develop by yuansong 2018-5-21///////////////////////////


/*get route tabel command macro, add by yuansong 2018-5-2*/

#define ERROR_CONTROL_MACRO    0x0

#define GET_DROUTE_TABLE_REQ   0x01

#define GET_DROUTE_TABLE_IND   0x02

#define GET_MODEN_DISTANCE_REQ 0x03

#define GET_MODEN_DISTANCE_IND 0x04

#define CMD_FROM_CENTRE        0x05


////////////////////////////////////////////////////////


/*2018-11-26 for SGS project, by yuan song*/
#define TRANSMIT_DATA_REQ 20

#define TRANSMIT_DATA_RSP 21

#define TRANSMIT_DATA_END 22
/////////////////////////////////////////////



#define PAYLOAD_SIZE 100

int MakeSendDataPacket()
{
	int i = 0;
	char buff[IMSG_MAX_DATA_LENGTH];

	memset(buff, 0,IMSG_MAX_DATA_LENGTH);

	PduBuff *pdu = (PduBuff*)buff;

	uint8_t txmode = -1;

	for (i=0; i<PAYLOAD_SIZE; i++)
	{
		if (i%2 == 0)
		{
			pdu->pkt_data[i] = 'C';
		}
		else
		{
			pdu->pkt_data[i] = 'D';
		}
	}

	pdu->hdr_net.src_addr = g_coreSharedData->netAddr;
	pdu->hdr_net.dst_addr = g_destNode;

	pdu->msg_len = PAYLOAD_SIZE;

	pdu->hdr_tra.hdr_len = sizeof(pdu->hdr_tra)-sizeof(pdu->hdr_tra.tra_data) + sizeof(int) +sizeof(char);
	pdu->hdr_tra.service_type = g_moduleId;

	txmode = 1;
	//*(pdu->hdr_tra.tra_data+sizeof(int)) =  5;//set user txmode for test.

	memcpy(pdu->hdr_tra.tra_data+sizeof(int), &txmode, sizeof(uint8_t));

	client_send_down(g_connFd, pdu, PDU_SIZE(PAYLOAD_SIZE), g_moduleId, NULL, 0);

	log_info("APP-CBR Send test data  in MakeSendDataPacket########\r\n");

	return 1;
}


int testcompile(int ctrl)
{

	typedef struct teststruct {
		/** Actual length of the whole header. */
			uint8_t hdr_len;
		/** ID of transport layer protocols. */
			uint8_t tra_type;
		/** Types of transport layer services. */
			uint8_t service_type;
		/** Extra data to the transport layer. */
			char tra_data[MAX_HEADER_SIZE_TRA - MIN_LENGTH_TRANS_HEADER];
	}/* __attribute__ ((__packed__)) */teststrcut;

	
	typedef struct packedstruct {
		/** Actual length of the whole header. */
			uint8_t hdr_len;
		/** ID of transport layer protocols. */
			uint8_t tra_type;
		/** Types of transport layer services. */
			uint8_t service_type;
		/** Extra data to the transport layer. */
			char tra_data[MAX_HEADER_SIZE_TRA - MIN_LENGTH_TRANS_HEADER];
	} __attribute__ ((__packed__)) packedstruct;



	teststrcut   test;
	packedstruct pack;

	char cc;
	cc = ctrl;
	int tmp = ctrl;
	int exdata = 0;
	memcpy(test.tra_data, &tmp, sizeof(int));

	memcpy(&exdata,test.tra_data, sizeof(int));

	log_info("APP-CBR test compile, tmp=%d, exdata=%d\r\n", tmp, exdata);
	

	*(test.tra_data) = cc;
	*(pack.tra_data) = cc;

	log_info("APP-CBR debug compile error,nopacked=%d, packed=%d, ctrl=%d, cc=%d in testcompile\r\n",*(int*)(test.tra_data),*(int*)(pack.tra_data), ctrl, cc);

	return 1;
}



int SendControlPacket(int ctrl)
{
	int  tmp = 0;
	char buff[IMSG_MAX_DATA_LENGTH];

	memset(buff, 0,IMSG_MAX_DATA_LENGTH);

	PduBuff *pdu = (PduBuff*)buff;

	pdu->msg_len = 0;

	pdu->hdr_net.src_addr = g_coreSharedData->netAddr;
	pdu->hdr_net.dst_addr = g_destNode;

	pdu->hdr_tra.hdr_len      = sizeof(TransportHeader)-sizeof(pdu->hdr_tra.tra_data)+sizeof(int)+sizeof(char);/*control id:sizeof(int), txmode:sizeof(char)*///add by yuansong
	pdu->hdr_tra.service_type = g_moduleId;
	tmp = ctrl;
	memcpy(pdu->hdr_tra.tra_data, &tmp, sizeof(int));

	//len  = MAX_HEADER_SIZE_TRA - MIN_LENGTH_TRANS_HEADER;
	log_info("APP-CBR send control msg ID=%d, hdr_tra.hdr_len=%d\r\n", ctrl, pdu->hdr_tra.hdr_len);

	client_send_down(g_connFd, pdu, PDU_SIZE(0), g_moduleId, NULL, 0);
	return 1;
}




int MakeSendBroadcastPacket()
{
	int i = 0;
	char buff[IMSG_MAX_DATA_LENGTH];

	memset(buff, 0,IMSG_MAX_DATA_LENGTH);

	PduBuff *pdu = (PduBuff*)buff;

	for (i=0; i<PAYLOAD_SIZE; i++)
	{
		if (i%2 == 0)
		{
			pdu->pkt_data[i] = '3';
		}
		else
		{
			pdu->pkt_data[i] = '4';
		}
	}

	pdu->hdr_net.src_addr = g_coreSharedData->netAddr;
	pdu->hdr_net.dst_addr = NET_BROADCAST_ADDR;

	pdu->msg_len = PAYLOAD_SIZE;

	pdu->hdr_tra.hdr_len = sizeof(pdu->hdr_tra)-sizeof(pdu->hdr_tra.tra_data) + sizeof(int) +sizeof(char);
	pdu->hdr_tra.service_type = g_moduleId;
	*(pdu->hdr_tra.tra_data+sizeof(int)) =  1;//set user txmode for test.

	client_send_down(g_connFd, pdu, PDU_SIZE(PAYLOAD_SIZE), g_moduleId, NULL, 0);

	log_info("APP-CBR Send broad data  in MakeSendDataPacket########\r\n");

	return 1;
}

#define APP_NET_MAX_HOPS 10

typedef struct _RouteInfo
{
	int     numHops;
	uint8_t dest;
	uint8_t nextHop;
	uint8_t relays[APP_NET_MAX_HOPS];
	uint8_t tag;
}RouteInfo;

void printRouteInfo(PduBuff *prt)
{
	uint16_t offset = 0;
	RouteInfo ri;
	memset(&ri, 0, sizeof(RouteInfo));

	if (prt->msg_len == 0)
	{
		log_info("No route info in control pkt!########\r\n");
		return;
	}

	log_info("--- Begin Routing Table ---");
	log_info("Dest | Next | Count");
	while (prt->msg_len > offset+1)//ought to add 1.
	{
		memcpy(&(ri.numHops), prt->pkt_data + offset, sizeof(int));
		offset += sizeof(int);
		memcpy(&(ri.dest), prt->pkt_data + offset, sizeof(uint8_t));
		offset += sizeof(uint8_t);
		memcpy(&(ri.nextHop), prt->pkt_data + offset, sizeof(uint8_t));
		offset += sizeof(uint8_t);
		if (ri.numHops > 2)
		{
			memcpy(&(ri.relays), prt->pkt_data + offset, sizeof(uint8_t)*(ri.numHops-2));
			offset += sizeof(uint8_t)*(ri.numHops-2);
		}
		memcpy(&(ri.tag), prt->pkt_data + offset, sizeof(uint8_t));
		offset += sizeof(uint8_t);

		log_info("%4d | %4d | %5d", ri.dest, ri.nextHop, ri.numHops);
		memset(&ri, 0, sizeof(RouteInfo));

	}
	log_info("--- End Routing Table ---");

}



typedef struct _Distance
{
	uint8_t macadrr;
	int     distance;
}Distance;

static int counter = 0;

void printDistance(PduBuff *pds)
{
	uint16_t offset=0;
	Distance dis;

	memset(&dis, 0, sizeof(Distance));

	if (pds->msg_len == 0)
	{
		log_info("No distance info now!!!!!!\r\n");
		return;
	}

	log_info("--------begin print distance info----------\r\n");
    log_info("Dest  |  Distance ");
	while (pds->msg_len > offset)
	{
		memcpy(&(dis.macadrr), pds->pkt_data+offset, sizeof(uint8_t));
		offset += sizeof(uint8_t);
		memcpy(&(dis.distance), pds->pkt_data+offset, sizeof(int));
		offset += sizeof(int);
		log_info("%4d  |  %5d\r\n",dis.macadrr, dis.distance);
		memset(&dis, 0, sizeof(Distance));
	}

	log_info("--------End print distance for modens-----\r\n");

	counter++;
	log_info("Debug print distance counter = %d#####\r\n", counter);
	
}



#define MAX_SIZE 100
#define TIMER_LONG 10

int flag;/*0:idle, 1:busy*/

char cmd[MAX_SIZE];

void process_timer_func(int para)
{
	flag = 0;
	memset(cmd, 0, MAX_SIZE);
}


/*add by yuansong for auv APP layer*/
int RecvCmdFromCenter(PduBuff *pbuff)
{
    char tmp_cmd[MAX_SIZE];
    /*
      inspect var that flag
	*/
	memset(tmp_cmd, 0, MAX_SIZE);

	if (0 == pbuff->msg_len)
	{
		log_info("Received a error command that length is zero in RecvCmdFromCenter\r\n");
		return 0;/*error command*/
	}
	if (flag)
	{
        memcpy(tmp_cmd, pbuff->pkt_data, pbuff->msg_len);
 		tmp_cmd[pbuff->msg_len] = '\0';
		if (strcmp(tmp_cmd, cmd))
		{
		    log_info("receive a repeat command from centre in RecvCmdFromCenter!\r\n");
			return 1;
		}

		alarm(0);/*cancel alarm*/

		memset(cmd, 0, MAX_SIZE);
		strcpy(cmd, tmp_cmd);
		/*restart alarm*/
		signal(SIGALRM, process_timer_func);
		alarm(TIMER_LONG);
		flag = 1;
		/*
		excute new command!
		*/ 
	}
	else
	{
		memcpy(cmd, pbuff->pkt_data, pbuff->msg_len);
		cmd[pbuff->msg_len] = '\0';
		signal(SIGALRM, process_timer_func);
		alarm(TIMER_LONG);
		flag = 1;/*I am in excute command status!*/
	}

	return 1;/*OK!*/
}





//////////////////////////////////add by yuansong for test 2018-7-6//////////////////////////////////////////////////////

void InputParam(int *sdtype, int *des, int *pksize, int *txmode, int *pkquantity)
{

	printf("*****Input send data parameters:**********\r\n");

	printf("Input send data type,[1--Ack, 2--Broadcast, 3--End:");
	scanf("%d", sdtype);

    printf("Input destinate address for sending data[A--except 99, B--99]:");
	scanf("%d", des);
	if (2==*sdtype && *des!=99)
	{
	    *des = 99;
	}

	printf("Input packet size:");
	scanf("%d", pksize);

	printf("Input tx mode[1~5]:");
	scanf("%d", txmode);	

	printf("Input quantity of sending packets:");
	scanf("%d", pkquantity);
}

 void SendComPkByPara(int des, int txmode, int pksize)
 {
	 int i = 0;
	 char buff[IMSG_MAX_DATA_LENGTH];
	 
	 memset(buff, 0,IMSG_MAX_DATA_LENGTH);
	 
	 PduBuff *pdu = (PduBuff*)buff;
	 
	 uint8_t mode = -1;
	 
	 for (i=0; i<pksize; i++)
	 {
		 if (i%2 == 0)
		 {
			 pdu->pkt_data[i] = 'C';
		 }
		 else
		 {
			 pdu->pkt_data[i] = 'D';
		 }
	 }
	 
	 pdu->hdr_net.src_addr     = g_coreSharedData->netAddr;
	 pdu->hdr_net.dst_addr     = des;
	 pdu->msg_len              = pksize;
	 pdu->hdr_tra.hdr_len      = sizeof(pdu->hdr_tra)-sizeof(pdu->hdr_tra.tra_data) + sizeof(int) +sizeof(char);
	 pdu->hdr_tra.service_type = g_moduleId;
	 
	 mode = txmode;
	 //*(pdu->hdr_tra.tra_data+sizeof(int)) =  5;//set user txmode for test.
	 
	 memcpy(pdu->hdr_tra.tra_data+sizeof(int), &mode, sizeof(uint8_t));
	 client_send_down(g_connFd, pdu, PDU_SIZE(pksize), g_moduleId, NULL, 0);
	 log_info("Send data to %d mode, pksize=%d, txmode=%d in SendComPkByPara\r\n", des, pksize, txmode);

 }

 void SendBroadcastPkByPara(int txmode, int pksize)
 {

 	int i = 0;
 	char buff[IMSG_MAX_DATA_LENGTH];
 
	memset(buff, 0,IMSG_MAX_DATA_LENGTH);
 
 	PduBuff *pdu = (PduBuff*)buff;

	uint8_t mode = -1;
 
 	for (i=0; i<pksize; i++)
 	{
		 if (i%2 == 0)
	 	{
			 pdu->pkt_data[i] = '3';
	 	}
	 	else
	 	{
			 pdu->pkt_data[i] = '4';
	 	}
 	}
 
 	pdu->hdr_net.src_addr = g_coreSharedData->netAddr;
 	pdu->hdr_net.dst_addr = NET_BROADCAST_ADDR;
 
	 pdu->msg_len = pksize;
 
 	pdu->hdr_tra.hdr_len = sizeof(pdu->hdr_tra)-sizeof(pdu->hdr_tra.tra_data) + sizeof(int) +sizeof(char);
 	pdu->hdr_tra.service_type = g_moduleId;

	mode = txmode;
	memcpy(pdu->hdr_tra.tra_data+sizeof(int), &mode, sizeof(uint8_t));
 	//*(pdu->hdr_tra.tra_data+sizeof(int)) =  1;//set user txmode for test.
 
 	client_send_down(g_connFd, pdu, PDU_SIZE(PAYLOAD_SIZE), g_moduleId, NULL, 0);
	log_info("Send Broadcast data, pksize=%d, txmode=%d in SendBroadcastPkByPara\r\n",pksize, txmode);

}


#if 1
void* SendByVarParams(void *param)
{
    #define MAX_RECVBUF_LEN 30
	int  des        = 0;
	int  sdtype     = 1;
	int  pksize     = 1;
	int  pkquantity = 1;
	int  txmode     = 1;
	int  i          = 0;
	int  offset     = 0;
    int  recvID     = 0;


    int  sockListen; 
    char recvbuf[MAX_RECVBUF_LEN] = {'\0'}; 
    int  recvbytes; 

	
    if((sockListen = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
    { 
        printf("socket fail\n"); 
        return NULL; 
    } 
    int set = 1; 
    setsockopt(sockListen, SOL_SOCKET, SO_REUSEADDR, &set, sizeof(int)); 
    struct sockaddr_in recvAddr; 
    memset(&recvAddr, 0, sizeof(struct sockaddr_in)); 
    recvAddr.sin_family = AF_INET; 
    recvAddr.sin_port = htons(3001); 
    recvAddr.sin_addr.s_addr = INADDR_ANY; 

    if(bind(sockListen, (struct sockaddr *)&recvAddr, sizeof(struct sockaddr)) == -1){ 
        printf("bind fail\n"); 
        return NULL; 
    } 
    
	int  addrLen = sizeof(struct sockaddr_in);

    while (sdtype != 3)
    {
		memset(recvbuf, 0, MAX_RECVBUF_LEN);
        offset = 0;
		if((recvbytes = recvfrom(sockListen, &recvbuf, MAX_RECVBUF_LEN, 0, (struct sockaddr *)&recvAddr, &addrLen)) != -1)
		{ 
            memcpy(&recvID, recvbuf+offset, sizeof(int));
			offset += sizeof(int);
			if (recvID != g_coreSharedData->netAddr)
			{
				continue;
			}
		    
            memcpy(&sdtype, recvbuf+offset, sizeof(int));
			offset += sizeof(int);
			if (3 == sdtype)
			{
			    continue;
			}

			memcpy(&des, recvbuf+offset, sizeof(int));
     		offset += sizeof(int);

			memcpy(&pksize, recvbuf+offset, sizeof(int));
			offset += sizeof(int);
			
			memcpy(&txmode, recvbuf+offset, sizeof(int));
			offset += sizeof(int);
			
			memcpy(&pkquantity, recvbuf+offset,sizeof(int));
			log_info("Recieved data from server: sdtype:=%d, des=%d, pksize=%d, txmode=%d, pkquantity=%d\r\n",sdtype, des, pksize, txmode, pkquantity);
		}
		else
		{ 
			printf("recvfrom fail\n");
			sdtype = 3;//end sending data behave.
            continue;
		}
		
	    InputParam(&sdtype, &des, &pksize, &txmode, &pkquantity);
	    log_info("User input parameter:sdtype=%d, des=%d, pksize=%d, txmode=%d, pkquantity=%d\r\n",sdtype, des, pksize, txmode, pkquantity);

		i = pkquantity;
		while (i != 0)
		{
			if (1 == sdtype)
			{
				SendComPkByPara(des,txmode,pksize);
			}
			else if (2 == sdtype)
			{
				SendBroadcastPkByPara(txmode, pksize);
			}
			else
			{
				log_info("Input TYPE=%c of send data is error in function SendByVarParams########\r\n", sdtype);
				return NULL;
			}
			i--;
			sleep(1);
		}

	}

    close(sockListen); 
    return NULL;	
}
#endif


#if 0
void SendByVarParams(void *param)
{
    #define MAX_RECVBUF_LEN 30
	int  des        = 0;
	int  sdtype     = 1;
	int  pksize     = 1;
	int  pkquantity = 1;
	int  txmode     = 1;
	int  i          = 0;
    char recvbuf[MAX_RECVBUF_LEN] = {'\0'}; 

    while (sdtype != 3)
    {
	    InputParam(&sdtype, &des, &pksize, &txmode, &pkquantity);
	    log_info("User input parameter:sdtype=%d, des=%d, pksize=%d, txmode=%d, pkquantity=%d\r\n",sdtype, des, pksize, txmode, pkquantity);

		i = pkquantity;
		while (i != 0)
		{
			if (1 == sdtype)
			{
				SendComPkByPara(des,txmode,pksize);
			}
			else if (2 == sdtype)
			{
				SendBroadcastPkByPara(txmode, pksize);
			}
			else
			{
				log_info("Input TYPE=%c of send data is error in function SendByVarParams########\r\n", sdtype);
				return;
			}
			i--;
			sleep(1);
		}

	}

    return;	
}
#endif

//////////////////////////////////add by yuansong for test 2018-7-6//////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void* TestFuncForAuvModem(void *param)
{
    #define MAX_RECVBUF_LEN 30
	int  ctrl       = 1;
	int  offset     = 0;
    int  recvID     = 0;
    int  sockListen; 
    char recvbuf[MAX_RECVBUF_LEN] = {'\0'}; 
    int  recvbytes; 

	
    if((sockListen = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
    { 
        printf("socket fail\n"); 
        return NULL; 
    } 
    int set = 1; 
    setsockopt(sockListen, SOL_SOCKET, SO_REUSEADDR, &set, sizeof(int)); 
    struct sockaddr_in recvAddr; 
    memset(&recvAddr, 0, sizeof(struct sockaddr_in)); 
    recvAddr.sin_family = AF_INET; 
    recvAddr.sin_port = htons(3001); 
    recvAddr.sin_addr.s_addr = INADDR_ANY; 

    if(bind(sockListen, (struct sockaddr *)&recvAddr, sizeof(struct sockaddr)) == -1){ 
        printf("bind fail\n"); 
        return NULL; 
    } 
    
	int  addrLen = sizeof(struct sockaddr_in);

    while (ctrl != 0)
    {
		memset(recvbuf, 0, MAX_RECVBUF_LEN);
        offset = 0;
		if((recvbytes = recvfrom(sockListen, &recvbuf, MAX_RECVBUF_LEN, 0, (struct sockaddr *)&recvAddr, &addrLen)) != -1)
		{ 
            memcpy(&recvID, recvbuf+offset, sizeof(int));
			offset += sizeof(int);
			if (recvID != g_coreSharedData->netAddr)
			{
				continue;
			}
		    
            memcpy(&ctrl, recvbuf+offset, sizeof(int));
			offset += sizeof(int);
			if (0 == ctrl)
			{
			    continue;
			}

			log_info("Recieved control data from server: recvID:=%d, ctrl=%d\r\n", recvID, ctrl);
		}
		else
		{ 
			printf("recvfrom fail\n");
			ctrl = 3;//end sending data behave.
            continue;
		}
		
		if (1 == ctrl)
		{
			SendControlPacket(TRANSMIT_DATA_REQ);
		}
		else if (2 == ctrl)
		{
		    MakeSendDataPacket();
		}
		else if (3 == ctrl)
		{
		    SendControlPacket(TRANSMIT_DATA_END);
		}
		else
		{
			log_info("Input control command id=%c of control AUV activity is error in function TestFuncForAuvModem########\r\n", ctrl);
			return NULL;
		}

	}

    close(sockListen); 
    return NULL;	
}


/*auto test for AUV modem*/
void* AutoTestFuncForAuvModem(void *param)
{
    int i = 0;

	sleep(30*g_coreSharedData->netAddr);		
    while(1)
    {
		SendControlPacket(TRANSMIT_DATA_REQ);
	    sleep(50);
		for(i=0; i<5; i++)
		{
			sleep(1);
	    	MakeSendDataPacket();
		}
		sleep(100);	
	    SendControlPacket(TRANSMIT_DATA_END);
	    sleep(30*g_coreSharedData->netAddr);
	}
}



/*copy from sealinx-droute.h, by yuansong 2018-11-30*/
typedef struct {
    /** Packet type. */
	uint8_t pktType;
} __attribute__ ((__packed__)) ProtocolInfo;

#define NET_PKT_CTRL_CMD 102


void SendCmdByBS(int des)
{
	int i = 0;
	char buff[IMSG_MAX_DATA_LENGTH];
	
	memset(buff, 0,IMSG_MAX_DATA_LENGTH);
	
	PduBuff *pdu = (PduBuff*)buff;
	ProtocolInfo *pi = (ProtocolInfo *)pdu->hdr_net.net_data;
	
	uint8_t mode = -1;
	
	for (i=0; i<5; i++)
	{
		if (i%2 == 0)
		{
			pdu->pkt_data[i] = 'C';
		}
		else
		{
			pdu->pkt_data[i] = 'D';
		}
	}
	
	pdu->hdr_net.src_addr	  = g_coreSharedData->netAddr;
	pdu->hdr_net.dst_addr	  = des;
	pi->pktType = NET_PKT_CTRL_CMD;
	pdu->hdr_net.hdr_len =
	    sizeof(pdu->hdr_net) - sizeof(pdu->hdr_net.net_data) +
	    sizeof(ProtocolInfo);

	pdu->msg_len			  = 5;
	pdu->hdr_tra.hdr_len	  = sizeof(pdu->hdr_tra)-sizeof(pdu->hdr_tra.tra_data) + sizeof(int) +sizeof(char);
	pdu->hdr_tra.service_type = g_moduleId;
	
	mode = 1;
	//*(pdu->hdr_tra.tra_data+sizeof(int)) =  5;//set user txmode for test.	
	memcpy(pdu->hdr_tra.tra_data+sizeof(int), &mode, sizeof(uint8_t));
	client_send_down(g_connFd, pdu, PDU_SIZE(pdu->msg_len), g_moduleId, NULL, 0);
}

void* TestFuncForBSModem(void *param)
{
    #define MAX_RECVBUF_LEN 30
	int  ctrl       = 1;
	int  offset     = 0;
    int  recvID     = 0;
    int  sockListen; 
    char recvbuf[MAX_RECVBUF_LEN] = {'\0'}; 
    int  recvbytes; 

	
    if((sockListen = socket(AF_INET, SOCK_DGRAM, 0)) == -1)
    { 
        printf("socket fail\n"); 
        return NULL; 
    } 
    int set = 1; 
    setsockopt(sockListen, SOL_SOCKET, SO_REUSEADDR, &set, sizeof(int)); 
    struct sockaddr_in recvAddr; 
    memset(&recvAddr, 0, sizeof(struct sockaddr_in)); 
    recvAddr.sin_family = AF_INET; 
    recvAddr.sin_port = htons(3001); 
    recvAddr.sin_addr.s_addr = INADDR_ANY; 

    if(bind(sockListen, (struct sockaddr *)&recvAddr, sizeof(struct sockaddr)) == -1){ 
        printf("bind fail\n"); 
        return NULL; 
    } 
    
	int  addrLen = sizeof(struct sockaddr_in);

    while (ctrl != 0)
    {
		memset(recvbuf, 0, MAX_RECVBUF_LEN);
        offset = 0;
		if((recvbytes = recvfrom(sockListen, &recvbuf, MAX_RECVBUF_LEN, 0, (struct sockaddr *)&recvAddr, &addrLen)) != -1)
		{ 
            memcpy(&recvID, recvbuf+offset, sizeof(int));
			offset += sizeof(int);
			if (recvID != g_coreSharedData->netAddr)
			{
				continue;
			}
		    
            memcpy(&ctrl, recvbuf+offset, sizeof(int));
			offset += sizeof(int);
			if (0 == ctrl)
			{
			    continue;
			}

			log_info("Recieved control data from server: recvID:=%d, ctrl=%d\r\n", recvID, ctrl);
		}
		else
		{ 
			printf("recvfrom fail\n");
			ctrl = 3;//end sending data behave.
            continue;
		}
		
        SendCmdByBS(ctrl);
	}

    close(sockListen); 
    return NULL;	
}


/*auto test for BS modem*/
void* AuotTestFuncForBSModem(void *param)
{
	sleep(50*g_coreSharedData->netAddr);
	while (1)
	{
        SendCmdByBS(199);
		sleep(300);
		SendCmdByBS(2);
		sleep(100);
		SendCmdByBS(3);
		sleep(100);
	    SendCmdByBS(4);
		sleep(50*g_coreSharedData->netAddr);
	}
}


//////////////add by yuansong for AUV test, 2018-11-30//////////////////////////////////////










void *TestSender(void *param)
{

	#define MAX_NUM 10
	#define MAX_B_NUM 20
	
	int i = 0;
	int j = 0;
	log_info("APP-CBR Enter into TestSender function!######\r\n");
	sleep(10);

	#if 0
	for (i=0; i<MAX_NUM; i++)
	{
		MakeSendDataPacket();
		sleep(1);
	}
    #endif

	#if 1
	for (i=0; i<MAX_B_NUM; i++)
	{
    	MakeSendBroadcastPacket();
		sleep(1);
	}

	//sleep(20);

    //MakeSendBroadcastPacket();
	
    #endif
	
	SendControlPacket(GET_DROUTE_TABLE_REQ);

	//testcompile(GET_DROUTE_TABLE_REQ);

	sleep(100);
		
	SendControlPacket(GET_MODEN_DISTANCE_REQ);

	return NULL;
}


int PrintRecvCtrlPkt(PduBuff *pbuff)
{
	int tmp = 0;

	memcpy( &tmp, pbuff->hdr_tra.tra_data, sizeof(int));

	log_info("#Control packet's control ID = %d######", tmp);

	if (GET_DROUTE_TABLE_IND == tmp)
	{

		printRouteInfo(pbuff);
	}
	
	if(GET_MODEN_DISTANCE_IND == tmp)
	{
		printDistance(pbuff);
	}

	if (CMD_FROM_CENTRE == tmp)
	{
       //process command from center
       RecvCmdFromCenter(pbuff);
	}
	return 1;
}





/**
 * Parse command line arguments.
 *
 * @param argc Number of arguments
 * @param argv The arguments
 * @return TRUE if the argument can be parse; FALSE, otherwise.
 */
int parse_arguments(int argc, char ** argv) {
    int i = 0;
    g_destNode = -1;
    while (i < argc) {
        char * t = argv[i];
        if (strcmp(t, "-i") == 0) {
            i++;
            if (i < argc) {
                int moduleId = strtol(argv[i], NULL, 10);
                if (moduleId > MAX_MODULE_ID || moduleId < MIN_MODULE_ID) {
                    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
                    return FALSE;
                }
                g_moduleId = moduleId;
            }
        } else if (strcmp(t, "-m") == 0) {
            i++;
            if (i < argc) {
                int macId = strtol(argv[i], NULL, 10);
                if (macId > MAX_MODULE_ID || macId < MIN_MODULE_ID) {
                    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
                    return FALSE;
                }
                g_macId = macId;
            }
        } else if (strcmp(t, "-n") == 0) {
            i++;
            if (i < argc) {
                int netId = strtol(argv[i], NULL, 10);
                if (netId > MAX_MODULE_ID || netId < MIN_MODULE_ID) {
                    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
                    return FALSE;
                }
                g_netId = netId;
            }
        } else if (strcmp(t, "-t") == 0) {
            i++;
            if (i < argc) {
                int transId = strtol(argv[i], NULL, 10);
                if (transId > MAX_MODULE_ID || transId < MIN_MODULE_ID) {
                    fprintf(stderr, "Invalid module ID (%s)\n", argv[i]);
                    return FALSE;
                }
                g_transId = transId;
            }
        } else if (strcmp(t, "-l") == 0) {
            i++;
            if (i < argc) {
                g_dataLength = strtol(argv[i], NULL, 10);
                if (g_dataLength <= 0) {
                    log_error("No data will be sent: invalid data length (%d)",
                            g_dataLength);
                    g_dataLength = 0;
                } else if (g_dataLength > IMSG_MAX_DATA_LENGTH) {
                    log_error("Only %d bytes in each chunk be sent",
                            IMSG_MAX_DATA_LENGTH);
                    g_dataLength = IMSG_MAX_DATA_LENGTH;
                }
            }
        } else if (strcmp(t, "-r") == 0) {
            i++;
            if (i < argc) {
                g_dataRate = atof(argv[i]);
                if (g_dataRate <= 0) {
                    log_error("No data will be sent: invalid data rate (%f)",
                            g_dataRate);
                    g_dataRate = 0;
                } else if (g_dataRate > 1) {
                    log_warning("Data rate (%f) is too high",
                            g_dataRate);
                }
            }
        } else if (strcmp(t, "-d") == 0) {
            i++;
            if (i < argc) {
                g_destNode = strtol(argv[i], NULL, 10);
            }
        } else if (strcmp(t, "-f") == 0) {
	    i ++;
	    if (i < argc) {
		gLogFile = atoi(argv[i]);
	    }
	}
        i++;
    }
    return g_moduleId >= MIN_MODULE_ID && g_moduleId <= MAX_MODULE_ID &&
            g_macId >= MIN_MODULE_ID && g_macId <= MAX_MODULE_ID &&
            g_netId >= MIN_MODULE_ID && g_netId <= MAX_MODULE_ID &&
            g_transId >= MIN_MODULE_ID && g_transId <= MAX_MODULE_ID;
}

/**
 * Print the usage of the program.
 */
void print_usage(const char *progName) {
    printf("USAGE: %s -i <module id> -m <mac protocol id> -n <network protocol id> "
            "-t <transport protocol id> "
            "-l <data length> -r <data rate> -d <dest node> [-f <log file outoput flag>]\n",
            progName);
}

/**
 * Initialize the program.
 */
int init(void) {
    int type = 0;
    ModuleId moduleIds[NUM_LAYERS];
    moduleIds[LAYER_MAC] = g_macId;
    moduleIds[LAYER_NETWORK] = g_netId;
    moduleIds[LAYER_TRANSPORT] = g_transId;
    moduleIds[LAYER_APPLICATION] = g_moduleId;

    g_running = TRUE;

    if (!init_logger(gLogFolder, gLogId, gLogFile, TRUE, moduleIds, 4)) {
        fprintf(stderr, "Unable to init the log module.");
        return FALSE;
    }

    RegistrationResponse serverResponse;

    g_connFd = client_connect(type, LAYER_APPLICATION, moduleIds, &serverResponse, NULL, 0);

    g_coreSharedMemId = serverResponse.coreShareMemId;

    log_info("Key of shared memory by the core: %d", g_coreSharedMemId);

    g_coreSharedData = (CoreSharedData *) shmat(g_coreSharedMemId, NULL, 0);
    if (g_coreSharedData == (CoreSharedData *) - 1) {
        fprintf(stderr, "Unable to attach the shared memory: %s",
                strerror(errno));
        return FALSE;
    }

    logger_set_node_id(g_coreSharedData->macAddr, g_coreSharedData->netAddr);
    log_info("Mac address: %d, net address: %d",
            (int) g_coreSharedData->macAddr, (int) g_coreSharedData->netAddr);

	/*add init command for auv, yuansong 2019-1-10 */
	flag = 0;
	memset(cmd, 0, MAX_SIZE);
	/*add init command for auv, yuansong 2019-1-10 */
	
    return TRUE;
}

/**
 * Signal handler.
 *
 * @param sig Signal ID.
 */
void signal_handler(int sig) {
    int type = 0;
    log_info("Received signal (%d)", sig);

    g_running = FALSE;

    if (g_connFd > -1) {
        client_close(type, g_connFd, NULL, 0);
        g_connFd = -1;
    }
}

/**
 * Clean up allocated resources.
 */
void clean_up(void) {
    int type = 0;
    log_info("Cleaning up ...");

    if (g_connFd > -1) {
        client_close(type, g_connFd, NULL, 0);
    }

    if (g_coreSharedData) {
        int rc = shmdt(g_coreSharedData);
        if (rc == -1) {
            log_error("Unable to detach shared data: %s", strerror(errno));
        }
    }

    close_logger();
}

void generateSampleString(char *str, int len) {
    int i;
    char *s = str;
    char x = 'a';
    for (i = 0; i < len; i++) {
        *s = x;
        s++;
        x++;
        if (x == 'z' + 1) {
            x = 'A';
        } else if (x == 'Z' + 1) {
            x = '0';
        } else if (x == '9' + 1) {
            x = 'a';
        }
    }
}

void *sender(void *param) {
    char buffer[IMSG_MAX_DATA_LENGTH];

    PduBuff *pbuf = (PduBuff *) buffer;

    int seqNum = 0;
    struct timeval start, end;
    char *dataToSend = (char *) malloc(sizeof (char) * g_dataLength);
    generateSampleString(dataToSend, g_dataLength);

    while (g_running) {
        gettimeofday(&start, NULL);

        char *data = pbuf->pkt_data;

        int idLen = sprintf(data, "[%hu][%hu][%d] ",
                g_coreSharedData->netAddr, g_destNode, seqNum);
        int nCharLeft = g_dataLength - idLen;
        int timeLen = get_timestring_sec(data + idLen,
                nCharLeft);
        nCharLeft -= timeLen;

        log_send(PKT_DATA, g_coreSharedData->netAddr, g_destNode,
                g_dataLength, "%s", data);

        memcpy(data + idLen + timeLen, dataToSend, nCharLeft);

        pbuf->hdr_net.src_addr = g_coreSharedData->netAddr;
        pbuf->hdr_net.dst_addr = g_destNode;

        pbuf->msg_len = g_dataLength;
        pbuf->hdr_tra.service_type = g_moduleId;
        client_send_down(g_connFd, pbuf, PDU_SIZE(g_dataLength),
                g_moduleId, NULL, 0);

        gettimeofday(&end, NULL);
        int timeDiff = end.tv_sec - start.tv_sec;
        seqNum++;

        int sleepTime = (int) ceil(1 / g_dataRate);
        log_info("Sleep for %d seconds", sleepTime);
        sleepTime -= timeDiff;
        if (sleepTime > 0) {
            sleep(sleepTime);
        }
    }
    free(dataToSend);

    return NULL;
}

void start_listener(void) {
    char buffer[IMSG_MAX_DATA_LENGTH];
    InternalMessageHeader dataHeader;

    PduBuff *pbuf = (PduBuff *) buffer;

    int totalDataSize = 0, nBytesRead;
    struct timeval start, now;
    gettimeofday(&start, NULL);

	log_info("###Enter int APP-CBR start_listener####\r\n");
    while (g_running)
	{
        nBytesRead = client_read(g_connFd, buffer, IMSG_MAX_DATA_LENGTH,
                &dataHeader, NULL, 0);

        if (nBytesRead == -1) {
            log_error("System error occurred");
            break;
        }

        if (nBytesRead == -2) {
            log_warning("Data was not successfully received");
            continue;
        }

        if (nBytesRead == 0) {
            logInfo("Connection closed by the core module");
            break;
        }

        if (from_lower_layer(dataHeader))
		{
			log_info("###APP-CBR Receive data from tra layer in start_listener####\r\n");

			if (pbuf->hdr_tra.hdr_len > 3)//add by yuansong 2018-5-31 for test object.
			{
				PrintRecvCtrlPkt(pbuf);
			}
			
            log_receive(PKT_DATA, pbuf->hdr_mac.src_addr,pbuf->hdr_mac.dst_addr, pbuf->msg_len,"DATA");
            totalDataSize += pbuf->msg_len;
            gettimeofday(&now, NULL);
            float time_diff = now.tv_sec - start.tv_sec;
            float throughput = (float) totalDataSize * 8 / time_diff;
            log_info("Throughput = %.2f bps", throughput);
        }
		else if (from_upper_layer(dataHeader))
		{
            log_warning("There is no layer higher than this one");
        }
		else
		{
            log_error("Packet state error");
            continue;
        }
    }
}

/**
 * Main program.
 *
 * @param argc Number of parameters.
 * @param argv Array of parameters.
 */
int main(int argc, char ** argv) {

	//log_info("Enter APP-CBR main function##############\r\n");///add by yuansong 2018-5-23
	atexit(clean_up);
    signal(SIGINT, signal_handler);
    if (!parse_arguments(argc, argv)) {
        print_usage(argv[0]);
        return EXIT_FAILURE;
    }
    if (!init()) {
        return EXIT_FAILURE;
    }
    int isSender = g_dataRate <= 0 || g_dataLength <= 0 || g_destNode <= -1;
	log_info("APP-CBR g_dataRate=%d, g_dataLengt=%d g_destNode=%d,####\r\n", g_dataRate, g_dataLength, g_destNode);
	log_info("APP-CBR Debug isSender = %d in man function########\r\n ", isSender);

	#if 1
    pthread_t sendThreadId;
    if (!isSender) //for old code
  	{
		log_info("Enter branch create sender thead follow in main function#######\r\n");///add by yuansong 2018-5-23
        int error = pthread_create(&sendThreadId, NULL, /*sender*//*TestSender*/SendByVarParams, NULL);
        if (error != 0)
		{
			log_info("Create sender thead failed!!!!!!!  in main function#######\r\n");///add by yuansong 2018-5-23
            log_error("Create sending thread: %s", strerror(error));
        }
    }
	else
	{
        log_info("Operate in listening mode");
    }
	#endif
    start_listener();

	#if 0
 	if (isSender)//for old code
	{
        pthread_join(sendThreadId, NULL);
    }
	#endif
    return EXIT_SUCCESS;
}

