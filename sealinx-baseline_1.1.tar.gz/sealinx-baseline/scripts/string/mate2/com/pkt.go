// Package com describes all the data structures runs in mate2
package com

import (
	"time"
)

// MaxDataLen limits by sealinx
const MaxDataLen int32 = 5120

// ModeLen ...
// Mode0 means default, process it as mode1
var ModeLen = []int32{38, 38, 80, 122, 164, 248}

// ModemPhyParams processed by modem
type ModemPhyParams struct {
	Dst        int32 // destnation modem Id
	Src        int32 // source modem Id
	Mode       int32 // communication mode in {1,2,3,4,5}
	Dtype      int32 // data type, 0: data message; 1: acoustic wave
	GuardTime  int32 // protection the acoustic wave between data blocks
	PowerLevel int32 // the wave power from 0(max) to 100
}

// AdpPkt contains the original infomation that gets from the socket
type AdpPkt struct {
	ModemPhyParams
	Length int32            // bytes of the data
	Data   [MaxDataLen]byte // the effective data in a packet
}

// ModemPkt contains the packet params processed by modem
type ModemPkt struct {
	Triggered bool          // packet triggered while recving
	False     bool          // packet error in data blocks
	Error     bool          // packet error in preamble
	TimeLen   time.Duration // time duration for date
	SendTime  int64         // tiemstamp(with nano) when send out the packet
	RecvTime  int64         // timestamp(with nano) when received the packet
}

// Packet processed in modem
type Packet struct {
	AdpPkt
	ModemPkt
}
